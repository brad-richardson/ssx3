#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_003B0FB8
// Address: 0x3b0fb8 - 0x3b10d0
void sub_003B0FB8_0x3b0fb8(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_003B0FB8_0x3b0fb8");
#endif

    switch (ctx->pc) {
        case 0x3b0fb8u: goto label_3b0fb8;
        case 0x3b0fbcu: goto label_3b0fbc;
        case 0x3b0fc0u: goto label_3b0fc0;
        case 0x3b0fc4u: goto label_3b0fc4;
        case 0x3b0fc8u: goto label_3b0fc8;
        case 0x3b0fccu: goto label_3b0fcc;
        case 0x3b0fd0u: goto label_3b0fd0;
        case 0x3b0fd4u: goto label_3b0fd4;
        case 0x3b0fd8u: goto label_3b0fd8;
        case 0x3b0fdcu: goto label_3b0fdc;
        case 0x3b0fe0u: goto label_3b0fe0;
        case 0x3b0fe4u: goto label_3b0fe4;
        case 0x3b0fe8u: goto label_3b0fe8;
        case 0x3b0fecu: goto label_3b0fec;
        case 0x3b0ff0u: goto label_3b0ff0;
        case 0x3b0ff4u: goto label_3b0ff4;
        case 0x3b0ff8u: goto label_3b0ff8;
        case 0x3b0ffcu: goto label_3b0ffc;
        case 0x3b1000u: goto label_3b1000;
        case 0x3b1004u: goto label_3b1004;
        case 0x3b1008u: goto label_3b1008;
        case 0x3b100cu: goto label_3b100c;
        case 0x3b1010u: goto label_3b1010;
        case 0x3b1014u: goto label_3b1014;
        case 0x3b1018u: goto label_3b1018;
        case 0x3b101cu: goto label_3b101c;
        case 0x3b1020u: goto label_3b1020;
        case 0x3b1024u: goto label_3b1024;
        case 0x3b1028u: goto label_3b1028;
        case 0x3b102cu: goto label_3b102c;
        case 0x3b1030u: goto label_3b1030;
        case 0x3b1034u: goto label_3b1034;
        case 0x3b1038u: goto label_3b1038;
        case 0x3b103cu: goto label_3b103c;
        case 0x3b1040u: goto label_3b1040;
        case 0x3b1044u: goto label_3b1044;
        case 0x3b1048u: goto label_3b1048;
        case 0x3b104cu: goto label_3b104c;
        case 0x3b1050u: goto label_3b1050;
        case 0x3b1054u: goto label_3b1054;
        case 0x3b1058u: goto label_3b1058;
        case 0x3b105cu: goto label_3b105c;
        case 0x3b1060u: goto label_3b1060;
        case 0x3b1064u: goto label_3b1064;
        case 0x3b1068u: goto label_3b1068;
        case 0x3b106cu: goto label_3b106c;
        case 0x3b1070u: goto label_3b1070;
        case 0x3b1074u: goto label_3b1074;
        case 0x3b1078u: goto label_3b1078;
        case 0x3b107cu: goto label_3b107c;
        case 0x3b1080u: goto label_3b1080;
        case 0x3b1084u: goto label_3b1084;
        case 0x3b1088u: goto label_3b1088;
        case 0x3b108cu: goto label_3b108c;
        case 0x3b1090u: goto label_3b1090;
        case 0x3b1094u: goto label_3b1094;
        case 0x3b1098u: goto label_3b1098;
        case 0x3b109cu: goto label_3b109c;
        case 0x3b10a0u: goto label_3b10a0;
        case 0x3b10a4u: goto label_3b10a4;
        case 0x3b10a8u: goto label_3b10a8;
        case 0x3b10acu: goto label_3b10ac;
        case 0x3b10b0u: goto label_3b10b0;
        case 0x3b10b4u: goto label_3b10b4;
        case 0x3b10b8u: goto label_3b10b8;
        case 0x3b10bcu: goto label_3b10bc;
        case 0x3b10c0u: goto label_3b10c0;
        case 0x3b10c4u: goto label_3b10c4;
        case 0x3b10c8u: goto label_3b10c8;
        case 0x3b10ccu: goto label_3b10cc;
        default: break;
    }

    ctx->pc = 0x3b0fb8u;

label_3b0fb8:
    // 0x3b0fb8: 0x27bdffd0  addiu       $sp, $sp, -0x30
    ctx->pc = 0x3b0fb8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967248));
label_3b0fbc:
    // 0x3b0fbc: 0x7fb00020  sq          $s0, 0x20($sp)
    ctx->pc = 0x3b0fbcu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 16));
label_3b0fc0:
    // 0x3b0fc0: 0x7fb10010  sq          $s1, 0x10($sp)
    ctx->pc = 0x3b0fc0u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 17));
label_3b0fc4:
    // 0x3b0fc4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x3b0fc4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_3b0fc8:
    // 0x3b0fc8: 0xc0ec434  jal         func_3B10D0
label_3b0fcc:
    if (ctx->pc == 0x3B0FCCu) {
        ctx->pc = 0x3B0FCCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0FC8u;
        // 0x3b0fcc: 0x80802d  daddu       $s0, $a0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0FD0u;
        goto label_3b0fd0;
    }
    ctx->pc = 0x3B0FC8u;
    SET_GPR_U32(ctx, 31, 0x3B0FD0u);
    ctx->pc = 0x3B0FCCu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0FC8u;
    // 0x3b0fcc: 0x80802d  daddu       $s0, $a0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3B10D0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3B10D0u, 0x3B0FC8u, 0x3B0FD0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0FD0u;
label_3b0fd0:
    // 0x3b0fd0: 0x40882d  daddu       $s1, $v0, $zero
    ctx->pc = 0x3b0fd0u;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_3b0fd4:
    // 0x3b0fd4: 0x8e250004  lw          $a1, 0x4($s1)
    ctx->pc = 0x3b0fd4u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 4)));
label_3b0fd8:
    // 0x3b0fd8: 0x8ca2000c  lw          $v0, 0xC($a1)
    ctx->pc = 0x3b0fd8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 12)));
label_3b0fdc:
    // 0x3b0fdc: 0x30421000  andi        $v0, $v0, 0x1000
    ctx->pc = 0x3b0fdcu;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)4096);
label_3b0fe0:
    // 0x3b0fe0: 0x50400003  beql        $v0, $zero, . + 4 + (0x3 << 2)
label_3b0fe4:
    if (ctx->pc == 0x3B0FE4u) {
        ctx->pc = 0x3B0FE4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0FE0u;
        // 0x3b0fe4: 0x24a50010  addiu       $a1, $a1, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0FE8u;
        goto label_3b0fe8;
    }
    ctx->pc = 0x3B0FE0u;
    {
        const bool branch_taken_0x3b0fe0 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x3b0fe0) {
            ctx->pc = 0x3B0FE4u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x3B0FE0u;
            // 0x3b0fe4: 0x24a50010  addiu       $a1, $a1, 0x10 (Delay Slot)
            SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 16));
            ctx->in_delay_slot = false;
            ctx->pc = 0x3B0FF0u;
            goto label_3b0ff0;
        }
    }
    ctx->pc = 0x3B0FE8u;
label_3b0fe8:
    // 0x3b0fe8: 0x8ca20010  lw          $v0, 0x10($a1)
    ctx->pc = 0x3b0fe8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 16)));
label_3b0fec:
    // 0x3b0fec: 0xa22821  addu        $a1, $a1, $v0
    ctx->pc = 0x3b0fecu;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 2)));
label_3b0ff0:
    // 0x3b0ff0: 0x8e040008  lw          $a0, 0x8($s0)
    ctx->pc = 0x3b0ff0u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 8)));
label_3b0ff4:
    // 0x3b0ff4: 0x2407ffff  addiu       $a3, $zero, -0x1
    ctx->pc = 0x3b0ff4u;
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
label_3b0ff8:
    // 0x3b0ff8: 0x8e06000c  lw          $a2, 0xC($s0)
    ctx->pc = 0x3b0ff8u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 12)));
label_3b0ffc:
    // 0x3b0ffc: 0xe4182a  slt         $v1, $a3, $a0
    ctx->pc = 0x3b0ffcu;
    SET_GPR_U64(ctx, 3, ((int64_t)GPR_S64(ctx, 7) < (int64_t)GPR_S64(ctx, 4)) ? 1 : 0);
label_3b1000:
    // 0x3b1000: 0x2482000f  addiu       $v0, $a0, 0xF
    ctx->pc = 0x3b1000u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 4), 15));
label_3b1004:
    // 0x3b1004: 0x83100b  movn        $v0, $a0, $v1
    ctx->pc = 0x3b1004u;
    if (GPR_U64(ctx, 3) != 0) SET_GPR_VEC(ctx, 2, GPR_VEC(ctx, 4));
label_3b1008:
    // 0x3b1008: 0x21103  sra         $v0, $v0, 4
    ctx->pc = 0x3b1008u;
    SET_GPR_S32(ctx, 2, SRA32(GPR_S32(ctx, 2), 4));
label_3b100c:
    // 0x3b100c: 0x26040030  addiu       $a0, $s0, 0x30
    ctx->pc = 0x3b100cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 48));
label_3b1010:
    // 0x3b1010: 0x461018  mult        $v0, $v0, $a2
    ctx->pc = 0x3b1010u;
    { int64_t result = (int64_t)GPR_S32(ctx, 2) * (int64_t)GPR_S32(ctx, 6); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 2, (int32_t)result); }
label_3b1014:
    // 0x3b1014: 0xe2382a  slt         $a3, $a3, $v0
    ctx->pc = 0x3b1014u;
    SET_GPR_U64(ctx, 7, ((int64_t)GPR_S64(ctx, 7) < (int64_t)GPR_S64(ctx, 2)) ? 1 : 0);
label_3b1018:
    // 0x3b1018: 0x2446000f  addiu       $a2, $v0, 0xF
    ctx->pc = 0x3b1018u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 2), 15));
label_3b101c:
    // 0x3b101c: 0x47300b  movn        $a2, $v0, $a3
    ctx->pc = 0x3b101cu;
    if (GPR_U64(ctx, 7) != 0) SET_GPR_VEC(ctx, 6, GPR_VEC(ctx, 2));
label_3b1020:
    // 0x3b1020: 0xc100a84  jal         func_402A10
label_3b1024:
    if (ctx->pc == 0x3B1024u) {
        ctx->pc = 0x3B1024u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B1020u;
        // 0x3b1024: 0x63103  sra         $a2, $a2, 4 (Delay Slot)
        SET_GPR_S32(ctx, 6, SRA32(GPR_S32(ctx, 6), 4));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B1028u;
        goto label_3b1028;
    }
    ctx->pc = 0x3B1020u;
    SET_GPR_U32(ctx, 31, 0x3B1028u);
    ctx->pc = 0x3B1024u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B1020u;
    // 0x3b1024: 0x63103  sra         $a2, $a2, 4 (Delay Slot)
    SET_GPR_S32(ctx, 6, SRA32(GPR_S32(ctx, 6), 4));
    ctx->in_delay_slot = false;
    ctx->pc = 0x402A10u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x402A10u, 0x3B1020u, 0x3B1028u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B1028u;
label_3b1028:
    // 0x3b1028: 0x8e030010  lw          $v1, 0x10($s0)
    ctx->pc = 0x3b1028u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 16)));
label_3b102c:
    // 0x3b102c: 0x220102d  daddu       $v0, $s1, $zero
    ctx->pc = 0x3b102cu;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_3b1030:
    // 0x3b1030: 0x7bb10010  lq          $s1, 0x10($sp)
    ctx->pc = 0x3b1030u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_3b1034:
    // 0x3b1034: 0x24630001  addiu       $v1, $v1, 0x1
    ctx->pc = 0x3b1034u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 1));
label_3b1038:
    // 0x3b1038: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x3b1038u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_3b103c:
    // 0x3b103c: 0xae030010  sw          $v1, 0x10($s0)
    ctx->pc = 0x3b103cu;
    WRITE32(ADD32(GPR_U32(ctx, 16), 16), GPR_U32(ctx, 3));
label_3b1040:
    // 0x3b1040: 0x7bb00020  lq          $s0, 0x20($sp)
    ctx->pc = 0x3b1040u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_3b1044:
    // 0x3b1044: 0x3e00008  jr          $ra
label_3b1048:
    if (ctx->pc == 0x3B1048u) {
        ctx->pc = 0x3B1048u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B1044u;
        // 0x3b1048: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B104Cu;
        goto label_3b104c;
    }
    ctx->pc = 0x3B1044u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3B1048u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B1044u;
        // 0x3b1048: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B1044u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3B104Cu;
label_3b104c:
    // 0x3b104c: 0x0  nop
    ctx->pc = 0x3b104cu;
    // NOP
label_3b1050:
    // 0x3b1050: 0x27bdffd0  addiu       $sp, $sp, -0x30
    ctx->pc = 0x3b1050u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967248));
label_3b1054:
    // 0x3b1054: 0x7fb10010  sq          $s1, 0x10($sp)
    ctx->pc = 0x3b1054u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 17));
label_3b1058:
    // 0x3b1058: 0x7fb00020  sq          $s0, 0x20($sp)
    ctx->pc = 0x3b1058u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 16));
label_3b105c:
    // 0x3b105c: 0xa0882d  daddu       $s1, $a1, $zero
    ctx->pc = 0x3b105cu;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_3b1060:
    // 0x3b1060: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x3b1060u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_3b1064:
    // 0x3b1064: 0x80802d  daddu       $s0, $a0, $zero
    ctx->pc = 0x3b1064u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_3b1068:
    // 0x3b1068: 0x282d  daddu       $a1, $zero, $zero
    ctx->pc = 0x3b1068u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_3b106c:
    // 0x3b106c: 0x0  nop
    ctx->pc = 0x3b106cu;
    // NOP
label_3b1070:
    // 0x3b1070: 0x10a00006  beqz        $a1, . + 4 + (0x6 << 2)
label_3b1074:
    if (ctx->pc == 0x3B1074u) {
        ctx->pc = 0x3B1078u;
        goto label_3b1078;
    }
    ctx->pc = 0x3B1070u;
    {
        const bool branch_taken_0x3b1070 = (GPR_U64(ctx, 5) == GPR_U64(ctx, 0));
        if (branch_taken_0x3b1070) {
            ctx->pc = 0x3B108Cu;
            goto label_3b108c;
        }
    }
    ctx->pc = 0x3B1078u;
label_3b1078:
    // 0x3b1078: 0x8e020000  lw          $v0, 0x0($s0)
    ctx->pc = 0x3b1078u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 0)));
label_3b107c:
    // 0x3b107c: 0x84440030  lh          $a0, 0x30($v0)
    ctx->pc = 0x3b107cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 48)));
label_3b1080:
    // 0x3b1080: 0x8c430034  lw          $v1, 0x34($v0)
    ctx->pc = 0x3b1080u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 52)));
label_3b1084:
    // 0x3b1084: 0x60f809  jalr        $v1
label_3b1088:
    if (ctx->pc == 0x3B1088u) {
        ctx->pc = 0x3B1088u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B1084u;
        // 0x3b1088: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B108Cu;
        goto label_3b108c;
    }
    ctx->pc = 0x3B1084u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x3B108Cu);
        ctx->pc = 0x3B1088u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B1084u;
        // 0x3b1088: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B1084u, 0x3B108Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x3B108Cu;
label_3b108c:
    // 0x3b108c: 0xc100ace  jal         func_402B38
label_3b1090:
    if (ctx->pc == 0x3B1090u) {
        ctx->pc = 0x3B1090u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B108Cu;
        // 0x3b1090: 0x26040030  addiu       $a0, $s0, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 48));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B1094u;
        goto label_3b1094;
    }
    ctx->pc = 0x3B108Cu;
    SET_GPR_U32(ctx, 31, 0x3B1094u);
    ctx->pc = 0x3B1090u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B108Cu;
    // 0x3b1090: 0x26040030  addiu       $a0, $s0, 0x30 (Delay Slot)
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 48));
    ctx->in_delay_slot = false;
    ctx->pc = 0x402B38u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x402B38u, 0x3B108Cu, 0x3B1094u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B1094u;
label_3b1094:
    // 0x3b1094: 0x14400009  bnez        $v0, . + 4 + (0x9 << 2)
label_3b1098:
    if (ctx->pc == 0x3B1098u) {
        ctx->pc = 0x3B1098u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B1094u;
        // 0x3b1098: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B109Cu;
        goto label_3b109c;
    }
    ctx->pc = 0x3B1094u;
    {
        const bool branch_taken_0x3b1094 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x3B1098u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B1094u;
        // 0x3b1098: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b1094) {
            ctx->pc = 0x3B10BCu;
            goto label_3b10bc;
        }
    }
    ctx->pc = 0x3B109Cu;
label_3b109c:
    // 0x3b109c: 0xc0ec3ee  jal         func_3B0FB8
label_3b10a0:
    if (ctx->pc == 0x3B10A0u) {
        ctx->pc = 0x3B10A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B109Cu;
        // 0x3b10a0: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B10A4u;
        goto label_3b10a4;
    }
    ctx->pc = 0x3B109Cu;
    SET_GPR_U32(ctx, 31, 0x3B10A4u);
    ctx->pc = 0x3B10A0u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B109Cu;
    // 0x3b10a0: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3B0FB8u;
    goto label_3b0fb8;
    ctx->pc = 0x3B10A4u;
label_3b10a4:
    // 0x3b10a4: 0x8e030010  lw          $v1, 0x10($s0)
    ctx->pc = 0x3b10a4u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 16)));
label_3b10a8:
    // 0x3b10a8: 0x71182b  sltu        $v1, $v1, $s1
    ctx->pc = 0x3b10a8u;
    SET_GPR_U64(ctx, 3, ((uint64_t)GPR_U64(ctx, 3) < (uint64_t)GPR_U64(ctx, 17)) ? 1 : 0);
label_3b10ac:
    // 0x3b10ac: 0x1460fff0  bnez        $v1, . + 4 + (-0x10 << 2)
label_3b10b0:
    if (ctx->pc == 0x3B10B0u) {
        ctx->pc = 0x3B10B0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B10ACu;
        // 0x3b10b0: 0x40282d  daddu       $a1, $v0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B10B4u;
        goto label_3b10b4;
    }
    ctx->pc = 0x3B10ACu;
    {
        const bool branch_taken_0x3b10ac = (GPR_U64(ctx, 3) != GPR_U64(ctx, 0));
        ctx->pc = 0x3B10B0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B10ACu;
        // 0x3b10b0: 0x40282d  daddu       $a1, $v0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b10ac) {
            ctx->pc = 0x3B1070u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_3b1070;
        }
    }
    ctx->pc = 0x3B10B4u;
label_3b10b4:
    // 0x3b10b4: 0x10000002  b           . + 4 + (0x2 << 2)
label_3b10b8:
    if (ctx->pc == 0x3B10B8u) {
        ctx->pc = 0x3B10B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B10B4u;
        // 0x3b10b8: 0x7bb00020  lq          $s0, 0x20($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 32)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B10BCu;
        goto label_3b10bc;
    }
    ctx->pc = 0x3B10B4u;
    {
        const bool branch_taken_0x3b10b4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3B10B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B10B4u;
        // 0x3b10b8: 0x7bb00020  lq          $s0, 0x20($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 32)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b10b4) {
            ctx->pc = 0x3B10C0u;
            goto label_3b10c0;
        }
    }
    ctx->pc = 0x3B10BCu;
label_3b10bc:
    // 0x3b10bc: 0x7bb00020  lq          $s0, 0x20($sp)
    ctx->pc = 0x3b10bcu;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_3b10c0:
    // 0x3b10c0: 0x7bb10010  lq          $s1, 0x10($sp)
    ctx->pc = 0x3b10c0u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_3b10c4:
    // 0x3b10c4: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x3b10c4u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_3b10c8:
    // 0x3b10c8: 0x3e00008  jr          $ra
label_3b10cc:
    if (ctx->pc == 0x3B10CCu) {
        ctx->pc = 0x3B10CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B10C8u;
        // 0x3b10cc: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B10D0u;
        goto label_fallthrough_0x3b10c8;
    }
    ctx->pc = 0x3B10C8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3B10CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B10C8u;
        // 0x3b10cc: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B10C8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
label_fallthrough_0x3b10c8:
    ctx->pc = 0x3B10D0u;
}
