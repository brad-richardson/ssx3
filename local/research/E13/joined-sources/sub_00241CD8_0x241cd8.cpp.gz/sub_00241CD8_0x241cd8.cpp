#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_00241CD8
// Address: 0x241cd8 - 0x241d40
void sub_00241CD8_0x241cd8(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_00241CD8_0x241cd8");
#endif

    switch (ctx->pc) {
        case 0x241cd8u: goto label_241cd8;
        case 0x241cdcu: goto label_241cdc;
        case 0x241ce0u: goto label_241ce0;
        case 0x241ce4u: goto label_241ce4;
        case 0x241ce8u: goto label_241ce8;
        case 0x241cecu: goto label_241cec;
        case 0x241cf0u: goto label_241cf0;
        case 0x241cf4u: goto label_241cf4;
        case 0x241cf8u: goto label_241cf8;
        case 0x241cfcu: goto label_241cfc;
        case 0x241d00u: goto label_241d00;
        case 0x241d04u: goto label_241d04;
        case 0x241d08u: goto label_241d08;
        case 0x241d0cu: goto label_241d0c;
        case 0x241d10u: goto label_241d10;
        case 0x241d14u: goto label_241d14;
        case 0x241d18u: goto label_241d18;
        case 0x241d1cu: goto label_241d1c;
        case 0x241d20u: goto label_241d20;
        case 0x241d24u: goto label_241d24;
        case 0x241d28u: goto label_241d28;
        case 0x241d2cu: goto label_241d2c;
        case 0x241d30u: goto label_241d30;
        case 0x241d34u: goto label_241d34;
        case 0x241d38u: goto label_241d38;
        case 0x241d3cu: goto label_241d3c;
        default: break;
    }

    ctx->pc = 0x241cd8u;

label_241cd8:
    // 0x241cd8: 0x27bdffe0  addiu       $sp, $sp, -0x20
    ctx->pc = 0x241cd8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967264));
label_241cdc:
    // 0x241cdc: 0x7fb00010  sq          $s0, 0x10($sp)
    ctx->pc = 0x241cdcu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 16));
label_241ce0:
    // 0x241ce0: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x241ce0u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_241ce4:
    // 0x241ce4: 0xc0906c8  jal         func_241B20
label_241ce8:
    if (ctx->pc == 0x241CE8u) {
        ctx->pc = 0x241CE8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241CE4u;
        // 0x241ce8: 0x80802d  daddu       $s0, $a0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241CECu;
        goto label_241cec;
    }
    ctx->pc = 0x241CE4u;
    SET_GPR_U32(ctx, 31, 0x241CECu);
    ctx->pc = 0x241CE8u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x241CE4u;
    // 0x241ce8: 0x80802d  daddu       $s0, $a0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x241B20u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x241B20u, 0x241CE4u, 0x241CECu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x241CECu;
label_241cec:
    // 0x241cec: 0x40202d  daddu       $a0, $v0, $zero
    ctx->pc = 0x241cecu;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_241cf0:
    // 0x241cf0: 0x8e030440  lw          $v1, 0x440($s0)
    ctx->pc = 0x241cf0u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1088)));
label_241cf4:
    // 0x241cf4: 0x8e02043c  lw          $v0, 0x43C($s0)
    ctx->pc = 0x241cf4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
label_241cf8:
    // 0x241cf8: 0x441026  xor         $v0, $v0, $a0
    ctx->pc = 0x241cf8u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) ^ GPR_U64(ctx, 4));
label_241cfc:
    // 0x241cfc: 0x10600003  beqz        $v1, . + 4 + (0x3 << 2)
label_241d00:
    if (ctx->pc == 0x241D00u) {
        ctx->pc = 0x241D00u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241CFCu;
        // 0x241d00: 0x2102b  sltu        $v0, $zero, $v0 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 0) < (uint64_t)GPR_U64(ctx, 2)) ? 1 : 0);
        ctx->in_delay_slot = false;
        ctx->pc = 0x241D04u;
        goto label_241d04;
    }
    ctx->pc = 0x241CFCu;
    {
        const bool branch_taken_0x241cfc = (GPR_U64(ctx, 3) == GPR_U64(ctx, 0));
        ctx->pc = 0x241D00u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241CFCu;
        // 0x241d00: 0x2102b  sltu        $v0, $zero, $v0 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 0) < (uint64_t)GPR_U64(ctx, 2)) ? 1 : 0);
        ctx->in_delay_slot = false;
        if (branch_taken_0x241cfc) {
            ctx->pc = 0x241D0Cu;
            goto label_241d0c;
        }
    }
    ctx->pc = 0x241D04u;
label_241d04:
    // 0x241d04: 0x50400009  beql        $v0, $zero, . + 4 + (0x9 << 2)
label_241d08:
    if (ctx->pc == 0x241D08u) {
        ctx->pc = 0x241D08u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241D04u;
        // 0x241d08: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241D0Cu;
        goto label_241d0c;
    }
    ctx->pc = 0x241D04u;
    {
        const bool branch_taken_0x241d04 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x241d04) {
            ctx->pc = 0x241D08u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x241D04u;
            // 0x241d08: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
            SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
            ctx->in_delay_slot = false;
            ctx->pc = 0x241D2Cu;
            goto label_241d2c;
        }
    }
    ctx->pc = 0x241D0Cu;
label_241d0c:
    // 0x241d0c: 0x10400005  beqz        $v0, . + 4 + (0x5 << 2)
label_241d10:
    if (ctx->pc == 0x241D10u) {
        ctx->pc = 0x241D10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241D0Cu;
        // 0x241d10: 0xae04043c  sw          $a0, 0x43C($s0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 16), 1084), GPR_U32(ctx, 4));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241D14u;
        goto label_241d14;
    }
    ctx->pc = 0x241D0Cu;
    {
        const bool branch_taken_0x241d0c = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x241D10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241D0Cu;
        // 0x241d10: 0xae04043c  sw          $a0, 0x43C($s0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 16), 1084), GPR_U32(ctx, 4));
        ctx->in_delay_slot = false;
        if (branch_taken_0x241d0c) {
            ctx->pc = 0x241D24u;
            goto label_241d24;
        }
    }
    ctx->pc = 0x241D14u;
label_241d14:
    // 0x241d14: 0x8e0200b0  lw          $v0, 0xB0($s0)
    ctx->pc = 0x241d14u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 176)));
label_241d18:
    // 0x241d18: 0x40f809  jalr        $v0
label_241d1c:
    if (ctx->pc == 0x241D1Cu) {
        ctx->pc = 0x241D20u;
        goto label_241d20;
    }
    ctx->pc = 0x241D18u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241D20u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241D18u, 0x241D20u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241D20u;
label_241d20:
    // 0x241d20: 0xae020440  sw          $v0, 0x440($s0)
    ctx->pc = 0x241d20u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 1088), GPR_U32(ctx, 2));
label_241d24:
    // 0x241d24: 0x8e020440  lw          $v0, 0x440($s0)
    ctx->pc = 0x241d24u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1088)));
label_241d28:
    // 0x241d28: 0x38420001  xori        $v0, $v0, 0x1
    ctx->pc = 0x241d28u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) ^ (uint64_t)(uint16_t)1);
label_241d2c:
    // 0x241d2c: 0x7bb00010  lq          $s0, 0x10($sp)
    ctx->pc = 0x241d2cu;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_241d30:
    // 0x241d30: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x241d30u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_241d34:
    // 0x241d34: 0x3e00008  jr          $ra
label_241d38:
    if (ctx->pc == 0x241D38u) {
        ctx->pc = 0x241D38u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241D34u;
        // 0x241d38: 0x27bd0020  addiu       $sp, $sp, 0x20 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 32));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241D3Cu;
        goto label_241d3c;
    }
    ctx->pc = 0x241D34u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x241D38u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241D34u;
        // 0x241d38: 0x27bd0020  addiu       $sp, $sp, 0x20 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 32));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241D34u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x241D3Cu;
label_241d3c:
    // 0x241d3c: 0x0  nop
    ctx->pc = 0x241d3cu;
    // NOP
    ctx->pc = 0x241d40u;
}
