#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_0023CDB0
// Address: 0x23cdb0 - 0x23d570
void sub_0023CDB0_0x23cdb0(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_0023CDB0_0x23cdb0");
#endif

    switch (ctx->pc) {
        case 0x23cdb0u: goto label_23cdb0;
        case 0x23cdb4u: goto label_23cdb4;
        case 0x23cdb8u: goto label_23cdb8;
        case 0x23cdbcu: goto label_23cdbc;
        case 0x23cdc0u: goto label_23cdc0;
        case 0x23cdc4u: goto label_23cdc4;
        case 0x23cdc8u: goto label_23cdc8;
        case 0x23cdccu: goto label_23cdcc;
        case 0x23cdd0u: goto label_23cdd0;
        case 0x23cdd4u: goto label_23cdd4;
        case 0x23cdd8u: goto label_23cdd8;
        case 0x23cddcu: goto label_23cddc;
        case 0x23cde0u: goto label_23cde0;
        case 0x23cde4u: goto label_23cde4;
        case 0x23cde8u: goto label_23cde8;
        case 0x23cdecu: goto label_23cdec;
        case 0x23cdf0u: goto label_23cdf0;
        case 0x23cdf4u: goto label_23cdf4;
        case 0x23cdf8u: goto label_23cdf8;
        case 0x23cdfcu: goto label_23cdfc;
        case 0x23ce00u: goto label_23ce00;
        case 0x23ce04u: goto label_23ce04;
        case 0x23ce08u: goto label_23ce08;
        case 0x23ce0cu: goto label_23ce0c;
        case 0x23ce10u: goto label_23ce10;
        case 0x23ce14u: goto label_23ce14;
        case 0x23ce18u: goto label_23ce18;
        case 0x23ce1cu: goto label_23ce1c;
        case 0x23ce20u: goto label_23ce20;
        case 0x23ce24u: goto label_23ce24;
        case 0x23ce28u: goto label_23ce28;
        case 0x23ce2cu: goto label_23ce2c;
        case 0x23ce30u: goto label_23ce30;
        case 0x23ce34u: goto label_23ce34;
        case 0x23ce38u: goto label_23ce38;
        case 0x23ce3cu: goto label_23ce3c;
        case 0x23ce40u: goto label_23ce40;
        case 0x23ce44u: goto label_23ce44;
        case 0x23ce48u: goto label_23ce48;
        case 0x23ce4cu: goto label_23ce4c;
        case 0x23ce50u: goto label_23ce50;
        case 0x23ce54u: goto label_23ce54;
        case 0x23ce58u: goto label_23ce58;
        case 0x23ce5cu: goto label_23ce5c;
        case 0x23ce60u: goto label_23ce60;
        case 0x23ce64u: goto label_23ce64;
        case 0x23ce68u: goto label_23ce68;
        case 0x23ce6cu: goto label_23ce6c;
        case 0x23ce70u: goto label_23ce70;
        case 0x23ce74u: goto label_23ce74;
        case 0x23ce78u: goto label_23ce78;
        case 0x23ce7cu: goto label_23ce7c;
        case 0x23ce80u: goto label_23ce80;
        case 0x23ce84u: goto label_23ce84;
        case 0x23ce88u: goto label_23ce88;
        case 0x23ce8cu: goto label_23ce8c;
        case 0x23ce90u: goto label_23ce90;
        case 0x23ce94u: goto label_23ce94;
        case 0x23ce98u: goto label_23ce98;
        case 0x23ce9cu: goto label_23ce9c;
        case 0x23cea0u: goto label_23cea0;
        case 0x23cea4u: goto label_23cea4;
        case 0x23cea8u: goto label_23cea8;
        case 0x23ceacu: goto label_23ceac;
        case 0x23ceb0u: goto label_23ceb0;
        case 0x23ceb4u: goto label_23ceb4;
        case 0x23ceb8u: goto label_23ceb8;
        case 0x23cebcu: goto label_23cebc;
        case 0x23cec0u: goto label_23cec0;
        case 0x23cec4u: goto label_23cec4;
        case 0x23cec8u: goto label_23cec8;
        case 0x23ceccu: goto label_23cecc;
        case 0x23ced0u: goto label_23ced0;
        case 0x23ced4u: goto label_23ced4;
        case 0x23ced8u: goto label_23ced8;
        case 0x23cedcu: goto label_23cedc;
        case 0x23cee0u: goto label_23cee0;
        case 0x23cee4u: goto label_23cee4;
        case 0x23cee8u: goto label_23cee8;
        case 0x23ceecu: goto label_23ceec;
        case 0x23cef0u: goto label_23cef0;
        case 0x23cef4u: goto label_23cef4;
        case 0x23cef8u: goto label_23cef8;
        case 0x23cefcu: goto label_23cefc;
        case 0x23cf00u: goto label_23cf00;
        case 0x23cf04u: goto label_23cf04;
        case 0x23cf08u: goto label_23cf08;
        case 0x23cf0cu: goto label_23cf0c;
        case 0x23cf10u: goto label_23cf10;
        case 0x23cf14u: goto label_23cf14;
        case 0x23cf18u: goto label_23cf18;
        case 0x23cf1cu: goto label_23cf1c;
        case 0x23cf20u: goto label_23cf20;
        case 0x23cf24u: goto label_23cf24;
        case 0x23cf28u: goto label_23cf28;
        case 0x23cf2cu: goto label_23cf2c;
        case 0x23cf30u: goto label_23cf30;
        case 0x23cf34u: goto label_23cf34;
        case 0x23cf38u: goto label_23cf38;
        case 0x23cf3cu: goto label_23cf3c;
        case 0x23cf40u: goto label_23cf40;
        case 0x23cf44u: goto label_23cf44;
        case 0x23cf48u: goto label_23cf48;
        case 0x23cf4cu: goto label_23cf4c;
        case 0x23cf50u: goto label_23cf50;
        case 0x23cf54u: goto label_23cf54;
        case 0x23cf58u: goto label_23cf58;
        case 0x23cf5cu: goto label_23cf5c;
        case 0x23cf60u: goto label_23cf60;
        case 0x23cf64u: goto label_23cf64;
        case 0x23cf68u: goto label_23cf68;
        case 0x23cf6cu: goto label_23cf6c;
        case 0x23cf70u: goto label_23cf70;
        case 0x23cf74u: goto label_23cf74;
        case 0x23cf78u: goto label_23cf78;
        case 0x23cf7cu: goto label_23cf7c;
        case 0x23cf80u: goto label_23cf80;
        case 0x23cf84u: goto label_23cf84;
        case 0x23cf88u: goto label_23cf88;
        case 0x23cf8cu: goto label_23cf8c;
        case 0x23cf90u: goto label_23cf90;
        case 0x23cf94u: goto label_23cf94;
        case 0x23cf98u: goto label_23cf98;
        case 0x23cf9cu: goto label_23cf9c;
        case 0x23cfa0u: goto label_23cfa0;
        case 0x23cfa4u: goto label_23cfa4;
        case 0x23cfa8u: goto label_23cfa8;
        case 0x23cfacu: goto label_23cfac;
        case 0x23cfb0u: goto label_23cfb0;
        case 0x23cfb4u: goto label_23cfb4;
        case 0x23cfb8u: goto label_23cfb8;
        case 0x23cfbcu: goto label_23cfbc;
        case 0x23cfc0u: goto label_23cfc0;
        case 0x23cfc4u: goto label_23cfc4;
        case 0x23cfc8u: goto label_23cfc8;
        case 0x23cfccu: goto label_23cfcc;
        case 0x23cfd0u: goto label_23cfd0;
        case 0x23cfd4u: goto label_23cfd4;
        case 0x23cfd8u: goto label_23cfd8;
        case 0x23cfdcu: goto label_23cfdc;
        case 0x23cfe0u: goto label_23cfe0;
        case 0x23cfe4u: goto label_23cfe4;
        case 0x23cfe8u: goto label_23cfe8;
        case 0x23cfecu: goto label_23cfec;
        case 0x23cff0u: goto label_23cff0;
        case 0x23cff4u: goto label_23cff4;
        case 0x23cff8u: goto label_23cff8;
        case 0x23cffcu: goto label_23cffc;
        case 0x23d000u: goto label_23d000;
        case 0x23d004u: goto label_23d004;
        case 0x23d008u: goto label_23d008;
        case 0x23d00cu: goto label_23d00c;
        case 0x23d010u: goto label_23d010;
        case 0x23d014u: goto label_23d014;
        case 0x23d018u: goto label_23d018;
        case 0x23d01cu: goto label_23d01c;
        case 0x23d020u: goto label_23d020;
        case 0x23d024u: goto label_23d024;
        case 0x23d028u: goto label_23d028;
        case 0x23d02cu: goto label_23d02c;
        case 0x23d030u: goto label_23d030;
        case 0x23d034u: goto label_23d034;
        case 0x23d038u: goto label_23d038;
        case 0x23d03cu: goto label_23d03c;
        case 0x23d040u: goto label_23d040;
        case 0x23d044u: goto label_23d044;
        case 0x23d048u: goto label_23d048;
        case 0x23d04cu: goto label_23d04c;
        case 0x23d050u: goto label_23d050;
        case 0x23d054u: goto label_23d054;
        case 0x23d058u: goto label_23d058;
        case 0x23d05cu: goto label_23d05c;
        case 0x23d060u: goto label_23d060;
        case 0x23d064u: goto label_23d064;
        case 0x23d068u: goto label_23d068;
        case 0x23d06cu: goto label_23d06c;
        case 0x23d070u: goto label_23d070;
        case 0x23d074u: goto label_23d074;
        case 0x23d078u: goto label_23d078;
        case 0x23d07cu: goto label_23d07c;
        case 0x23d080u: goto label_23d080;
        case 0x23d084u: goto label_23d084;
        case 0x23d088u: goto label_23d088;
        case 0x23d08cu: goto label_23d08c;
        case 0x23d090u: goto label_23d090;
        case 0x23d094u: goto label_23d094;
        case 0x23d098u: goto label_23d098;
        case 0x23d09cu: goto label_23d09c;
        case 0x23d0a0u: goto label_23d0a0;
        case 0x23d0a4u: goto label_23d0a4;
        case 0x23d0a8u: goto label_23d0a8;
        case 0x23d0acu: goto label_23d0ac;
        case 0x23d0b0u: goto label_23d0b0;
        case 0x23d0b4u: goto label_23d0b4;
        case 0x23d0b8u: goto label_23d0b8;
        case 0x23d0bcu: goto label_23d0bc;
        case 0x23d0c0u: goto label_23d0c0;
        case 0x23d0c4u: goto label_23d0c4;
        case 0x23d0c8u: goto label_23d0c8;
        case 0x23d0ccu: goto label_23d0cc;
        case 0x23d0d0u: goto label_23d0d0;
        case 0x23d0d4u: goto label_23d0d4;
        case 0x23d0d8u: goto label_23d0d8;
        case 0x23d0dcu: goto label_23d0dc;
        case 0x23d0e0u: goto label_23d0e0;
        case 0x23d0e4u: goto label_23d0e4;
        case 0x23d0e8u: goto label_23d0e8;
        case 0x23d0ecu: goto label_23d0ec;
        case 0x23d0f0u: goto label_23d0f0;
        case 0x23d0f4u: goto label_23d0f4;
        case 0x23d0f8u: goto label_23d0f8;
        case 0x23d0fcu: goto label_23d0fc;
        case 0x23d100u: goto label_23d100;
        case 0x23d104u: goto label_23d104;
        case 0x23d108u: goto label_23d108;
        case 0x23d10cu: goto label_23d10c;
        case 0x23d110u: goto label_23d110;
        case 0x23d114u: goto label_23d114;
        case 0x23d118u: goto label_23d118;
        case 0x23d11cu: goto label_23d11c;
        case 0x23d120u: goto label_23d120;
        case 0x23d124u: goto label_23d124;
        case 0x23d128u: goto label_23d128;
        case 0x23d12cu: goto label_23d12c;
        case 0x23d130u: goto label_23d130;
        case 0x23d134u: goto label_23d134;
        case 0x23d138u: goto label_23d138;
        case 0x23d13cu: goto label_23d13c;
        case 0x23d140u: goto label_23d140;
        case 0x23d144u: goto label_23d144;
        case 0x23d148u: goto label_23d148;
        case 0x23d14cu: goto label_23d14c;
        case 0x23d150u: goto label_23d150;
        case 0x23d154u: goto label_23d154;
        case 0x23d158u: goto label_23d158;
        case 0x23d15cu: goto label_23d15c;
        case 0x23d160u: goto label_23d160;
        case 0x23d164u: goto label_23d164;
        case 0x23d168u: goto label_23d168;
        case 0x23d16cu: goto label_23d16c;
        case 0x23d170u: goto label_23d170;
        case 0x23d174u: goto label_23d174;
        case 0x23d178u: goto label_23d178;
        case 0x23d17cu: goto label_23d17c;
        case 0x23d180u: goto label_23d180;
        case 0x23d184u: goto label_23d184;
        case 0x23d188u: goto label_23d188;
        case 0x23d18cu: goto label_23d18c;
        case 0x23d190u: goto label_23d190;
        case 0x23d194u: goto label_23d194;
        case 0x23d198u: goto label_23d198;
        case 0x23d19cu: goto label_23d19c;
        case 0x23d1a0u: goto label_23d1a0;
        case 0x23d1a4u: goto label_23d1a4;
        case 0x23d1a8u: goto label_23d1a8;
        case 0x23d1acu: goto label_23d1ac;
        case 0x23d1b0u: goto label_23d1b0;
        case 0x23d1b4u: goto label_23d1b4;
        case 0x23d1b8u: goto label_23d1b8;
        case 0x23d1bcu: goto label_23d1bc;
        case 0x23d1c0u: goto label_23d1c0;
        case 0x23d1c4u: goto label_23d1c4;
        case 0x23d1c8u: goto label_23d1c8;
        case 0x23d1ccu: goto label_23d1cc;
        case 0x23d1d0u: goto label_23d1d0;
        case 0x23d1d4u: goto label_23d1d4;
        case 0x23d1d8u: goto label_23d1d8;
        case 0x23d1dcu: goto label_23d1dc;
        case 0x23d1e0u: goto label_23d1e0;
        case 0x23d1e4u: goto label_23d1e4;
        case 0x23d1e8u: goto label_23d1e8;
        case 0x23d1ecu: goto label_23d1ec;
        case 0x23d1f0u: goto label_23d1f0;
        case 0x23d1f4u: goto label_23d1f4;
        case 0x23d1f8u: goto label_23d1f8;
        case 0x23d1fcu: goto label_23d1fc;
        case 0x23d200u: goto label_23d200;
        case 0x23d204u: goto label_23d204;
        case 0x23d208u: goto label_23d208;
        case 0x23d20cu: goto label_23d20c;
        case 0x23d210u: goto label_23d210;
        case 0x23d214u: goto label_23d214;
        case 0x23d218u: goto label_23d218;
        case 0x23d21cu: goto label_23d21c;
        case 0x23d220u: goto label_23d220;
        case 0x23d224u: goto label_23d224;
        case 0x23d228u: goto label_23d228;
        case 0x23d22cu: goto label_23d22c;
        case 0x23d230u: goto label_23d230;
        case 0x23d234u: goto label_23d234;
        case 0x23d238u: goto label_23d238;
        case 0x23d23cu: goto label_23d23c;
        case 0x23d240u: goto label_23d240;
        case 0x23d244u: goto label_23d244;
        case 0x23d248u: goto label_23d248;
        case 0x23d24cu: goto label_23d24c;
        case 0x23d250u: goto label_23d250;
        case 0x23d254u: goto label_23d254;
        case 0x23d258u: goto label_23d258;
        case 0x23d25cu: goto label_23d25c;
        case 0x23d260u: goto label_23d260;
        case 0x23d264u: goto label_23d264;
        case 0x23d268u: goto label_23d268;
        case 0x23d26cu: goto label_23d26c;
        case 0x23d270u: goto label_23d270;
        case 0x23d274u: goto label_23d274;
        case 0x23d278u: goto label_23d278;
        case 0x23d27cu: goto label_23d27c;
        case 0x23d280u: goto label_23d280;
        case 0x23d284u: goto label_23d284;
        case 0x23d288u: goto label_23d288;
        case 0x23d28cu: goto label_23d28c;
        case 0x23d290u: goto label_23d290;
        case 0x23d294u: goto label_23d294;
        case 0x23d298u: goto label_23d298;
        case 0x23d29cu: goto label_23d29c;
        case 0x23d2a0u: goto label_23d2a0;
        case 0x23d2a4u: goto label_23d2a4;
        case 0x23d2a8u: goto label_23d2a8;
        case 0x23d2acu: goto label_23d2ac;
        case 0x23d2b0u: goto label_23d2b0;
        case 0x23d2b4u: goto label_23d2b4;
        case 0x23d2b8u: goto label_23d2b8;
        case 0x23d2bcu: goto label_23d2bc;
        case 0x23d2c0u: goto label_23d2c0;
        case 0x23d2c4u: goto label_23d2c4;
        case 0x23d2c8u: goto label_23d2c8;
        case 0x23d2ccu: goto label_23d2cc;
        case 0x23d2d0u: goto label_23d2d0;
        case 0x23d2d4u: goto label_23d2d4;
        case 0x23d2d8u: goto label_23d2d8;
        case 0x23d2dcu: goto label_23d2dc;
        case 0x23d2e0u: goto label_23d2e0;
        case 0x23d2e4u: goto label_23d2e4;
        case 0x23d2e8u: goto label_23d2e8;
        case 0x23d2ecu: goto label_23d2ec;
        case 0x23d2f0u: goto label_23d2f0;
        case 0x23d2f4u: goto label_23d2f4;
        case 0x23d2f8u: goto label_23d2f8;
        case 0x23d2fcu: goto label_23d2fc;
        case 0x23d300u: goto label_23d300;
        case 0x23d304u: goto label_23d304;
        case 0x23d308u: goto label_23d308;
        case 0x23d30cu: goto label_23d30c;
        case 0x23d310u: goto label_23d310;
        case 0x23d314u: goto label_23d314;
        case 0x23d318u: goto label_23d318;
        case 0x23d31cu: goto label_23d31c;
        case 0x23d320u: goto label_23d320;
        case 0x23d324u: goto label_23d324;
        case 0x23d328u: goto label_23d328;
        case 0x23d32cu: goto label_23d32c;
        case 0x23d330u: goto label_23d330;
        case 0x23d334u: goto label_23d334;
        case 0x23d338u: goto label_23d338;
        case 0x23d33cu: goto label_23d33c;
        case 0x23d340u: goto label_23d340;
        case 0x23d344u: goto label_23d344;
        case 0x23d348u: goto label_23d348;
        case 0x23d34cu: goto label_23d34c;
        case 0x23d350u: goto label_23d350;
        case 0x23d354u: goto label_23d354;
        case 0x23d358u: goto label_23d358;
        case 0x23d35cu: goto label_23d35c;
        case 0x23d360u: goto label_23d360;
        case 0x23d364u: goto label_23d364;
        case 0x23d368u: goto label_23d368;
        case 0x23d36cu: goto label_23d36c;
        case 0x23d370u: goto label_23d370;
        case 0x23d374u: goto label_23d374;
        case 0x23d378u: goto label_23d378;
        case 0x23d37cu: goto label_23d37c;
        case 0x23d380u: goto label_23d380;
        case 0x23d384u: goto label_23d384;
        case 0x23d388u: goto label_23d388;
        case 0x23d38cu: goto label_23d38c;
        case 0x23d390u: goto label_23d390;
        case 0x23d394u: goto label_23d394;
        case 0x23d398u: goto label_23d398;
        case 0x23d39cu: goto label_23d39c;
        case 0x23d3a0u: goto label_23d3a0;
        case 0x23d3a4u: goto label_23d3a4;
        case 0x23d3a8u: goto label_23d3a8;
        case 0x23d3acu: goto label_23d3ac;
        case 0x23d3b0u: goto label_23d3b0;
        case 0x23d3b4u: goto label_23d3b4;
        case 0x23d3b8u: goto label_23d3b8;
        case 0x23d3bcu: goto label_23d3bc;
        case 0x23d3c0u: goto label_23d3c0;
        case 0x23d3c4u: goto label_23d3c4;
        case 0x23d3c8u: goto label_23d3c8;
        case 0x23d3ccu: goto label_23d3cc;
        case 0x23d3d0u: goto label_23d3d0;
        case 0x23d3d4u: goto label_23d3d4;
        case 0x23d3d8u: goto label_23d3d8;
        case 0x23d3dcu: goto label_23d3dc;
        case 0x23d3e0u: goto label_23d3e0;
        case 0x23d3e4u: goto label_23d3e4;
        case 0x23d3e8u: goto label_23d3e8;
        case 0x23d3ecu: goto label_23d3ec;
        case 0x23d3f0u: goto label_23d3f0;
        case 0x23d3f4u: goto label_23d3f4;
        case 0x23d3f8u: goto label_23d3f8;
        case 0x23d3fcu: goto label_23d3fc;
        case 0x23d400u: goto label_23d400;
        case 0x23d404u: goto label_23d404;
        case 0x23d408u: goto label_23d408;
        case 0x23d40cu: goto label_23d40c;
        case 0x23d410u: goto label_23d410;
        case 0x23d414u: goto label_23d414;
        case 0x23d418u: goto label_23d418;
        case 0x23d41cu: goto label_23d41c;
        case 0x23d420u: goto label_23d420;
        case 0x23d424u: goto label_23d424;
        case 0x23d428u: goto label_23d428;
        case 0x23d42cu: goto label_23d42c;
        case 0x23d430u: goto label_23d430;
        case 0x23d434u: goto label_23d434;
        case 0x23d438u: goto label_23d438;
        case 0x23d43cu: goto label_23d43c;
        case 0x23d440u: goto label_23d440;
        case 0x23d444u: goto label_23d444;
        case 0x23d448u: goto label_23d448;
        case 0x23d44cu: goto label_23d44c;
        case 0x23d450u: goto label_23d450;
        case 0x23d454u: goto label_23d454;
        case 0x23d458u: goto label_23d458;
        case 0x23d45cu: goto label_23d45c;
        case 0x23d460u: goto label_23d460;
        case 0x23d464u: goto label_23d464;
        case 0x23d468u: goto label_23d468;
        case 0x23d46cu: goto label_23d46c;
        case 0x23d470u: goto label_23d470;
        case 0x23d474u: goto label_23d474;
        case 0x23d478u: goto label_23d478;
        case 0x23d47cu: goto label_23d47c;
        case 0x23d480u: goto label_23d480;
        case 0x23d484u: goto label_23d484;
        case 0x23d488u: goto label_23d488;
        case 0x23d48cu: goto label_23d48c;
        case 0x23d490u: goto label_23d490;
        case 0x23d494u: goto label_23d494;
        case 0x23d498u: goto label_23d498;
        case 0x23d49cu: goto label_23d49c;
        case 0x23d4a0u: goto label_23d4a0;
        case 0x23d4a4u: goto label_23d4a4;
        case 0x23d4a8u: goto label_23d4a8;
        case 0x23d4acu: goto label_23d4ac;
        case 0x23d4b0u: goto label_23d4b0;
        case 0x23d4b4u: goto label_23d4b4;
        case 0x23d4b8u: goto label_23d4b8;
        case 0x23d4bcu: goto label_23d4bc;
        case 0x23d4c0u: goto label_23d4c0;
        case 0x23d4c4u: goto label_23d4c4;
        case 0x23d4c8u: goto label_23d4c8;
        case 0x23d4ccu: goto label_23d4cc;
        case 0x23d4d0u: goto label_23d4d0;
        case 0x23d4d4u: goto label_23d4d4;
        case 0x23d4d8u: goto label_23d4d8;
        case 0x23d4dcu: goto label_23d4dc;
        case 0x23d4e0u: goto label_23d4e0;
        case 0x23d4e4u: goto label_23d4e4;
        case 0x23d4e8u: goto label_23d4e8;
        case 0x23d4ecu: goto label_23d4ec;
        case 0x23d4f0u: goto label_23d4f0;
        case 0x23d4f4u: goto label_23d4f4;
        case 0x23d4f8u: goto label_23d4f8;
        case 0x23d4fcu: goto label_23d4fc;
        case 0x23d500u: goto label_23d500;
        case 0x23d504u: goto label_23d504;
        case 0x23d508u: goto label_23d508;
        case 0x23d50cu: goto label_23d50c;
        case 0x23d510u: goto label_23d510;
        case 0x23d514u: goto label_23d514;
        case 0x23d518u: goto label_23d518;
        case 0x23d51cu: goto label_23d51c;
        case 0x23d520u: goto label_23d520;
        case 0x23d524u: goto label_23d524;
        case 0x23d528u: goto label_23d528;
        case 0x23d52cu: goto label_23d52c;
        case 0x23d530u: goto label_23d530;
        case 0x23d534u: goto label_23d534;
        case 0x23d538u: goto label_23d538;
        case 0x23d53cu: goto label_23d53c;
        case 0x23d540u: goto label_23d540;
        case 0x23d544u: goto label_23d544;
        case 0x23d548u: goto label_23d548;
        case 0x23d54cu: goto label_23d54c;
        case 0x23d550u: goto label_23d550;
        case 0x23d554u: goto label_23d554;
        case 0x23d558u: goto label_23d558;
        case 0x23d55cu: goto label_23d55c;
        case 0x23d560u: goto label_23d560;
        case 0x23d564u: goto label_23d564;
        case 0x23d568u: goto label_23d568;
        case 0x23d56cu: goto label_23d56c;
        default: break;
    }

    ctx->pc = 0x23cdb0u;

label_23cdb0:
    // 0x23cdb0: 0x27bdf790  addiu       $sp, $sp, -0x870
    ctx->pc = 0x23cdb0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294965136));
label_23cdb4:
    // 0x23cdb4: 0x7fb20840  sq          $s2, 0x840($sp)
    ctx->pc = 0x23cdb4u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 2112), GPR_VEC(ctx, 18));
label_23cdb8:
    // 0x23cdb8: 0x27a60200  addiu       $a2, $sp, 0x200
    ctx->pc = 0x23cdb8u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 29), 512));
label_23cdbc:
    // 0x23cdbc: 0x7fb40820  sq          $s4, 0x820($sp)
    ctx->pc = 0x23cdbcu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 2080), GPR_VEC(ctx, 20));
label_23cdc0:
    // 0x23cdc0: 0x80902d  daddu       $s2, $a0, $zero
    ctx->pc = 0x23cdc0u;
    SET_GPR_U64(ctx, 18, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_23cdc4:
    // 0x23cdc4: 0x7fb30830  sq          $s3, 0x830($sp)
    ctx->pc = 0x23cdc4u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 2096), GPR_VEC(ctx, 19));
label_23cdc8:
    // 0x23cdc8: 0xa0a02d  daddu       $s4, $a1, $zero
    ctx->pc = 0x23cdc8u;
    SET_GPR_U64(ctx, 20, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_23cdcc:
    // 0x23cdcc: 0x7fb50810  sq          $s5, 0x810($sp)
    ctx->pc = 0x23cdccu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 2064), GPR_VEC(ctx, 21));
label_23cdd0:
    // 0x23cdd0: 0x7fb00860  sq          $s0, 0x860($sp)
    ctx->pc = 0x23cdd0u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 2144), GPR_VEC(ctx, 16));
label_23cdd4:
    // 0x23cdd4: 0x7fb10850  sq          $s1, 0x850($sp)
    ctx->pc = 0x23cdd4u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 2128), GPR_VEC(ctx, 17));
label_23cdd8:
    // 0x23cdd8: 0xffbf0800  sd          $ra, 0x800($sp)
    ctx->pc = 0x23cdd8u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 2048), GPR_U64(ctx, 31));
label_23cddc:
    // 0x23cddc: 0xc08f31e  jal         func_23CC78
label_23cde0:
    if (ctx->pc == 0x23CDE0u) {
        ctx->pc = 0x23CDE0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CDDCu;
        // 0x23cde0: 0xc0982d  daddu       $s3, $a2, $zero (Delay Slot)
        SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CDE4u;
        goto label_23cde4;
    }
    ctx->pc = 0x23CDDCu;
    SET_GPR_U32(ctx, 31, 0x23CDE4u);
    ctx->pc = 0x23CDE0u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CDDCu;
    // 0x23cde0: 0xc0982d  daddu       $s3, $a2, $zero (Delay Slot)
    SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x23CC78u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x23CC78u, 0x23CDDCu, 0x23CDE4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CDE4u;
label_23cde4:
    // 0x23cde4: 0x27a40400  addiu       $a0, $sp, 0x400
    ctx->pc = 0x23cde4u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 29), 1024));
label_23cde8:
    // 0x23cde8: 0x3c050048  lui         $a1, 0x48
    ctx->pc = 0x23cde8u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)72 << 16));
label_23cdec:
    // 0x23cdec: 0x80a82d  daddu       $s5, $a0, $zero
    ctx->pc = 0x23cdecu;
    SET_GPR_U64(ctx, 21, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_23cdf0:
    // 0x23cdf0: 0xc0b0950  jal         func_2C2540
label_23cdf4:
    if (ctx->pc == 0x23CDF4u) {
        ctx->pc = 0x23CDF4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CDF0u;
        // 0x23cdf4: 0x24a5c150  addiu       $a1, $a1, -0x3EB0 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 4294951248));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CDF8u;
        goto label_23cdf8;
    }
    ctx->pc = 0x23CDF0u;
    SET_GPR_U32(ctx, 31, 0x23CDF8u);
    ctx->pc = 0x23CDF4u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CDF0u;
    // 0x23cdf4: 0x24a5c150  addiu       $a1, $a1, -0x3EB0 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 4294951248));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2540u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2540u, 0x23CDF0u, 0x23CDF8u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CDF8u;
label_23cdf8:
    // 0x23cdf8: 0x8e4300b4  lw          $v1, 0xB4($s2)
    ctx->pc = 0x23cdf8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 180)));
label_23cdfc:
    // 0x23cdfc: 0x10600005  beqz        $v1, . + 4 + (0x5 << 2)
label_23ce00:
    if (ctx->pc == 0x23CE00u) {
        ctx->pc = 0x23CE00u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CDFCu;
        // 0x23ce00: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE04u;
        goto label_23ce04;
    }
    ctx->pc = 0x23CDFCu;
    {
        const bool branch_taken_0x23cdfc = (GPR_U64(ctx, 3) == GPR_U64(ctx, 0));
        ctx->pc = 0x23CE00u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CDFCu;
        // 0x23ce00: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23cdfc) {
            ctx->pc = 0x23CE14u;
            goto label_23ce14;
        }
    }
    ctx->pc = 0x23CE04u;
label_23ce04:
    // 0x23ce04: 0x10620016  beq         $v1, $v0, . + 4 + (0x16 << 2)
label_23ce08:
    if (ctx->pc == 0x23CE08u) {
        ctx->pc = 0x23CE08u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE04u;
        // 0x23ce08: 0x8f82f7b8  lw          $v0, -0x848($gp) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294965176)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE0Cu;
        goto label_23ce0c;
    }
    ctx->pc = 0x23CE04u;
    {
        const bool branch_taken_0x23ce04 = (GPR_U64(ctx, 3) == GPR_U64(ctx, 2));
        ctx->pc = 0x23CE08u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE04u;
        // 0x23ce08: 0x8f82f7b8  lw          $v0, -0x848($gp) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294965176)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23ce04) {
            ctx->pc = 0x23CE60u;
            goto label_23ce60;
        }
    }
    ctx->pc = 0x23CE0Cu;
label_23ce0c:
    // 0x23ce0c: 0x10000026  b           . + 4 + (0x26 << 2)
label_23ce10:
    if (ctx->pc == 0x23CE10u) {
        ctx->pc = 0x23CE10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE0Cu;
        // 0x23ce10: 0x3c040048  lui         $a0, 0x48 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)72 << 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE14u;
        goto label_23ce14;
    }
    ctx->pc = 0x23CE0Cu;
    {
        const bool branch_taken_0x23ce0c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23CE10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE0Cu;
        // 0x23ce10: 0x3c040048  lui         $a0, 0x48 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)72 << 16));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23ce0c) {
            ctx->pc = 0x23CEA8u;
            goto label_23cea8;
        }
    }
    ctx->pc = 0x23CE14u;
label_23ce14:
    // 0x23ce14: 0x8f82f7b8  lw          $v0, -0x848($gp)
    ctx->pc = 0x23ce14u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294965176)));
label_23ce18:
    // 0x23ce18: 0x3c040048  lui         $a0, 0x48
    ctx->pc = 0x23ce18u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)72 << 16));
label_23ce1c:
    // 0x23ce1c: 0x2484c160  addiu       $a0, $a0, -0x3EA0
    ctx->pc = 0x23ce1cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 4294951264));
label_23ce20:
    // 0x23ce20: 0x8c50008c  lw          $s0, 0x8C($v0)
    ctx->pc = 0x23ce20u;
    SET_GPR_S32(ctx, 16, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 140)));
label_23ce24:
    // 0x23ce24: 0x8e110004  lw          $s1, 0x4($s0)
    ctx->pc = 0x23ce24u;
    SET_GPR_S32(ctx, 17, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 4)));
label_23ce28:
    // 0x23ce28: 0x86220020  lh          $v0, 0x20($s1)
    ctx->pc = 0x23ce28u;
    SET_GPR_S32(ctx, 2, (int16_t)READ16(ADD32(GPR_U32(ctx, 17), 32)));
label_23ce2c:
    // 0x23ce2c: 0xc0c5d9c  jal         func_317670
label_23ce30:
    if (ctx->pc == 0x23CE30u) {
        ctx->pc = 0x23CE30u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE2Cu;
        // 0x23ce30: 0x2028021  addu        $s0, $s0, $v0 (Delay Slot)
        SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 2)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE34u;
        goto label_23ce34;
    }
    ctx->pc = 0x23CE2Cu;
    SET_GPR_U32(ctx, 31, 0x23CE34u);
    ctx->pc = 0x23CE30u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CE2Cu;
    // 0x23ce30: 0x2028021  addu        $s0, $s0, $v0 (Delay Slot)
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 2)));
    ctx->in_delay_slot = false;
    ctx->pc = 0x317670u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x317670u, 0x23CE2Cu, 0x23CE34u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CE34u;
label_23ce34:
    // 0x23ce34: 0x8e230024  lw          $v1, 0x24($s1)
    ctx->pc = 0x23ce34u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 36)));
label_23ce38:
    // 0x23ce38: 0x200202d  daddu       $a0, $s0, $zero
    ctx->pc = 0x23ce38u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_23ce3c:
    // 0x23ce3c: 0x60f809  jalr        $v1
label_23ce40:
    if (ctx->pc == 0x23CE40u) {
        ctx->pc = 0x23CE40u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE3Cu;
        // 0x23ce40: 0x40282d  daddu       $a1, $v0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE44u;
        goto label_23ce44;
    }
    ctx->pc = 0x23CE3Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23CE44u);
        ctx->pc = 0x23CE40u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE3Cu;
        // 0x23ce40: 0x40282d  daddu       $a1, $v0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23CE3Cu, 0x23CE44u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23CE44u;
label_23ce44:
    // 0x23ce44: 0x2a0282d  daddu       $a1, $s5, $zero
    ctx->pc = 0x23ce44u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 21) + (uint64_t)GPR_U64(ctx, 0));
label_23ce48:
    // 0x23ce48: 0x40302d  daddu       $a2, $v0, $zero
    ctx->pc = 0x23ce48u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_23ce4c:
    // 0x23ce4c: 0xc0b09b4  jal         func_2C26D0
label_23ce50:
    if (ctx->pc == 0x23CE50u) {
        ctx->pc = 0x23CE50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE4Cu;
        // 0x23ce50: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE54u;
        goto label_23ce54;
    }
    ctx->pc = 0x23CE4Cu;
    SET_GPR_U32(ctx, 31, 0x23CE54u);
    ctx->pc = 0x23CE50u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CE4Cu;
    // 0x23ce50: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C26D0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C26D0u, 0x23CE4Cu, 0x23CE54u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CE54u;
label_23ce54:
    // 0x23ce54: 0x260282d  daddu       $a1, $s3, $zero
    ctx->pc = 0x23ce54u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
label_23ce58:
    // 0x23ce58: 0x1000000f  b           . + 4 + (0xF << 2)
label_23ce5c:
    if (ctx->pc == 0x23CE5Cu) {
        ctx->pc = 0x23CE5Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE58u;
        // 0x23ce5c: 0x280302d  daddu       $a2, $s4, $zero (Delay Slot)
        SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 20) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE60u;
        goto label_23ce60;
    }
    ctx->pc = 0x23CE58u;
    {
        const bool branch_taken_0x23ce58 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23CE5Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE58u;
        // 0x23ce5c: 0x280302d  daddu       $a2, $s4, $zero (Delay Slot)
        SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 20) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23ce58) {
            ctx->pc = 0x23CE98u;
            goto label_23ce98;
        }
    }
    ctx->pc = 0x23CE60u;
label_23ce60:
    // 0x23ce60: 0xc053720  jal         func_14DC80
label_23ce64:
    if (ctx->pc == 0x23CE64u) {
        ctx->pc = 0x23CE68u;
        goto label_23ce68;
    }
    ctx->pc = 0x23CE60u;
    SET_GPR_U32(ctx, 31, 0x23CE68u);
    ctx->pc = 0x14DC80u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x14DC80u, 0x23CE60u, 0x23CE68u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CE68u;
label_23ce68:
    // 0x23ce68: 0x40202d  daddu       $a0, $v0, $zero
    ctx->pc = 0x23ce68u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_23ce6c:
    // 0x23ce6c: 0xc053756  jal         func_14DD58
label_23ce70:
    if (ctx->pc == 0x23CE70u) {
        ctx->pc = 0x23CE70u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE6Cu;
        // 0x23ce70: 0x24050001  addiu       $a1, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE74u;
        goto label_23ce74;
    }
    ctx->pc = 0x23CE6Cu;
    SET_GPR_U32(ctx, 31, 0x23CE74u);
    ctx->pc = 0x23CE70u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CE6Cu;
    // 0x23ce70: 0x24050001  addiu       $a1, $zero, 0x1 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
    ctx->in_delay_slot = false;
    ctx->pc = 0x14DD58u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x14DD58u, 0x23CE6Cu, 0x23CE74u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CE74u;
label_23ce74:
    // 0x23ce74: 0x8e4500fc  lw          $a1, 0xFC($s2)
    ctx->pc = 0x23ce74u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 252)));
label_23ce78:
    // 0x23ce78: 0x27b00600  addiu       $s0, $sp, 0x600
    ctx->pc = 0x23ce78u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 29), 1536));
label_23ce7c:
    // 0x23ce7c: 0xc051c5c  jal         func_147170
label_23ce80:
    if (ctx->pc == 0x23CE80u) {
        ctx->pc = 0x23CE80u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE7Cu;
        // 0x23ce80: 0x40202d  daddu       $a0, $v0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE84u;
        goto label_23ce84;
    }
    ctx->pc = 0x23CE7Cu;
    SET_GPR_U32(ctx, 31, 0x23CE84u);
    ctx->pc = 0x23CE80u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CE7Cu;
    // 0x23ce80: 0x40202d  daddu       $a0, $v0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x147170u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x147170u, 0x23CE7Cu, 0x23CE84u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CE84u;
label_23ce84:
    // 0x23ce84: 0x40282d  daddu       $a1, $v0, $zero
    ctx->pc = 0x23ce84u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_23ce88:
    // 0x23ce88: 0xc0b0950  jal         func_2C2540
label_23ce8c:
    if (ctx->pc == 0x23CE8Cu) {
        ctx->pc = 0x23CE8Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE88u;
        // 0x23ce8c: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CE90u;
        goto label_23ce90;
    }
    ctx->pc = 0x23CE88u;
    SET_GPR_U32(ctx, 31, 0x23CE90u);
    ctx->pc = 0x23CE8Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CE88u;
    // 0x23ce8c: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2540u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2540u, 0x23CE88u, 0x23CE90u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CE90u;
label_23ce90:
    // 0x23ce90: 0x2a0282d  daddu       $a1, $s5, $zero
    ctx->pc = 0x23ce90u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 21) + (uint64_t)GPR_U64(ctx, 0));
label_23ce94:
    // 0x23ce94: 0x200302d  daddu       $a2, $s0, $zero
    ctx->pc = 0x23ce94u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_23ce98:
    // 0x23ce98: 0xc0b09b4  jal         func_2C26D0
label_23ce9c:
    if (ctx->pc == 0x23CE9Cu) {
        ctx->pc = 0x23CE9Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CE98u;
        // 0x23ce9c: 0x3a0202d  daddu       $a0, $sp, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CEA0u;
        goto label_23cea0;
    }
    ctx->pc = 0x23CE98u;
    SET_GPR_U32(ctx, 31, 0x23CEA0u);
    ctx->pc = 0x23CE9Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CE98u;
    // 0x23ce9c: 0x3a0202d  daddu       $a0, $sp, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C26D0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C26D0u, 0x23CE98u, 0x23CEA0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CEA0u;
label_23cea0:
    // 0x23cea0: 0x10000013  b           . + 4 + (0x13 << 2)
label_23cea4:
    if (ctx->pc == 0x23CEA4u) {
        ctx->pc = 0x23CEA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CEA0u;
        // 0x23cea4: 0x8e460434  lw          $a2, 0x434($s2) (Delay Slot)
        SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CEA8u;
        goto label_23cea8;
    }
    ctx->pc = 0x23CEA0u;
    {
        const bool branch_taken_0x23cea0 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23CEA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CEA0u;
        // 0x23cea4: 0x8e460434  lw          $a2, 0x434($s2) (Delay Slot)
        SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23cea0) {
            ctx->pc = 0x23CEF0u;
            goto label_23cef0;
        }
    }
    ctx->pc = 0x23CEA8u;
label_23cea8:
    // 0x23cea8: 0x2484c138  addiu       $a0, $a0, -0x3EC8
    ctx->pc = 0x23cea8u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 4294951224));
label_23ceac:
    // 0x23ceac: 0x8c50008c  lw          $s0, 0x8C($v0)
    ctx->pc = 0x23ceacu;
    SET_GPR_S32(ctx, 16, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 140)));
label_23ceb0:
    // 0x23ceb0: 0x8e110004  lw          $s1, 0x4($s0)
    ctx->pc = 0x23ceb0u;
    SET_GPR_S32(ctx, 17, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 4)));
label_23ceb4:
    // 0x23ceb4: 0x86220020  lh          $v0, 0x20($s1)
    ctx->pc = 0x23ceb4u;
    SET_GPR_S32(ctx, 2, (int16_t)READ16(ADD32(GPR_U32(ctx, 17), 32)));
label_23ceb8:
    // 0x23ceb8: 0xc0c5d9c  jal         func_317670
label_23cebc:
    if (ctx->pc == 0x23CEBCu) {
        ctx->pc = 0x23CEBCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CEB8u;
        // 0x23cebc: 0x2028021  addu        $s0, $s0, $v0 (Delay Slot)
        SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 2)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CEC0u;
        goto label_23cec0;
    }
    ctx->pc = 0x23CEB8u;
    SET_GPR_U32(ctx, 31, 0x23CEC0u);
    ctx->pc = 0x23CEBCu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CEB8u;
    // 0x23cebc: 0x2028021  addu        $s0, $s0, $v0 (Delay Slot)
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 2)));
    ctx->in_delay_slot = false;
    ctx->pc = 0x317670u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x317670u, 0x23CEB8u, 0x23CEC0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CEC0u;
label_23cec0:
    // 0x23cec0: 0x8e230024  lw          $v1, 0x24($s1)
    ctx->pc = 0x23cec0u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 36)));
label_23cec4:
    // 0x23cec4: 0x200202d  daddu       $a0, $s0, $zero
    ctx->pc = 0x23cec4u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_23cec8:
    // 0x23cec8: 0x60f809  jalr        $v1
label_23cecc:
    if (ctx->pc == 0x23CECCu) {
        ctx->pc = 0x23CECCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CEC8u;
        // 0x23cecc: 0x40282d  daddu       $a1, $v0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CED0u;
        goto label_23ced0;
    }
    ctx->pc = 0x23CEC8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23CED0u);
        ctx->pc = 0x23CECCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CEC8u;
        // 0x23cecc: 0x40282d  daddu       $a1, $v0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23CEC8u, 0x23CED0u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23CED0u;
label_23ced0:
    // 0x23ced0: 0x40282d  daddu       $a1, $v0, $zero
    ctx->pc = 0x23ced0u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_23ced4:
    // 0x23ced4: 0xc0b0942  jal         func_2C2508
label_23ced8:
    if (ctx->pc == 0x23CED8u) {
        ctx->pc = 0x23CED8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CED4u;
        // 0x23ced8: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CEDCu;
        goto label_23cedc;
    }
    ctx->pc = 0x23CED4u;
    SET_GPR_U32(ctx, 31, 0x23CEDCu);
    ctx->pc = 0x23CED8u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CED4u;
    // 0x23ced8: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2508u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2508u, 0x23CED4u, 0x23CEDCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CEDCu;
label_23cedc:
    // 0x23cedc: 0x2a0282d  daddu       $a1, $s5, $zero
    ctx->pc = 0x23cedcu;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 21) + (uint64_t)GPR_U64(ctx, 0));
label_23cee0:
    // 0x23cee0: 0x260302d  daddu       $a2, $s3, $zero
    ctx->pc = 0x23cee0u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
label_23cee4:
    // 0x23cee4: 0xc0b09b4  jal         func_2C26D0
label_23cee8:
    if (ctx->pc == 0x23CEE8u) {
        ctx->pc = 0x23CEE8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CEE4u;
        // 0x23cee8: 0x3a0202d  daddu       $a0, $sp, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CEECu;
        goto label_23ceec;
    }
    ctx->pc = 0x23CEE4u;
    SET_GPR_U32(ctx, 31, 0x23CEECu);
    ctx->pc = 0x23CEE8u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CEE4u;
    // 0x23cee8: 0x3a0202d  daddu       $a0, $sp, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C26D0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C26D0u, 0x23CEE4u, 0x23CEECu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CEECu;
label_23ceec:
    // 0x23ceec: 0x8e460434  lw          $a2, 0x434($s2)
    ctx->pc = 0x23ceecu;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
label_23cef0:
    // 0x23cef0: 0x3a0282d  daddu       $a1, $sp, $zero
    ctx->pc = 0x23cef0u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
label_23cef4:
    // 0x23cef4: 0x8cc20000  lw          $v0, 0x0($a2)
    ctx->pc = 0x23cef4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_23cef8:
    // 0x23cef8: 0x84440168  lh          $a0, 0x168($v0)
    ctx->pc = 0x23cef8u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 360)));
label_23cefc:
    // 0x23cefc: 0x8c43016c  lw          $v1, 0x16C($v0)
    ctx->pc = 0x23cefcu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 364)));
label_23cf00:
    // 0x23cf00: 0x60f809  jalr        $v1
label_23cf04:
    if (ctx->pc == 0x23CF04u) {
        ctx->pc = 0x23CF04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CF00u;
        // 0x23cf04: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CF08u;
        goto label_23cf08;
    }
    ctx->pc = 0x23CF00u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23CF08u);
        ctx->pc = 0x23CF04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CF00u;
        // 0x23cf04: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23CF00u, 0x23CF08u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23CF08u;
label_23cf08:
    // 0x23cf08: 0x26440234  addiu       $a0, $s2, 0x234
    ctx->pc = 0x23cf08u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 18), 564));
label_23cf0c:
    // 0x23cf0c: 0xc0b0942  jal         func_2C2508
label_23cf10:
    if (ctx->pc == 0x23CF10u) {
        ctx->pc = 0x23CF10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CF0Cu;
        // 0x23cf10: 0x3a0282d  daddu       $a1, $sp, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CF14u;
        goto label_23cf14;
    }
    ctx->pc = 0x23CF0Cu;
    SET_GPR_U32(ctx, 31, 0x23CF14u);
    ctx->pc = 0x23CF10u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CF0Cu;
    // 0x23cf10: 0x3a0282d  daddu       $a1, $sp, $zero (Delay Slot)
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2508u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2508u, 0x23CF0Cu, 0x23CF14u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CF14u;
label_23cf14:
    // 0x23cf14: 0x7bb00860  lq          $s0, 0x860($sp)
    ctx->pc = 0x23cf14u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 2144)));
label_23cf18:
    // 0x23cf18: 0x7bb10850  lq          $s1, 0x850($sp)
    ctx->pc = 0x23cf18u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 2128)));
label_23cf1c:
    // 0x23cf1c: 0x7bb20840  lq          $s2, 0x840($sp)
    ctx->pc = 0x23cf1cu;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 2112)));
label_23cf20:
    // 0x23cf20: 0x7bb30830  lq          $s3, 0x830($sp)
    ctx->pc = 0x23cf20u;
    SET_GPR_VEC(ctx, 19, READ128(ADD32(GPR_U32(ctx, 29), 2096)));
label_23cf24:
    // 0x23cf24: 0x7bb40820  lq          $s4, 0x820($sp)
    ctx->pc = 0x23cf24u;
    SET_GPR_VEC(ctx, 20, READ128(ADD32(GPR_U32(ctx, 29), 2080)));
label_23cf28:
    // 0x23cf28: 0x7bb50810  lq          $s5, 0x810($sp)
    ctx->pc = 0x23cf28u;
    SET_GPR_VEC(ctx, 21, READ128(ADD32(GPR_U32(ctx, 29), 2064)));
label_23cf2c:
    // 0x23cf2c: 0xdfbf0800  ld          $ra, 0x800($sp)
    ctx->pc = 0x23cf2cu;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 2048)));
label_23cf30:
    // 0x23cf30: 0x3e00008  jr          $ra
label_23cf34:
    if (ctx->pc == 0x23CF34u) {
        ctx->pc = 0x23CF34u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CF30u;
        // 0x23cf34: 0x27bd0870  addiu       $sp, $sp, 0x870 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 2160));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CF38u;
        goto label_23cf38;
    }
    ctx->pc = 0x23CF30u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x23CF34u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CF30u;
        // 0x23cf34: 0x27bd0870  addiu       $sp, $sp, 0x870 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 2160));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23CF30u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x23CF38u;
label_23cf38:
    // 0x23cf38: 0x27bdf9a0  addiu       $sp, $sp, -0x660
    ctx->pc = 0x23cf38u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294965664));
label_23cf3c:
    // 0x23cf3c: 0x7fb40610  sq          $s4, 0x610($sp)
    ctx->pc = 0x23cf3cu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 1552), GPR_VEC(ctx, 20));
label_23cf40:
    // 0x23cf40: 0xa0a02d  daddu       $s4, $a1, $zero
    ctx->pc = 0x23cf40u;
    SET_GPR_U64(ctx, 20, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_23cf44:
    // 0x23cf44: 0x7fb30620  sq          $s3, 0x620($sp)
    ctx->pc = 0x23cf44u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 1568), GPR_VEC(ctx, 19));
label_23cf48:
    // 0x23cf48: 0x2683ffff  addiu       $v1, $s4, -0x1
    ctx->pc = 0x23cf48u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 20), 4294967295));
label_23cf4c:
    // 0x23cf4c: 0x7fb00650  sq          $s0, 0x650($sp)
    ctx->pc = 0x23cf4cu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 1616), GPR_VEC(ctx, 16));
label_23cf50:
    // 0x23cf50: 0x7fb10640  sq          $s1, 0x640($sp)
    ctx->pc = 0x23cf50u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 1600), GPR_VEC(ctx, 17));
label_23cf54:
    // 0x23cf54: 0x80982d  daddu       $s3, $a0, $zero
    ctx->pc = 0x23cf54u;
    SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_23cf58:
    // 0x23cf58: 0x7fb20630  sq          $s2, 0x630($sp)
    ctx->pc = 0x23cf58u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 1584), GPR_VEC(ctx, 18));
label_23cf5c:
    // 0x23cf5c: 0x2c620038  sltiu       $v0, $v1, 0x38
    ctx->pc = 0x23cf5cu;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 3) < (uint64_t)(int64_t)(int32_t)56) ? 1 : 0);
label_23cf60:
    // 0x23cf60: 0x1040017a  beqz        $v0, . + 4 + (0x17A << 2)
label_23cf64:
    if (ctx->pc == 0x23CF64u) {
        ctx->pc = 0x23CF64u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CF60u;
        // 0x23cf64: 0xffbf0600  sd          $ra, 0x600($sp) (Delay Slot)
        WRITE64(ADD32(GPR_U32(ctx, 29), 1536), GPR_U64(ctx, 31));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CF68u;
        goto label_23cf68;
    }
    ctx->pc = 0x23CF60u;
    {
        const bool branch_taken_0x23cf60 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x23CF64u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CF60u;
        // 0x23cf64: 0xffbf0600  sd          $ra, 0x600($sp) (Delay Slot)
        WRITE64(ADD32(GPR_U32(ctx, 29), 1536), GPR_U64(ctx, 31));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23cf60) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23CF68u;
label_23cf68:
    // 0x23cf68: 0x3c020048  lui         $v0, 0x48
    ctx->pc = 0x23cf68u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)72 << 16));
label_23cf6c:
    // 0x23cf6c: 0x31880  sll         $v1, $v1, 2
    ctx->pc = 0x23cf6cu;
    SET_GPR_S32(ctx, 3, (int32_t)SLL32(GPR_U32(ctx, 3), 2));
label_23cf70:
    // 0x23cf70: 0x2442c1a0  addiu       $v0, $v0, -0x3E60
    ctx->pc = 0x23cf70u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 4294951328));
label_23cf74:
    // 0x23cf74: 0x621821  addu        $v1, $v1, $v0
    ctx->pc = 0x23cf74u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), GPR_U32(ctx, 2)));
label_23cf78:
    // 0x23cf78: 0x8c640000  lw          $a0, 0x0($v1)
    ctx->pc = 0x23cf78u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 0)));
label_23cf7c:
    // 0x23cf7c: 0x800008  jr          $a0
label_23cf80:
    if (ctx->pc == 0x23CF80u) {
        ctx->pc = 0x23CF84u;
        goto label_23cf84;
    }
    ctx->pc = 0x23CF7Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 4);
        ctx->pc = jumpTarget;
        switch (jumpTarget) {
            case 0x23CF84u: goto label_23cf84;
            case 0x23CFACu: goto label_23cfac;
            case 0x23CFC4u: goto label_23cfc4;
            case 0x23D01Cu: goto label_23d01c;
            case 0x23D074u: goto label_23d074;
            case 0x23D088u: goto label_23d088;
            case 0x23D0A0u: goto label_23d0a0;
            case 0x23D0F4u: goto label_23d0f4;
            case 0x23D120u: goto label_23d120;
            case 0x23D13Cu: goto label_23d13c;
            case 0x23D17Cu: goto label_23d17c;
            case 0x23D198u: goto label_23d198;
            case 0x23D1A0u: goto label_23d1a0;
            case 0x23D1BCu: goto label_23d1bc;
            case 0x23D2F8u: goto label_23d2f8;
            case 0x23D304u: goto label_23d304;
            case 0x23D354u: goto label_23d354;
            case 0x23D36Cu: goto label_23d36c;
            case 0x23D3A4u: goto label_23d3a4;
            case 0x23D3ACu: goto label_23d3ac;
            case 0x23D3C4u: goto label_23d3c4;
            case 0x23D3DCu: goto label_23d3dc;
            case 0x23D3E4u: goto label_23d3e4;
            case 0x23D3ECu: goto label_23d3ec;
            case 0x23D410u: goto label_23d410;
            case 0x23D418u: goto label_23d418;
            case 0x23D42Cu: goto label_23d42c;
            case 0x23D440u: goto label_23d440;
            case 0x23D454u: goto label_23d454;
            case 0x23D468u: goto label_23d468;
            case 0x23D47Cu: goto label_23d47c;
            case 0x23D490u: goto label_23d490;
            case 0x23D498u: goto label_23d498;
            case 0x23D4DCu: goto label_23d4dc;
            case 0x23D4E4u: goto label_23d4e4;
            case 0x23D4ECu: goto label_23d4ec;
            case 0x23D4F4u: goto label_23d4f4;
            case 0x23D520u: goto label_23d520;
            case 0x23D534u: goto label_23d534;
            case 0x23D53Cu: goto label_23d53c;
            case 0x23D548u: goto label_23d548;
            case 0x23D54Cu: goto label_23d54c;
            default: break;
        }
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23CF7Cu, 0x0u, PS2Runtime::GuestBranchKind::IndirectJump, "JR")) {
            return;
        }
    }
    ctx->pc = 0x23CF84u;
label_23cf84:
    // 0x23cf84: 0xaf80fb88  sw          $zero, -0x478($gp)
    ctx->pc = 0x23cf84u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 0));
label_23cf88:
    // 0x23cf88: 0x260202d  daddu       $a0, $s3, $zero
    ctx->pc = 0x23cf88u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
label_23cf8c:
    // 0x23cf8c: 0xc08f55c  jal         func_23D570
label_23cf90:
    if (ctx->pc == 0x23CF90u) {
        ctx->pc = 0x23CF90u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CF8Cu;
        // 0x23cf90: 0x24050001  addiu       $a1, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CF94u;
        goto label_23cf94;
    }
    ctx->pc = 0x23CF8Cu;
    SET_GPR_U32(ctx, 31, 0x23CF94u);
    ctx->pc = 0x23CF90u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CF8Cu;
    // 0x23cf90: 0x24050001  addiu       $a1, $zero, 0x1 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
    ctx->in_delay_slot = false;
    ctx->pc = 0x23D570u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x23D570u, 0x23CF8Cu, 0x23CF94u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CF94u;
label_23cf94:
    // 0x23cf94: 0x2402ffff  addiu       $v0, $zero, -0x1
    ctx->pc = 0x23cf94u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
label_23cf98:
    // 0x23cf98: 0xae6000c4  sw          $zero, 0xC4($s3)
    ctx->pc = 0x23cf98u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 196), GPR_U32(ctx, 0));
label_23cf9c:
    // 0x23cf9c: 0xae6200fc  sw          $v0, 0xFC($s3)
    ctx->pc = 0x23cf9cu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 252), GPR_U32(ctx, 2));
label_23cfa0:
    // 0x23cfa0: 0xae6000bc  sw          $zero, 0xBC($s3)
    ctx->pc = 0x23cfa0u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 188), GPR_U32(ctx, 0));
label_23cfa4:
    // 0x23cfa4: 0x10000169  b           . + 4 + (0x169 << 2)
label_23cfa8:
    if (ctx->pc == 0x23CFA8u) {
        ctx->pc = 0x23CFA8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CFA4u;
        // 0x23cfa8: 0xae6000c0  sw          $zero, 0xC0($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 192), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CFACu;
        goto label_23cfac;
    }
    ctx->pc = 0x23CFA4u;
    {
        const bool branch_taken_0x23cfa4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23CFA8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CFA4u;
        // 0x23cfa8: 0xae6000c0  sw          $zero, 0xC0($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 192), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23cfa4) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23CFACu;
label_23cfac:
    // 0x23cfac: 0xae6000c8  sw          $zero, 0xC8($s3)
    ctx->pc = 0x23cfacu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 200), GPR_U32(ctx, 0));
label_23cfb0:
    // 0x23cfb0: 0x260202d  daddu       $a0, $s3, $zero
    ctx->pc = 0x23cfb0u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
label_23cfb4:
    // 0x23cfb4: 0xc08fec8  jal         func_23FB20
label_23cfb8:
    if (ctx->pc == 0x23CFB8u) {
        ctx->pc = 0x23CFB8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CFB4u;
        // 0x23cfb8: 0x8e650428  lw          $a1, 0x428($s3) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1064)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CFBCu;
        goto label_23cfbc;
    }
    ctx->pc = 0x23CFB4u;
    SET_GPR_U32(ctx, 31, 0x23CFBCu);
    ctx->pc = 0x23CFB8u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CFB4u;
    // 0x23cfb8: 0x8e650428  lw          $a1, 0x428($s3) (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1064)));
    ctx->in_delay_slot = false;
    ctx->pc = 0x23FB20u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x23FB20u, 0x23CFB4u, 0x23CFBCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CFBCu;
label_23cfbc:
    // 0x23cfbc: 0x1000004b  b           . + 4 + (0x4B << 2)
label_23cfc0:
    if (ctx->pc == 0x23CFC0u) {
        ctx->pc = 0x23CFC0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CFBCu;
        // 0x23cfc0: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CFC4u;
        goto label_23cfc4;
    }
    ctx->pc = 0x23CFBCu;
    {
        const bool branch_taken_0x23cfbc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23CFC0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CFBCu;
        // 0x23cfc0: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23cfbc) {
            ctx->pc = 0x23D0ECu;
            goto label_23d0ec;
        }
    }
    ctx->pc = 0x23CFC4u;
label_23cfc4:
    // 0x23cfc4: 0x8e620428  lw          $v0, 0x428($s3)
    ctx->pc = 0x23cfc4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1064)));
label_23cfc8:
    // 0x23cfc8: 0x260202d  daddu       $a0, $s3, $zero
    ctx->pc = 0x23cfc8u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
label_23cfcc:
    // 0x23cfcc: 0xc0907ec  jal         func_241FB0
label_23cfd0:
    if (ctx->pc == 0x23CFD0u) {
        ctx->pc = 0x23CFD0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CFCCu;
        // 0x23cfd0: 0xae62042c  sw          $v0, 0x42C($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 1068), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CFD4u;
        goto label_23cfd4;
    }
    ctx->pc = 0x23CFCCu;
    SET_GPR_U32(ctx, 31, 0x23CFD4u);
    ctx->pc = 0x23CFD0u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23CFCCu;
    // 0x23cfd0: 0xae62042c  sw          $v0, 0x42C($s3) (Delay Slot)
    WRITE32(ADD32(GPR_U32(ctx, 19), 1068), GPR_U32(ctx, 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x241FB0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x241FB0u, 0x23CFCCu, 0x23CFD4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23CFD4u;
label_23cfd4:
    // 0x23cfd4: 0x8e650434  lw          $a1, 0x434($s3)
    ctx->pc = 0x23cfd4u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23cfd8:
    // 0x23cfd8: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23cfd8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23cfdc:
    // 0x23cfdc: 0x846401a8  lh          $a0, 0x1A8($v1)
    ctx->pc = 0x23cfdcu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 424)));
label_23cfe0:
    // 0x23cfe0: 0x8c6201ac  lw          $v0, 0x1AC($v1)
    ctx->pc = 0x23cfe0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 428)));
label_23cfe4:
    // 0x23cfe4: 0x40f809  jalr        $v0
label_23cfe8:
    if (ctx->pc == 0x23CFE8u) {
        ctx->pc = 0x23CFE8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CFE4u;
        // 0x23cfe8: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CFECu;
        goto label_23cfec;
    }
    ctx->pc = 0x23CFE4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23CFECu);
        ctx->pc = 0x23CFE8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CFE4u;
        // 0x23cfe8: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23CFE4u, 0x23CFECu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23CFECu;
label_23cfec:
    // 0x23cfec: 0x54400007  bnel        $v0, $zero, . + 4 + (0x7 << 2)
label_23cff0:
    if (ctx->pc == 0x23CFF0u) {
        ctx->pc = 0x23CFF0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23CFECu;
        // 0x23cff0: 0x8e620090  lw          $v0, 0x90($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 144)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23CFF4u;
        goto label_23cff4;
    }
    ctx->pc = 0x23CFECu;
    {
        const bool branch_taken_0x23cfec = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x23cfec) {
            ctx->pc = 0x23CFF0u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23CFECu;
            // 0x23cff0: 0x8e620090  lw          $v0, 0x90($s3) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 144)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23D00Cu;
            goto label_23d00c;
        }
    }
    ctx->pc = 0x23CFF4u;
label_23cff4:
    // 0x23cff4: 0x8e62042c  lw          $v0, 0x42C($s3)
    ctx->pc = 0x23cff4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1068)));
label_23cff8:
    // 0x23cff8: 0x240300e0  addiu       $v1, $zero, 0xE0
    ctx->pc = 0x23cff8u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 224));
label_23cffc:
    // 0x23cffc: 0x432018  mult        $a0, $v0, $v1
    ctx->pc = 0x23cffcu;
    { int64_t result = (int64_t)GPR_S32(ctx, 2) * (int64_t)GPR_S32(ctx, 3); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 4, (int32_t)result); }
label_23d000:
    // 0x23d000: 0x931021  addu        $v0, $a0, $s3
    ctx->pc = 0x23d000u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 19)));
label_23d004:
    // 0x23d004: 0xac400350  sw          $zero, 0x350($v0)
    ctx->pc = 0x23d004u;
    WRITE32(ADD32(GPR_U32(ctx, 2), 848), GPR_U32(ctx, 0));
label_23d008:
    // 0x23d008: 0x8e620090  lw          $v0, 0x90($s3)
    ctx->pc = 0x23d008u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 144)));
label_23d00c:
    // 0x23d00c: 0x40f809  jalr        $v0
label_23d010:
    if (ctx->pc == 0x23D010u) {
        ctx->pc = 0x23D014u;
        goto label_23d014;
    }
    ctx->pc = 0x23D00Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D014u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D00Cu, 0x23D014u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D014u;
label_23d014:
    // 0x23d014: 0x1000014f  b           . + 4 + (0x14F << 2)
label_23d018:
    if (ctx->pc == 0x23D018u) {
        ctx->pc = 0x23D018u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D014u;
        // 0x23d018: 0x7bb00650  lq          $s0, 0x650($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 1616)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D01Cu;
        goto label_23d01c;
    }
    ctx->pc = 0x23D014u;
    {
        const bool branch_taken_0x23d014 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D018u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D014u;
        // 0x23d018: 0x7bb00650  lq          $s0, 0x650($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 1616)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d014) {
            ctx->pc = 0x23D554u;
            goto label_23d554;
        }
    }
    ctx->pc = 0x23D01Cu;
label_23d01c:
    // 0x23d01c: 0xae6000c8  sw          $zero, 0xC8($s3)
    ctx->pc = 0x23d01cu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 200), GPR_U32(ctx, 0));
label_23d020:
    // 0x23d020: 0x8e650434  lw          $a1, 0x434($s3)
    ctx->pc = 0x23d020u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d024:
    // 0x23d024: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23d024u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23d028:
    // 0x23d028: 0x84640058  lh          $a0, 0x58($v1)
    ctx->pc = 0x23d028u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 88)));
label_23d02c:
    // 0x23d02c: 0x8c62005c  lw          $v0, 0x5C($v1)
    ctx->pc = 0x23d02cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 92)));
label_23d030:
    // 0x23d030: 0x40f809  jalr        $v0
label_23d034:
    if (ctx->pc == 0x23D034u) {
        ctx->pc = 0x23D034u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D030u;
        // 0x23d034: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D038u;
        goto label_23d038;
    }
    ctx->pc = 0x23D030u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D038u);
        ctx->pc = 0x23D034u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D030u;
        // 0x23d034: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D030u, 0x23D038u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D038u;
label_23d038:
    // 0x23d038: 0x10400008  beqz        $v0, . + 4 + (0x8 << 2)
label_23d03c:
    if (ctx->pc == 0x23D03Cu) {
        ctx->pc = 0x23D03Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D038u;
        // 0x23d03c: 0x24050035  addiu       $a1, $zero, 0x35 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 53));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D040u;
        goto label_23d040;
    }
    ctx->pc = 0x23D038u;
    {
        const bool branch_taken_0x23d038 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D03Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D038u;
        // 0x23d03c: 0x24050035  addiu       $a1, $zero, 0x35 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 53));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d038) {
            ctx->pc = 0x23D05Cu;
            goto label_23d05c;
        }
    }
    ctx->pc = 0x23D040u;
label_23d040:
    // 0x23d040: 0x8e620748  lw          $v0, 0x748($s3)
    ctx->pc = 0x23d040u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1864)));
label_23d044:
    // 0x23d044: 0x84440008  lh          $a0, 0x8($v0)
    ctx->pc = 0x23d044u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 8)));
label_23d048:
    // 0x23d048: 0x8c43000c  lw          $v1, 0xC($v0)
    ctx->pc = 0x23d048u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 12)));
label_23d04c:
    // 0x23d04c: 0x60f809  jalr        $v1
label_23d050:
    if (ctx->pc == 0x23D050u) {
        ctx->pc = 0x23D050u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D04Cu;
        // 0x23d050: 0x2642021  addu        $a0, $s3, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 19), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D054u;
        goto label_23d054;
    }
    ctx->pc = 0x23D04Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23D054u);
        ctx->pc = 0x23D050u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D04Cu;
        // 0x23d050: 0x2642021  addu        $a0, $s3, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 19), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D04Cu, 0x23D054u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D054u;
label_23d054:
    // 0x23d054: 0x1000013f  b           . + 4 + (0x13F << 2)
label_23d058:
    if (ctx->pc == 0x23D058u) {
        ctx->pc = 0x23D058u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D054u;
        // 0x23d058: 0x7bb00650  lq          $s0, 0x650($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 1616)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D05Cu;
        goto label_23d05c;
    }
    ctx->pc = 0x23D054u;
    {
        const bool branch_taken_0x23d054 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D058u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D054u;
        // 0x23d058: 0x7bb00650  lq          $s0, 0x650($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 1616)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d054) {
            ctx->pc = 0x23D554u;
            goto label_23d554;
        }
    }
    ctx->pc = 0x23D05Cu;
label_23d05c:
    // 0x23d05c: 0x8e660434  lw          $a2, 0x434($s3)
    ctx->pc = 0x23d05cu;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d060:
    // 0x23d060: 0x266501b4  addiu       $a1, $s3, 0x1B4
    ctx->pc = 0x23d060u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 19), 436));
label_23d064:
    // 0x23d064: 0x8cc20000  lw          $v0, 0x0($a2)
    ctx->pc = 0x23d064u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_23d068:
    // 0x23d068: 0x84440038  lh          $a0, 0x38($v0)
    ctx->pc = 0x23d068u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 56)));
label_23d06c:
    // 0x23d06c: 0x100000c9  b           . + 4 + (0xC9 << 2)
label_23d070:
    if (ctx->pc == 0x23D070u) {
        ctx->pc = 0x23D070u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D06Cu;
        // 0x23d070: 0x8c43003c  lw          $v1, 0x3C($v0) (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 60)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D074u;
        goto label_23d074;
    }
    ctx->pc = 0x23D06Cu;
    {
        const bool branch_taken_0x23d06c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D070u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D06Cu;
        // 0x23d070: 0x8c43003c  lw          $v1, 0x3C($v0) (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 60)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d06c) {
            ctx->pc = 0x23D394u;
            goto label_23d394;
        }
    }
    ctx->pc = 0x23D074u;
label_23d074:
    // 0x23d074: 0x8e620094  lw          $v0, 0x94($s3)
    ctx->pc = 0x23d074u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 148)));
label_23d078:
    // 0x23d078: 0x40f809  jalr        $v0
label_23d07c:
    if (ctx->pc == 0x23D07Cu) {
        ctx->pc = 0x23D080u;
        goto label_23d080;
    }
    ctx->pc = 0x23D078u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D080u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D078u, 0x23D080u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D080u;
label_23d080:
    // 0x23d080: 0x10000134  b           . + 4 + (0x134 << 2)
label_23d084:
    if (ctx->pc == 0x23D084u) {
        ctx->pc = 0x23D084u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D080u;
        // 0x23d084: 0x7bb00650  lq          $s0, 0x650($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 1616)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D088u;
        goto label_23d088;
    }
    ctx->pc = 0x23D080u;
    {
        const bool branch_taken_0x23d080 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D084u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D080u;
        // 0x23d084: 0x7bb00650  lq          $s0, 0x650($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 1616)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d080) {
            ctx->pc = 0x23D554u;
            goto label_23d554;
        }
    }
    ctx->pc = 0x23D088u;
label_23d088:
    // 0x23d088: 0x3c013f80  lui         $at, 0x3F80
    ctx->pc = 0x23d088u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16256 << 16));
label_23d08c:
    // 0x23d08c: 0x44810000  mtc1        $at, $f0
    ctx->pc = 0x23d08cu;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[0], &bits, sizeof(bits)); }
label_23d090:
    // 0x23d090: 0x2402005a  addiu       $v0, $zero, 0x5A
    ctx->pc = 0x23d090u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 90));
label_23d094:
    // 0x23d094: 0xc781aeb8  lwc1        $f1, -0x5148($gp)
    ctx->pc = 0x23d094u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294946488)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_23d098:
    // 0x23d098: 0x100000da  b           . + 4 + (0xDA << 2)
label_23d09c:
    if (ctx->pc == 0x23D09Cu) {
        ctx->pc = 0x23D09Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D098u;
        // 0x23d09c: 0xae620108  sw          $v0, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D0A0u;
        goto label_23d0a0;
    }
    ctx->pc = 0x23D098u;
    {
        const bool branch_taken_0x23d098 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D09Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D098u;
        // 0x23d09c: 0xae620108  sw          $v0, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d098) {
            ctx->pc = 0x23D404u;
            goto label_23d404;
        }
    }
    ctx->pc = 0x23D0A0u;
label_23d0a0:
    // 0x23d0a0: 0x8e650434  lw          $a1, 0x434($s3)
    ctx->pc = 0x23d0a0u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d0a4:
    // 0x23d0a4: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23d0a4u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23d0a8:
    // 0x23d0a8: 0x84640058  lh          $a0, 0x58($v1)
    ctx->pc = 0x23d0a8u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 88)));
label_23d0ac:
    // 0x23d0ac: 0x8c62005c  lw          $v0, 0x5C($v1)
    ctx->pc = 0x23d0acu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 92)));
label_23d0b0:
    // 0x23d0b0: 0x40f809  jalr        $v0
label_23d0b4:
    if (ctx->pc == 0x23D0B4u) {
        ctx->pc = 0x23D0B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D0B0u;
        // 0x23d0b4: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D0B8u;
        goto label_23d0b8;
    }
    ctx->pc = 0x23D0B0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D0B8u);
        ctx->pc = 0x23D0B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D0B0u;
        // 0x23d0b4: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D0B0u, 0x23D0B8u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D0B8u;
label_23d0b8:
    // 0x23d0b8: 0x54400125  bnel        $v0, $zero, . + 4 + (0x125 << 2)
label_23d0bc:
    if (ctx->pc == 0x23D0BCu) {
        ctx->pc = 0x23D0BCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D0B8u;
        // 0x23d0bc: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D0C0u;
        goto label_23d0c0;
    }
    ctx->pc = 0x23D0B8u;
    {
        const bool branch_taken_0x23d0b8 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x23d0b8) {
            ctx->pc = 0x23D0BCu;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23D0B8u;
            // 0x23d0bc: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
            WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D0C0u;
label_23d0c0:
    // 0x23d0c0: 0x8e620338  lw          $v0, 0x338($s3)
    ctx->pc = 0x23d0c0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 824)));
label_23d0c4:
    // 0x23d0c4: 0x54400122  bnel        $v0, $zero, . + 4 + (0x122 << 2)
label_23d0c8:
    if (ctx->pc == 0x23D0C8u) {
        ctx->pc = 0x23D0C8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D0C4u;
        // 0x23d0c8: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D0CCu;
        goto label_23d0cc;
    }
    ctx->pc = 0x23D0C4u;
    {
        const bool branch_taken_0x23d0c4 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x23d0c4) {
            ctx->pc = 0x23D0C8u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23D0C4u;
            // 0x23d0c8: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
            WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D0CCu;
label_23d0cc:
    // 0x23d0cc: 0x8e660434  lw          $a2, 0x434($s3)
    ctx->pc = 0x23d0ccu;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d0d0:
    // 0x23d0d0: 0x8e650428  lw          $a1, 0x428($s3)
    ctx->pc = 0x23d0d0u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1064)));
label_23d0d4:
    // 0x23d0d4: 0x8cc20000  lw          $v0, 0x0($a2)
    ctx->pc = 0x23d0d4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_23d0d8:
    // 0x23d0d8: 0x84440028  lh          $a0, 0x28($v0)
    ctx->pc = 0x23d0d8u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 40)));
label_23d0dc:
    // 0x23d0dc: 0x8c43002c  lw          $v1, 0x2C($v0)
    ctx->pc = 0x23d0dcu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 44)));
label_23d0e0:
    // 0x23d0e0: 0x60f809  jalr        $v1
label_23d0e4:
    if (ctx->pc == 0x23D0E4u) {
        ctx->pc = 0x23D0E4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D0E0u;
        // 0x23d0e4: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D0E8u;
        goto label_23d0e8;
    }
    ctx->pc = 0x23D0E0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23D0E8u);
        ctx->pc = 0x23D0E4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D0E0u;
        // 0x23d0e4: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D0E0u, 0x23D0E8u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D0E8u;
label_23d0e8:
    // 0x23d0e8: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x23d0e8u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d0ec:
    // 0x23d0ec: 0x10000117  b           . + 4 + (0x117 << 2)
label_23d0f0:
    if (ctx->pc == 0x23D0F0u) {
        ctx->pc = 0x23D0F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D0ECu;
        // 0x23d0f0: 0xae620338  sw          $v0, 0x338($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 824), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D0F4u;
        goto label_23d0f4;
    }
    ctx->pc = 0x23D0ECu;
    {
        const bool branch_taken_0x23d0ec = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D0F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D0ECu;
        // 0x23d0f0: 0xae620338  sw          $v0, 0x338($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 824), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d0ec) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23D0F4u;
label_23d0f4:
    // 0x23d0f4: 0x3c013f80  lui         $at, 0x3F80
    ctx->pc = 0x23d0f4u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16256 << 16));
label_23d0f8:
    // 0x23d0f8: 0x44810800  mtc1        $at, $f1
    ctx->pc = 0x23d0f8u;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[1], &bits, sizeof(bits)); }
label_23d0fc:
    // 0x23d0fc: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x23d0fcu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d100:
    // 0x23d100: 0xc780aebc  lwc1        $f0, -0x5144($gp)
    ctx->pc = 0x23d100u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294946492)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
label_23d104:
    // 0x23d104: 0x8e630054  lw          $v1, 0x54($s3)
    ctx->pc = 0x23d104u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 84)));
label_23d108:
    // 0x23d108: 0xae6200c0  sw          $v0, 0xC0($s3)
    ctx->pc = 0x23d108u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 192), GPR_U32(ctx, 2));
label_23d10c:
    // 0x23d10c: 0xe6610110  swc1        $f1, 0x110($s3)
    ctx->pc = 0x23d10cu;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 272), bits); }
label_23d110:
    // 0x23d110: 0x60f809  jalr        $v1
label_23d114:
    if (ctx->pc == 0x23D114u) {
        ctx->pc = 0x23D114u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D110u;
        // 0x23d114: 0xe6600114  swc1        $f0, 0x114($s3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 276), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D118u;
        goto label_23d118;
    }
    ctx->pc = 0x23D110u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23D118u);
        ctx->pc = 0x23D114u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D110u;
        // 0x23d114: 0xe6600114  swc1        $f0, 0x114($s3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 276), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D110u, 0x23D118u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D118u;
label_23d118:
    // 0x23d118: 0x1000010d  b           . + 4 + (0x10D << 2)
label_23d11c:
    if (ctx->pc == 0x23D11Cu) {
        ctx->pc = 0x23D11Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D118u;
        // 0x23d11c: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D120u;
        goto label_23d120;
    }
    ctx->pc = 0x23D118u;
    {
        const bool branch_taken_0x23d118 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D11Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D118u;
        // 0x23d11c: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d118) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D120u;
label_23d120:
    // 0x23d120: 0xae6000c8  sw          $zero, 0xC8($s3)
    ctx->pc = 0x23d120u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 200), GPR_U32(ctx, 0));
label_23d124:
    // 0x23d124: 0x266501b4  addiu       $a1, $s3, 0x1B4
    ctx->pc = 0x23d124u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 19), 436));
label_23d128:
    // 0x23d128: 0x8e660434  lw          $a2, 0x434($s3)
    ctx->pc = 0x23d128u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d12c:
    // 0x23d12c: 0x8cc20000  lw          $v0, 0x0($a2)
    ctx->pc = 0x23d12cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_23d130:
    // 0x23d130: 0x84440038  lh          $a0, 0x38($v0)
    ctx->pc = 0x23d130u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 56)));
label_23d134:
    // 0x23d134: 0x10000097  b           . + 4 + (0x97 << 2)
label_23d138:
    if (ctx->pc == 0x23D138u) {
        ctx->pc = 0x23D138u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D134u;
        // 0x23d138: 0x8c43003c  lw          $v1, 0x3C($v0) (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 60)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D13Cu;
        goto label_23d13c;
    }
    ctx->pc = 0x23D134u;
    {
        const bool branch_taken_0x23d134 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D138u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D134u;
        // 0x23d138: 0x8c43003c  lw          $v1, 0x3C($v0) (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 60)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d134) {
            ctx->pc = 0x23D394u;
            goto label_23d394;
        }
    }
    ctx->pc = 0x23D13Cu;
label_23d13c:
    // 0x23d13c: 0x8e650434  lw          $a1, 0x434($s3)
    ctx->pc = 0x23d13cu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d140:
    // 0x23d140: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x23d140u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d144:
    // 0x23d144: 0xaf82fb88  sw          $v0, -0x478($gp)
    ctx->pc = 0x23d144u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 2));
label_23d148:
    // 0x23d148: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23d148u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23d14c:
    // 0x23d14c: 0x84640040  lh          $a0, 0x40($v1)
    ctx->pc = 0x23d14cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 64)));
label_23d150:
    // 0x23d150: 0x8c620044  lw          $v0, 0x44($v1)
    ctx->pc = 0x23d150u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 68)));
label_23d154:
    // 0x23d154: 0x40f809  jalr        $v0
label_23d158:
    if (ctx->pc == 0x23D158u) {
        ctx->pc = 0x23D158u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D154u;
        // 0x23d158: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D15Cu;
        goto label_23d15c;
    }
    ctx->pc = 0x23D154u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D15Cu);
        ctx->pc = 0x23D158u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D154u;
        // 0x23d158: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D154u, 0x23D15Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D15Cu;
label_23d15c:
    // 0x23d15c: 0x3c013f80  lui         $at, 0x3F80
    ctx->pc = 0x23d15cu;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16256 << 16));
label_23d160:
    // 0x23d160: 0x44810800  mtc1        $at, $f1
    ctx->pc = 0x23d160u;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[1], &bits, sizeof(bits)); }
label_23d164:
    // 0x23d164: 0x24020078  addiu       $v0, $zero, 0x78
    ctx->pc = 0x23d164u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 120));
label_23d168:
    // 0x23d168: 0xc780aec0  lwc1        $f0, -0x5140($gp)
    ctx->pc = 0x23d168u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294946496)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
label_23d16c:
    // 0x23d16c: 0xe6610110  swc1        $f1, 0x110($s3)
    ctx->pc = 0x23d16cu;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 272), bits); }
label_23d170:
    // 0x23d170: 0xe6600114  swc1        $f0, 0x114($s3)
    ctx->pc = 0x23d170u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 276), bits); }
label_23d174:
    // 0x23d174: 0x100000f5  b           . + 4 + (0xF5 << 2)
label_23d178:
    if (ctx->pc == 0x23D178u) {
        ctx->pc = 0x23D178u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D174u;
        // 0x23d178: 0xae620108  sw          $v0, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D17Cu;
        goto label_23d17c;
    }
    ctx->pc = 0x23D174u;
    {
        const bool branch_taken_0x23d174 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D178u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D174u;
        // 0x23d178: 0xae620108  sw          $v0, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d174) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23D17Cu;
label_23d17c:
    // 0x23d17c: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x23d17cu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d180:
    // 0x23d180: 0x8e6500f8  lw          $a1, 0xF8($s3)
    ctx->pc = 0x23d180u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 248)));
label_23d184:
    // 0x23d184: 0xaf82fb88  sw          $v0, -0x478($gp)
    ctx->pc = 0x23d184u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 2));
label_23d188:
    // 0x23d188: 0xc08f36c  jal         func_23CDB0
label_23d18c:
    if (ctx->pc == 0x23D18Cu) {
        ctx->pc = 0x23D18Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D188u;
        // 0x23d18c: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D190u;
        goto label_23d190;
    }
    ctx->pc = 0x23D188u;
    SET_GPR_U32(ctx, 31, 0x23D190u);
    ctx->pc = 0x23D18Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23D188u;
    // 0x23d18c: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x23CDB0u;
    goto label_23cdb0;
    ctx->pc = 0x23D190u;
label_23d190:
    // 0x23d190: 0xae60010c  sw          $zero, 0x10C($s3)
    ctx->pc = 0x23d190u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 268), GPR_U32(ctx, 0));
label_23d194:
    // 0x23d194: 0xae6000e4  sw          $zero, 0xE4($s3)
    ctx->pc = 0x23d194u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 228), GPR_U32(ctx, 0));
label_23d198:
    // 0x23d198: 0x100000ec  b           . + 4 + (0xEC << 2)
label_23d19c:
    if (ctx->pc == 0x23D19Cu) {
        ctx->pc = 0x23D19Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D198u;
        // 0x23d19c: 0xae600108  sw          $zero, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D1A0u;
        goto label_23d1a0;
    }
    ctx->pc = 0x23D198u;
    {
        const bool branch_taken_0x23d198 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D19Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D198u;
        // 0x23d19c: 0xae600108  sw          $zero, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d198) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23D1A0u;
label_23d1a0:
    // 0x23d1a0: 0x24030001  addiu       $v1, $zero, 0x1
    ctx->pc = 0x23d1a0u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d1a4:
    // 0x23d1a4: 0x8e660434  lw          $a2, 0x434($s3)
    ctx->pc = 0x23d1a4u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d1a8:
    // 0x23d1a8: 0xae6300c0  sw          $v1, 0xC0($s3)
    ctx->pc = 0x23d1a8u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 192), GPR_U32(ctx, 3));
label_23d1ac:
    // 0x23d1ac: 0x8e6500f8  lw          $a1, 0xF8($s3)
    ctx->pc = 0x23d1acu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 248)));
label_23d1b0:
    // 0x23d1b0: 0x8cc20000  lw          $v0, 0x0($a2)
    ctx->pc = 0x23d1b0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_23d1b4:
    // 0x23d1b4: 0x10000075  b           . + 4 + (0x75 << 2)
label_23d1b8:
    if (ctx->pc == 0x23D1B8u) {
        ctx->pc = 0x23D1B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1B4u;
        // 0x23d1b8: 0xaf83fb88  sw          $v1, -0x478($gp) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 3));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D1BCu;
        goto label_23d1bc;
    }
    ctx->pc = 0x23D1B4u;
    {
        const bool branch_taken_0x23d1b4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D1B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1B4u;
        // 0x23d1b8: 0xaf83fb88  sw          $v1, -0x478($gp) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 3));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d1b4) {
            ctx->pc = 0x23D38Cu;
            goto label_23d38c;
        }
    }
    ctx->pc = 0x23D1BCu;
label_23d1bc:
    // 0x23d1bc: 0x8e6300b4  lw          $v1, 0xB4($s3)
    ctx->pc = 0x23d1bcu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 180)));
label_23d1c0:
    // 0x23d1c0: 0x1460000e  bnez        $v1, . + 4 + (0xE << 2)
label_23d1c4:
    if (ctx->pc == 0x23D1C4u) {
        ctx->pc = 0x23D1C4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1C0u;
        // 0x23d1c4: 0x24020002  addiu       $v0, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D1C8u;
        goto label_23d1c8;
    }
    ctx->pc = 0x23D1C0u;
    {
        const bool branch_taken_0x23d1c0 = (GPR_U64(ctx, 3) != GPR_U64(ctx, 0));
        ctx->pc = 0x23D1C4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1C0u;
        // 0x23d1c4: 0x24020002  addiu       $v0, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d1c0) {
            ctx->pc = 0x23D1FCu;
            goto label_23d1fc;
        }
    }
    ctx->pc = 0x23D1C8u;
label_23d1c8:
    // 0x23d1c8: 0x3a0302d  daddu       $a2, $sp, $zero
    ctx->pc = 0x23d1c8u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
label_23d1cc:
    // 0x23d1cc: 0x24070100  addiu       $a3, $zero, 0x100
    ctx->pc = 0x23d1ccu;
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 0), 256));
label_23d1d0:
    // 0x23d1d0: 0x282d  daddu       $a1, $zero, $zero
    ctx->pc = 0x23d1d0u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_23d1d4:
    // 0x23d1d4: 0xc090750  jal         func_241D40
label_23d1d8:
    if (ctx->pc == 0x23D1D8u) {
        ctx->pc = 0x23D1D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1D4u;
        // 0x23d1d8: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D1DCu;
        goto label_23d1dc;
    }
    ctx->pc = 0x23D1D4u;
    SET_GPR_U32(ctx, 31, 0x23D1DCu);
    ctx->pc = 0x23D1D8u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23D1D4u;
    // 0x23d1d8: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x241D40u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x241D40u, 0x23D1D4u, 0x23D1DCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23D1DCu;
label_23d1dc:
    // 0x23d1dc: 0x26720134  addiu       $s2, $s3, 0x134
    ctx->pc = 0x23d1dcu;
    SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 19), 308));
label_23d1e0:
    // 0x23d1e0: 0x27b10400  addiu       $s1, $sp, 0x400
    ctx->pc = 0x23d1e0u;
    SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 29), 1024));
label_23d1e4:
    // 0x23d1e4: 0x3c050048  lui         $a1, 0x48
    ctx->pc = 0x23d1e4u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)72 << 16));
label_23d1e8:
    // 0x23d1e8: 0x24a5c178  addiu       $a1, $a1, -0x3E88
    ctx->pc = 0x23d1e8u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 4294951288));
label_23d1ec:
    // 0x23d1ec: 0xc0b0950  jal         func_2C2540
label_23d1f0:
    if (ctx->pc == 0x23D1F0u) {
        ctx->pc = 0x23D1F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1ECu;
        // 0x23d1f0: 0x220202d  daddu       $a0, $s1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D1F4u;
        goto label_23d1f4;
    }
    ctx->pc = 0x23D1ECu;
    SET_GPR_U32(ctx, 31, 0x23D1F4u);
    ctx->pc = 0x23D1F0u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23D1ECu;
    // 0x23d1f0: 0x220202d  daddu       $a0, $s1, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2540u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2540u, 0x23D1ECu, 0x23D1F4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23D1F4u;
label_23d1f4:
    // 0x23d1f4: 0x10000023  b           . + 4 + (0x23 << 2)
label_23d1f8:
    if (ctx->pc == 0x23D1F8u) {
        ctx->pc = 0x23D1F8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1F4u;
        // 0x23d1f8: 0x27b00200  addiu       $s0, $sp, 0x200 (Delay Slot)
        SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 29), 512));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D1FCu;
        goto label_23d1fc;
    }
    ctx->pc = 0x23D1F4u;
    {
        const bool branch_taken_0x23d1f4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D1F8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1F4u;
        // 0x23d1f8: 0x27b00200  addiu       $s0, $sp, 0x200 (Delay Slot)
        SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 29), 512));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d1f4) {
            ctx->pc = 0x23D284u;
            goto label_23d284;
        }
    }
    ctx->pc = 0x23D1FCu;
label_23d1fc:
    // 0x23d1fc: 0x14620016  bne         $v1, $v0, . + 4 + (0x16 << 2)
label_23d200:
    if (ctx->pc == 0x23D200u) {
        ctx->pc = 0x23D200u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1FCu;
        // 0x23d200: 0x3a0302d  daddu       $a2, $sp, $zero (Delay Slot)
        SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D204u;
        goto label_23d204;
    }
    ctx->pc = 0x23D1FCu;
    {
        const bool branch_taken_0x23d1fc = (GPR_U64(ctx, 3) != GPR_U64(ctx, 2));
        ctx->pc = 0x23D200u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D1FCu;
        // 0x23d200: 0x3a0302d  daddu       $a2, $sp, $zero (Delay Slot)
        SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d1fc) {
            ctx->pc = 0x23D258u;
            goto label_23d258;
        }
    }
    ctx->pc = 0x23D204u;
label_23d204:
    // 0x23d204: 0x27b10400  addiu       $s1, $sp, 0x400
    ctx->pc = 0x23d204u;
    SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 29), 1024));
label_23d208:
    // 0x23d208: 0x3c050048  lui         $a1, 0x48
    ctx->pc = 0x23d208u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)72 << 16));
label_23d20c:
    // 0x23d20c: 0x24a5c178  addiu       $a1, $a1, -0x3E88
    ctx->pc = 0x23d20cu;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 4294951288));
label_23d210:
    // 0x23d210: 0xc0b0950  jal         func_2C2540
label_23d214:
    if (ctx->pc == 0x23D214u) {
        ctx->pc = 0x23D214u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D210u;
        // 0x23d214: 0x220202d  daddu       $a0, $s1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D218u;
        goto label_23d218;
    }
    ctx->pc = 0x23D210u;
    SET_GPR_U32(ctx, 31, 0x23D218u);
    ctx->pc = 0x23D214u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23D210u;
    // 0x23d214: 0x220202d  daddu       $a0, $s1, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2540u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2540u, 0x23D210u, 0x23D218u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23D218u;
label_23d218:
    // 0x23d218: 0x26720134  addiu       $s2, $s3, 0x134
    ctx->pc = 0x23d218u;
    SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 19), 308));
label_23d21c:
    // 0x23d21c: 0x3a0202d  daddu       $a0, $sp, $zero
    ctx->pc = 0x23d21cu;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
label_23d220:
    // 0x23d220: 0xc0906a8  jal         func_241AA0
label_23d224:
    if (ctx->pc == 0x23D224u) {
        ctx->pc = 0x23D224u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D220u;
        // 0x23d224: 0x24050200  addiu       $a1, $zero, 0x200 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 512));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D228u;
        goto label_23d228;
    }
    ctx->pc = 0x23D220u;
    SET_GPR_U32(ctx, 31, 0x23D228u);
    ctx->pc = 0x23D224u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23D220u;
    // 0x23d224: 0x24050200  addiu       $a1, $zero, 0x200 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 512));
    ctx->in_delay_slot = false;
    ctx->pc = 0x241AA0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x241AA0u, 0x23D220u, 0x23D228u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23D228u;
label_23d228:
    // 0x23d228: 0x27b00200  addiu       $s0, $sp, 0x200
    ctx->pc = 0x23d228u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 29), 512));
label_23d22c:
    // 0x23d22c: 0x260202d  daddu       $a0, $s3, $zero
    ctx->pc = 0x23d22cu;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
label_23d230:
    // 0x23d230: 0x24050002  addiu       $a1, $zero, 0x2
    ctx->pc = 0x23d230u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
label_23d234:
    // 0x23d234: 0x200302d  daddu       $a2, $s0, $zero
    ctx->pc = 0x23d234u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_23d238:
    // 0x23d238: 0xc090750  jal         func_241D40
label_23d23c:
    if (ctx->pc == 0x23D23Cu) {
        ctx->pc = 0x23D23Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D238u;
        // 0x23d23c: 0x24070200  addiu       $a3, $zero, 0x200 (Delay Slot)
        SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 0), 512));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D240u;
        goto label_23d240;
    }
    ctx->pc = 0x23D238u;
    SET_GPR_U32(ctx, 31, 0x23D240u);
    ctx->pc = 0x23D23Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23D238u;
    // 0x23d23c: 0x24070200  addiu       $a3, $zero, 0x200 (Delay Slot)
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 0), 512));
    ctx->in_delay_slot = false;
    ctx->pc = 0x241D40u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x241D40u, 0x23D238u, 0x23D240u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23D240u;
label_23d240:
    // 0x23d240: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x23d240u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_23d244:
    // 0x23d244: 0x200382d  daddu       $a3, $s0, $zero
    ctx->pc = 0x23d244u;
    SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_23d248:
    // 0x23d248: 0x3a0302d  daddu       $a2, $sp, $zero
    ctx->pc = 0x23d248u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
label_23d24c:
    // 0x23d24c: 0x240202d  daddu       $a0, $s2, $zero
    ctx->pc = 0x23d24cu;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_23d250:
    // 0x23d250: 0x10000015  b           . + 4 + (0x15 << 2)
label_23d254:
    if (ctx->pc == 0x23D254u) {
        ctx->pc = 0x23D254u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D250u;
        // 0x23d254: 0x24080001  addiu       $t0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D258u;
        goto label_23d258;
    }
    ctx->pc = 0x23D250u;
    {
        const bool branch_taken_0x23d250 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D254u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D250u;
        // 0x23d254: 0x24080001  addiu       $t0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d250) {
            ctx->pc = 0x23D2A8u;
            goto label_23d2a8;
        }
    }
    ctx->pc = 0x23D258u;
label_23d258:
    // 0x23d258: 0x24070100  addiu       $a3, $zero, 0x100
    ctx->pc = 0x23d258u;
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 0), 256));
label_23d25c:
    // 0x23d25c: 0x24050001  addiu       $a1, $zero, 0x1
    ctx->pc = 0x23d25cu;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d260:
    // 0x23d260: 0xc090750  jal         func_241D40
label_23d264:
    if (ctx->pc == 0x23D264u) {
        ctx->pc = 0x23D264u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D260u;
        // 0x23d264: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D268u;
        goto label_23d268;
    }
    ctx->pc = 0x23D260u;
    SET_GPR_U32(ctx, 31, 0x23D268u);
    ctx->pc = 0x23D264u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23D260u;
    // 0x23d264: 0x260202d  daddu       $a0, $s3, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x241D40u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x241D40u, 0x23D260u, 0x23D268u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23D268u;
label_23d268:
    // 0x23d268: 0x26720134  addiu       $s2, $s3, 0x134
    ctx->pc = 0x23d268u;
    SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 19), 308));
label_23d26c:
    // 0x23d26c: 0x27b10400  addiu       $s1, $sp, 0x400
    ctx->pc = 0x23d26cu;
    SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 29), 1024));
label_23d270:
    // 0x23d270: 0x3c050048  lui         $a1, 0x48
    ctx->pc = 0x23d270u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)72 << 16));
label_23d274:
    // 0x23d274: 0x24a5c178  addiu       $a1, $a1, -0x3E88
    ctx->pc = 0x23d274u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 4294951288));
label_23d278:
    // 0x23d278: 0xc0b0950  jal         func_2C2540
label_23d27c:
    if (ctx->pc == 0x23D27Cu) {
        ctx->pc = 0x23D27Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D278u;
        // 0x23d27c: 0x220202d  daddu       $a0, $s1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D280u;
        goto label_23d280;
    }
    ctx->pc = 0x23D278u;
    SET_GPR_U32(ctx, 31, 0x23D280u);
    ctx->pc = 0x23D27Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23D278u;
    // 0x23d27c: 0x220202d  daddu       $a0, $s1, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2540u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2540u, 0x23D278u, 0x23D280u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23D280u;
label_23d280:
    // 0x23d280: 0x27b00200  addiu       $s0, $sp, 0x200
    ctx->pc = 0x23d280u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 29), 512));
label_23d284:
    // 0x23d284: 0x24050100  addiu       $a1, $zero, 0x100
    ctx->pc = 0x23d284u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 256));
label_23d288:
    // 0x23d288: 0xc0906a8  jal         func_241AA0
label_23d28c:
    if (ctx->pc == 0x23D28Cu) {
        ctx->pc = 0x23D28Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D288u;
        // 0x23d28c: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D290u;
        goto label_23d290;
    }
    ctx->pc = 0x23D288u;
    SET_GPR_U32(ctx, 31, 0x23D290u);
    ctx->pc = 0x23D28Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23D288u;
    // 0x23d28c: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x241AA0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x241AA0u, 0x23D288u, 0x23D290u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23D290u;
label_23d290:
    // 0x23d290: 0x8e6800f8  lw          $t0, 0xF8($s3)
    ctx->pc = 0x23d290u;
    SET_GPR_S32(ctx, 8, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 248)));
label_23d294:
    // 0x23d294: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x23d294u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_23d298:
    // 0x23d298: 0x240202d  daddu       $a0, $s2, $zero
    ctx->pc = 0x23d298u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_23d29c:
    // 0x23d29c: 0x3a0382d  daddu       $a3, $sp, $zero
    ctx->pc = 0x23d29cu;
    SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
label_23d2a0:
    // 0x23d2a0: 0x200302d  daddu       $a2, $s0, $zero
    ctx->pc = 0x23d2a0u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_23d2a4:
    // 0x23d2a4: 0x25080001  addiu       $t0, $t0, 0x1
    ctx->pc = 0x23d2a4u;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 8), 1));
label_23d2a8:
    // 0x23d2a8: 0xc0b09b4  jal         func_2C26D0
label_23d2ac:
    if (ctx->pc == 0x23D2ACu) {
        ctx->pc = 0x23D2B0u;
        goto label_23d2b0;
    }
    ctx->pc = 0x23D2A8u;
    SET_GPR_U32(ctx, 31, 0x23D2B0u);
    ctx->pc = 0x2C26D0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C26D0u, 0x23D2A8u, 0x23D2B0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23D2B0u;
label_23d2b0:
    // 0x23d2b0: 0x8e670434  lw          $a3, 0x434($s3)
    ctx->pc = 0x23d2b0u;
    SET_GPR_S32(ctx, 7, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d2b4:
    // 0x23d2b4: 0x3c050048  lui         $a1, 0x48
    ctx->pc = 0x23d2b4u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)72 << 16));
label_23d2b8:
    // 0x23d2b8: 0x24a5c188  addiu       $a1, $a1, -0x3E78
    ctx->pc = 0x23d2b8u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 4294951304));
label_23d2bc:
    // 0x23d2bc: 0x302d  daddu       $a2, $zero, $zero
    ctx->pc = 0x23d2bcu;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_23d2c0:
    // 0x23d2c0: 0x8ce20000  lw          $v0, 0x0($a3)
    ctx->pc = 0x23d2c0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 7), 0)));
label_23d2c4:
    // 0x23d2c4: 0x84440138  lh          $a0, 0x138($v0)
    ctx->pc = 0x23d2c4u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 312)));
label_23d2c8:
    // 0x23d2c8: 0x8c43013c  lw          $v1, 0x13C($v0)
    ctx->pc = 0x23d2c8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 316)));
label_23d2cc:
    // 0x23d2cc: 0x60f809  jalr        $v1
label_23d2d0:
    if (ctx->pc == 0x23D2D0u) {
        ctx->pc = 0x23D2D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D2CCu;
        // 0x23d2d0: 0xe42021  addu        $a0, $a3, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 7), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D2D4u;
        goto label_23d2d4;
    }
    ctx->pc = 0x23D2CCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23D2D4u);
        ctx->pc = 0x23D2D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D2CCu;
        // 0x23d2d0: 0xe42021  addu        $a0, $a3, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 7), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D2CCu, 0x23D2D4u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D2D4u;
label_23d2d4:
    // 0x23d2d4: 0x240282d  daddu       $a1, $s2, $zero
    ctx->pc = 0x23d2d4u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_23d2d8:
    // 0x23d2d8: 0x24030001  addiu       $v1, $zero, 0x1
    ctx->pc = 0x23d2d8u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d2dc:
    // 0x23d2dc: 0x8e660434  lw          $a2, 0x434($s3)
    ctx->pc = 0x23d2dcu;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d2e0:
    // 0x23d2e0: 0xaf83fb88  sw          $v1, -0x478($gp)
    ctx->pc = 0x23d2e0u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 3));
label_23d2e4:
    // 0x23d2e4: 0xae630118  sw          $v1, 0x118($s3)
    ctx->pc = 0x23d2e4u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 280), GPR_U32(ctx, 3));
label_23d2e8:
    // 0x23d2e8: 0x8cc20000  lw          $v0, 0x0($a2)
    ctx->pc = 0x23d2e8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_23d2ec:
    // 0x23d2ec: 0x84440118  lh          $a0, 0x118($v0)
    ctx->pc = 0x23d2ecu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 280)));
label_23d2f0:
    // 0x23d2f0: 0x10000028  b           . + 4 + (0x28 << 2)
label_23d2f4:
    if (ctx->pc == 0x23D2F4u) {
        ctx->pc = 0x23D2F4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D2F0u;
        // 0x23d2f4: 0x8c43011c  lw          $v1, 0x11C($v0) (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 284)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D2F8u;
        goto label_23d2f8;
    }
    ctx->pc = 0x23D2F0u;
    {
        const bool branch_taken_0x23d2f0 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D2F4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D2F0u;
        // 0x23d2f4: 0x8c43011c  lw          $v1, 0x11C($v0) (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 284)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d2f0) {
            ctx->pc = 0x23D394u;
            goto label_23d394;
        }
    }
    ctx->pc = 0x23D2F8u;
label_23d2f8:
    // 0x23d2f8: 0x2402003c  addiu       $v0, $zero, 0x3C
    ctx->pc = 0x23d2f8u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 60));
label_23d2fc:
    // 0x23d2fc: 0x10000017  b           . + 4 + (0x17 << 2)
label_23d300:
    if (ctx->pc == 0x23D300u) {
        ctx->pc = 0x23D300u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D2FCu;
        // 0x23d300: 0x8e630000  lw          $v1, 0x0($s3) (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 0)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D304u;
        goto label_23d304;
    }
    ctx->pc = 0x23D2FCu;
    {
        const bool branch_taken_0x23d2fc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D300u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D2FCu;
        // 0x23d300: 0x8e630000  lw          $v1, 0x0($s3) (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d2fc) {
            ctx->pc = 0x23D35Cu;
            goto label_23d35c;
        }
    }
    ctx->pc = 0x23D304u;
label_23d304:
    // 0x23d304: 0x3c013f80  lui         $at, 0x3F80
    ctx->pc = 0x23d304u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16256 << 16));
label_23d308:
    // 0x23d308: 0x44810800  mtc1        $at, $f1
    ctx->pc = 0x23d308u;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[1], &bits, sizeof(bits)); }
label_23d30c:
    // 0x23d30c: 0x26660234  addiu       $a2, $s3, 0x234
    ctx->pc = 0x23d30cu;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 19), 564));
label_23d310:
    // 0x23d310: 0xc780aec4  lwc1        $f0, -0x513C($gp)
    ctx->pc = 0x23d310u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294946500)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
label_23d314:
    // 0x23d314: 0xe6610110  swc1        $f1, 0x110($s3)
    ctx->pc = 0x23d314u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 272), bits); }
label_23d318:
    // 0x23d318: 0xe6600114  swc1        $f0, 0x114($s3)
    ctx->pc = 0x23d318u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 276), bits); }
label_23d31c:
    // 0x23d31c: 0x8e670434  lw          $a3, 0x434($s3)
    ctx->pc = 0x23d31cu;
    SET_GPR_S32(ctx, 7, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d320:
    // 0x23d320: 0x8e6500f8  lw          $a1, 0xF8($s3)
    ctx->pc = 0x23d320u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 248)));
label_23d324:
    // 0x23d324: 0x8ce20000  lw          $v0, 0x0($a3)
    ctx->pc = 0x23d324u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 7), 0)));
label_23d328:
    // 0x23d328: 0x84440070  lh          $a0, 0x70($v0)
    ctx->pc = 0x23d328u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 112)));
label_23d32c:
    // 0x23d32c: 0x8c430074  lw          $v1, 0x74($v0)
    ctx->pc = 0x23d32cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 116)));
label_23d330:
    // 0x23d330: 0x60f809  jalr        $v1
label_23d334:
    if (ctx->pc == 0x23D334u) {
        ctx->pc = 0x23D334u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D330u;
        // 0x23d334: 0xe42021  addu        $a0, $a3, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 7), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D338u;
        goto label_23d338;
    }
    ctx->pc = 0x23D330u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23D338u);
        ctx->pc = 0x23D334u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D330u;
        // 0x23d334: 0xe42021  addu        $a0, $a3, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 7), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D330u, 0x23D338u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D338u;
label_23d338:
    // 0x23d338: 0x2404004d  addiu       $a0, $zero, 0x4D
    ctx->pc = 0x23d338u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 0), 77));
label_23d33c:
    // 0x23d33c: 0xae60010c  sw          $zero, 0x10C($s3)
    ctx->pc = 0x23d33cu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 268), GPR_U32(ctx, 0));
label_23d340:
    // 0x23d340: 0x8e620014  lw          $v0, 0x14($s3)
    ctx->pc = 0x23d340u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 20)));
label_23d344:
    // 0x23d344: 0x40f809  jalr        $v0
label_23d348:
    if (ctx->pc == 0x23D348u) {
        ctx->pc = 0x23D348u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D344u;
        // 0x23d348: 0xae6400e8  sw          $a0, 0xE8($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 232), GPR_U32(ctx, 4));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D34Cu;
        goto label_23d34c;
    }
    ctx->pc = 0x23D344u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D34Cu);
        ctx->pc = 0x23D348u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D344u;
        // 0x23d348: 0xae6400e8  sw          $a0, 0xE8($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 232), GPR_U32(ctx, 4));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D344u, 0x23D34Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D34Cu;
label_23d34c:
    // 0x23d34c: 0x10000080  b           . + 4 + (0x80 << 2)
label_23d350:
    if (ctx->pc == 0x23D350u) {
        ctx->pc = 0x23D350u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D34Cu;
        // 0x23d350: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D354u;
        goto label_23d354;
    }
    ctx->pc = 0x23D34Cu;
    {
        const bool branch_taken_0x23d34c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D350u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D34Cu;
        // 0x23d350: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d34c) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D354u;
label_23d354:
    // 0x23d354: 0x2402003c  addiu       $v0, $zero, 0x3C
    ctx->pc = 0x23d354u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 60));
label_23d358:
    // 0x23d358: 0x8e630018  lw          $v1, 0x18($s3)
    ctx->pc = 0x23d358u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 24)));
label_23d35c:
    // 0x23d35c: 0x60f809  jalr        $v1
label_23d360:
    if (ctx->pc == 0x23D360u) {
        ctx->pc = 0x23D360u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D35Cu;
        // 0x23d360: 0xae620108  sw          $v0, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D364u;
        goto label_23d364;
    }
    ctx->pc = 0x23D35Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23D364u);
        ctx->pc = 0x23D360u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D35Cu;
        // 0x23d360: 0xae620108  sw          $v0, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D35Cu, 0x23D364u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D364u;
label_23d364:
    // 0x23d364: 0x1000007a  b           . + 4 + (0x7A << 2)
label_23d368:
    if (ctx->pc == 0x23D368u) {
        ctx->pc = 0x23D368u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D364u;
        // 0x23d368: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D36Cu;
        goto label_23d36c;
    }
    ctx->pc = 0x23D364u;
    {
        const bool branch_taken_0x23d364 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D368u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D364u;
        // 0x23d368: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d364) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D36Cu;
label_23d36c:
    // 0x23d36c: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x23d36cu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d370:
    // 0x23d370: 0x2403003c  addiu       $v1, $zero, 0x3C
    ctx->pc = 0x23d370u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 60));
label_23d374:
    // 0x23d374: 0xae6200c0  sw          $v0, 0xC0($s3)
    ctx->pc = 0x23d374u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 192), GPR_U32(ctx, 2));
label_23d378:
    // 0x23d378: 0xaf82fb88  sw          $v0, -0x478($gp)
    ctx->pc = 0x23d378u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 2));
label_23d37c:
    // 0x23d37c: 0xae630108  sw          $v1, 0x108($s3)
    ctx->pc = 0x23d37cu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 3));
label_23d380:
    // 0x23d380: 0x8e660434  lw          $a2, 0x434($s3)
    ctx->pc = 0x23d380u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d384:
    // 0x23d384: 0x8e6500f8  lw          $a1, 0xF8($s3)
    ctx->pc = 0x23d384u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 248)));
label_23d388:
    // 0x23d388: 0x8cc20000  lw          $v0, 0x0($a2)
    ctx->pc = 0x23d388u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_23d38c:
    // 0x23d38c: 0x84440050  lh          $a0, 0x50($v0)
    ctx->pc = 0x23d38cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 80)));
label_23d390:
    // 0x23d390: 0x8c430054  lw          $v1, 0x54($v0)
    ctx->pc = 0x23d390u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 84)));
label_23d394:
    // 0x23d394: 0x60f809  jalr        $v1
label_23d398:
    if (ctx->pc == 0x23D398u) {
        ctx->pc = 0x23D398u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D394u;
        // 0x23d398: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D39Cu;
        goto label_23d39c;
    }
    ctx->pc = 0x23D394u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23D39Cu);
        ctx->pc = 0x23D398u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D394u;
        // 0x23d398: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D394u, 0x23D39Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D39Cu;
label_23d39c:
    // 0x23d39c: 0x1000006c  b           . + 4 + (0x6C << 2)
label_23d3a0:
    if (ctx->pc == 0x23D3A0u) {
        ctx->pc = 0x23D3A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D39Cu;
        // 0x23d3a0: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D3A4u;
        goto label_23d3a4;
    }
    ctx->pc = 0x23D39Cu;
    {
        const bool branch_taken_0x23d39c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D3A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D39Cu;
        // 0x23d3a0: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d39c) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D3A4u;
label_23d3a4:
    // 0x23d3a4: 0x10000068  b           . + 4 + (0x68 << 2)
label_23d3a8:
    if (ctx->pc == 0x23D3A8u) {
        ctx->pc = 0x23D3A8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3A4u;
        // 0x23d3a8: 0xae6000c0  sw          $zero, 0xC0($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 192), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D3ACu;
        goto label_23d3ac;
    }
    ctx->pc = 0x23D3A4u;
    {
        const bool branch_taken_0x23d3a4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D3A8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3A4u;
        // 0x23d3a8: 0xae6000c0  sw          $zero, 0xC0($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 192), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d3a4) {
            ctx->pc = 0x23D548u;
            goto label_23d548;
        }
    }
    ctx->pc = 0x23D3ACu;
label_23d3ac:
    // 0x23d3ac: 0xae6000c0  sw          $zero, 0xC0($s3)
    ctx->pc = 0x23d3acu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 192), GPR_U32(ctx, 0));
label_23d3b0:
    // 0x23d3b0: 0x8e620034  lw          $v0, 0x34($s3)
    ctx->pc = 0x23d3b0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 52)));
label_23d3b4:
    // 0x23d3b4: 0x40f809  jalr        $v0
label_23d3b8:
    if (ctx->pc == 0x23D3B8u) {
        ctx->pc = 0x23D3BCu;
        goto label_23d3bc;
    }
    ctx->pc = 0x23D3B4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D3BCu);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D3B4u, 0x23D3BCu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D3BCu;
label_23d3bc:
    // 0x23d3bc: 0x10000063  b           . + 4 + (0x63 << 2)
label_23d3c0:
    if (ctx->pc == 0x23D3C0u) {
        ctx->pc = 0x23D3C0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3BCu;
        // 0x23d3c0: 0xaf80fb88  sw          $zero, -0x478($gp) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D3C4u;
        goto label_23d3c4;
    }
    ctx->pc = 0x23D3BCu;
    {
        const bool branch_taken_0x23d3bc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D3C0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3BCu;
        // 0x23d3c0: 0xaf80fb88  sw          $zero, -0x478($gp) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d3bc) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23D3C4u;
label_23d3c4:
    // 0x23d3c4: 0xaf80fb88  sw          $zero, -0x478($gp)
    ctx->pc = 0x23d3c4u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 0));
label_23d3c8:
    // 0x23d3c8: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x23d3c8u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d3cc:
    // 0x23d3cc: 0x2403ffff  addiu       $v1, $zero, -0x1
    ctx->pc = 0x23d3ccu;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
label_23d3d0:
    // 0x23d3d0: 0xae6200dc  sw          $v0, 0xDC($s3)
    ctx->pc = 0x23d3d0u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 220), GPR_U32(ctx, 2));
label_23d3d4:
    // 0x23d3d4: 0x1000005d  b           . + 4 + (0x5D << 2)
label_23d3d8:
    if (ctx->pc == 0x23D3D8u) {
        ctx->pc = 0x23D3D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3D4u;
        // 0x23d3d8: 0xae6300fc  sw          $v1, 0xFC($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 252), GPR_U32(ctx, 3));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D3DCu;
        goto label_23d3dc;
    }
    ctx->pc = 0x23D3D4u;
    {
        const bool branch_taken_0x23d3d4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D3D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3D4u;
        // 0x23d3d8: 0xae6300fc  sw          $v1, 0xFC($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 252), GPR_U32(ctx, 3));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d3d4) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23D3DCu;
label_23d3dc:
    // 0x23d3dc: 0x10000004  b           . + 4 + (0x4 << 2)
label_23d3e0:
    if (ctx->pc == 0x23D3E0u) {
        ctx->pc = 0x23D3E0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3DCu;
        // 0x23d3e0: 0x8e620048  lw          $v0, 0x48($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 72)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D3E4u;
        goto label_23d3e4;
    }
    ctx->pc = 0x23D3DCu;
    {
        const bool branch_taken_0x23d3dc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D3E0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3DCu;
        // 0x23d3e0: 0x8e620048  lw          $v0, 0x48($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 72)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d3dc) {
            ctx->pc = 0x23D3F0u;
            goto label_23d3f0;
        }
    }
    ctx->pc = 0x23D3E4u;
label_23d3e4:
    // 0x23d3e4: 0x10000056  b           . + 4 + (0x56 << 2)
label_23d3e8:
    if (ctx->pc == 0x23D3E8u) {
        ctx->pc = 0x23D3E8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3E4u;
        // 0x23d3e8: 0x8e62004c  lw          $v0, 0x4C($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 76)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D3ECu;
        goto label_23d3ec;
    }
    ctx->pc = 0x23D3E4u;
    {
        const bool branch_taken_0x23d3e4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D3E8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D3E4u;
        // 0x23d3e8: 0x8e62004c  lw          $v0, 0x4C($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 76)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d3e4) {
            ctx->pc = 0x23D540u;
            goto label_23d540;
        }
    }
    ctx->pc = 0x23D3ECu;
label_23d3ec:
    // 0x23d3ec: 0x8e620044  lw          $v0, 0x44($s3)
    ctx->pc = 0x23d3ecu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 68)));
label_23d3f0:
    // 0x23d3f0: 0x40f809  jalr        $v0
label_23d3f4:
    if (ctx->pc == 0x23D3F4u) {
        ctx->pc = 0x23D3F8u;
        goto label_23d3f8;
    }
    ctx->pc = 0x23D3F0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D3F8u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D3F0u, 0x23D3F8u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D3F8u;
label_23d3f8:
    // 0x23d3f8: 0x3c013f80  lui         $at, 0x3F80
    ctx->pc = 0x23d3f8u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16256 << 16));
label_23d3fc:
    // 0x23d3fc: 0x44810000  mtc1        $at, $f0
    ctx->pc = 0x23d3fcu;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[0], &bits, sizeof(bits)); }
label_23d400:
    // 0x23d400: 0xc781aec8  lwc1        $f1, -0x5138($gp)
    ctx->pc = 0x23d400u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294946504)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_23d404:
    // 0x23d404: 0xe6600110  swc1        $f0, 0x110($s3)
    ctx->pc = 0x23d404u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 272), bits); }
label_23d408:
    // 0x23d408: 0x10000050  b           . + 4 + (0x50 << 2)
label_23d40c:
    if (ctx->pc == 0x23D40Cu) {
        ctx->pc = 0x23D40Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D408u;
        // 0x23d40c: 0xe6610114  swc1        $f1, 0x114($s3) (Delay Slot)
        { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 276), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D410u;
        goto label_23d410;
    }
    ctx->pc = 0x23D408u;
    {
        const bool branch_taken_0x23d408 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D40Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D408u;
        // 0x23d40c: 0xe6610114  swc1        $f1, 0x114($s3) (Delay Slot)
        { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 276), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d408) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23D410u;
label_23d410:
    // 0x23d410: 0x1000004b  b           . + 4 + (0x4B << 2)
label_23d414:
    if (ctx->pc == 0x23D414u) {
        ctx->pc = 0x23D414u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D410u;
        // 0x23d414: 0x8e620010  lw          $v0, 0x10($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 16)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D418u;
        goto label_23d418;
    }
    ctx->pc = 0x23D410u;
    {
        const bool branch_taken_0x23d410 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D414u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D410u;
        // 0x23d414: 0x8e620010  lw          $v0, 0x10($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 16)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d410) {
            ctx->pc = 0x23D540u;
            goto label_23d540;
        }
    }
    ctx->pc = 0x23D418u;
label_23d418:
    // 0x23d418: 0x8e620060  lw          $v0, 0x60($s3)
    ctx->pc = 0x23d418u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 96)));
label_23d41c:
    // 0x23d41c: 0x40f809  jalr        $v0
label_23d420:
    if (ctx->pc == 0x23D420u) {
        ctx->pc = 0x23D424u;
        goto label_23d424;
    }
    ctx->pc = 0x23D41Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D424u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D41Cu, 0x23D424u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D424u;
label_23d424:
    // 0x23d424: 0x1000004a  b           . + 4 + (0x4A << 2)
label_23d428:
    if (ctx->pc == 0x23D428u) {
        ctx->pc = 0x23D428u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D424u;
        // 0x23d428: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D42Cu;
        goto label_23d42c;
    }
    ctx->pc = 0x23D424u;
    {
        const bool branch_taken_0x23d424 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D428u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D424u;
        // 0x23d428: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d424) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D42Cu;
label_23d42c:
    // 0x23d42c: 0x8e62005c  lw          $v0, 0x5C($s3)
    ctx->pc = 0x23d42cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 92)));
label_23d430:
    // 0x23d430: 0x40f809  jalr        $v0
label_23d434:
    if (ctx->pc == 0x23D434u) {
        ctx->pc = 0x23D438u;
        goto label_23d438;
    }
    ctx->pc = 0x23D430u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D438u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D430u, 0x23D438u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D438u;
label_23d438:
    // 0x23d438: 0x10000045  b           . + 4 + (0x45 << 2)
label_23d43c:
    if (ctx->pc == 0x23D43Cu) {
        ctx->pc = 0x23D43Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D438u;
        // 0x23d43c: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D440u;
        goto label_23d440;
    }
    ctx->pc = 0x23D438u;
    {
        const bool branch_taken_0x23d438 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D43Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D438u;
        // 0x23d43c: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d438) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D440u;
label_23d440:
    // 0x23d440: 0x8e62003c  lw          $v0, 0x3C($s3)
    ctx->pc = 0x23d440u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 60)));
label_23d444:
    // 0x23d444: 0x40f809  jalr        $v0
label_23d448:
    if (ctx->pc == 0x23D448u) {
        ctx->pc = 0x23D44Cu;
        goto label_23d44c;
    }
    ctx->pc = 0x23D444u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D44Cu);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D444u, 0x23D44Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D44Cu;
label_23d44c:
    // 0x23d44c: 0x10000040  b           . + 4 + (0x40 << 2)
label_23d450:
    if (ctx->pc == 0x23D450u) {
        ctx->pc = 0x23D450u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D44Cu;
        // 0x23d450: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D454u;
        goto label_23d454;
    }
    ctx->pc = 0x23D44Cu;
    {
        const bool branch_taken_0x23d44c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D450u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D44Cu;
        // 0x23d450: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d44c) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D454u;
label_23d454:
    // 0x23d454: 0x8e620024  lw          $v0, 0x24($s3)
    ctx->pc = 0x23d454u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 36)));
label_23d458:
    // 0x23d458: 0x40f809  jalr        $v0
label_23d45c:
    if (ctx->pc == 0x23D45Cu) {
        ctx->pc = 0x23D460u;
        goto label_23d460;
    }
    ctx->pc = 0x23D458u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D460u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D458u, 0x23D460u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D460u;
label_23d460:
    // 0x23d460: 0x1000003a  b           . + 4 + (0x3A << 2)
label_23d464:
    if (ctx->pc == 0x23D464u) {
        ctx->pc = 0x23D464u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D460u;
        // 0x23d464: 0xae600108  sw          $zero, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D468u;
        goto label_23d468;
    }
    ctx->pc = 0x23D460u;
    {
        const bool branch_taken_0x23d460 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D464u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D460u;
        // 0x23d464: 0xae600108  sw          $zero, 0x108($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d460) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23D468u;
label_23d468:
    // 0x23d468: 0x8e620040  lw          $v0, 0x40($s3)
    ctx->pc = 0x23d468u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 64)));
label_23d46c:
    // 0x23d46c: 0x40f809  jalr        $v0
label_23d470:
    if (ctx->pc == 0x23D470u) {
        ctx->pc = 0x23D474u;
        goto label_23d474;
    }
    ctx->pc = 0x23D46Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D474u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D46Cu, 0x23D474u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D474u;
label_23d474:
    // 0x23d474: 0x10000036  b           . + 4 + (0x36 << 2)
label_23d478:
    if (ctx->pc == 0x23D478u) {
        ctx->pc = 0x23D478u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D474u;
        // 0x23d478: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D47Cu;
        goto label_23d47c;
    }
    ctx->pc = 0x23D474u;
    {
        const bool branch_taken_0x23d474 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D478u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D474u;
        // 0x23d478: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d474) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D47Cu;
label_23d47c:
    // 0x23d47c: 0x8e62008c  lw          $v0, 0x8C($s3)
    ctx->pc = 0x23d47cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 140)));
label_23d480:
    // 0x23d480: 0x40f809  jalr        $v0
label_23d484:
    if (ctx->pc == 0x23D484u) {
        ctx->pc = 0x23D488u;
        goto label_23d488;
    }
    ctx->pc = 0x23D480u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D488u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D480u, 0x23D488u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D488u;
label_23d488:
    // 0x23d488: 0x10000031  b           . + 4 + (0x31 << 2)
label_23d48c:
    if (ctx->pc == 0x23D48Cu) {
        ctx->pc = 0x23D48Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D488u;
        // 0x23d48c: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D490u;
        goto label_23d490;
    }
    ctx->pc = 0x23D488u;
    {
        const bool branch_taken_0x23d488 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D48Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D488u;
        // 0x23d48c: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d488) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D490u;
label_23d490:
    // 0x23d490: 0x1000002b  b           . + 4 + (0x2B << 2)
label_23d494:
    if (ctx->pc == 0x23D494u) {
        ctx->pc = 0x23D494u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D490u;
        // 0x23d494: 0x8e620048  lw          $v0, 0x48($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 72)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D498u;
        goto label_23d498;
    }
    ctx->pc = 0x23D490u;
    {
        const bool branch_taken_0x23d490 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D494u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D490u;
        // 0x23d494: 0x8e620048  lw          $v0, 0x48($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 72)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d490) {
            ctx->pc = 0x23D540u;
            goto label_23d540;
        }
    }
    ctx->pc = 0x23D498u;
label_23d498:
    // 0x23d498: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x23d498u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d49c:
    // 0x23d49c: 0x3c013f80  lui         $at, 0x3F80
    ctx->pc = 0x23d49cu;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16256 << 16));
label_23d4a0:
    // 0x23d4a0: 0x44810000  mtc1        $at, $f0
    ctx->pc = 0x23d4a0u;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[0], &bits, sizeof(bits)); }
label_23d4a4:
    // 0x23d4a4: 0xc781aecc  lwc1        $f1, -0x5134($gp)
    ctx->pc = 0x23d4a4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294946508)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_23d4a8:
    // 0x23d4a8: 0x24030078  addiu       $v1, $zero, 0x78
    ctx->pc = 0x23d4a8u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 120));
label_23d4ac:
    // 0x23d4ac: 0xaf82fb88  sw          $v0, -0x478($gp)
    ctx->pc = 0x23d4acu;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 2));
label_23d4b0:
    // 0x23d4b0: 0xe6600110  swc1        $f0, 0x110($s3)
    ctx->pc = 0x23d4b0u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 272), bits); }
label_23d4b4:
    // 0x23d4b4: 0xe6610114  swc1        $f1, 0x114($s3)
    ctx->pc = 0x23d4b4u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 276), bits); }
label_23d4b8:
    // 0x23d4b8: 0xae630108  sw          $v1, 0x108($s3)
    ctx->pc = 0x23d4b8u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 3));
label_23d4bc:
    // 0x23d4bc: 0x8e650434  lw          $a1, 0x434($s3)
    ctx->pc = 0x23d4bcu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 1076)));
label_23d4c0:
    // 0x23d4c0: 0x8ca20000  lw          $v0, 0x0($a1)
    ctx->pc = 0x23d4c0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23d4c4:
    // 0x23d4c4: 0x84440040  lh          $a0, 0x40($v0)
    ctx->pc = 0x23d4c4u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 64)));
label_23d4c8:
    // 0x23d4c8: 0x8c430044  lw          $v1, 0x44($v0)
    ctx->pc = 0x23d4c8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 68)));
label_23d4cc:
    // 0x23d4cc: 0x60f809  jalr        $v1
label_23d4d0:
    if (ctx->pc == 0x23D4D0u) {
        ctx->pc = 0x23D4D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4CCu;
        // 0x23d4d0: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D4D4u;
        goto label_23d4d4;
    }
    ctx->pc = 0x23D4CCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23D4D4u);
        ctx->pc = 0x23D4D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4CCu;
        // 0x23d4d0: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D4CCu, 0x23D4D4u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D4D4u;
label_23d4d4:
    // 0x23d4d4: 0x1000001e  b           . + 4 + (0x1E << 2)
label_23d4d8:
    if (ctx->pc == 0x23D4D8u) {
        ctx->pc = 0x23D4D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4D4u;
        // 0x23d4d8: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D4DCu;
        goto label_23d4dc;
    }
    ctx->pc = 0x23D4D4u;
    {
        const bool branch_taken_0x23d4d4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D4D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4D4u;
        // 0x23d4d8: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d4d4) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D4DCu;
label_23d4dc:
    // 0x23d4dc: 0x10000018  b           . + 4 + (0x18 << 2)
label_23d4e0:
    if (ctx->pc == 0x23D4E0u) {
        ctx->pc = 0x23D4E0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4DCu;
        // 0x23d4e0: 0x8e62004c  lw          $v0, 0x4C($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 76)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D4E4u;
        goto label_23d4e4;
    }
    ctx->pc = 0x23D4DCu;
    {
        const bool branch_taken_0x23d4dc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D4E0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4DCu;
        // 0x23d4e0: 0x8e62004c  lw          $v0, 0x4C($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 76)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d4dc) {
            ctx->pc = 0x23D540u;
            goto label_23d540;
        }
    }
    ctx->pc = 0x23D4E4u;
label_23d4e4:
    // 0x23d4e4: 0x10000016  b           . + 4 + (0x16 << 2)
label_23d4e8:
    if (ctx->pc == 0x23D4E8u) {
        ctx->pc = 0x23D4E8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4E4u;
        // 0x23d4e8: 0x8e620050  lw          $v0, 0x50($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 80)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D4ECu;
        goto label_23d4ec;
    }
    ctx->pc = 0x23D4E4u;
    {
        const bool branch_taken_0x23d4e4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D4E8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4E4u;
        // 0x23d4e8: 0x8e620050  lw          $v0, 0x50($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 80)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d4e4) {
            ctx->pc = 0x23D540u;
            goto label_23d540;
        }
    }
    ctx->pc = 0x23D4ECu;
label_23d4ec:
    // 0x23d4ec: 0x10000014  b           . + 4 + (0x14 << 2)
label_23d4f0:
    if (ctx->pc == 0x23D4F0u) {
        ctx->pc = 0x23D4F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4ECu;
        // 0x23d4f0: 0x8e620054  lw          $v0, 0x54($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 84)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D4F4u;
        goto label_23d4f4;
    }
    ctx->pc = 0x23D4ECu;
    {
        const bool branch_taken_0x23d4ec = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D4F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D4ECu;
        // 0x23d4f0: 0x8e620054  lw          $v0, 0x54($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 84)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d4ec) {
            ctx->pc = 0x23D540u;
            goto label_23d540;
        }
    }
    ctx->pc = 0x23D4F4u;
label_23d4f4:
    // 0x23d4f4: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x23d4f4u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23d4f8:
    // 0x23d4f8: 0x3c013f80  lui         $at, 0x3F80
    ctx->pc = 0x23d4f8u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16256 << 16));
label_23d4fc:
    // 0x23d4fc: 0x44810000  mtc1        $at, $f0
    ctx->pc = 0x23d4fcu;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[0], &bits, sizeof(bits)); }
label_23d500:
    // 0x23d500: 0xc781aed0  lwc1        $f1, -0x5130($gp)
    ctx->pc = 0x23d500u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294946512)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_23d504:
    // 0x23d504: 0x2403003c  addiu       $v1, $zero, 0x3C
    ctx->pc = 0x23d504u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 60));
label_23d508:
    // 0x23d508: 0xaf82fb88  sw          $v0, -0x478($gp)
    ctx->pc = 0x23d508u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 2));
label_23d50c:
    // 0x23d50c: 0xe6600110  swc1        $f0, 0x110($s3)
    ctx->pc = 0x23d50cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 272), bits); }
label_23d510:
    // 0x23d510: 0xe6610114  swc1        $f1, 0x114($s3)
    ctx->pc = 0x23d510u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 276), bits); }
label_23d514:
    // 0x23d514: 0xae630108  sw          $v1, 0x108($s3)
    ctx->pc = 0x23d514u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 264), GPR_U32(ctx, 3));
label_23d518:
    // 0x23d518: 0x1000000c  b           . + 4 + (0xC << 2)
label_23d51c:
    if (ctx->pc == 0x23D51Cu) {
        ctx->pc = 0x23D51Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D518u;
        // 0x23d51c: 0xae600438  sw          $zero, 0x438($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 1080), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D520u;
        goto label_23d520;
    }
    ctx->pc = 0x23D518u;
    {
        const bool branch_taken_0x23d518 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D51Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D518u;
        // 0x23d51c: 0xae600438  sw          $zero, 0x438($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 1080), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d518) {
            ctx->pc = 0x23D54Cu;
            goto label_23d54c;
        }
    }
    ctx->pc = 0x23D520u;
label_23d520:
    // 0x23d520: 0x8e620058  lw          $v0, 0x58($s3)
    ctx->pc = 0x23d520u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 88)));
label_23d524:
    // 0x23d524: 0x40f809  jalr        $v0
label_23d528:
    if (ctx->pc == 0x23D528u) {
        ctx->pc = 0x23D52Cu;
        goto label_23d52c;
    }
    ctx->pc = 0x23D524u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D52Cu);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D524u, 0x23D52Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D52Cu;
label_23d52c:
    // 0x23d52c: 0x10000008  b           . + 4 + (0x8 << 2)
label_23d530:
    if (ctx->pc == 0x23D530u) {
        ctx->pc = 0x23D530u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D52Cu;
        // 0x23d530: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D534u;
        goto label_23d534;
    }
    ctx->pc = 0x23D52Cu;
    {
        const bool branch_taken_0x23d52c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D530u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D52Cu;
        // 0x23d530: 0xae740130  sw          $s4, 0x130($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d52c) {
            ctx->pc = 0x23D550u;
            goto label_23d550;
        }
    }
    ctx->pc = 0x23D534u;
label_23d534:
    // 0x23d534: 0x10000002  b           . + 4 + (0x2 << 2)
label_23d538:
    if (ctx->pc == 0x23D538u) {
        ctx->pc = 0x23D538u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D534u;
        // 0x23d538: 0x8e6200a0  lw          $v0, 0xA0($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 160)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D53Cu;
        goto label_23d53c;
    }
    ctx->pc = 0x23D534u;
    {
        const bool branch_taken_0x23d534 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D538u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D534u;
        // 0x23d538: 0x8e6200a0  lw          $v0, 0xA0($s3) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 160)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d534) {
            ctx->pc = 0x23D540u;
            goto label_23d540;
        }
    }
    ctx->pc = 0x23D53Cu;
label_23d53c:
    // 0x23d53c: 0x8e6200a8  lw          $v0, 0xA8($s3)
    ctx->pc = 0x23d53cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 168)));
label_23d540:
    // 0x23d540: 0x40f809  jalr        $v0
label_23d544:
    if (ctx->pc == 0x23D544u) {
        ctx->pc = 0x23D548u;
        goto label_23d548;
    }
    ctx->pc = 0x23D540u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23D548u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D540u, 0x23D548u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23D548u;
label_23d548:
    // 0x23d548: 0xaf80fb88  sw          $zero, -0x478($gp)
    ctx->pc = 0x23d548u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294966152), GPR_U32(ctx, 0));
label_23d54c:
    // 0x23d54c: 0xae740130  sw          $s4, 0x130($s3)
    ctx->pc = 0x23d54cu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 304), GPR_U32(ctx, 20));
label_23d550:
    // 0x23d550: 0x7bb00650  lq          $s0, 0x650($sp)
    ctx->pc = 0x23d550u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 1616)));
label_23d554:
    // 0x23d554: 0x7bb10640  lq          $s1, 0x640($sp)
    ctx->pc = 0x23d554u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 1600)));
label_23d558:
    // 0x23d558: 0x7bb20630  lq          $s2, 0x630($sp)
    ctx->pc = 0x23d558u;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 1584)));
label_23d55c:
    // 0x23d55c: 0x7bb30620  lq          $s3, 0x620($sp)
    ctx->pc = 0x23d55cu;
    SET_GPR_VEC(ctx, 19, READ128(ADD32(GPR_U32(ctx, 29), 1568)));
label_23d560:
    // 0x23d560: 0x7bb40610  lq          $s4, 0x610($sp)
    ctx->pc = 0x23d560u;
    SET_GPR_VEC(ctx, 20, READ128(ADD32(GPR_U32(ctx, 29), 1552)));
label_23d564:
    // 0x23d564: 0xdfbf0600  ld          $ra, 0x600($sp)
    ctx->pc = 0x23d564u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 1536)));
label_23d568:
    // 0x23d568: 0x3e00008  jr          $ra
label_23d56c:
    if (ctx->pc == 0x23D56Cu) {
        ctx->pc = 0x23D56Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D568u;
        // 0x23d56c: 0x27bd0660  addiu       $sp, $sp, 0x660 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 1632));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23D570u;
        goto label_fallthrough_0x23d568;
    }
    ctx->pc = 0x23D568u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x23D56Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D568u;
        // 0x23d56c: 0x27bd0660  addiu       $sp, $sp, 0x660 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 1632));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D568u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
label_fallthrough_0x23d568:
    ctx->pc = 0x23D570u;
}
