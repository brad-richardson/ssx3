#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_0023D570
// Address: 0x23d570 - 0x23d5a8
void sub_0023D570_0x23d570(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_0023D570_0x23d570");
#endif

    ctx->pc = 0x23d570u;

    // 0x23d570: 0x10a0000a  beqz        $a1, . + 4 + (0xA << 2)
    ctx->pc = 0x23D570u;
    {
        const bool branch_taken_0x23d570 = (GPR_U64(ctx, 5) == GPR_U64(ctx, 0));
        ctx->pc = 0x23D574u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D570u;
        // 0x23d574: 0xac8500b8  sw          $a1, 0xB8($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 184), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d570) {
            ctx->pc = 0x23D59Cu;
            goto label_23d59c;
        }
    }
    ctx->pc = 0x23D578u;
    // 0x23d578: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x23d578u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
    // 0x23d57c: 0x14a20007  bne         $a1, $v0, . + 4 + (0x7 << 2)
    ctx->pc = 0x23D57Cu;
    {
        const bool branch_taken_0x23d57c = (GPR_U64(ctx, 5) != GPR_U64(ctx, 2));
        ctx->pc = 0x23D580u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23D57Cu;
        // 0x23d580: 0x2402003c  addiu       $v0, $zero, 0x3C (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 60));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23d57c) {
            ctx->pc = 0x23D59Cu;
            goto label_23d59c;
        }
    }
    ctx->pc = 0x23D584u;
    // 0x23d584: 0x3c013f80  lui         $at, 0x3F80
    ctx->pc = 0x23d584u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16256 << 16));
    // 0x23d588: 0x44810000  mtc1        $at, $f0
    ctx->pc = 0x23d588u;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[0], &bits, sizeof(bits)); }
    // 0x23d58c: 0xc781aed4  lwc1        $f1, -0x512C($gp)
    ctx->pc = 0x23d58cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294946516)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
    // 0x23d590: 0xac820108  sw          $v0, 0x108($a0)
    ctx->pc = 0x23d590u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 264), GPR_U32(ctx, 2));
    // 0x23d594: 0xe4800110  swc1        $f0, 0x110($a0)
    ctx->pc = 0x23d594u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 272), bits); }
    // 0x23d598: 0xe4810114  swc1        $f1, 0x114($a0)
    ctx->pc = 0x23d598u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 276), bits); }
label_23d59c:
    // 0x23d59c: 0x3e00008  jr          $ra
    ctx->pc = 0x23D59Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23D59Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x23D5A4u;
    // 0x23d5a4: 0x0  nop
    ctx->pc = 0x23d5a4u;
    // NOP
    ctx->pc = 0x23d5a8u;
}
