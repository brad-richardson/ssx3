#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_0023E540
// Address: 0x23e540 - 0x23e820
void sub_0023E540_0x23e540(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_0023E540_0x23e540");
#endif

    switch (ctx->pc) {
        case 0x23e540u: goto label_23e540;
        case 0x23e544u: goto label_23e544;
        case 0x23e548u: goto label_23e548;
        case 0x23e54cu: goto label_23e54c;
        case 0x23e550u: goto label_23e550;
        case 0x23e554u: goto label_23e554;
        case 0x23e558u: goto label_23e558;
        case 0x23e55cu: goto label_23e55c;
        case 0x23e560u: goto label_23e560;
        case 0x23e564u: goto label_23e564;
        case 0x23e568u: goto label_23e568;
        case 0x23e56cu: goto label_23e56c;
        case 0x23e570u: goto label_23e570;
        case 0x23e574u: goto label_23e574;
        case 0x23e578u: goto label_23e578;
        case 0x23e57cu: goto label_23e57c;
        case 0x23e580u: goto label_23e580;
        case 0x23e584u: goto label_23e584;
        case 0x23e588u: goto label_23e588;
        case 0x23e58cu: goto label_23e58c;
        case 0x23e590u: goto label_23e590;
        case 0x23e594u: goto label_23e594;
        case 0x23e598u: goto label_23e598;
        case 0x23e59cu: goto label_23e59c;
        case 0x23e5a0u: goto label_23e5a0;
        case 0x23e5a4u: goto label_23e5a4;
        case 0x23e5a8u: goto label_23e5a8;
        case 0x23e5acu: goto label_23e5ac;
        case 0x23e5b0u: goto label_23e5b0;
        case 0x23e5b4u: goto label_23e5b4;
        case 0x23e5b8u: goto label_23e5b8;
        case 0x23e5bcu: goto label_23e5bc;
        case 0x23e5c0u: goto label_23e5c0;
        case 0x23e5c4u: goto label_23e5c4;
        case 0x23e5c8u: goto label_23e5c8;
        case 0x23e5ccu: goto label_23e5cc;
        case 0x23e5d0u: goto label_23e5d0;
        case 0x23e5d4u: goto label_23e5d4;
        case 0x23e5d8u: goto label_23e5d8;
        case 0x23e5dcu: goto label_23e5dc;
        case 0x23e5e0u: goto label_23e5e0;
        case 0x23e5e4u: goto label_23e5e4;
        case 0x23e5e8u: goto label_23e5e8;
        case 0x23e5ecu: goto label_23e5ec;
        case 0x23e5f0u: goto label_23e5f0;
        case 0x23e5f4u: goto label_23e5f4;
        case 0x23e5f8u: goto label_23e5f8;
        case 0x23e5fcu: goto label_23e5fc;
        case 0x23e600u: goto label_23e600;
        case 0x23e604u: goto label_23e604;
        case 0x23e608u: goto label_23e608;
        case 0x23e60cu: goto label_23e60c;
        case 0x23e610u: goto label_23e610;
        case 0x23e614u: goto label_23e614;
        case 0x23e618u: goto label_23e618;
        case 0x23e61cu: goto label_23e61c;
        case 0x23e620u: goto label_23e620;
        case 0x23e624u: goto label_23e624;
        case 0x23e628u: goto label_23e628;
        case 0x23e62cu: goto label_23e62c;
        case 0x23e630u: goto label_23e630;
        case 0x23e634u: goto label_23e634;
        case 0x23e638u: goto label_23e638;
        case 0x23e63cu: goto label_23e63c;
        case 0x23e640u: goto label_23e640;
        case 0x23e644u: goto label_23e644;
        case 0x23e648u: goto label_23e648;
        case 0x23e64cu: goto label_23e64c;
        case 0x23e650u: goto label_23e650;
        case 0x23e654u: goto label_23e654;
        case 0x23e658u: goto label_23e658;
        case 0x23e65cu: goto label_23e65c;
        case 0x23e660u: goto label_23e660;
        case 0x23e664u: goto label_23e664;
        case 0x23e668u: goto label_23e668;
        case 0x23e66cu: goto label_23e66c;
        case 0x23e670u: goto label_23e670;
        case 0x23e674u: goto label_23e674;
        case 0x23e678u: goto label_23e678;
        case 0x23e67cu: goto label_23e67c;
        case 0x23e680u: goto label_23e680;
        case 0x23e684u: goto label_23e684;
        case 0x23e688u: goto label_23e688;
        case 0x23e68cu: goto label_23e68c;
        case 0x23e690u: goto label_23e690;
        case 0x23e694u: goto label_23e694;
        case 0x23e698u: goto label_23e698;
        case 0x23e69cu: goto label_23e69c;
        case 0x23e6a0u: goto label_23e6a0;
        case 0x23e6a4u: goto label_23e6a4;
        case 0x23e6a8u: goto label_23e6a8;
        case 0x23e6acu: goto label_23e6ac;
        case 0x23e6b0u: goto label_23e6b0;
        case 0x23e6b4u: goto label_23e6b4;
        case 0x23e6b8u: goto label_23e6b8;
        case 0x23e6bcu: goto label_23e6bc;
        case 0x23e6c0u: goto label_23e6c0;
        case 0x23e6c4u: goto label_23e6c4;
        case 0x23e6c8u: goto label_23e6c8;
        case 0x23e6ccu: goto label_23e6cc;
        case 0x23e6d0u: goto label_23e6d0;
        case 0x23e6d4u: goto label_23e6d4;
        case 0x23e6d8u: goto label_23e6d8;
        case 0x23e6dcu: goto label_23e6dc;
        case 0x23e6e0u: goto label_23e6e0;
        case 0x23e6e4u: goto label_23e6e4;
        case 0x23e6e8u: goto label_23e6e8;
        case 0x23e6ecu: goto label_23e6ec;
        case 0x23e6f0u: goto label_23e6f0;
        case 0x23e6f4u: goto label_23e6f4;
        case 0x23e6f8u: goto label_23e6f8;
        case 0x23e6fcu: goto label_23e6fc;
        case 0x23e700u: goto label_23e700;
        case 0x23e704u: goto label_23e704;
        case 0x23e708u: goto label_23e708;
        case 0x23e70cu: goto label_23e70c;
        case 0x23e710u: goto label_23e710;
        case 0x23e714u: goto label_23e714;
        case 0x23e718u: goto label_23e718;
        case 0x23e71cu: goto label_23e71c;
        case 0x23e720u: goto label_23e720;
        case 0x23e724u: goto label_23e724;
        case 0x23e728u: goto label_23e728;
        case 0x23e72cu: goto label_23e72c;
        case 0x23e730u: goto label_23e730;
        case 0x23e734u: goto label_23e734;
        case 0x23e738u: goto label_23e738;
        case 0x23e73cu: goto label_23e73c;
        case 0x23e740u: goto label_23e740;
        case 0x23e744u: goto label_23e744;
        case 0x23e748u: goto label_23e748;
        case 0x23e74cu: goto label_23e74c;
        case 0x23e750u: goto label_23e750;
        case 0x23e754u: goto label_23e754;
        case 0x23e758u: goto label_23e758;
        case 0x23e75cu: goto label_23e75c;
        case 0x23e760u: goto label_23e760;
        case 0x23e764u: goto label_23e764;
        case 0x23e768u: goto label_23e768;
        case 0x23e76cu: goto label_23e76c;
        case 0x23e770u: goto label_23e770;
        case 0x23e774u: goto label_23e774;
        case 0x23e778u: goto label_23e778;
        case 0x23e77cu: goto label_23e77c;
        case 0x23e780u: goto label_23e780;
        case 0x23e784u: goto label_23e784;
        case 0x23e788u: goto label_23e788;
        case 0x23e78cu: goto label_23e78c;
        case 0x23e790u: goto label_23e790;
        case 0x23e794u: goto label_23e794;
        case 0x23e798u: goto label_23e798;
        case 0x23e79cu: goto label_23e79c;
        case 0x23e7a0u: goto label_23e7a0;
        case 0x23e7a4u: goto label_23e7a4;
        case 0x23e7a8u: goto label_23e7a8;
        case 0x23e7acu: goto label_23e7ac;
        case 0x23e7b0u: goto label_23e7b0;
        case 0x23e7b4u: goto label_23e7b4;
        case 0x23e7b8u: goto label_23e7b8;
        case 0x23e7bcu: goto label_23e7bc;
        case 0x23e7c0u: goto label_23e7c0;
        case 0x23e7c4u: goto label_23e7c4;
        case 0x23e7c8u: goto label_23e7c8;
        case 0x23e7ccu: goto label_23e7cc;
        case 0x23e7d0u: goto label_23e7d0;
        case 0x23e7d4u: goto label_23e7d4;
        case 0x23e7d8u: goto label_23e7d8;
        case 0x23e7dcu: goto label_23e7dc;
        case 0x23e7e0u: goto label_23e7e0;
        case 0x23e7e4u: goto label_23e7e4;
        case 0x23e7e8u: goto label_23e7e8;
        case 0x23e7ecu: goto label_23e7ec;
        case 0x23e7f0u: goto label_23e7f0;
        case 0x23e7f4u: goto label_23e7f4;
        case 0x23e7f8u: goto label_23e7f8;
        case 0x23e7fcu: goto label_23e7fc;
        case 0x23e800u: goto label_23e800;
        case 0x23e804u: goto label_23e804;
        case 0x23e808u: goto label_23e808;
        case 0x23e80cu: goto label_23e80c;
        case 0x23e810u: goto label_23e810;
        case 0x23e814u: goto label_23e814;
        case 0x23e818u: goto label_23e818;
        case 0x23e81cu: goto label_23e81c;
        default: break;
    }

    ctx->pc = 0x23e540u;

label_23e540:
    // 0x23e540: 0x27bdffc0  addiu       $sp, $sp, -0x40
    ctx->pc = 0x23e540u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967232));
label_23e544:
    // 0x23e544: 0x7fb00030  sq          $s0, 0x30($sp)
    ctx->pc = 0x23e544u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 48), GPR_VEC(ctx, 16));
label_23e548:
    // 0x23e548: 0x7fb10020  sq          $s1, 0x20($sp)
    ctx->pc = 0x23e548u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 17));
label_23e54c:
    // 0x23e54c: 0x80802d  daddu       $s0, $a0, $zero
    ctx->pc = 0x23e54cu;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_23e550:
    // 0x23e550: 0x7fb20010  sq          $s2, 0x10($sp)
    ctx->pc = 0x23e550u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 18));
label_23e554:
    // 0x23e554: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x23e554u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_23e558:
    // 0x23e558: 0x8e050434  lw          $a1, 0x434($s0)
    ctx->pc = 0x23e558u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_23e55c:
    // 0x23e55c: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23e55cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23e560:
    // 0x23e560: 0x84640058  lh          $a0, 0x58($v1)
    ctx->pc = 0x23e560u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 88)));
label_23e564:
    // 0x23e564: 0x8c62005c  lw          $v0, 0x5C($v1)
    ctx->pc = 0x23e564u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 92)));
label_23e568:
    // 0x23e568: 0x40f809  jalr        $v0
label_23e56c:
    if (ctx->pc == 0x23E56Cu) {
        ctx->pc = 0x23E56Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E568u;
        // 0x23e56c: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E570u;
        goto label_23e570;
    }
    ctx->pc = 0x23E568u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E570u);
        ctx->pc = 0x23E56Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E568u;
        // 0x23e56c: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E568u, 0x23E570u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E570u;
label_23e570:
    // 0x23e570: 0x544000a6  bnel        $v0, $zero, . + 4 + (0xA6 << 2)
label_23e574:
    if (ctx->pc == 0x23E574u) {
        ctx->pc = 0x23E574u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E570u;
        // 0x23e574: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E578u;
        goto label_23e578;
    }
    ctx->pc = 0x23E570u;
    {
        const bool branch_taken_0x23e570 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x23e570) {
            ctx->pc = 0x23E574u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E570u;
            // 0x23e574: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
            SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E80Cu;
            goto label_23e80c;
        }
    }
    ctx->pc = 0x23E578u;
label_23e578:
    // 0x23e578: 0x8e0200bc  lw          $v0, 0xBC($s0)
    ctx->pc = 0x23e578u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 188)));
label_23e57c:
    // 0x23e57c: 0x14400009  bnez        $v0, . + 4 + (0x9 << 2)
label_23e580:
    if (ctx->pc == 0x23E580u) {
        ctx->pc = 0x23E580u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E57Cu;
        // 0x23e580: 0x882d  daddu       $s1, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E584u;
        goto label_23e584;
    }
    ctx->pc = 0x23E57Cu;
    {
        const bool branch_taken_0x23e57c = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x23E580u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E57Cu;
        // 0x23e580: 0x882d  daddu       $s1, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e57c) {
            ctx->pc = 0x23E5A4u;
            goto label_23e5a4;
        }
    }
    ctx->pc = 0x23E584u;
label_23e584:
    // 0x23e584: 0x8e0200c0  lw          $v0, 0xC0($s0)
    ctx->pc = 0x23e584u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 192)));
label_23e588:
    // 0x23e588: 0x54400007  bnel        $v0, $zero, . + 4 + (0x7 << 2)
label_23e58c:
    if (ctx->pc == 0x23E58Cu) {
        ctx->pc = 0x23E58Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E588u;
        // 0x23e58c: 0x24110001  addiu       $s1, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E590u;
        goto label_23e590;
    }
    ctx->pc = 0x23E588u;
    {
        const bool branch_taken_0x23e588 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x23e588) {
            ctx->pc = 0x23E58Cu;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E588u;
            // 0x23e58c: 0x24110001  addiu       $s1, $zero, 0x1 (Delay Slot)
            SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E5A8u;
            goto label_23e5a8;
        }
    }
    ctx->pc = 0x23E590u;
label_23e590:
    // 0x23e590: 0x8e020078  lw          $v0, 0x78($s0)
    ctx->pc = 0x23e590u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 120)));
label_23e594:
    // 0x23e594: 0x40f809  jalr        $v0
label_23e598:
    if (ctx->pc == 0x23E598u) {
        ctx->pc = 0x23E59Cu;
        goto label_23e59c;
    }
    ctx->pc = 0x23E594u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E59Cu);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E594u, 0x23E59Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E59Cu;
label_23e59c:
    // 0x23e59c: 0x50400003  beql        $v0, $zero, . + 4 + (0x3 << 2)
label_23e5a0:
    if (ctx->pc == 0x23E5A0u) {
        ctx->pc = 0x23E5A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E59Cu;
        // 0x23e5a0: 0x8e020128  lw          $v0, 0x128($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 296)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E5A4u;
        goto label_23e5a4;
    }
    ctx->pc = 0x23E59Cu;
    {
        const bool branch_taken_0x23e59c = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e59c) {
            ctx->pc = 0x23E5A0u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E59Cu;
            // 0x23e5a0: 0x8e020128  lw          $v0, 0x128($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 296)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E5ACu;
            goto label_23e5ac;
        }
    }
    ctx->pc = 0x23E5A4u;
label_23e5a4:
    // 0x23e5a4: 0x24110001  addiu       $s1, $zero, 0x1
    ctx->pc = 0x23e5a4u;
    SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_23e5a8:
    // 0x23e5a8: 0x8e020128  lw          $v0, 0x128($s0)
    ctx->pc = 0x23e5a8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 296)));
label_23e5ac:
    // 0x23e5ac: 0x50400009  beql        $v0, $zero, . + 4 + (0x9 << 2)
label_23e5b0:
    if (ctx->pc == 0x23E5B0u) {
        ctx->pc = 0x23E5B0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E5ACu;
        // 0x23e5b0: 0x8e12043c  lw          $s2, 0x43C($s0) (Delay Slot)
        SET_GPR_S32(ctx, 18, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E5B4u;
        goto label_23e5b4;
    }
    ctx->pc = 0x23E5ACu;
    {
        const bool branch_taken_0x23e5ac = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e5ac) {
            ctx->pc = 0x23E5B0u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E5ACu;
            // 0x23e5b0: 0x8e12043c  lw          $s2, 0x43C($s0) (Delay Slot)
            SET_GPR_S32(ctx, 18, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E5D4u;
            goto label_23e5d4;
        }
    }
    ctx->pc = 0x23E5B4u;
label_23e5b4:
    // 0x23e5b4: 0x8e0200c8  lw          $v0, 0xC8($s0)
    ctx->pc = 0x23e5b4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 200)));
label_23e5b8:
    // 0x23e5b8: 0x50400006  beql        $v0, $zero, . + 4 + (0x6 << 2)
label_23e5bc:
    if (ctx->pc == 0x23E5BCu) {
        ctx->pc = 0x23E5BCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E5B8u;
        // 0x23e5bc: 0x8e12043c  lw          $s2, 0x43C($s0) (Delay Slot)
        SET_GPR_S32(ctx, 18, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E5C0u;
        goto label_23e5c0;
    }
    ctx->pc = 0x23E5B8u;
    {
        const bool branch_taken_0x23e5b8 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e5b8) {
            ctx->pc = 0x23E5BCu;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E5B8u;
            // 0x23e5bc: 0x8e12043c  lw          $s2, 0x43C($s0) (Delay Slot)
            SET_GPR_S32(ctx, 18, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E5D4u;
            goto label_23e5d4;
        }
    }
    ctx->pc = 0x23E5C0u;
label_23e5c0:
    // 0x23e5c0: 0x12200003  beqz        $s1, . + 4 + (0x3 << 2)
label_23e5c4:
    if (ctx->pc == 0x23E5C4u) {
        ctx->pc = 0x23E5C4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E5C0u;
        // 0x23e5c4: 0x24050038  addiu       $a1, $zero, 0x38 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 56));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E5C8u;
        goto label_23e5c8;
    }
    ctx->pc = 0x23E5C0u;
    {
        const bool branch_taken_0x23e5c0 = (GPR_U64(ctx, 17) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E5C4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E5C0u;
        // 0x23e5c4: 0x24050038  addiu       $a1, $zero, 0x38 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 56));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e5c0) {
            ctx->pc = 0x23E5D0u;
            goto label_23e5d0;
        }
    }
    ctx->pc = 0x23E5C8u;
label_23e5c8:
    // 0x23e5c8: 0x10000084  b           . + 4 + (0x84 << 2)
label_23e5cc:
    if (ctx->pc == 0x23E5CCu) {
        ctx->pc = 0x23E5CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E5C8u;
        // 0x23e5cc: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E5D0u;
        goto label_23e5d0;
    }
    ctx->pc = 0x23E5C8u;
    {
        const bool branch_taken_0x23e5c8 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E5CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E5C8u;
        // 0x23e5cc: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e5c8) {
            ctx->pc = 0x23E7DCu;
            goto label_23e7dc;
        }
    }
    ctx->pc = 0x23E5D0u;
label_23e5d0:
    // 0x23e5d0: 0x8e12043c  lw          $s2, 0x43C($s0)
    ctx->pc = 0x23e5d0u;
    SET_GPR_S32(ctx, 18, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
label_23e5d4:
    // 0x23e5d4: 0xc090736  jal         func_241CD8
label_23e5d8:
    if (ctx->pc == 0x23E5D8u) {
        ctx->pc = 0x23E5D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E5D4u;
        // 0x23e5d8: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E5DCu;
        goto label_23e5dc;
    }
    ctx->pc = 0x23E5D4u;
    SET_GPR_U32(ctx, 31, 0x23E5DCu);
    ctx->pc = 0x23E5D8u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23E5D4u;
    // 0x23e5d8: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x241CD8u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x241CD8u, 0x23E5D4u, 0x23E5DCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23E5DCu;
label_23e5dc:
    // 0x23e5dc: 0x1040002c  beqz        $v0, . + 4 + (0x2C << 2)
label_23e5e0:
    if (ctx->pc == 0x23E5E0u) {
        ctx->pc = 0x23E5E4u;
        goto label_23e5e4;
    }
    ctx->pc = 0x23E5DCu;
    {
        const bool branch_taken_0x23e5dc = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e5dc) {
            ctx->pc = 0x23E690u;
            goto label_23e690;
        }
    }
    ctx->pc = 0x23E5E4u;
label_23e5e4:
    // 0x23e5e4: 0x8e020124  lw          $v0, 0x124($s0)
    ctx->pc = 0x23e5e4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 292)));
label_23e5e8:
    // 0x23e5e8: 0x14400003  bnez        $v0, . + 4 + (0x3 << 2)
label_23e5ec:
    if (ctx->pc == 0x23E5ECu) {
        ctx->pc = 0x23E5ECu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E5E8u;
        // 0x23e5ec: 0x8e02043c  lw          $v0, 0x43C($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E5F0u;
        goto label_23e5f0;
    }
    ctx->pc = 0x23E5E8u;
    {
        const bool branch_taken_0x23e5e8 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x23E5ECu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E5E8u;
        // 0x23e5ec: 0x8e02043c  lw          $v0, 0x43C($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e5e8) {
            ctx->pc = 0x23E5F8u;
            goto label_23e5f8;
        }
    }
    ctx->pc = 0x23E5F0u;
label_23e5f0:
    // 0x23e5f0: 0x12200009  beqz        $s1, . + 4 + (0x9 << 2)
label_23e5f4:
    if (ctx->pc == 0x23E5F4u) {
        ctx->pc = 0x23E5F8u;
        goto label_23e5f8;
    }
    ctx->pc = 0x23E5F0u;
    {
        const bool branch_taken_0x23e5f0 = (GPR_U64(ctx, 17) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e5f0) {
            ctx->pc = 0x23E618u;
            goto label_23e618;
        }
    }
    ctx->pc = 0x23E5F8u;
label_23e5f8:
    // 0x23e5f8: 0x40182d  daddu       $v1, $v0, $zero
    ctx->pc = 0x23e5f8u;
    SET_GPR_U64(ctx, 3, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_23e5fc:
    // 0x23e5fc: 0x30420008  andi        $v0, $v0, 0x8
    ctx->pc = 0x23e5fcu;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)8);
label_23e600:
    // 0x23e600: 0x1040000a  beqz        $v0, . + 4 + (0xA << 2)
label_23e604:
    if (ctx->pc == 0x23E604u) {
        ctx->pc = 0x23E604u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E600u;
        // 0x23e604: 0x30620001  andi        $v0, $v1, 0x1 (Delay Slot)
        SET_GPR_U64(ctx, 2, GPR_U64(ctx, 3) & (uint64_t)(uint16_t)1);
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E608u;
        goto label_23e608;
    }
    ctx->pc = 0x23E600u;
    {
        const bool branch_taken_0x23e600 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E604u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E600u;
        // 0x23e604: 0x30620001  andi        $v0, $v1, 0x1 (Delay Slot)
        SET_GPR_U64(ctx, 2, GPR_U64(ctx, 3) & (uint64_t)(uint16_t)1);
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e600) {
            ctx->pc = 0x23E62Cu;
            goto label_23e62c;
        }
    }
    ctx->pc = 0x23E608u;
label_23e608:
    // 0x23e608: 0xc08fad4  jal         func_23EB50
label_23e60c:
    if (ctx->pc == 0x23E60Cu) {
        ctx->pc = 0x23E60Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E608u;
        // 0x23e60c: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E610u;
        goto label_23e610;
    }
    ctx->pc = 0x23E608u;
    SET_GPR_U32(ctx, 31, 0x23E610u);
    ctx->pc = 0x23E60Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23E608u;
    // 0x23e60c: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x23EB50u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x23EB50u, 0x23E608u, 0x23E610u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23E610u;
label_23e610:
    // 0x23e610: 0x1000007e  b           . + 4 + (0x7E << 2)
label_23e614:
    if (ctx->pc == 0x23E614u) {
        ctx->pc = 0x23E614u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E610u;
        // 0x23e614: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E618u;
        goto label_23e618;
    }
    ctx->pc = 0x23E610u;
    {
        const bool branch_taken_0x23e610 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E614u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E610u;
        // 0x23e614: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e610) {
            ctx->pc = 0x23E80Cu;
            goto label_23e80c;
        }
    }
    ctx->pc = 0x23E618u;
label_23e618:
    // 0x23e618: 0x40182d  daddu       $v1, $v0, $zero
    ctx->pc = 0x23e618u;
    SET_GPR_U64(ctx, 3, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_23e61c:
    // 0x23e61c: 0x30420008  andi        $v0, $v0, 0x8
    ctx->pc = 0x23e61cu;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)8);
label_23e620:
    // 0x23e620: 0x14400013  bnez        $v0, . + 4 + (0x13 << 2)
label_23e624:
    if (ctx->pc == 0x23E624u) {
        ctx->pc = 0x23E624u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E620u;
        // 0x23e624: 0x2402fffb  addiu       $v0, $zero, -0x5 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967291));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E628u;
        goto label_23e628;
    }
    ctx->pc = 0x23E620u;
    {
        const bool branch_taken_0x23e620 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x23E624u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E620u;
        // 0x23e624: 0x2402fffb  addiu       $v0, $zero, -0x5 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967291));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e620) {
            ctx->pc = 0x23E670u;
            goto label_23e670;
        }
    }
    ctx->pc = 0x23E628u;
label_23e628:
    // 0x23e628: 0x30620001  andi        $v0, $v1, 0x1
    ctx->pc = 0x23e628u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 3) & (uint64_t)(uint16_t)1);
label_23e62c:
    // 0x23e62c: 0x10400003  beqz        $v0, . + 4 + (0x3 << 2)
label_23e630:
    if (ctx->pc == 0x23E630u) {
        ctx->pc = 0x23E630u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E62Cu;
        // 0x23e630: 0x24050005  addiu       $a1, $zero, 0x5 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E634u;
        goto label_23e634;
    }
    ctx->pc = 0x23E62Cu;
    {
        const bool branch_taken_0x23e62c = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E630u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E62Cu;
        // 0x23e630: 0x24050005  addiu       $a1, $zero, 0x5 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 5));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e62c) {
            ctx->pc = 0x23E63Cu;
            goto label_23e63c;
        }
    }
    ctx->pc = 0x23E634u;
label_23e634:
    // 0x23e634: 0x10000069  b           . + 4 + (0x69 << 2)
label_23e638:
    if (ctx->pc == 0x23E638u) {
        ctx->pc = 0x23E638u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E634u;
        // 0x23e638: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E63Cu;
        goto label_23e63c;
    }
    ctx->pc = 0x23E634u;
    {
        const bool branch_taken_0x23e634 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E638u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E634u;
        // 0x23e638: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e634) {
            ctx->pc = 0x23E7DCu;
            goto label_23e7dc;
        }
    }
    ctx->pc = 0x23E63Cu;
label_23e63c:
    // 0x23e63c: 0x8e020120  lw          $v0, 0x120($s0)
    ctx->pc = 0x23e63cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 288)));
label_23e640:
    // 0x23e640: 0x10400005  beqz        $v0, . + 4 + (0x5 << 2)
label_23e644:
    if (ctx->pc == 0x23E644u) {
        ctx->pc = 0x23E644u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E640u;
        // 0x23e644: 0x30620010  andi        $v0, $v1, 0x10 (Delay Slot)
        SET_GPR_U64(ctx, 2, GPR_U64(ctx, 3) & (uint64_t)(uint16_t)16);
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E648u;
        goto label_23e648;
    }
    ctx->pc = 0x23E640u;
    {
        const bool branch_taken_0x23e640 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E644u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E640u;
        // 0x23e644: 0x30620010  andi        $v0, $v1, 0x10 (Delay Slot)
        SET_GPR_U64(ctx, 2, GPR_U64(ctx, 3) & (uint64_t)(uint16_t)16);
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e640) {
            ctx->pc = 0x23E658u;
            goto label_23e658;
        }
    }
    ctx->pc = 0x23E648u;
label_23e648:
    // 0x23e648: 0x10400003  beqz        $v0, . + 4 + (0x3 << 2)
label_23e64c:
    if (ctx->pc == 0x23E64Cu) {
        ctx->pc = 0x23E64Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E648u;
        // 0x23e64c: 0x24050027  addiu       $a1, $zero, 0x27 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 39));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E650u;
        goto label_23e650;
    }
    ctx->pc = 0x23E648u;
    {
        const bool branch_taken_0x23e648 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E64Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E648u;
        // 0x23e64c: 0x24050027  addiu       $a1, $zero, 0x27 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 39));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e648) {
            ctx->pc = 0x23E658u;
            goto label_23e658;
        }
    }
    ctx->pc = 0x23E650u;
label_23e650:
    // 0x23e650: 0x10000062  b           . + 4 + (0x62 << 2)
label_23e654:
    if (ctx->pc == 0x23E654u) {
        ctx->pc = 0x23E654u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E650u;
        // 0x23e654: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E658u;
        goto label_23e658;
    }
    ctx->pc = 0x23E650u;
    {
        const bool branch_taken_0x23e650 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E654u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E650u;
        // 0x23e654: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e650) {
            ctx->pc = 0x23E7DCu;
            goto label_23e7dc;
        }
    }
    ctx->pc = 0x23E658u;
label_23e658:
    // 0x23e658: 0x30620008  andi        $v0, $v1, 0x8
    ctx->pc = 0x23e658u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 3) & (uint64_t)(uint16_t)8);
label_23e65c:
    // 0x23e65c: 0x14400004  bnez        $v0, . + 4 + (0x4 << 2)
label_23e660:
    if (ctx->pc == 0x23E660u) {
        ctx->pc = 0x23E660u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E65Cu;
        // 0x23e660: 0x2402fffb  addiu       $v0, $zero, -0x5 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967291));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E664u;
        goto label_23e664;
    }
    ctx->pc = 0x23E65Cu;
    {
        const bool branch_taken_0x23e65c = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x23E660u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E65Cu;
        // 0x23e660: 0x2402fffb  addiu       $v0, $zero, -0x5 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967291));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e65c) {
            ctx->pc = 0x23E670u;
            goto label_23e670;
        }
    }
    ctx->pc = 0x23E664u;
label_23e664:
    // 0x23e664: 0x32420008  andi        $v0, $s2, 0x8
    ctx->pc = 0x23e664u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 18) & (uint64_t)(uint16_t)8);
label_23e668:
    // 0x23e668: 0x14400005  bnez        $v0, . + 4 + (0x5 << 2)
label_23e66c:
    if (ctx->pc == 0x23E66Cu) {
        ctx->pc = 0x23E66Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E668u;
        // 0x23e66c: 0x2402fffb  addiu       $v0, $zero, -0x5 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967291));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E670u;
        goto label_23e670;
    }
    ctx->pc = 0x23E668u;
    {
        const bool branch_taken_0x23e668 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x23E66Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E668u;
        // 0x23e66c: 0x2402fffb  addiu       $v0, $zero, -0x5 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967291));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e668) {
            ctx->pc = 0x23E680u;
            goto label_23e680;
        }
    }
    ctx->pc = 0x23E670u;
label_23e670:
    // 0x23e670: 0x14600007  bnez        $v1, . + 4 + (0x7 << 2)
label_23e674:
    if (ctx->pc == 0x23E674u) {
        ctx->pc = 0x23E674u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E670u;
        // 0x23e674: 0x2421024  and         $v0, $s2, $v0 (Delay Slot)
        SET_GPR_U64(ctx, 2, GPR_U64(ctx, 18) & GPR_U64(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E678u;
        goto label_23e678;
    }
    ctx->pc = 0x23E670u;
    {
        const bool branch_taken_0x23e670 = (GPR_U64(ctx, 3) != GPR_U64(ctx, 0));
        ctx->pc = 0x23E674u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E670u;
        // 0x23e674: 0x2421024  and         $v0, $s2, $v0 (Delay Slot)
        SET_GPR_U64(ctx, 2, GPR_U64(ctx, 18) & GPR_U64(ctx, 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e670) {
            ctx->pc = 0x23E690u;
            goto label_23e690;
        }
    }
    ctx->pc = 0x23E678u;
label_23e678:
    // 0x23e678: 0x10400005  beqz        $v0, . + 4 + (0x5 << 2)
label_23e67c:
    if (ctx->pc == 0x23E67Cu) {
        ctx->pc = 0x23E680u;
        goto label_23e680;
    }
    ctx->pc = 0x23E678u;
    {
        const bool branch_taken_0x23e678 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e678) {
            ctx->pc = 0x23E690u;
            goto label_23e690;
        }
    }
    ctx->pc = 0x23E680u;
label_23e680:
    // 0x23e680: 0xc0907f4  jal         func_241FD0
label_23e684:
    if (ctx->pc == 0x23E684u) {
        ctx->pc = 0x23E684u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E680u;
        // 0x23e684: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E688u;
        goto label_23e688;
    }
    ctx->pc = 0x23E680u;
    SET_GPR_U32(ctx, 31, 0x23E688u);
    ctx->pc = 0x23E684u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23E680u;
    // 0x23e684: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x241FD0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x241FD0u, 0x23E680u, 0x23E688u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23E688u;
label_23e688:
    // 0x23e688: 0x10000060  b           . + 4 + (0x60 << 2)
label_23e68c:
    if (ctx->pc == 0x23E68Cu) {
        ctx->pc = 0x23E68Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E688u;
        // 0x23e68c: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E690u;
        goto label_23e690;
    }
    ctx->pc = 0x23E688u;
    {
        const bool branch_taken_0x23e688 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E68Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E688u;
        // 0x23e68c: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e688) {
            ctx->pc = 0x23E80Cu;
            goto label_23e80c;
        }
    }
    ctx->pc = 0x23E690u;
label_23e690:
    // 0x23e690: 0x5620000f  bnel        $s1, $zero, . + 4 + (0xF << 2)
label_23e694:
    if (ctx->pc == 0x23E694u) {
        ctx->pc = 0x23E694u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E690u;
        // 0x23e694: 0x8e0200bc  lw          $v0, 0xBC($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 188)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E698u;
        goto label_23e698;
    }
    ctx->pc = 0x23E690u;
    {
        const bool branch_taken_0x23e690 = (GPR_U64(ctx, 17) != GPR_U64(ctx, 0));
        if (branch_taken_0x23e690) {
            ctx->pc = 0x23E694u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E690u;
            // 0x23e694: 0x8e0200bc  lw          $v0, 0xBC($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 188)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E6D0u;
            goto label_23e6d0;
        }
    }
    ctx->pc = 0x23E698u;
label_23e698:
    // 0x23e698: 0x8e0200c8  lw          $v0, 0xC8($s0)
    ctx->pc = 0x23e698u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 200)));
label_23e69c:
    // 0x23e69c: 0x50400006  beql        $v0, $zero, . + 4 + (0x6 << 2)
label_23e6a0:
    if (ctx->pc == 0x23E6A0u) {
        ctx->pc = 0x23E6A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E69Cu;
        // 0x23e6a0: 0x8e02043c  lw          $v0, 0x43C($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E6A4u;
        goto label_23e6a4;
    }
    ctx->pc = 0x23E69Cu;
    {
        const bool branch_taken_0x23e69c = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e69c) {
            ctx->pc = 0x23E6A0u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E69Cu;
            // 0x23e6a0: 0x8e02043c  lw          $v0, 0x43C($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1084)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E6B8u;
            goto label_23e6b8;
        }
    }
    ctx->pc = 0x23E6A4u;
label_23e6a4:
    // 0x23e6a4: 0xae0000c8  sw          $zero, 0xC8($s0)
    ctx->pc = 0x23e6a4u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 200), GPR_U32(ctx, 0));
label_23e6a8:
    // 0x23e6a8: 0xc090814  jal         func_242050
label_23e6ac:
    if (ctx->pc == 0x23E6ACu) {
        ctx->pc = 0x23E6ACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6A8u;
        // 0x23e6ac: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E6B0u;
        goto label_23e6b0;
    }
    ctx->pc = 0x23E6A8u;
    SET_GPR_U32(ctx, 31, 0x23E6B0u);
    ctx->pc = 0x23E6ACu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x23E6A8u;
    // 0x23e6ac: 0x200202d  daddu       $a0, $s0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x242050u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x242050u, 0x23E6A8u, 0x23E6B0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x23E6B0u;
label_23e6b0:
    // 0x23e6b0: 0x10000056  b           . + 4 + (0x56 << 2)
label_23e6b4:
    if (ctx->pc == 0x23E6B4u) {
        ctx->pc = 0x23E6B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6B0u;
        // 0x23e6b4: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E6B8u;
        goto label_23e6b8;
    }
    ctx->pc = 0x23E6B0u;
    {
        const bool branch_taken_0x23e6b0 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E6B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6B0u;
        // 0x23e6b4: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e6b0) {
            ctx->pc = 0x23E80Cu;
            goto label_23e80c;
        }
    }
    ctx->pc = 0x23E6B8u;
label_23e6b8:
    // 0x23e6b8: 0x30420008  andi        $v0, $v0, 0x8
    ctx->pc = 0x23e6b8u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)8);
label_23e6bc:
    // 0x23e6bc: 0x10400003  beqz        $v0, . + 4 + (0x3 << 2)
label_23e6c0:
    if (ctx->pc == 0x23E6C0u) {
        ctx->pc = 0x23E6C0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6BCu;
        // 0x23e6c0: 0x24050031  addiu       $a1, $zero, 0x31 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 49));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E6C4u;
        goto label_23e6c4;
    }
    ctx->pc = 0x23E6BCu;
    {
        const bool branch_taken_0x23e6bc = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E6C0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6BCu;
        // 0x23e6c0: 0x24050031  addiu       $a1, $zero, 0x31 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 49));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e6bc) {
            ctx->pc = 0x23E6CCu;
            goto label_23e6cc;
        }
    }
    ctx->pc = 0x23E6C4u;
label_23e6c4:
    // 0x23e6c4: 0x10000045  b           . + 4 + (0x45 << 2)
label_23e6c8:
    if (ctx->pc == 0x23E6C8u) {
        ctx->pc = 0x23E6C8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6C4u;
        // 0x23e6c8: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E6CCu;
        goto label_23e6cc;
    }
    ctx->pc = 0x23E6C4u;
    {
        const bool branch_taken_0x23e6c4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E6C8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6C4u;
        // 0x23e6c8: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e6c4) {
            ctx->pc = 0x23E7DCu;
            goto label_23e7dc;
        }
    }
    ctx->pc = 0x23E6CCu;
label_23e6cc:
    // 0x23e6cc: 0x8e0200bc  lw          $v0, 0xBC($s0)
    ctx->pc = 0x23e6ccu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 188)));
label_23e6d0:
    // 0x23e6d0: 0x10400022  beqz        $v0, . + 4 + (0x22 << 2)
label_23e6d4:
    if (ctx->pc == 0x23E6D4u) {
        ctx->pc = 0x23E6D4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6D0u;
        // 0x23e6d4: 0x8e050434  lw          $a1, 0x434($s0) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E6D8u;
        goto label_23e6d8;
    }
    ctx->pc = 0x23E6D0u;
    {
        const bool branch_taken_0x23e6d0 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E6D4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6D0u;
        // 0x23e6d4: 0x8e050434  lw          $a1, 0x434($s0) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e6d0) {
            ctx->pc = 0x23E75Cu;
            goto label_23e75c;
        }
    }
    ctx->pc = 0x23E6D8u;
label_23e6d8:
    // 0x23e6d8: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23e6d8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23e6dc:
    // 0x23e6dc: 0x846401b8  lh          $a0, 0x1B8($v1)
    ctx->pc = 0x23e6dcu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 440)));
label_23e6e0:
    // 0x23e6e0: 0x8c6201bc  lw          $v0, 0x1BC($v1)
    ctx->pc = 0x23e6e0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 444)));
label_23e6e4:
    // 0x23e6e4: 0x40f809  jalr        $v0
label_23e6e8:
    if (ctx->pc == 0x23E6E8u) {
        ctx->pc = 0x23E6E8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6E4u;
        // 0x23e6e8: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E6ECu;
        goto label_23e6ec;
    }
    ctx->pc = 0x23E6E4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E6ECu);
        ctx->pc = 0x23E6E8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6E4u;
        // 0x23e6e8: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E6E4u, 0x23E6ECu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E6ECu;
label_23e6ec:
    // 0x23e6ec: 0x50400019  beql        $v0, $zero, . + 4 + (0x19 << 2)
label_23e6f0:
    if (ctx->pc == 0x23E6F0u) {
        ctx->pc = 0x23E6F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E6ECu;
        // 0x23e6f0: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E6F4u;
        goto label_23e6f4;
    }
    ctx->pc = 0x23E6ECu;
    {
        const bool branch_taken_0x23e6ec = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e6ec) {
            ctx->pc = 0x23E6F0u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E6ECu;
            // 0x23e6f0: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E754u;
            goto label_23e754;
        }
    }
    ctx->pc = 0x23E6F4u;
label_23e6f4:
    // 0x23e6f4: 0x8e050434  lw          $a1, 0x434($s0)
    ctx->pc = 0x23e6f4u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_23e6f8:
    // 0x23e6f8: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23e6f8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23e6fc:
    // 0x23e6fc: 0x846401d0  lh          $a0, 0x1D0($v1)
    ctx->pc = 0x23e6fcu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 464)));
label_23e700:
    // 0x23e700: 0x8c6201d4  lw          $v0, 0x1D4($v1)
    ctx->pc = 0x23e700u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 468)));
label_23e704:
    // 0x23e704: 0x40f809  jalr        $v0
label_23e708:
    if (ctx->pc == 0x23E708u) {
        ctx->pc = 0x23E708u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E704u;
        // 0x23e708: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E70Cu;
        goto label_23e70c;
    }
    ctx->pc = 0x23E704u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E70Cu);
        ctx->pc = 0x23E708u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E704u;
        // 0x23e708: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E704u, 0x23E70Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E70Cu;
label_23e70c:
    // 0x23e70c: 0x50400011  beql        $v0, $zero, . + 4 + (0x11 << 2)
label_23e710:
    if (ctx->pc == 0x23E710u) {
        ctx->pc = 0x23E710u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E70Cu;
        // 0x23e710: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E714u;
        goto label_23e714;
    }
    ctx->pc = 0x23E70Cu;
    {
        const bool branch_taken_0x23e70c = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e70c) {
            ctx->pc = 0x23E710u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E70Cu;
            // 0x23e710: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E754u;
            goto label_23e754;
        }
    }
    ctx->pc = 0x23E714u;
label_23e714:
    // 0x23e714: 0x8e050434  lw          $a1, 0x434($s0)
    ctx->pc = 0x23e714u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_23e718:
    // 0x23e718: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23e718u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23e71c:
    // 0x23e71c: 0x84640198  lh          $a0, 0x198($v1)
    ctx->pc = 0x23e71cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 408)));
label_23e720:
    // 0x23e720: 0x8c62019c  lw          $v0, 0x19C($v1)
    ctx->pc = 0x23e720u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 412)));
label_23e724:
    // 0x23e724: 0x40f809  jalr        $v0
label_23e728:
    if (ctx->pc == 0x23E728u) {
        ctx->pc = 0x23E728u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E724u;
        // 0x23e728: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E72Cu;
        goto label_23e72c;
    }
    ctx->pc = 0x23E724u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E72Cu);
        ctx->pc = 0x23E728u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E724u;
        // 0x23e728: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E724u, 0x23E72Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E72Cu;
label_23e72c:
    // 0x23e72c: 0x54400009  bnel        $v0, $zero, . + 4 + (0x9 << 2)
label_23e730:
    if (ctx->pc == 0x23E730u) {
        ctx->pc = 0x23E730u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E72Cu;
        // 0x23e730: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E734u;
        goto label_23e734;
    }
    ctx->pc = 0x23E72Cu;
    {
        const bool branch_taken_0x23e72c = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x23e72c) {
            ctx->pc = 0x23E730u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E72Cu;
            // 0x23e730: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E754u;
            goto label_23e754;
        }
    }
    ctx->pc = 0x23E734u;
label_23e734:
    // 0x23e734: 0x8e050434  lw          $a1, 0x434($s0)
    ctx->pc = 0x23e734u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_23e738:
    // 0x23e738: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23e738u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23e73c:
    // 0x23e73c: 0x846401d8  lh          $a0, 0x1D8($v1)
    ctx->pc = 0x23e73cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 472)));
label_23e740:
    // 0x23e740: 0x8c6201dc  lw          $v0, 0x1DC($v1)
    ctx->pc = 0x23e740u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 476)));
label_23e744:
    // 0x23e744: 0x40f809  jalr        $v0
label_23e748:
    if (ctx->pc == 0x23E748u) {
        ctx->pc = 0x23E748u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E744u;
        // 0x23e748: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E74Cu;
        goto label_23e74c;
    }
    ctx->pc = 0x23E744u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E74Cu);
        ctx->pc = 0x23E748u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E744u;
        // 0x23e748: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E744u, 0x23E74Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E74Cu;
label_23e74c:
    // 0x23e74c: 0x10400022  beqz        $v0, . + 4 + (0x22 << 2)
label_23e750:
    if (ctx->pc == 0x23E750u) {
        ctx->pc = 0x23E750u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E74Cu;
        // 0x23e750: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E754u;
        goto label_23e754;
    }
    ctx->pc = 0x23E74Cu;
    {
        const bool branch_taken_0x23e74c = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E750u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E74Cu;
        // 0x23e750: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e74c) {
            ctx->pc = 0x23E7D8u;
            goto label_23e7d8;
        }
    }
    ctx->pc = 0x23E754u;
label_23e754:
    // 0x23e754: 0x10000021  b           . + 4 + (0x21 << 2)
label_23e758:
    if (ctx->pc == 0x23E758u) {
        ctx->pc = 0x23E758u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E754u;
        // 0x23e758: 0x24050007  addiu       $a1, $zero, 0x7 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 7));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E75Cu;
        goto label_23e75c;
    }
    ctx->pc = 0x23E754u;
    {
        const bool branch_taken_0x23e754 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E758u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E754u;
        // 0x23e758: 0x24050007  addiu       $a1, $zero, 0x7 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 7));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e754) {
            ctx->pc = 0x23E7DCu;
            goto label_23e7dc;
        }
    }
    ctx->pc = 0x23E75Cu;
label_23e75c:
    // 0x23e75c: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23e75cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23e760:
    // 0x23e760: 0x846401b8  lh          $a0, 0x1B8($v1)
    ctx->pc = 0x23e760u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 440)));
label_23e764:
    // 0x23e764: 0x8c6201bc  lw          $v0, 0x1BC($v1)
    ctx->pc = 0x23e764u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 444)));
label_23e768:
    // 0x23e768: 0x40f809  jalr        $v0
label_23e76c:
    if (ctx->pc == 0x23E76Cu) {
        ctx->pc = 0x23E76Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E768u;
        // 0x23e76c: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E770u;
        goto label_23e770;
    }
    ctx->pc = 0x23E768u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E770u);
        ctx->pc = 0x23E76Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E768u;
        // 0x23e76c: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E768u, 0x23E770u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E770u;
label_23e770:
    // 0x23e770: 0x50400020  beql        $v0, $zero, . + 4 + (0x20 << 2)
label_23e774:
    if (ctx->pc == 0x23E774u) {
        ctx->pc = 0x23E774u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E770u;
        // 0x23e774: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E778u;
        goto label_23e778;
    }
    ctx->pc = 0x23E770u;
    {
        const bool branch_taken_0x23e770 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e770) {
            ctx->pc = 0x23E774u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E770u;
            // 0x23e774: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E7F4u;
            goto label_23e7f4;
        }
    }
    ctx->pc = 0x23E778u;
label_23e778:
    // 0x23e778: 0x8e050434  lw          $a1, 0x434($s0)
    ctx->pc = 0x23e778u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_23e77c:
    // 0x23e77c: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23e77cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23e780:
    // 0x23e780: 0x846401d0  lh          $a0, 0x1D0($v1)
    ctx->pc = 0x23e780u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 464)));
label_23e784:
    // 0x23e784: 0x8c6201d4  lw          $v0, 0x1D4($v1)
    ctx->pc = 0x23e784u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 468)));
label_23e788:
    // 0x23e788: 0x40f809  jalr        $v0
label_23e78c:
    if (ctx->pc == 0x23E78Cu) {
        ctx->pc = 0x23E78Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E788u;
        // 0x23e78c: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E790u;
        goto label_23e790;
    }
    ctx->pc = 0x23E788u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E790u);
        ctx->pc = 0x23E78Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E788u;
        // 0x23e78c: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E788u, 0x23E790u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E790u;
label_23e790:
    // 0x23e790: 0x50400018  beql        $v0, $zero, . + 4 + (0x18 << 2)
label_23e794:
    if (ctx->pc == 0x23E794u) {
        ctx->pc = 0x23E794u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E790u;
        // 0x23e794: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E798u;
        goto label_23e798;
    }
    ctx->pc = 0x23E790u;
    {
        const bool branch_taken_0x23e790 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x23e790) {
            ctx->pc = 0x23E794u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E790u;
            // 0x23e794: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E7F4u;
            goto label_23e7f4;
        }
    }
    ctx->pc = 0x23E798u;
label_23e798:
    // 0x23e798: 0x8e050434  lw          $a1, 0x434($s0)
    ctx->pc = 0x23e798u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_23e79c:
    // 0x23e79c: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23e79cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23e7a0:
    // 0x23e7a0: 0x84640198  lh          $a0, 0x198($v1)
    ctx->pc = 0x23e7a0u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 408)));
label_23e7a4:
    // 0x23e7a4: 0x8c62019c  lw          $v0, 0x19C($v1)
    ctx->pc = 0x23e7a4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 412)));
label_23e7a8:
    // 0x23e7a8: 0x40f809  jalr        $v0
label_23e7ac:
    if (ctx->pc == 0x23E7ACu) {
        ctx->pc = 0x23E7ACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7A8u;
        // 0x23e7ac: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E7B0u;
        goto label_23e7b0;
    }
    ctx->pc = 0x23E7A8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E7B0u);
        ctx->pc = 0x23E7ACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7A8u;
        // 0x23e7ac: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E7A8u, 0x23E7B0u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E7B0u;
label_23e7b0:
    // 0x23e7b0: 0x54400010  bnel        $v0, $zero, . + 4 + (0x10 << 2)
label_23e7b4:
    if (ctx->pc == 0x23E7B4u) {
        ctx->pc = 0x23E7B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7B0u;
        // 0x23e7b4: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E7B8u;
        goto label_23e7b8;
    }
    ctx->pc = 0x23E7B0u;
    {
        const bool branch_taken_0x23e7b0 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x23e7b0) {
            ctx->pc = 0x23E7B4u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x23E7B0u;
            // 0x23e7b4: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x23E7F4u;
            goto label_23e7f4;
        }
    }
    ctx->pc = 0x23E7B8u;
label_23e7b8:
    // 0x23e7b8: 0x8e050434  lw          $a1, 0x434($s0)
    ctx->pc = 0x23e7b8u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_23e7bc:
    // 0x23e7bc: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x23e7bcu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_23e7c0:
    // 0x23e7c0: 0x846401d8  lh          $a0, 0x1D8($v1)
    ctx->pc = 0x23e7c0u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 472)));
label_23e7c4:
    // 0x23e7c4: 0x8c6201dc  lw          $v0, 0x1DC($v1)
    ctx->pc = 0x23e7c4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 476)));
label_23e7c8:
    // 0x23e7c8: 0x40f809  jalr        $v0
label_23e7cc:
    if (ctx->pc == 0x23E7CCu) {
        ctx->pc = 0x23E7CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7C8u;
        // 0x23e7cc: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E7D0u;
        goto label_23e7d0;
    }
    ctx->pc = 0x23E7C8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x23E7D0u);
        ctx->pc = 0x23E7CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7C8u;
        // 0x23e7cc: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E7C8u, 0x23E7D0u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E7D0u;
label_23e7d0:
    // 0x23e7d0: 0x14400008  bnez        $v0, . + 4 + (0x8 << 2)
label_23e7d4:
    if (ctx->pc == 0x23E7D4u) {
        ctx->pc = 0x23E7D4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7D0u;
        // 0x23e7d4: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E7D8u;
        goto label_23e7d8;
    }
    ctx->pc = 0x23E7D0u;
    {
        const bool branch_taken_0x23e7d0 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x23E7D4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7D0u;
        // 0x23e7d4: 0x8e020748  lw          $v0, 0x748($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1864)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e7d0) {
            ctx->pc = 0x23E7F4u;
            goto label_23e7f4;
        }
    }
    ctx->pc = 0x23E7D8u;
label_23e7d8:
    // 0x23e7d8: 0x24050006  addiu       $a1, $zero, 0x6
    ctx->pc = 0x23e7d8u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 6));
label_23e7dc:
    // 0x23e7dc: 0x84440008  lh          $a0, 0x8($v0)
    ctx->pc = 0x23e7dcu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 8)));
label_23e7e0:
    // 0x23e7e0: 0x8c43000c  lw          $v1, 0xC($v0)
    ctx->pc = 0x23e7e0u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 12)));
label_23e7e4:
    // 0x23e7e4: 0x60f809  jalr        $v1
label_23e7e8:
    if (ctx->pc == 0x23E7E8u) {
        ctx->pc = 0x23E7E8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7E4u;
        // 0x23e7e8: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E7ECu;
        goto label_23e7ec;
    }
    ctx->pc = 0x23E7E4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23E7ECu);
        ctx->pc = 0x23E7E8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7E4u;
        // 0x23e7e8: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E7E4u, 0x23E7ECu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E7ECu;
label_23e7ec:
    // 0x23e7ec: 0x10000007  b           . + 4 + (0x7 << 2)
label_23e7f0:
    if (ctx->pc == 0x23E7F0u) {
        ctx->pc = 0x23E7F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7ECu;
        // 0x23e7f0: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E7F4u;
        goto label_23e7f4;
    }
    ctx->pc = 0x23E7ECu;
    {
        const bool branch_taken_0x23e7ec = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x23E7F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E7ECu;
        // 0x23e7f0: 0x7bb00030  lq          $s0, 0x30($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x23e7ec) {
            ctx->pc = 0x23E80Cu;
            goto label_23e80c;
        }
    }
    ctx->pc = 0x23E7F4u;
label_23e7f4:
    // 0x23e7f4: 0x2405001d  addiu       $a1, $zero, 0x1D
    ctx->pc = 0x23e7f4u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 29));
label_23e7f8:
    // 0x23e7f8: 0x84440008  lh          $a0, 0x8($v0)
    ctx->pc = 0x23e7f8u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 8)));
label_23e7fc:
    // 0x23e7fc: 0x8c43000c  lw          $v1, 0xC($v0)
    ctx->pc = 0x23e7fcu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 12)));
label_23e800:
    // 0x23e800: 0x60f809  jalr        $v1
label_23e804:
    if (ctx->pc == 0x23E804u) {
        ctx->pc = 0x23E804u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E800u;
        // 0x23e804: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E808u;
        goto label_23e808;
    }
    ctx->pc = 0x23E800u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x23E808u);
        ctx->pc = 0x23E804u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E800u;
        // 0x23e804: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E800u, 0x23E808u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23E808u;
label_23e808:
    // 0x23e808: 0x7bb00030  lq          $s0, 0x30($sp)
    ctx->pc = 0x23e808u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
label_23e80c:
    // 0x23e80c: 0x7bb10020  lq          $s1, 0x20($sp)
    ctx->pc = 0x23e80cu;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_23e810:
    // 0x23e810: 0x7bb20010  lq          $s2, 0x10($sp)
    ctx->pc = 0x23e810u;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_23e814:
    // 0x23e814: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x23e814u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_23e818:
    // 0x23e818: 0x3e00008  jr          $ra
label_23e81c:
    if (ctx->pc == 0x23E81Cu) {
        ctx->pc = 0x23E81Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E818u;
        // 0x23e81c: 0x27bd0040  addiu       $sp, $sp, 0x40 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 64));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23E820u;
        goto label_fallthrough_0x23e818;
    }
    ctx->pc = 0x23E818u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x23E81Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23E818u;
        // 0x23e81c: 0x27bd0040  addiu       $sp, $sp, 0x40 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 64));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23E818u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
label_fallthrough_0x23e818:
    ctx->pc = 0x23E820u;
}
