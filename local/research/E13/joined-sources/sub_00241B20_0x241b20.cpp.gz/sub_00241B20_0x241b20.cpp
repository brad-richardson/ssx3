#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_00241B20
// Address: 0x241b20 - 0x241cd8
void sub_00241B20_0x241b20(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_00241B20_0x241b20");
#endif

    switch (ctx->pc) {
        case 0x241b20u: goto label_241b20;
        case 0x241b24u: goto label_241b24;
        case 0x241b28u: goto label_241b28;
        case 0x241b2cu: goto label_241b2c;
        case 0x241b30u: goto label_241b30;
        case 0x241b34u: goto label_241b34;
        case 0x241b38u: goto label_241b38;
        case 0x241b3cu: goto label_241b3c;
        case 0x241b40u: goto label_241b40;
        case 0x241b44u: goto label_241b44;
        case 0x241b48u: goto label_241b48;
        case 0x241b4cu: goto label_241b4c;
        case 0x241b50u: goto label_241b50;
        case 0x241b54u: goto label_241b54;
        case 0x241b58u: goto label_241b58;
        case 0x241b5cu: goto label_241b5c;
        case 0x241b60u: goto label_241b60;
        case 0x241b64u: goto label_241b64;
        case 0x241b68u: goto label_241b68;
        case 0x241b6cu: goto label_241b6c;
        case 0x241b70u: goto label_241b70;
        case 0x241b74u: goto label_241b74;
        case 0x241b78u: goto label_241b78;
        case 0x241b7cu: goto label_241b7c;
        case 0x241b80u: goto label_241b80;
        case 0x241b84u: goto label_241b84;
        case 0x241b88u: goto label_241b88;
        case 0x241b8cu: goto label_241b8c;
        case 0x241b90u: goto label_241b90;
        case 0x241b94u: goto label_241b94;
        case 0x241b98u: goto label_241b98;
        case 0x241b9cu: goto label_241b9c;
        case 0x241ba0u: goto label_241ba0;
        case 0x241ba4u: goto label_241ba4;
        case 0x241ba8u: goto label_241ba8;
        case 0x241bacu: goto label_241bac;
        case 0x241bb0u: goto label_241bb0;
        case 0x241bb4u: goto label_241bb4;
        case 0x241bb8u: goto label_241bb8;
        case 0x241bbcu: goto label_241bbc;
        case 0x241bc0u: goto label_241bc0;
        case 0x241bc4u: goto label_241bc4;
        case 0x241bc8u: goto label_241bc8;
        case 0x241bccu: goto label_241bcc;
        case 0x241bd0u: goto label_241bd0;
        case 0x241bd4u: goto label_241bd4;
        case 0x241bd8u: goto label_241bd8;
        case 0x241bdcu: goto label_241bdc;
        case 0x241be0u: goto label_241be0;
        case 0x241be4u: goto label_241be4;
        case 0x241be8u: goto label_241be8;
        case 0x241becu: goto label_241bec;
        case 0x241bf0u: goto label_241bf0;
        case 0x241bf4u: goto label_241bf4;
        case 0x241bf8u: goto label_241bf8;
        case 0x241bfcu: goto label_241bfc;
        case 0x241c00u: goto label_241c00;
        case 0x241c04u: goto label_241c04;
        case 0x241c08u: goto label_241c08;
        case 0x241c0cu: goto label_241c0c;
        case 0x241c10u: goto label_241c10;
        case 0x241c14u: goto label_241c14;
        case 0x241c18u: goto label_241c18;
        case 0x241c1cu: goto label_241c1c;
        case 0x241c20u: goto label_241c20;
        case 0x241c24u: goto label_241c24;
        case 0x241c28u: goto label_241c28;
        case 0x241c2cu: goto label_241c2c;
        case 0x241c30u: goto label_241c30;
        case 0x241c34u: goto label_241c34;
        case 0x241c38u: goto label_241c38;
        case 0x241c3cu: goto label_241c3c;
        case 0x241c40u: goto label_241c40;
        case 0x241c44u: goto label_241c44;
        case 0x241c48u: goto label_241c48;
        case 0x241c4cu: goto label_241c4c;
        case 0x241c50u: goto label_241c50;
        case 0x241c54u: goto label_241c54;
        case 0x241c58u: goto label_241c58;
        case 0x241c5cu: goto label_241c5c;
        case 0x241c60u: goto label_241c60;
        case 0x241c64u: goto label_241c64;
        case 0x241c68u: goto label_241c68;
        case 0x241c6cu: goto label_241c6c;
        case 0x241c70u: goto label_241c70;
        case 0x241c74u: goto label_241c74;
        case 0x241c78u: goto label_241c78;
        case 0x241c7cu: goto label_241c7c;
        case 0x241c80u: goto label_241c80;
        case 0x241c84u: goto label_241c84;
        case 0x241c88u: goto label_241c88;
        case 0x241c8cu: goto label_241c8c;
        case 0x241c90u: goto label_241c90;
        case 0x241c94u: goto label_241c94;
        case 0x241c98u: goto label_241c98;
        case 0x241c9cu: goto label_241c9c;
        case 0x241ca0u: goto label_241ca0;
        case 0x241ca4u: goto label_241ca4;
        case 0x241ca8u: goto label_241ca8;
        case 0x241cacu: goto label_241cac;
        case 0x241cb0u: goto label_241cb0;
        case 0x241cb4u: goto label_241cb4;
        case 0x241cb8u: goto label_241cb8;
        case 0x241cbcu: goto label_241cbc;
        case 0x241cc0u: goto label_241cc0;
        case 0x241cc4u: goto label_241cc4;
        case 0x241cc8u: goto label_241cc8;
        case 0x241cccu: goto label_241ccc;
        case 0x241cd0u: goto label_241cd0;
        case 0x241cd4u: goto label_241cd4;
        default: break;
    }

    ctx->pc = 0x241b20u;

label_241b20:
    // 0x241b20: 0x27bdffb0  addiu       $sp, $sp, -0x50
    ctx->pc = 0x241b20u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967216));
label_241b24:
    // 0x241b24: 0x7fb20020  sq          $s2, 0x20($sp)
    ctx->pc = 0x241b24u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 18));
label_241b28:
    // 0x241b28: 0x7fb00040  sq          $s0, 0x40($sp)
    ctx->pc = 0x241b28u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 64), GPR_VEC(ctx, 16));
label_241b2c:
    // 0x241b2c: 0x80902d  daddu       $s2, $a0, $zero
    ctx->pc = 0x241b2cu;
    SET_GPR_U64(ctx, 18, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_241b30:
    // 0x241b30: 0x7fb10030  sq          $s1, 0x30($sp)
    ctx->pc = 0x241b30u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 48), GPR_VEC(ctx, 17));
label_241b34:
    // 0x241b34: 0x7fb30010  sq          $s3, 0x10($sp)
    ctx->pc = 0x241b34u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 19));
label_241b38:
    // 0x241b38: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x241b38u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_241b3c:
    // 0x241b3c: 0x8e43042c  lw          $v1, 0x42C($s2)
    ctx->pc = 0x241b3cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1068)));
label_241b40:
    // 0x241b40: 0x8e420428  lw          $v0, 0x428($s2)
    ctx->pc = 0x241b40u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1064)));
label_241b44:
    // 0x241b44: 0x50620003  beql        $v1, $v0, . + 4 + (0x3 << 2)
label_241b48:
    if (ctx->pc == 0x241B48u) {
        ctx->pc = 0x241B48u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241B44u;
        // 0x241b48: 0x8e450434  lw          $a1, 0x434($s2) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241B4Cu;
        goto label_241b4c;
    }
    ctx->pc = 0x241B44u;
    {
        const bool branch_taken_0x241b44 = (GPR_U64(ctx, 3) == GPR_U64(ctx, 2));
        if (branch_taken_0x241b44) {
            ctx->pc = 0x241B48u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x241B44u;
            // 0x241b48: 0x8e450434  lw          $a1, 0x434($s2) (Delay Slot)
            SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x241B54u;
            goto label_241b54;
        }
    }
    ctx->pc = 0x241B4Cu;
label_241b4c:
    // 0x241b4c: 0x1000005a  b           . + 4 + (0x5A << 2)
label_241b50:
    if (ctx->pc == 0x241B50u) {
        ctx->pc = 0x241B50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241B4Cu;
        // 0x241b50: 0x8e42043c  lw          $v0, 0x43C($s2) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1084)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241B54u;
        goto label_241b54;
    }
    ctx->pc = 0x241B4Cu;
    {
        const bool branch_taken_0x241b4c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x241B50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241B4Cu;
        // 0x241b50: 0x8e42043c  lw          $v0, 0x43C($s2) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1084)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x241b4c) {
            ctx->pc = 0x241CB8u;
            goto label_241cb8;
        }
    }
    ctx->pc = 0x241B54u;
label_241b54:
    // 0x241b54: 0x882d  daddu       $s1, $zero, $zero
    ctx->pc = 0x241b54u;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_241b58:
    // 0x241b58: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x241b58u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_241b5c:
    // 0x241b5c: 0x84640188  lh          $a0, 0x188($v1)
    ctx->pc = 0x241b5cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 392)));
label_241b60:
    // 0x241b60: 0x8c62018c  lw          $v0, 0x18C($v1)
    ctx->pc = 0x241b60u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 396)));
label_241b64:
    // 0x241b64: 0x40f809  jalr        $v0
label_241b68:
    if (ctx->pc == 0x241B68u) {
        ctx->pc = 0x241B68u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241B64u;
        // 0x241b68: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241B6Cu;
        goto label_241b6c;
    }
    ctx->pc = 0x241B64u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241B6Cu);
        ctx->pc = 0x241B68u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241B64u;
        // 0x241b68: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241B64u, 0x241B6Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241B6Cu;
label_241b6c:
    // 0x241b6c: 0x8e450434  lw          $a1, 0x434($s2)
    ctx->pc = 0x241b6cu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
label_241b70:
    // 0x241b70: 0x30500001  andi        $s0, $v0, 0x1
    ctx->pc = 0x241b70u;
    SET_GPR_U64(ctx, 16, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)1);
label_241b74:
    // 0x241b74: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x241b74u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_241b78:
    // 0x241b78: 0x84640198  lh          $a0, 0x198($v1)
    ctx->pc = 0x241b78u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 408)));
label_241b7c:
    // 0x241b7c: 0x8c62019c  lw          $v0, 0x19C($v1)
    ctx->pc = 0x241b7cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 412)));
label_241b80:
    // 0x241b80: 0x40f809  jalr        $v0
label_241b84:
    if (ctx->pc == 0x241B84u) {
        ctx->pc = 0x241B84u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241B80u;
        // 0x241b84: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241B88u;
        goto label_241b88;
    }
    ctx->pc = 0x241B80u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241B88u);
        ctx->pc = 0x241B84u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241B80u;
        // 0x241b84: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241B80u, 0x241B88u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241B88u;
label_241b88:
    // 0x241b88: 0x5440000a  bnel        $v0, $zero, . + 4 + (0xA << 2)
label_241b8c:
    if (ctx->pc == 0x241B8Cu) {
        ctx->pc = 0x241B8Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241B88u;
        // 0x241b8c: 0x24110001  addiu       $s1, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241B90u;
        goto label_241b90;
    }
    ctx->pc = 0x241B88u;
    {
        const bool branch_taken_0x241b88 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x241b88) {
            ctx->pc = 0x241B8Cu;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x241B88u;
            // 0x241b8c: 0x24110001  addiu       $s1, $zero, 0x1 (Delay Slot)
            SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
            ctx->in_delay_slot = false;
            ctx->pc = 0x241BB4u;
            goto label_241bb4;
        }
    }
    ctx->pc = 0x241B90u;
label_241b90:
    // 0x241b90: 0x8e450434  lw          $a1, 0x434($s2)
    ctx->pc = 0x241b90u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
label_241b94:
    // 0x241b94: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x241b94u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_241b98:
    // 0x241b98: 0x846401d8  lh          $a0, 0x1D8($v1)
    ctx->pc = 0x241b98u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 472)));
label_241b9c:
    // 0x241b9c: 0x8c6201dc  lw          $v0, 0x1DC($v1)
    ctx->pc = 0x241b9cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 476)));
label_241ba0:
    // 0x241ba0: 0x40f809  jalr        $v0
label_241ba4:
    if (ctx->pc == 0x241BA4u) {
        ctx->pc = 0x241BA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241BA0u;
        // 0x241ba4: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241BA8u;
        goto label_241ba8;
    }
    ctx->pc = 0x241BA0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241BA8u);
        ctx->pc = 0x241BA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241BA0u;
        // 0x241ba4: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241BA0u, 0x241BA8u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241BA8u;
label_241ba8:
    // 0x241ba8: 0x50400003  beql        $v0, $zero, . + 4 + (0x3 << 2)
label_241bac:
    if (ctx->pc == 0x241BACu) {
        ctx->pc = 0x241BACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241BA8u;
        // 0x241bac: 0x8e450434  lw          $a1, 0x434($s2) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241BB0u;
        goto label_241bb0;
    }
    ctx->pc = 0x241BA8u;
    {
        const bool branch_taken_0x241ba8 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x241ba8) {
            ctx->pc = 0x241BACu;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x241BA8u;
            // 0x241bac: 0x8e450434  lw          $a1, 0x434($s2) (Delay Slot)
            SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x241BB8u;
            goto label_241bb8;
        }
    }
    ctx->pc = 0x241BB0u;
label_241bb0:
    // 0x241bb0: 0x24110001  addiu       $s1, $zero, 0x1
    ctx->pc = 0x241bb0u;
    SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_241bb4:
    // 0x241bb4: 0x8e450434  lw          $a1, 0x434($s2)
    ctx->pc = 0x241bb4u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
label_241bb8:
    // 0x241bb8: 0x111040  sll         $v0, $s1, 1
    ctx->pc = 0x241bb8u;
    SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 17), 1));
label_241bbc:
    // 0x241bbc: 0x2028825  or          $s1, $s0, $v0
    ctx->pc = 0x241bbcu;
    SET_GPR_U64(ctx, 17, GPR_U64(ctx, 16) | GPR_U64(ctx, 2));
label_241bc0:
    // 0x241bc0: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x241bc0u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_241bc4:
    // 0x241bc4: 0x802d  daddu       $s0, $zero, $zero
    ctx->pc = 0x241bc4u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_241bc8:
    // 0x241bc8: 0x84640068  lh          $a0, 0x68($v1)
    ctx->pc = 0x241bc8u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 104)));
label_241bcc:
    // 0x241bcc: 0x8c62006c  lw          $v0, 0x6C($v1)
    ctx->pc = 0x241bccu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 108)));
label_241bd0:
    // 0x241bd0: 0x40f809  jalr        $v0
label_241bd4:
    if (ctx->pc == 0x241BD4u) {
        ctx->pc = 0x241BD4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241BD0u;
        // 0x241bd4: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241BD8u;
        goto label_241bd8;
    }
    ctx->pc = 0x241BD0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241BD8u);
        ctx->pc = 0x241BD4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241BD0u;
        // 0x241bd4: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241BD0u, 0x241BD8u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241BD8u;
label_241bd8:
    // 0x241bd8: 0x54400010  bnel        $v0, $zero, . + 4 + (0x10 << 2)
label_241bdc:
    if (ctx->pc == 0x241BDCu) {
        ctx->pc = 0x241BDCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241BD8u;
        // 0x241bdc: 0x8e460434  lw          $a2, 0x434($s2) (Delay Slot)
        SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241BE0u;
        goto label_241be0;
    }
    ctx->pc = 0x241BD8u;
    {
        const bool branch_taken_0x241bd8 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x241bd8) {
            ctx->pc = 0x241BDCu;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x241BD8u;
            // 0x241bdc: 0x8e460434  lw          $a2, 0x434($s2) (Delay Slot)
            SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x241C1Cu;
            goto label_241c1c;
        }
    }
    ctx->pc = 0x241BE0u;
label_241be0:
    // 0x241be0: 0x8e450434  lw          $a1, 0x434($s2)
    ctx->pc = 0x241be0u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
label_241be4:
    // 0x241be4: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x241be4u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_241be8:
    // 0x241be8: 0x846400a0  lh          $a0, 0xA0($v1)
    ctx->pc = 0x241be8u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 160)));
label_241bec:
    // 0x241bec: 0x8c6200a4  lw          $v0, 0xA4($v1)
    ctx->pc = 0x241becu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 164)));
label_241bf0:
    // 0x241bf0: 0x40f809  jalr        $v0
label_241bf4:
    if (ctx->pc == 0x241BF4u) {
        ctx->pc = 0x241BF4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241BF0u;
        // 0x241bf4: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241BF8u;
        goto label_241bf8;
    }
    ctx->pc = 0x241BF0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241BF8u);
        ctx->pc = 0x241BF4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241BF0u;
        // 0x241bf4: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241BF0u, 0x241BF8u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241BF8u;
label_241bf8:
    // 0x241bf8: 0x8e450434  lw          $a1, 0x434($s2)
    ctx->pc = 0x241bf8u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
label_241bfc:
    // 0x241bfc: 0x40802d  daddu       $s0, $v0, $zero
    ctx->pc = 0x241bfcu;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_241c00:
    // 0x241c00: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x241c00u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_241c04:
    // 0x241c04: 0x846400b8  lh          $a0, 0xB8($v1)
    ctx->pc = 0x241c04u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 184)));
label_241c08:
    // 0x241c08: 0x8c6200bc  lw          $v0, 0xBC($v1)
    ctx->pc = 0x241c08u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 188)));
label_241c0c:
    // 0x241c0c: 0x40f809  jalr        $v0
label_241c10:
    if (ctx->pc == 0x241C10u) {
        ctx->pc = 0x241C10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C0Cu;
        // 0x241c10: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241C14u;
        goto label_241c14;
    }
    ctx->pc = 0x241C0Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241C14u);
        ctx->pc = 0x241C10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C0Cu;
        // 0x241c10: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241C0Cu, 0x241C14u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241C14u;
label_241c14:
    // 0x241c14: 0x202802a  slt         $s0, $s0, $v0
    ctx->pc = 0x241c14u;
    SET_GPR_U64(ctx, 16, ((int64_t)GPR_S64(ctx, 16) < (int64_t)GPR_S64(ctx, 2)) ? 1 : 0);
label_241c18:
    // 0x241c18: 0x8e460434  lw          $a2, 0x434($s2)
    ctx->pc = 0x241c18u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
label_241c1c:
    // 0x241c1c: 0x2402fffb  addiu       $v0, $zero, -0x5
    ctx->pc = 0x241c1cu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967291));
label_241c20:
    // 0x241c20: 0x2228824  and         $s1, $s1, $v0
    ctx->pc = 0x241c20u;
    SET_GPR_U64(ctx, 17, GPR_U64(ctx, 17) & GPR_U64(ctx, 2));
label_241c24:
    // 0x241c24: 0x101880  sll         $v1, $s0, 2
    ctx->pc = 0x241c24u;
    SET_GPR_S32(ctx, 3, (int32_t)SLL32(GPR_U32(ctx, 16), 2));
label_241c28:
    // 0x241c28: 0x8cc50000  lw          $a1, 0x0($a2)
    ctx->pc = 0x241c28u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_241c2c:
    // 0x241c2c: 0x2238825  or          $s1, $s1, $v1
    ctx->pc = 0x241c2cu;
    SET_GPR_U64(ctx, 17, GPR_U64(ctx, 17) | GPR_U64(ctx, 3));
label_241c30:
    // 0x241c30: 0x982d  daddu       $s3, $zero, $zero
    ctx->pc = 0x241c30u;
    SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_241c34:
    // 0x241c34: 0x84a401a8  lh          $a0, 0x1A8($a1)
    ctx->pc = 0x241c34u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 5), 424)));
label_241c38:
    // 0x241c38: 0x8ca201ac  lw          $v0, 0x1AC($a1)
    ctx->pc = 0x241c38u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 428)));
label_241c3c:
    // 0x241c3c: 0x40f809  jalr        $v0
label_241c40:
    if (ctx->pc == 0x241C40u) {
        ctx->pc = 0x241C40u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C3Cu;
        // 0x241c40: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241C44u;
        goto label_241c44;
    }
    ctx->pc = 0x241C3Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241C44u);
        ctx->pc = 0x241C40u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C3Cu;
        // 0x241c40: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241C3Cu, 0x241C44u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241C44u;
label_241c44:
    // 0x241c44: 0x8e460434  lw          $a2, 0x434($s2)
    ctx->pc = 0x241c44u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
label_241c48:
    // 0x241c48: 0x38420001  xori        $v0, $v0, 0x1
    ctx->pc = 0x241c48u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) ^ (uint64_t)(uint16_t)1);
label_241c4c:
    // 0x241c4c: 0x30420001  andi        $v0, $v0, 0x1
    ctx->pc = 0x241c4cu;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)1);
label_241c50:
    // 0x241c50: 0x2403fff7  addiu       $v1, $zero, -0x9
    ctx->pc = 0x241c50u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967287));
label_241c54:
    // 0x241c54: 0x8cc50000  lw          $a1, 0x0($a2)
    ctx->pc = 0x241c54u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_241c58:
    // 0x241c58: 0x210c0  sll         $v0, $v0, 3
    ctx->pc = 0x241c58u;
    SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 2), 3));
label_241c5c:
    // 0x241c5c: 0x2238824  and         $s1, $s1, $v1
    ctx->pc = 0x241c5cu;
    SET_GPR_U64(ctx, 17, GPR_U64(ctx, 17) & GPR_U64(ctx, 3));
label_241c60:
    // 0x241c60: 0x84a401b8  lh          $a0, 0x1B8($a1)
    ctx->pc = 0x241c60u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 5), 440)));
label_241c64:
    // 0x241c64: 0x2228025  or          $s0, $s1, $v0
    ctx->pc = 0x241c64u;
    SET_GPR_U64(ctx, 16, GPR_U64(ctx, 17) | GPR_U64(ctx, 2));
label_241c68:
    // 0x241c68: 0x8ca201bc  lw          $v0, 0x1BC($a1)
    ctx->pc = 0x241c68u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 444)));
label_241c6c:
    // 0x241c6c: 0x40f809  jalr        $v0
label_241c70:
    if (ctx->pc == 0x241C70u) {
        ctx->pc = 0x241C70u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C6Cu;
        // 0x241c70: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241C74u;
        goto label_241c74;
    }
    ctx->pc = 0x241C6Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241C74u);
        ctx->pc = 0x241C70u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C6Cu;
        // 0x241c70: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241C6Cu, 0x241C74u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241C74u;
label_241c74:
    // 0x241c74: 0x5040000a  beql        $v0, $zero, . + 4 + (0xA << 2)
label_241c78:
    if (ctx->pc == 0x241C78u) {
        ctx->pc = 0x241C78u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C74u;
        // 0x241c78: 0x24130001  addiu       $s3, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241C7Cu;
        goto label_241c7c;
    }
    ctx->pc = 0x241C74u;
    {
        const bool branch_taken_0x241c74 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x241c74) {
            ctx->pc = 0x241C78u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x241C74u;
            // 0x241c78: 0x24130001  addiu       $s3, $zero, 0x1 (Delay Slot)
            SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
            ctx->in_delay_slot = false;
            ctx->pc = 0x241CA0u;
            goto label_241ca0;
        }
    }
    ctx->pc = 0x241C7Cu;
label_241c7c:
    // 0x241c7c: 0x8e450434  lw          $a1, 0x434($s2)
    ctx->pc = 0x241c7cu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 1076)));
label_241c80:
    // 0x241c80: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x241c80u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_241c84:
    // 0x241c84: 0x846401d0  lh          $a0, 0x1D0($v1)
    ctx->pc = 0x241c84u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 464)));
label_241c88:
    // 0x241c88: 0x8c6201d4  lw          $v0, 0x1D4($v1)
    ctx->pc = 0x241c88u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 468)));
label_241c8c:
    // 0x241c8c: 0x40f809  jalr        $v0
label_241c90:
    if (ctx->pc == 0x241C90u) {
        ctx->pc = 0x241C90u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C8Cu;
        // 0x241c90: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241C94u;
        goto label_241c94;
    }
    ctx->pc = 0x241C8Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x241C94u);
        ctx->pc = 0x241C90u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C8Cu;
        // 0x241c90: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241C8Cu, 0x241C94u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x241C94u;
label_241c94:
    // 0x241c94: 0x14400003  bnez        $v0, . + 4 + (0x3 << 2)
label_241c98:
    if (ctx->pc == 0x241C98u) {
        ctx->pc = 0x241C98u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C94u;
        // 0x241c98: 0x2402ffef  addiu       $v0, $zero, -0x11 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967279));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241C9Cu;
        goto label_241c9c;
    }
    ctx->pc = 0x241C94u;
    {
        const bool branch_taken_0x241c94 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x241C98u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241C94u;
        // 0x241c98: 0x2402ffef  addiu       $v0, $zero, -0x11 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967279));
        ctx->in_delay_slot = false;
        if (branch_taken_0x241c94) {
            ctx->pc = 0x241CA4u;
            goto label_241ca4;
        }
    }
    ctx->pc = 0x241C9Cu;
label_241c9c:
    // 0x241c9c: 0x24130001  addiu       $s3, $zero, 0x1
    ctx->pc = 0x241c9cu;
    SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_241ca0:
    // 0x241ca0: 0x2402ffef  addiu       $v0, $zero, -0x11
    ctx->pc = 0x241ca0u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967279));
label_241ca4:
    // 0x241ca4: 0x131900  sll         $v1, $s3, 4
    ctx->pc = 0x241ca4u;
    SET_GPR_S32(ctx, 3, (int32_t)SLL32(GPR_U32(ctx, 19), 4));
label_241ca8:
    // 0x241ca8: 0x2028824  and         $s1, $s0, $v0
    ctx->pc = 0x241ca8u;
    SET_GPR_U64(ctx, 17, GPR_U64(ctx, 16) & GPR_U64(ctx, 2));
label_241cac:
    // 0x241cac: 0x2402fe1f  addiu       $v0, $zero, -0x1E1
    ctx->pc = 0x241cacu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294966815));
label_241cb0:
    // 0x241cb0: 0x2238825  or          $s1, $s1, $v1
    ctx->pc = 0x241cb0u;
    SET_GPR_U64(ctx, 17, GPR_U64(ctx, 17) | GPR_U64(ctx, 3));
label_241cb4:
    // 0x241cb4: 0x2221024  and         $v0, $s1, $v0
    ctx->pc = 0x241cb4u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 17) & GPR_U64(ctx, 2));
label_241cb8:
    // 0x241cb8: 0x7bb00040  lq          $s0, 0x40($sp)
    ctx->pc = 0x241cb8u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 64)));
label_241cbc:
    // 0x241cbc: 0x7bb10030  lq          $s1, 0x30($sp)
    ctx->pc = 0x241cbcu;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 48)));
label_241cc0:
    // 0x241cc0: 0x7bb20020  lq          $s2, 0x20($sp)
    ctx->pc = 0x241cc0u;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_241cc4:
    // 0x241cc4: 0x7bb30010  lq          $s3, 0x10($sp)
    ctx->pc = 0x241cc4u;
    SET_GPR_VEC(ctx, 19, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_241cc8:
    // 0x241cc8: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x241cc8u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_241ccc:
    // 0x241ccc: 0x3e00008  jr          $ra
label_241cd0:
    if (ctx->pc == 0x241CD0u) {
        ctx->pc = 0x241CD0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241CCCu;
        // 0x241cd0: 0x27bd0050  addiu       $sp, $sp, 0x50 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 80));
        ctx->in_delay_slot = false;
        ctx->pc = 0x241CD4u;
        goto label_241cd4;
    }
    ctx->pc = 0x241CCCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x241CD0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x241CCCu;
        // 0x241cd0: 0x27bd0050  addiu       $sp, $sp, 0x50 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 80));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x241CCCu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x241CD4u;
label_241cd4:
    // 0x241cd4: 0x0  nop
    ctx->pc = 0x241cd4u;
    // NOP
    ctx->pc = 0x241cd8u;
}
