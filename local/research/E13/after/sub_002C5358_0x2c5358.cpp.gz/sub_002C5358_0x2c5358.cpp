#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_002C5358
// Address: 0x2c5358 - 0x2c53b0
void sub_002C5358_0x2c5358(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_002C5358_0x2c5358");
#endif

    ctx->pc = 0x2c5358u;

    // 0x2c5358: 0x24020014  addiu       $v0, $zero, 0x14
    ctx->pc = 0x2c5358u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 20));
    // 0x2c535c: 0x2403fff9  addiu       $v1, $zero, -0x7
    ctx->pc = 0x2c535cu;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967289));
    // 0x2c5360: 0xa23018  mult        $a2, $a1, $v0
    ctx->pc = 0x2c5360u;
    { int64_t result = (int64_t)GPR_S32(ctx, 5) * (int64_t)GPR_S32(ctx, 2); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 6, (int32_t)result); }
    // 0x2c5364: 0xc42021  addu        $a0, $a2, $a0
    ctx->pc = 0x2c5364u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
    // 0x2c5368: 0x8c840184  lw          $a0, 0x184($a0)
    ctx->pc = 0x2c5368u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 388)));
    // 0x2c536c: 0x1083000c  beq         $a0, $v1, . + 4 + (0xC << 2)
    ctx->pc = 0x2C536Cu;
    {
        const bool branch_taken_0x2c536c = (GPR_U64(ctx, 4) == GPR_U64(ctx, 3));
        ctx->pc = 0x2C5370u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C536Cu;
        // 0x2c5370: 0x2882fffa  slti        $v0, $a0, -0x6 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 4) < (int64_t)(int32_t)4294967290) ? 1 : 0);
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c536c) {
            ctx->pc = 0x2C53A0u;
            goto label_2c53a0;
        }
    }
    ctx->pc = 0x2C5374u;
    // 0x2c5374: 0x10400005  beqz        $v0, . + 4 + (0x5 << 2)
    ctx->pc = 0x2C5374u;
    {
        const bool branch_taken_0x2c5374 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x2C5378u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5374u;
        // 0x2c5378: 0x2402d8ef  addiu       $v0, $zero, -0x2711 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294957295));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c5374) {
            ctx->pc = 0x2C538Cu;
            goto label_2c538c;
        }
    }
    ctx->pc = 0x2C537Cu;
    // 0x2c537c: 0x10820008  beq         $a0, $v0, . + 4 + (0x8 << 2)
    ctx->pc = 0x2C537Cu;
    {
        const bool branch_taken_0x2c537c = (GPR_U64(ctx, 4) == GPR_U64(ctx, 2));
        ctx->pc = 0x2C5380u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C537Cu;
        // 0x2c5380: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c537c) {
            ctx->pc = 0x2C53A0u;
            goto label_2c53a0;
        }
    }
    ctx->pc = 0x2C5384u;
    // 0x2c5384: 0x10000008  b           . + 4 + (0x8 << 2)
    ctx->pc = 0x2C5384u;
    {
        const bool branch_taken_0x2c5384 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        if (branch_taken_0x2c5384) {
            ctx->pc = 0x2C53A8u;
            goto label_2c53a8;
        }
    }
    ctx->pc = 0x2C538Cu;
label_2c538c:
    // 0x2c538c: 0x1c800006  bgtz        $a0, . + 4 + (0x6 << 2)
    ctx->pc = 0x2C538Cu;
    {
        const bool branch_taken_0x2c538c = (GPR_S32(ctx, 4) > 0);
        ctx->pc = 0x2C5390u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C538Cu;
        // 0x2c5390: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c538c) {
            ctx->pc = 0x2C53A8u;
            goto label_2c53a8;
        }
    }
    ctx->pc = 0x2C5394u;
    // 0x2c5394: 0x2882fffb  slti        $v0, $a0, -0x5
    ctx->pc = 0x2c5394u;
    SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 4) < (int64_t)(int32_t)4294967291) ? 1 : 0);
    // 0x2c5398: 0x14400003  bnez        $v0, . + 4 + (0x3 << 2)
    ctx->pc = 0x2C5398u;
    {
        const bool branch_taken_0x2c5398 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x2C539Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5398u;
        // 0x2c539c: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c5398) {
            ctx->pc = 0x2C53A8u;
            goto label_2c53a8;
        }
    }
    ctx->pc = 0x2C53A0u;
label_2c53a0:
    // 0x2c53a0: 0x3e00008  jr          $ra
    ctx->pc = 0x2C53A0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C53A4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C53A0u;
        // 0x2c53a4: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C53A0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C53A8u;
label_2c53a8:
    // 0x2c53a8: 0x3e00008  jr          $ra
    ctx->pc = 0x2C53A8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C53A8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C53B0u;
}
