#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_004261F0
// Address: 0x4261f0 - 0x426358
void sub_004261F0_0x4261f0(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_004261F0_0x4261f0");
#endif

    switch (ctx->pc) {
        case 0x4261f0u: goto label_4261f0;
        case 0x4261f4u: goto label_4261f4;
        case 0x4261f8u: goto label_4261f8;
        case 0x4261fcu: goto label_4261fc;
        case 0x426200u: goto label_426200;
        case 0x426204u: goto label_426204;
        case 0x426208u: goto label_426208;
        case 0x42620cu: goto label_42620c;
        case 0x426210u: goto label_426210;
        case 0x426214u: goto label_426214;
        case 0x426218u: goto label_426218;
        case 0x42621cu: goto label_42621c;
        case 0x426220u: goto label_426220;
        case 0x426224u: goto label_426224;
        case 0x426228u: goto label_426228;
        case 0x42622cu: goto label_42622c;
        case 0x426230u: goto label_426230;
        case 0x426234u: goto label_426234;
        case 0x426238u: goto label_426238;
        case 0x42623cu: goto label_42623c;
        case 0x426240u: goto label_426240;
        case 0x426244u: goto label_426244;
        case 0x426248u: goto label_426248;
        case 0x42624cu: goto label_42624c;
        case 0x426250u: goto label_426250;
        case 0x426254u: goto label_426254;
        case 0x426258u: goto label_426258;
        case 0x42625cu: goto label_42625c;
        case 0x426260u: goto label_426260;
        case 0x426264u: goto label_426264;
        case 0x426268u: goto label_426268;
        case 0x42626cu: goto label_42626c;
        case 0x426270u: goto label_426270;
        case 0x426274u: goto label_426274;
        case 0x426278u: goto label_426278;
        case 0x42627cu: goto label_42627c;
        case 0x426280u: goto label_426280;
        case 0x426284u: goto label_426284;
        case 0x426288u: goto label_426288;
        case 0x42628cu: goto label_42628c;
        case 0x426290u: goto label_426290;
        case 0x426294u: goto label_426294;
        case 0x426298u: goto label_426298;
        case 0x42629cu: goto label_42629c;
        case 0x4262a0u: goto label_4262a0;
        case 0x4262a4u: goto label_4262a4;
        case 0x4262a8u: goto label_4262a8;
        case 0x4262acu: goto label_4262ac;
        case 0x4262b0u: goto label_4262b0;
        case 0x4262b4u: goto label_4262b4;
        case 0x4262b8u: goto label_4262b8;
        case 0x4262bcu: goto label_4262bc;
        case 0x4262c0u: goto label_4262c0;
        case 0x4262c4u: goto label_4262c4;
        case 0x4262c8u: goto label_4262c8;
        case 0x4262ccu: goto label_4262cc;
        case 0x4262d0u: goto label_4262d0;
        case 0x4262d4u: goto label_4262d4;
        case 0x4262d8u: goto label_4262d8;
        case 0x4262dcu: goto label_4262dc;
        case 0x4262e0u: goto label_4262e0;
        case 0x4262e4u: goto label_4262e4;
        case 0x4262e8u: goto label_4262e8;
        case 0x4262ecu: goto label_4262ec;
        case 0x4262f0u: goto label_4262f0;
        case 0x4262f4u: goto label_4262f4;
        case 0x4262f8u: goto label_4262f8;
        case 0x4262fcu: goto label_4262fc;
        case 0x426300u: goto label_426300;
        case 0x426304u: goto label_426304;
        case 0x426308u: goto label_426308;
        case 0x42630cu: goto label_42630c;
        case 0x426310u: goto label_426310;
        case 0x426314u: goto label_426314;
        case 0x426318u: goto label_426318;
        case 0x42631cu: goto label_42631c;
        case 0x426320u: goto label_426320;
        case 0x426324u: goto label_426324;
        case 0x426328u: goto label_426328;
        case 0x42632cu: goto label_42632c;
        case 0x426330u: goto label_426330;
        case 0x426334u: goto label_426334;
        case 0x426338u: goto label_426338;
        case 0x42633cu: goto label_42633c;
        case 0x426340u: goto label_426340;
        case 0x426344u: goto label_426344;
        case 0x426348u: goto label_426348;
        case 0x42634cu: goto label_42634c;
        case 0x426350u: goto label_426350;
        case 0x426354u: goto label_426354;
        default: break;
    }

    ctx->pc = 0x4261f0u;

label_4261f0:
    // 0x4261f0: 0xc0102d  daddu       $v0, $a2, $zero
    ctx->pc = 0x4261f0u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
label_4261f4:
    // 0x4261f4: 0xe0182d  daddu       $v1, $a3, $zero
    ctx->pc = 0x4261f4u;
    SET_GPR_U64(ctx, 3, (uint64_t)GPR_U64(ctx, 7) + (uint64_t)GPR_U64(ctx, 0));
label_4261f8:
    // 0x4261f8: 0x100582d  daddu       $t3, $t0, $zero
    ctx->pc = 0x4261f8u;
    SET_GPR_U64(ctx, 11, (uint64_t)GPR_U64(ctx, 8) + (uint64_t)GPR_U64(ctx, 0));
label_4261fc:
    // 0x4261fc: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x4261fcu;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_426200:
    // 0x426200: 0x120502d  daddu       $t2, $t1, $zero
    ctx->pc = 0x426200u;
    SET_GPR_U64(ctx, 10, (uint64_t)GPR_U64(ctx, 9) + (uint64_t)GPR_U64(ctx, 0));
label_426204:
    // 0x426204: 0xa0302d  daddu       $a2, $a1, $zero
    ctx->pc = 0x426204u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_426208:
    // 0x426208: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x426208u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_42620c:
    // 0x42620c: 0x40382d  daddu       $a3, $v0, $zero
    ctx->pc = 0x42620cu;
    SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_426210:
    // 0x426210: 0x60402d  daddu       $t0, $v1, $zero
    ctx->pc = 0x426210u;
    SET_GPR_U64(ctx, 8, (uint64_t)GPR_U64(ctx, 3) + (uint64_t)GPR_U64(ctx, 0));
label_426214:
    // 0x426214: 0x160482d  daddu       $t1, $t3, $zero
    ctx->pc = 0x426214u;
    SET_GPR_U64(ctx, 9, (uint64_t)GPR_U64(ctx, 11) + (uint64_t)GPR_U64(ctx, 0));
label_426218:
    // 0x426218: 0xc10981e  jal         func_426078
label_42621c:
    if (ctx->pc == 0x42621Cu) {
        ctx->pc = 0x42621Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426218u;
        // 0x42621c: 0x24050001  addiu       $a1, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x426220u;
        goto label_426220;
    }
    ctx->pc = 0x426218u;
    SET_GPR_U32(ctx, 31, 0x426220u);
    ctx->pc = 0x42621Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x426218u;
    // 0x42621c: 0x24050001  addiu       $a1, $zero, 0x1 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
    ctx->in_delay_slot = false;
    ctx->pc = 0x426078u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x426078u, 0x426218u, 0x426220u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x426220u;
label_426220:
    // 0x426220: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x426220u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_426224:
    // 0x426224: 0x3e00008  jr          $ra
label_426228:
    if (ctx->pc == 0x426228u) {
        ctx->pc = 0x426228u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426224u;
        // 0x426228: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x42622Cu;
        goto label_42622c;
    }
    ctx->pc = 0x426224u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x426228u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426224u;
        // 0x426228: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x426224u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x42622Cu;
label_42622c:
    // 0x42622c: 0x0  nop
    ctx->pc = 0x42622cu;
    // NOP
label_426230:
    // 0x426230: 0x27bdff70  addiu       $sp, $sp, -0x90
    ctx->pc = 0x426230u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967152));
label_426234:
    // 0x426234: 0xffb00070  sd          $s0, 0x70($sp)
    ctx->pc = 0x426234u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 112), GPR_U64(ctx, 16));
label_426238:
    // 0x426238: 0xffbf0080  sd          $ra, 0x80($sp)
    ctx->pc = 0x426238u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 128), GPR_U64(ctx, 31));
label_42623c:
    // 0x42623c: 0xc10b030  jal         func_42C0C0
label_426240:
    if (ctx->pc == 0x426240u) {
        ctx->pc = 0x426244u;
        goto label_426244;
    }
    ctx->pc = 0x42623Cu;
    SET_GPR_U32(ctx, 31, 0x426244u);
    ctx->pc = 0x42C0C0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x42C0C0u, 0x42623Cu, 0x426244u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x426244u;
label_426244:
    // 0x426244: 0x3c030053  lui         $v1, 0x53
    ctx->pc = 0x426244u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)83 << 16));
label_426248:
    // 0x426248: 0x8c67bcd8  lw          $a3, -0x4328($v1)
    ctx->pc = 0x426248u;
    SET_GPR_S32(ctx, 7, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 4294950104)));
label_42624c:
    // 0x42624c: 0x2470bcd8  addiu       $s0, $v1, -0x4328
    ctx->pc = 0x42624cu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 3), 4294950104));
label_426250:
    // 0x426250: 0x90e20000  lbu         $v0, 0x0($a3)
    ctx->pc = 0x426250u;
    SET_GPR_U32(ctx, 2, (uint8_t)READ8(ADD32(GPR_U32(ctx, 7), 0)));
label_426254:
    // 0x426254: 0x304500ff  andi        $a1, $v0, 0xFF
    ctx->pc = 0x426254u;
    SET_GPR_U64(ctx, 5, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)255);
label_426258:
    // 0x426258: 0x10a0003b  beqz        $a1, . + 4 + (0x3B << 2)
label_42625c:
    if (ctx->pc == 0x42625Cu) {
        ctx->pc = 0x42625Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426258u;
        // 0x42625c: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x426260u;
        goto label_426260;
    }
    ctx->pc = 0x426258u;
    {
        const bool branch_taken_0x426258 = (GPR_U64(ctx, 5) == GPR_U64(ctx, 0));
        ctx->pc = 0x42625Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426258u;
        // 0x42625c: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x426258) {
            ctx->pc = 0x426348u;
            goto label_426348;
        }
    }
    ctx->pc = 0x426260u;
label_426260:
    // 0x426260: 0x24a2000f  addiu       $v0, $a1, 0xF
    ctx->pc = 0x426260u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 5), 15));
label_426264:
    // 0x426264: 0x2403ffff  addiu       $v1, $zero, -0x1
    ctx->pc = 0x426264u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
label_426268:
    // 0x426268: 0x24a4001e  addiu       $a0, $a1, 0x1E
    ctx->pc = 0x426268u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), 30));
label_42626c:
    // 0x42626c: 0x62182a  slt         $v1, $v1, $v0
    ctx->pc = 0x42626cu;
    SET_GPR_U64(ctx, 3, ((int64_t)GPR_S64(ctx, 3) < (int64_t)GPR_S64(ctx, 2)) ? 1 : 0);
label_426270:
    // 0x426270: 0x43200b  movn        $a0, $v0, $v1
    ctx->pc = 0x426270u;
    if (GPR_U64(ctx, 3) != 0) SET_GPR_VEC(ctx, 4, GPR_VEC(ctx, 2));
label_426274:
    // 0x426274: 0xe0302d  daddu       $a2, $a3, $zero
    ctx->pc = 0x426274u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 7) + (uint64_t)GPR_U64(ctx, 0));
label_426278:
    // 0x426278: 0x42903  sra         $a1, $a0, 4
    ctx->pc = 0x426278u;
    SET_GPR_S32(ctx, 5, SRA32(GPR_S32(ctx, 4), 4));
label_42627c:
    // 0x42627c: 0xa0e00000  sb          $zero, 0x0($a3)
    ctx->pc = 0x42627cu;
    WRITE8(ADD32(GPR_U32(ctx, 7), 0), (uint8_t)GPR_U32(ctx, 0));
label_426280:
    // 0x426280: 0x18a0000a  blez        $a1, . + 4 + (0xA << 2)
label_426284:
    if (ctx->pc == 0x426284u) {
        ctx->pc = 0x426284u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426280u;
        // 0x426284: 0xa0202d  daddu       $a0, $a1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x426288u;
        goto label_426288;
    }
    ctx->pc = 0x426280u;
    {
        const bool branch_taken_0x426280 = (GPR_S32(ctx, 5) <= 0);
        ctx->pc = 0x426284u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426280u;
        // 0x426284: 0xa0202d  daddu       $a0, $a1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x426280) {
            ctx->pc = 0x4262ACu;
            goto label_4262ac;
        }
    }
    ctx->pc = 0x426288u;
label_426288:
    // 0x426288: 0x3a0182d  daddu       $v1, $sp, $zero
    ctx->pc = 0x426288u;
    SET_GPR_U64(ctx, 3, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
label_42628c:
    // 0x42628c: 0x0  nop
    ctx->pc = 0x42628cu;
    // NOP
label_426290:
    // 0x426290: 0x78c20000  lq          $v0, 0x0($a2)
    ctx->pc = 0x426290u;
    SET_GPR_VEC(ctx, 2, READ128(ADD32(GPR_U32(ctx, 6), 0)));
label_426294:
    // 0x426294: 0x2484ffff  addiu       $a0, $a0, -0x1
    ctx->pc = 0x426294u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 4294967295));
label_426298:
    // 0x426298: 0x24c60010  addiu       $a2, $a2, 0x10
    ctx->pc = 0x426298u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), 16));
label_42629c:
    // 0x42629c: 0x7c620000  sq          $v0, 0x0($v1)
    ctx->pc = 0x42629cu;
    WRITE128(ADD32(GPR_U32(ctx, 3), 0), GPR_VEC(ctx, 2));
label_4262a0:
    // 0x4262a0: 0x24630010  addiu       $v1, $v1, 0x10
    ctx->pc = 0x4262a0u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 16));
label_4262a4:
    // 0x4262a4: 0x1480fffa  bnez        $a0, . + 4 + (-0x6 << 2)
label_4262a8:
    if (ctx->pc == 0x4262A8u) {
        ctx->pc = 0x4262ACu;
        goto label_4262ac;
    }
    ctx->pc = 0x4262A4u;
    {
        const bool branch_taken_0x4262a4 = (GPR_U64(ctx, 4) != GPR_U64(ctx, 0));
        if (branch_taken_0x4262a4) {
            ctx->pc = 0x426290u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_426290;
        }
    }
    ctx->pc = 0x4262ACu;
label_4262ac:
    // 0x4262ac: 0xc109064  jal         func_424190
label_4262b0:
    if (ctx->pc == 0x4262B0u) {
        ctx->pc = 0x4262B4u;
        goto label_4262b4;
    }
    ctx->pc = 0x4262ACu;
    SET_GPR_U32(ctx, 31, 0x4262B4u);
    ctx->pc = 0x424190u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x424190u, 0x4262ACu, 0x4262B4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x4262B4u;
label_4262b4:
    // 0x4262b4: 0x8fa30008  lw          $v1, 0x8($sp)
    ctx->pc = 0x4262b4u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 29), 8)));
label_4262b8:
    // 0x4262b8: 0x4610013  bgez        $v1, . + 4 + (0x13 << 2)
label_4262bc:
    if (ctx->pc == 0x4262BCu) {
        ctx->pc = 0x4262C0u;
        goto label_4262c0;
    }
    ctx->pc = 0x4262B8u;
    {
        const bool branch_taken_0x4262b8 = (GPR_S32(ctx, 3) >= 0);
        if (branch_taken_0x4262b8) {
            ctx->pc = 0x426308u;
            goto label_426308;
        }
    }
    ctx->pc = 0x4262C0u;
label_4262c0:
    // 0x4262c0: 0x8fa20008  lw          $v0, 0x8($sp)
    ctx->pc = 0x4262c0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 29), 8)));
label_4262c4:
    // 0x4262c4: 0x3c037fff  lui         $v1, 0x7FFF
    ctx->pc = 0x4262c4u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)32767 << 16));
label_4262c8:
    // 0x4262c8: 0x3463ffff  ori         $v1, $v1, 0xFFFF
    ctx->pc = 0x4262c8u;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 3) | (uint64_t)(uint16_t)65535);
label_4262cc:
    // 0x4262cc: 0x8e040010  lw          $a0, 0x10($s0)
    ctx->pc = 0x4262ccu;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 16)));
label_4262d0:
    // 0x4262d0: 0x432824  and         $a1, $v0, $v1
    ctx->pc = 0x4262d0u;
    SET_GPR_U64(ctx, 5, GPR_U64(ctx, 2) & GPR_U64(ctx, 3));
label_4262d4:
    // 0x4262d4: 0xa4202a  slt         $a0, $a1, $a0
    ctx->pc = 0x4262d4u;
    SET_GPR_U64(ctx, 4, ((int64_t)GPR_S64(ctx, 5) < (int64_t)GPR_S64(ctx, 4)) ? 1 : 0);
label_4262d8:
    // 0x4262d8: 0x10800018  beqz        $a0, . + 4 + (0x18 << 2)
label_4262dc:
    if (ctx->pc == 0x4262DCu) {
        ctx->pc = 0x4262DCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x4262D8u;
        // 0x4262dc: 0x510c0  sll         $v0, $a1, 3 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 5), 3));
        ctx->in_delay_slot = false;
        ctx->pc = 0x4262E0u;
        goto label_4262e0;
    }
    ctx->pc = 0x4262D8u;
    {
        const bool branch_taken_0x4262d8 = (GPR_U64(ctx, 4) == GPR_U64(ctx, 0));
        ctx->pc = 0x4262DCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x4262D8u;
        // 0x4262dc: 0x510c0  sll         $v0, $a1, 3 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 5), 3));
        ctx->in_delay_slot = false;
        if (branch_taken_0x4262d8) {
            ctx->pc = 0x42633Cu;
            goto label_42633c;
        }
    }
    ctx->pc = 0x4262E0u;
label_4262e0:
    // 0x4262e0: 0x8e03000c  lw          $v1, 0xC($s0)
    ctx->pc = 0x4262e0u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 12)));
label_4262e4:
    // 0x4262e4: 0x431021  addu        $v0, $v0, $v1
    ctx->pc = 0x4262e4u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), GPR_U32(ctx, 3)));
label_4262e8:
    // 0x4262e8: 0x8c460000  lw          $a2, 0x0($v0)
    ctx->pc = 0x4262e8u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 0)));
label_4262ec:
    // 0x4262ec: 0x10c00013  beqz        $a2, . + 4 + (0x13 << 2)
label_4262f0:
    if (ctx->pc == 0x4262F0u) {
        ctx->pc = 0x4262F4u;
        goto label_4262f4;
    }
    ctx->pc = 0x4262ECu;
    {
        const bool branch_taken_0x4262ec = (GPR_U64(ctx, 6) == GPR_U64(ctx, 0));
        if (branch_taken_0x4262ec) {
            ctx->pc = 0x42633Cu;
            goto label_42633c;
        }
    }
    ctx->pc = 0x4262F4u;
label_4262f4:
    // 0x4262f4: 0x8c450004  lw          $a1, 0x4($v0)
    ctx->pc = 0x4262f4u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 4)));
label_4262f8:
    // 0x4262f8: 0xc0f809  jalr        $a2
label_4262fc:
    if (ctx->pc == 0x4262FCu) {
        ctx->pc = 0x4262FCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x4262F8u;
        // 0x4262fc: 0x3a0202d  daddu       $a0, $sp, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x426300u;
        goto label_426300;
    }
    ctx->pc = 0x4262F8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 6);
        SET_GPR_U32(ctx, 31, 0x426300u);
        ctx->pc = 0x4262FCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x4262F8u;
        // 0x4262fc: 0x3a0202d  daddu       $a0, $sp, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x4262F8u, 0x426300u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x426300u;
label_426300:
    // 0x426300: 0x1000000e  b           . + 4 + (0xE << 2)
label_426304:
    if (ctx->pc == 0x426304u) {
        ctx->pc = 0x426308u;
        goto label_426308;
    }
    ctx->pc = 0x426300u;
    {
        const bool branch_taken_0x426300 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        if (branch_taken_0x426300) {
            ctx->pc = 0x42633Cu;
            goto label_42633c;
        }
    }
    ctx->pc = 0x426308u;
label_426308:
    // 0x426308: 0x8fa50008  lw          $a1, 0x8($sp)
    ctx->pc = 0x426308u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 29), 8)));
label_42630c:
    // 0x42630c: 0x8e020018  lw          $v0, 0x18($s0)
    ctx->pc = 0x42630cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 24)));
label_426310:
    // 0x426310: 0xa2102a  slt         $v0, $a1, $v0
    ctx->pc = 0x426310u;
    SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 5) < (int64_t)GPR_S64(ctx, 2)) ? 1 : 0);
label_426314:
    // 0x426314: 0x10400009  beqz        $v0, . + 4 + (0x9 << 2)
label_426318:
    if (ctx->pc == 0x426318u) {
        ctx->pc = 0x426318u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426314u;
        // 0x426318: 0x510c0  sll         $v0, $a1, 3 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 5), 3));
        ctx->in_delay_slot = false;
        ctx->pc = 0x42631Cu;
        goto label_42631c;
    }
    ctx->pc = 0x426314u;
    {
        const bool branch_taken_0x426314 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x426318u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426314u;
        // 0x426318: 0x510c0  sll         $v0, $a1, 3 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 5), 3));
        ctx->in_delay_slot = false;
        if (branch_taken_0x426314) {
            ctx->pc = 0x42633Cu;
            goto label_42633c;
        }
    }
    ctx->pc = 0x42631Cu;
label_42631c:
    // 0x42631c: 0x8e030014  lw          $v1, 0x14($s0)
    ctx->pc = 0x42631cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 20)));
label_426320:
    // 0x426320: 0x431021  addu        $v0, $v0, $v1
    ctx->pc = 0x426320u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), GPR_U32(ctx, 3)));
label_426324:
    // 0x426324: 0x8c460000  lw          $a2, 0x0($v0)
    ctx->pc = 0x426324u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 0)));
label_426328:
    // 0x426328: 0x10c00004  beqz        $a2, . + 4 + (0x4 << 2)
label_42632c:
    if (ctx->pc == 0x42632Cu) {
        ctx->pc = 0x426330u;
        goto label_426330;
    }
    ctx->pc = 0x426328u;
    {
        const bool branch_taken_0x426328 = (GPR_U64(ctx, 6) == GPR_U64(ctx, 0));
        if (branch_taken_0x426328) {
            ctx->pc = 0x42633Cu;
            goto label_42633c;
        }
    }
    ctx->pc = 0x426330u;
label_426330:
    // 0x426330: 0x8c450004  lw          $a1, 0x4($v0)
    ctx->pc = 0x426330u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 4)));
label_426334:
    // 0x426334: 0xc0f809  jalr        $a2
label_426338:
    if (ctx->pc == 0x426338u) {
        ctx->pc = 0x426338u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426334u;
        // 0x426338: 0x3a0202d  daddu       $a0, $sp, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x42633Cu;
        goto label_42633c;
    }
    ctx->pc = 0x426334u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 6);
        SET_GPR_U32(ctx, 31, 0x42633Cu);
        ctx->pc = 0x426338u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426334u;
        // 0x426338: 0x3a0202d  daddu       $a0, $sp, $zero (Delay Slot)
        SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x426334u, 0x42633Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x42633Cu;
label_42633c:
    // 0x42633c: 0xf  sync
    ctx->pc = 0x42633cu;
    // SYNC instruction - memory barrier
// In recompiled code, we don't need explicit memory barriers
label_426340:
    // 0x426340: 0x42000038  ei
    ctx->pc = 0x426340u;
    ctx->cop0_status |= 0x10000; // Enable interrupts
label_426344:
    // 0x426344: 0x102d  daddu       $v0, $zero, $zero
    ctx->pc = 0x426344u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_426348:
    // 0x426348: 0xdfbf0080  ld          $ra, 0x80($sp)
    ctx->pc = 0x426348u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 128)));
label_42634c:
    // 0x42634c: 0xdfb00070  ld          $s0, 0x70($sp)
    ctx->pc = 0x42634cu;
    SET_GPR_U64(ctx, 16, READ64(ADD32(GPR_U32(ctx, 29), 112)));
label_426350:
    // 0x426350: 0x3e00008  jr          $ra
label_426354:
    if (ctx->pc == 0x426354u) {
        ctx->pc = 0x426354u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426350u;
        // 0x426354: 0x27bd0090  addiu       $sp, $sp, 0x90 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 144));
        ctx->in_delay_slot = false;
        ctx->pc = 0x426358u;
        goto label_fallthrough_0x426350;
    }
    ctx->pc = 0x426350u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x426354u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x426350u;
        // 0x426354: 0x27bd0090  addiu       $sp, $sp, 0x90 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 144));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x426350u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
label_fallthrough_0x426350:
    ctx->pc = 0x426358u;
}
