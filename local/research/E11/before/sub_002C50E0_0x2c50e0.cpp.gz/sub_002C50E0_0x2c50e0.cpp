#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_002C50E0
// Address: 0x2c50e0 - 0x2c51d0
void sub_002C50E0_0x2c50e0(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_002C50E0_0x2c50e0");
#endif

    switch (ctx->pc) {
        case 0x2c5118u: goto label_2c5118;
        default: break;
    }

    ctx->pc = 0x2c50e0u;

    // 0x2c50e0: 0x27bdffe0  addiu       $sp, $sp, -0x20
    ctx->pc = 0x2c50e0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967264));
    // 0x2c50e4: 0xaf800848  sw          $zero, 0x848($gp)
    ctx->pc = 0x2c50e4u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 2120), GPR_U32(ctx, 0));
    // 0x2c50e8: 0x7fb00010  sq          $s0, 0x10($sp)
    ctx->pc = 0x2c50e8u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 16));
    // 0x2c50ec: 0x282d  daddu       $a1, $zero, $zero
    ctx->pc = 0x2c50ecu;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
    // 0x2c50f0: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2c50f0u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
    // 0x2c50f4: 0x80802d  daddu       $s0, $a0, $zero
    ctx->pc = 0x2c50f4u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
    // 0x2c50f8: 0xae000020  sw          $zero, 0x20($s0)
    ctx->pc = 0x2c50f8u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 32), GPR_U32(ctx, 0));
    // 0x2c50fc: 0x27860848  addiu       $a2, $gp, 0x848
    ctx->pc = 0x2c50fcu;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 28), 2120));
    // 0x2c5100: 0x8e04000c  lw          $a0, 0xC($s0)
    ctx->pc = 0x2c5100u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 12)));
    // 0x2c5104: 0x2787084c  addiu       $a3, $gp, 0x84C
    ctx->pc = 0x2c5104u;
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 28), 2124));
    // 0x2c5108: 0x27880854  addiu       $t0, $gp, 0x854
    ctx->pc = 0x2c5108u;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 28), 2132));
    // 0x2c510c: 0xaf800854  sw          $zero, 0x854($gp)
    ctx->pc = 0x2c510cu;
    WRITE32(ADD32(GPR_U32(ctx, 28), 2132), GPR_U32(ctx, 0));
    // 0x2c5110: 0xc102926  jal         func_40A498
    ctx->pc = 0x2C5110u;
    SET_GPR_U32(ctx, 31, 0x2C5118u);
    ctx->pc = 0x2C5114u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2C5110u;
    // 0x2c5114: 0xaf80084c  sw          $zero, 0x84C($gp) (Delay Slot)
    WRITE32(ADD32(GPR_U32(ctx, 28), 2124), GPR_U32(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x40A498u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x40A498u, 0x2C5110u, 0x2C5118u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2C5118u;
label_2c5118:
    // 0x2c5118: 0x2c430001  sltiu       $v1, $v0, 0x1
    ctx->pc = 0x2c5118u;
    SET_GPR_U64(ctx, 3, ((uint64_t)GPR_U64(ctx, 2) < (uint64_t)(int64_t)(int32_t)1) ? 1 : 0);
    // 0x2c511c: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2c511cu;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
    // 0x2c5120: 0x24020005  addiu       $v0, $zero, 0x5
    ctx->pc = 0x2c5120u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 5));
    // 0x2c5124: 0xae030040  sw          $v1, 0x40($s0)
    ctx->pc = 0x2c5124u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 64), GPR_U32(ctx, 3));
    // 0x2c5128: 0xae02004c  sw          $v0, 0x4C($s0)
    ctx->pc = 0x2c5128u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 76), GPR_U32(ctx, 2));
    // 0x2c512c: 0x7bb00010  lq          $s0, 0x10($sp)
    ctx->pc = 0x2c512cu;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 16)));
    // 0x2c5130: 0x60102d  daddu       $v0, $v1, $zero
    ctx->pc = 0x2c5130u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 3) + (uint64_t)GPR_U64(ctx, 0));
    // 0x2c5134: 0x3e00008  jr          $ra
    ctx->pc = 0x2C5134u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C5138u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5134u;
        // 0x2c5138: 0x27bd0020  addiu       $sp, $sp, 0x20 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 32));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C5134u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C513Cu;
    // 0x2c513c: 0x0  nop
    ctx->pc = 0x2c513cu;
    // NOP
    // 0x2c5140: 0x8c820004  lw          $v0, 0x4($a0)
    ctx->pc = 0x2c5140u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 4)));
    // 0x2c5144: 0x14400004  bnez        $v0, . + 4 + (0x4 << 2)
    ctx->pc = 0x2C5144u;
    {
        const bool branch_taken_0x2c5144 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c5144) {
            ctx->pc = 0x2C5158u;
            goto label_2c5158;
        }
    }
    ctx->pc = 0x2C514Cu;
    // 0x2c514c: 0x8c820040  lw          $v0, 0x40($a0)
    ctx->pc = 0x2c514cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 64)));
    // 0x2c5150: 0x10400003  beqz        $v0, . + 4 + (0x3 << 2)
    ctx->pc = 0x2C5150u;
    {
        const bool branch_taken_0x2c5150 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x2c5150) {
            ctx->pc = 0x2C5160u;
            goto label_2c5160;
        }
    }
    ctx->pc = 0x2C5158u;
label_2c5158:
    // 0x2c5158: 0x3e00008  jr          $ra
    ctx->pc = 0x2C5158u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C515Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5158u;
        // 0x2c515c: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C5158u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C5160u;
label_2c5160:
    // 0x2c5160: 0x3e00008  jr          $ra
    ctx->pc = 0x2C5160u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C5164u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5160u;
        // 0x2c5164: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C5160u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C5168u;
    // 0x2c5168: 0x8c82000c  lw          $v0, 0xC($a0)
    ctx->pc = 0x2c5168u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
    // 0x2c516c: 0x24030014  addiu       $v1, $zero, 0x14
    ctx->pc = 0x2c516cu;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 20));
    // 0x2c5170: 0x432818  mult        $a1, $v0, $v1
    ctx->pc = 0x2c5170u;
    { int64_t result = (int64_t)GPR_S32(ctx, 2) * (int64_t)GPR_S32(ctx, 3); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 5, (int32_t)result); }
    // 0x2c5174: 0xa41021  addu        $v0, $a1, $a0
    ctx->pc = 0x2c5174u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
    // 0x2c5178: 0x8c440184  lw          $a0, 0x184($v0)
    ctx->pc = 0x2c5178u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 388)));
    // 0x2c517c: 0x2883fff9  slti        $v1, $a0, -0x7
    ctx->pc = 0x2c517cu;
    SET_GPR_U64(ctx, 3, ((int64_t)GPR_S64(ctx, 4) < (int64_t)(int32_t)4294967289) ? 1 : 0);
    // 0x2c5180: 0x10600009  beqz        $v1, . + 4 + (0x9 << 2)
    ctx->pc = 0x2C5180u;
    {
        const bool branch_taken_0x2c5180 = (GPR_U64(ctx, 3) == GPR_U64(ctx, 0));
        ctx->pc = 0x2C5184u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5180u;
        // 0x2c5184: 0x2882fff6  slti        $v0, $a0, -0xA (Delay Slot)
        SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 4) < (int64_t)(int32_t)4294967286) ? 1 : 0);
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c5180) {
            ctx->pc = 0x2C51A8u;
            goto label_2c51a8;
        }
    }
    ctx->pc = 0x2C5188u;
    // 0x2c5188: 0x1040000c  beqz        $v0, . + 4 + (0xC << 2)
    ctx->pc = 0x2C5188u;
    {
        const bool branch_taken_0x2c5188 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x2C518Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5188u;
        // 0x2c518c: 0x2882d8f0  slti        $v0, $a0, -0x2710 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 4) < (int64_t)(int32_t)4294957296) ? 1 : 0);
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c5188) {
            ctx->pc = 0x2C51BCu;
            goto label_2c51bc;
        }
    }
    ctx->pc = 0x2C5190u;
    // 0x2c5190: 0x1040000c  beqz        $v0, . + 4 + (0xC << 2)
    ctx->pc = 0x2C5190u;
    {
        const bool branch_taken_0x2c5190 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x2C5194u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5190u;
        // 0x2c5194: 0x2882d8ee  slti        $v0, $a0, -0x2712 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 4) < (int64_t)(int32_t)4294957294) ? 1 : 0);
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c5190) {
            ctx->pc = 0x2C51C4u;
            goto label_2c51c4;
        }
    }
    ctx->pc = 0x2C5198u;
    // 0x2c5198: 0x1440000b  bnez        $v0, . + 4 + (0xB << 2)
    ctx->pc = 0x2C5198u;
    {
        const bool branch_taken_0x2c5198 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x2C519Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5198u;
        // 0x2c519c: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c5198) {
            ctx->pc = 0x2C51C8u;
            goto label_2c51c8;
        }
    }
    ctx->pc = 0x2C51A0u;
    // 0x2c51a0: 0x3e00008  jr          $ra
    ctx->pc = 0x2C51A0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C51A4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C51A0u;
        // 0x2c51a4: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C51A0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C51A8u;
label_2c51a8:
    // 0x2c51a8: 0x2402fffd  addiu       $v0, $zero, -0x3
    ctx->pc = 0x2c51a8u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967293));
    // 0x2c51ac: 0x10820003  beq         $a0, $v0, . + 4 + (0x3 << 2)
    ctx->pc = 0x2C51ACu;
    {
        const bool branch_taken_0x2c51ac = (GPR_U64(ctx, 4) == GPR_U64(ctx, 2));
        ctx->pc = 0x2C51B0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C51ACu;
        // 0x2c51b0: 0x2402ffff  addiu       $v0, $zero, -0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c51ac) {
            ctx->pc = 0x2C51BCu;
            goto label_2c51bc;
        }
    }
    ctx->pc = 0x2C51B4u;
    // 0x2c51b4: 0x14820004  bne         $a0, $v0, . + 4 + (0x4 << 2)
    ctx->pc = 0x2C51B4u;
    {
        const bool branch_taken_0x2c51b4 = (GPR_U64(ctx, 4) != GPR_U64(ctx, 2));
        ctx->pc = 0x2C51B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C51B4u;
        // 0x2c51b8: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c51b4) {
            ctx->pc = 0x2C51C8u;
            goto label_2c51c8;
        }
    }
    ctx->pc = 0x2C51BCu;
label_2c51bc:
    // 0x2c51bc: 0x3e00008  jr          $ra
    ctx->pc = 0x2C51BCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C51C0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C51BCu;
        // 0x2c51c0: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C51BCu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C51C4u;
label_2c51c4:
    // 0x2c51c4: 0x102d  daddu       $v0, $zero, $zero
    ctx->pc = 0x2c51c4u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_2c51c8:
    // 0x2c51c8: 0x3e00008  jr          $ra
    ctx->pc = 0x2C51C8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C51C8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C51D0u;
}
