#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_002420C8
// Address: 0x2420c8 - 0x242288
void sub_002420C8_0x2420c8(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_002420C8_0x2420c8");
#endif

    switch (ctx->pc) {
        case 0x2420c8u: goto label_2420c8;
        case 0x2420ccu: goto label_2420cc;
        case 0x2420d0u: goto label_2420d0;
        case 0x2420d4u: goto label_2420d4;
        case 0x2420d8u: goto label_2420d8;
        case 0x2420dcu: goto label_2420dc;
        case 0x2420e0u: goto label_2420e0;
        case 0x2420e4u: goto label_2420e4;
        case 0x2420e8u: goto label_2420e8;
        case 0x2420ecu: goto label_2420ec;
        case 0x2420f0u: goto label_2420f0;
        case 0x2420f4u: goto label_2420f4;
        case 0x2420f8u: goto label_2420f8;
        case 0x2420fcu: goto label_2420fc;
        case 0x242100u: goto label_242100;
        case 0x242104u: goto label_242104;
        case 0x242108u: goto label_242108;
        case 0x24210cu: goto label_24210c;
        case 0x242110u: goto label_242110;
        case 0x242114u: goto label_242114;
        case 0x242118u: goto label_242118;
        case 0x24211cu: goto label_24211c;
        case 0x242120u: goto label_242120;
        case 0x242124u: goto label_242124;
        case 0x242128u: goto label_242128;
        case 0x24212cu: goto label_24212c;
        case 0x242130u: goto label_242130;
        case 0x242134u: goto label_242134;
        case 0x242138u: goto label_242138;
        case 0x24213cu: goto label_24213c;
        case 0x242140u: goto label_242140;
        case 0x242144u: goto label_242144;
        case 0x242148u: goto label_242148;
        case 0x24214cu: goto label_24214c;
        case 0x242150u: goto label_242150;
        case 0x242154u: goto label_242154;
        case 0x242158u: goto label_242158;
        case 0x24215cu: goto label_24215c;
        case 0x242160u: goto label_242160;
        case 0x242164u: goto label_242164;
        case 0x242168u: goto label_242168;
        case 0x24216cu: goto label_24216c;
        case 0x242170u: goto label_242170;
        case 0x242174u: goto label_242174;
        case 0x242178u: goto label_242178;
        case 0x24217cu: goto label_24217c;
        case 0x242180u: goto label_242180;
        case 0x242184u: goto label_242184;
        case 0x242188u: goto label_242188;
        case 0x24218cu: goto label_24218c;
        case 0x242190u: goto label_242190;
        case 0x242194u: goto label_242194;
        case 0x242198u: goto label_242198;
        case 0x24219cu: goto label_24219c;
        case 0x2421a0u: goto label_2421a0;
        case 0x2421a4u: goto label_2421a4;
        case 0x2421a8u: goto label_2421a8;
        case 0x2421acu: goto label_2421ac;
        case 0x2421b0u: goto label_2421b0;
        case 0x2421b4u: goto label_2421b4;
        case 0x2421b8u: goto label_2421b8;
        case 0x2421bcu: goto label_2421bc;
        case 0x2421c0u: goto label_2421c0;
        case 0x2421c4u: goto label_2421c4;
        case 0x2421c8u: goto label_2421c8;
        case 0x2421ccu: goto label_2421cc;
        case 0x2421d0u: goto label_2421d0;
        case 0x2421d4u: goto label_2421d4;
        case 0x2421d8u: goto label_2421d8;
        case 0x2421dcu: goto label_2421dc;
        case 0x2421e0u: goto label_2421e0;
        case 0x2421e4u: goto label_2421e4;
        case 0x2421e8u: goto label_2421e8;
        case 0x2421ecu: goto label_2421ec;
        case 0x2421f0u: goto label_2421f0;
        case 0x2421f4u: goto label_2421f4;
        case 0x2421f8u: goto label_2421f8;
        case 0x2421fcu: goto label_2421fc;
        case 0x242200u: goto label_242200;
        case 0x242204u: goto label_242204;
        case 0x242208u: goto label_242208;
        case 0x24220cu: goto label_24220c;
        case 0x242210u: goto label_242210;
        case 0x242214u: goto label_242214;
        case 0x242218u: goto label_242218;
        case 0x24221cu: goto label_24221c;
        case 0x242220u: goto label_242220;
        case 0x242224u: goto label_242224;
        case 0x242228u: goto label_242228;
        case 0x24222cu: goto label_24222c;
        case 0x242230u: goto label_242230;
        case 0x242234u: goto label_242234;
        case 0x242238u: goto label_242238;
        case 0x24223cu: goto label_24223c;
        case 0x242240u: goto label_242240;
        case 0x242244u: goto label_242244;
        case 0x242248u: goto label_242248;
        case 0x24224cu: goto label_24224c;
        case 0x242250u: goto label_242250;
        case 0x242254u: goto label_242254;
        case 0x242258u: goto label_242258;
        case 0x24225cu: goto label_24225c;
        case 0x242260u: goto label_242260;
        case 0x242264u: goto label_242264;
        case 0x242268u: goto label_242268;
        case 0x24226cu: goto label_24226c;
        case 0x242270u: goto label_242270;
        case 0x242274u: goto label_242274;
        case 0x242278u: goto label_242278;
        case 0x24227cu: goto label_24227c;
        case 0x242280u: goto label_242280;
        case 0x242284u: goto label_242284;
        default: break;
    }

    ctx->pc = 0x2420c8u;

label_2420c8:
    // 0x2420c8: 0x27bdff90  addiu       $sp, $sp, -0x70
    ctx->pc = 0x2420c8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967184));
label_2420cc:
    // 0x2420cc: 0x24070001  addiu       $a3, $zero, 0x1
    ctx->pc = 0x2420ccu;
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_2420d0:
    // 0x2420d0: 0x7fb10050  sq          $s1, 0x50($sp)
    ctx->pc = 0x2420d0u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 80), GPR_VEC(ctx, 17));
label_2420d4:
    // 0x2420d4: 0x240600c8  addiu       $a2, $zero, 0xC8
    ctx->pc = 0x2420d4u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 0), 200));
label_2420d8:
    // 0x2420d8: 0x7fb50010  sq          $s5, 0x10($sp)
    ctx->pc = 0x2420d8u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 21));
label_2420dc:
    // 0x2420dc: 0xa0882d  daddu       $s1, $a1, $zero
    ctx->pc = 0x2420dcu;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_2420e0:
    // 0x2420e0: 0x241500e0  addiu       $s5, $zero, 0xE0
    ctx->pc = 0x2420e0u;
    SET_GPR_S32(ctx, 21, (int32_t)ADD32(GPR_U32(ctx, 0), 224));
label_2420e4:
    // 0x2420e4: 0x7fb00060  sq          $s0, 0x60($sp)
    ctx->pc = 0x2420e4u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 96), GPR_VEC(ctx, 16));
label_2420e8:
    // 0x2420e8: 0x2351818  mult        $v1, $s1, $s5
    ctx->pc = 0x2420e8u;
    { int64_t result = (int64_t)GPR_S32(ctx, 17) * (int64_t)GPR_S32(ctx, 21); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 3, (int32_t)result); }
label_2420ec:
    // 0x2420ec: 0x80802d  daddu       $s0, $a0, $zero
    ctx->pc = 0x2420ecu;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2420f0:
    // 0x2420f0: 0x7fb20040  sq          $s2, 0x40($sp)
    ctx->pc = 0x2420f0u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 64), GPR_VEC(ctx, 18));
label_2420f4:
    // 0x2420f4: 0x26040348  addiu       $a0, $s0, 0x348
    ctx->pc = 0x2420f4u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 840));
label_2420f8:
    // 0x2420f8: 0x7fb30030  sq          $s3, 0x30($sp)
    ctx->pc = 0x2420f8u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 48), GPR_VEC(ctx, 19));
label_2420fc:
    // 0x2420fc: 0x2608034c  addiu       $t0, $s0, 0x34C
    ctx->pc = 0x2420fcu;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 16), 844));
label_242100:
    // 0x242100: 0x7fb40020  sq          $s4, 0x20($sp)
    ctx->pc = 0x242100u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 20));
label_242104:
    // 0x242104: 0x282d  daddu       $a1, $zero, $zero
    ctx->pc = 0x242104u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_242108:
    // 0x242108: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x242108u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_24210c:
    // 0x24210c: 0x2031021  addu        $v0, $s0, $v1
    ctx->pc = 0x24210cu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 3)));
label_242110:
    // 0x242110: 0xac470344  sw          $a3, 0x344($v0)
    ctx->pc = 0x242110u;
    WRITE32(ADD32(GPR_U32(ctx, 2), 836), GPR_U32(ctx, 7));
label_242114:
    // 0x242114: 0x839021  addu        $s2, $a0, $v1
    ctx->pc = 0x242114u;
    SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 3)));
label_242118:
    // 0x242118: 0x701021  addu        $v0, $v1, $s0
    ctx->pc = 0x242118u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 3), GPR_U32(ctx, 16)));
label_24211c:
    // 0x24211c: 0x1039821  addu        $s3, $t0, $v1
    ctx->pc = 0x24211cu;
    SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 8), GPR_U32(ctx, 3)));
label_242120:
    // 0x242120: 0xae470000  sw          $a3, 0x0($s2)
    ctx->pc = 0x242120u;
    WRITE32(ADD32(GPR_U32(ctx, 18), 0), GPR_U32(ctx, 7));
label_242124:
    // 0x242124: 0x2454035c  addiu       $s4, $v0, 0x35C
    ctx->pc = 0x242124u;
    SET_GPR_S32(ctx, 20, (int32_t)ADD32(GPR_U32(ctx, 2), 860));
label_242128:
    // 0x242128: 0x2031821  addu        $v1, $s0, $v1
    ctx->pc = 0x242128u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 3)));
label_24212c:
    // 0x24212c: 0xae670000  sw          $a3, 0x0($s3)
    ctx->pc = 0x24212cu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 0), GPR_U32(ctx, 7));
label_242130:
    // 0x242130: 0x280202d  daddu       $a0, $s4, $zero
    ctx->pc = 0x242130u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 20) + (uint64_t)GPR_U64(ctx, 0));
label_242134:
    // 0x242134: 0xc0f9912  jal         func_3E6448
label_242138:
    if (ctx->pc == 0x242138u) {
        ctx->pc = 0x242138u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242134u;
        // 0x242138: 0xac670350  sw          $a3, 0x350($v1) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 3), 848), GPR_U32(ctx, 7));
        ctx->in_delay_slot = false;
        ctx->pc = 0x24213Cu;
        goto label_24213c;
    }
    ctx->pc = 0x242134u;
    SET_GPR_U32(ctx, 31, 0x24213Cu);
    ctx->pc = 0x242138u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x242134u;
    // 0x242138: 0xac670350  sw          $a3, 0x350($v1) (Delay Slot)
    WRITE32(ADD32(GPR_U32(ctx, 3), 848), GPR_U32(ctx, 7));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3E6448u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3E6448u, 0x242134u, 0x24213Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x24213Cu;
label_24213c:
    // 0x24213c: 0x8e060434  lw          $a2, 0x434($s0)
    ctx->pc = 0x24213cu;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_242140:
    // 0x242140: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x242140u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_242144:
    // 0x242144: 0x8cc30000  lw          $v1, 0x0($a2)
    ctx->pc = 0x242144u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_242148:
    // 0x242148: 0x84640180  lh          $a0, 0x180($v1)
    ctx->pc = 0x242148u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 384)));
label_24214c:
    // 0x24214c: 0x8c620184  lw          $v0, 0x184($v1)
    ctx->pc = 0x24214cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 388)));
label_242150:
    // 0x242150: 0x40f809  jalr        $v0
label_242154:
    if (ctx->pc == 0x242154u) {
        ctx->pc = 0x242154u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242150u;
        // 0x242154: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x242158u;
        goto label_242158;
    }
    ctx->pc = 0x242150u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x242158u);
        ctx->pc = 0x242154u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242150u;
        // 0x242154: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x242150u, 0x242158u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x242158u;
label_242158:
    // 0x242158: 0x14400013  bnez        $v0, . + 4 + (0x13 << 2)
label_24215c:
    if (ctx->pc == 0x24215Cu) {
        ctx->pc = 0x24215Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242158u;
        // 0x24215c: 0x240200e0  addiu       $v0, $zero, 0xE0 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 224));
        ctx->in_delay_slot = false;
        ctx->pc = 0x242160u;
        goto label_242160;
    }
    ctx->pc = 0x242158u;
    {
        const bool branch_taken_0x242158 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x24215Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242158u;
        // 0x24215c: 0x240200e0  addiu       $v0, $zero, 0xE0 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 224));
        ctx->in_delay_slot = false;
        if (branch_taken_0x242158) {
            ctx->pc = 0x2421A8u;
            goto label_2421a8;
        }
    }
    ctx->pc = 0x242160u;
label_242160:
    // 0x242160: 0x8e060434  lw          $a2, 0x434($s0)
    ctx->pc = 0x242160u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_242164:
    // 0x242164: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x242164u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_242168:
    // 0x242168: 0x8cc30000  lw          $v1, 0x0($a2)
    ctx->pc = 0x242168u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_24216c:
    // 0x24216c: 0x84640190  lh          $a0, 0x190($v1)
    ctx->pc = 0x24216cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 400)));
label_242170:
    // 0x242170: 0x8c620194  lw          $v0, 0x194($v1)
    ctx->pc = 0x242170u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 404)));
label_242174:
    // 0x242174: 0x40f809  jalr        $v0
label_242178:
    if (ctx->pc == 0x242178u) {
        ctx->pc = 0x242178u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242174u;
        // 0x242178: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x24217Cu;
        goto label_24217c;
    }
    ctx->pc = 0x242174u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x24217Cu);
        ctx->pc = 0x242178u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242174u;
        // 0x242178: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x242174u, 0x24217Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x24217Cu;
label_24217c:
    // 0x24217c: 0x1440000a  bnez        $v0, . + 4 + (0xA << 2)
label_242180:
    if (ctx->pc == 0x242180u) {
        ctx->pc = 0x242180u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x24217Cu;
        // 0x242180: 0x240200e0  addiu       $v0, $zero, 0xE0 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 224));
        ctx->in_delay_slot = false;
        ctx->pc = 0x242184u;
        goto label_242184;
    }
    ctx->pc = 0x24217Cu;
    {
        const bool branch_taken_0x24217c = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x242180u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x24217Cu;
        // 0x242180: 0x240200e0  addiu       $v0, $zero, 0xE0 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 224));
        ctx->in_delay_slot = false;
        if (branch_taken_0x24217c) {
            ctx->pc = 0x2421A8u;
            goto label_2421a8;
        }
    }
    ctx->pc = 0x242184u;
label_242184:
    // 0x242184: 0x8e060434  lw          $a2, 0x434($s0)
    ctx->pc = 0x242184u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_242188:
    // 0x242188: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x242188u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_24218c:
    // 0x24218c: 0x8cc30000  lw          $v1, 0x0($a2)
    ctx->pc = 0x24218cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_242190:
    // 0x242190: 0x846401e0  lh          $a0, 0x1E0($v1)
    ctx->pc = 0x242190u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 480)));
label_242194:
    // 0x242194: 0x8c6201e4  lw          $v0, 0x1E4($v1)
    ctx->pc = 0x242194u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 484)));
label_242198:
    // 0x242198: 0x40f809  jalr        $v0
label_24219c:
    if (ctx->pc == 0x24219Cu) {
        ctx->pc = 0x24219Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242198u;
        // 0x24219c: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2421A0u;
        goto label_2421a0;
    }
    ctx->pc = 0x242198u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2421A0u);
        ctx->pc = 0x24219Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242198u;
        // 0x24219c: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x242198u, 0x2421A0u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2421A0u;
label_2421a0:
    // 0x2421a0: 0x10400005  beqz        $v0, . + 4 + (0x5 << 2)
label_2421a4:
    if (ctx->pc == 0x2421A4u) {
        ctx->pc = 0x2421A4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421A0u;
        // 0x2421a4: 0x240200e0  addiu       $v0, $zero, 0xE0 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 224));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2421A8u;
        goto label_2421a8;
    }
    ctx->pc = 0x2421A0u;
    {
        const bool branch_taken_0x2421a0 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x2421A4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421A0u;
        // 0x2421a4: 0x240200e0  addiu       $v0, $zero, 0xE0 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 224));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2421a0) {
            ctx->pc = 0x2421B8u;
            goto label_2421b8;
        }
    }
    ctx->pc = 0x2421A8u;
label_2421a8:
    // 0x2421a8: 0x2221818  mult        $v1, $s1, $v0
    ctx->pc = 0x2421a8u;
    { int64_t result = (int64_t)GPR_S32(ctx, 17) * (int64_t)GPR_S32(ctx, 2); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 3, (int32_t)result); }
label_2421ac:
    // 0x2421ac: 0x701021  addu        $v0, $v1, $s0
    ctx->pc = 0x2421acu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 3), GPR_U32(ctx, 16)));
label_2421b0:
    // 0x2421b0: 0x1000002b  b           . + 4 + (0x2B << 2)
label_2421b4:
    if (ctx->pc == 0x2421B4u) {
        ctx->pc = 0x2421B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421B0u;
        // 0x2421b4: 0xac400344  sw          $zero, 0x344($v0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 2), 836), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2421B8u;
        goto label_2421b8;
    }
    ctx->pc = 0x2421B0u;
    {
        const bool branch_taken_0x2421b0 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x2421B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421B0u;
        // 0x2421b4: 0xac400344  sw          $zero, 0x344($v0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 2), 836), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2421b0) {
            ctx->pc = 0x242260u;
            goto label_242260;
        }
    }
    ctx->pc = 0x2421B8u;
label_2421b8:
    // 0x2421b8: 0x8e060434  lw          $a2, 0x434($s0)
    ctx->pc = 0x2421b8u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_2421bc:
    // 0x2421bc: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x2421bcu;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_2421c0:
    // 0x2421c0: 0x8cc30000  lw          $v1, 0x0($a2)
    ctx->pc = 0x2421c0u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_2421c4:
    // 0x2421c4: 0x846401c0  lh          $a0, 0x1C0($v1)
    ctx->pc = 0x2421c4u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 448)));
label_2421c8:
    // 0x2421c8: 0x8c6201c4  lw          $v0, 0x1C4($v1)
    ctx->pc = 0x2421c8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 452)));
label_2421cc:
    // 0x2421cc: 0x40f809  jalr        $v0
label_2421d0:
    if (ctx->pc == 0x2421D0u) {
        ctx->pc = 0x2421D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421CCu;
        // 0x2421d0: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2421D4u;
        goto label_2421d4;
    }
    ctx->pc = 0x2421CCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2421D4u);
        ctx->pc = 0x2421D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421CCu;
        // 0x2421d0: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2421CCu, 0x2421D4u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2421D4u;
label_2421d4:
    // 0x2421d4: 0x54400003  bnel        $v0, $zero, . + 4 + (0x3 << 2)
label_2421d8:
    if (ctx->pc == 0x2421D8u) {
        ctx->pc = 0x2421D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421D4u;
        // 0x2421d8: 0x8e060434  lw          $a2, 0x434($s0) (Delay Slot)
        SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2421DCu;
        goto label_2421dc;
    }
    ctx->pc = 0x2421D4u;
    {
        const bool branch_taken_0x2421d4 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2421d4) {
            ctx->pc = 0x2421D8u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2421D4u;
            // 0x2421d8: 0x8e060434  lw          $a2, 0x434($s0) (Delay Slot)
            SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2421E4u;
            goto label_2421e4;
        }
    }
    ctx->pc = 0x2421DCu;
label_2421dc:
    // 0x2421dc: 0x10000020  b           . + 4 + (0x20 << 2)
label_2421e0:
    if (ctx->pc == 0x2421E0u) {
        ctx->pc = 0x2421E0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421DCu;
        // 0x2421e0: 0xae400000  sw          $zero, 0x0($s2) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 18), 0), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2421E4u;
        goto label_2421e4;
    }
    ctx->pc = 0x2421DCu;
    {
        const bool branch_taken_0x2421dc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x2421E0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421DCu;
        // 0x2421e0: 0xae400000  sw          $zero, 0x0($s2) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 18), 0), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2421dc) {
            ctx->pc = 0x242260u;
            goto label_242260;
        }
    }
    ctx->pc = 0x2421E4u;
label_2421e4:
    // 0x2421e4: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x2421e4u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_2421e8:
    // 0x2421e8: 0x8cc30000  lw          $v1, 0x0($a2)
    ctx->pc = 0x2421e8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 0)));
label_2421ec:
    // 0x2421ec: 0x846401c8  lh          $a0, 0x1C8($v1)
    ctx->pc = 0x2421ecu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 456)));
label_2421f0:
    // 0x2421f0: 0x8c6201cc  lw          $v0, 0x1CC($v1)
    ctx->pc = 0x2421f0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 460)));
label_2421f4:
    // 0x2421f4: 0x40f809  jalr        $v0
label_2421f8:
    if (ctx->pc == 0x2421F8u) {
        ctx->pc = 0x2421F8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421F4u;
        // 0x2421f8: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2421FCu;
        goto label_2421fc;
    }
    ctx->pc = 0x2421F4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2421FCu);
        ctx->pc = 0x2421F8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421F4u;
        // 0x2421f8: 0xc42021  addu        $a0, $a2, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2421F4u, 0x2421FCu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2421FCu;
label_2421fc:
    // 0x2421fc: 0x54400003  bnel        $v0, $zero, . + 4 + (0x3 << 2)
label_242200:
    if (ctx->pc == 0x242200u) {
        ctx->pc = 0x242200u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2421FCu;
        // 0x242200: 0x8e02042c  lw          $v0, 0x42C($s0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1068)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x242204u;
        goto label_242204;
    }
    ctx->pc = 0x2421FCu;
    {
        const bool branch_taken_0x2421fc = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2421fc) {
            ctx->pc = 0x242200u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2421FCu;
            // 0x242200: 0x8e02042c  lw          $v0, 0x42C($s0) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1068)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x24220Cu;
            goto label_24220c;
        }
    }
    ctx->pc = 0x242204u;
label_242204:
    // 0x242204: 0x10000016  b           . + 4 + (0x16 << 2)
label_242208:
    if (ctx->pc == 0x242208u) {
        ctx->pc = 0x242208u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242204u;
        // 0x242208: 0xae600000  sw          $zero, 0x0($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 0), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x24220Cu;
        goto label_24220c;
    }
    ctx->pc = 0x242204u;
    {
        const bool branch_taken_0x242204 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x242208u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242204u;
        // 0x242208: 0xae600000  sw          $zero, 0x0($s3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 19), 0), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x242204) {
            ctx->pc = 0x242260u;
            goto label_242260;
        }
    }
    ctx->pc = 0x24220Cu;
label_24220c:
    // 0x24220c: 0x5622000c  bnel        $s1, $v0, . + 4 + (0xC << 2)
label_242210:
    if (ctx->pc == 0x242210u) {
        ctx->pc = 0x242210u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x24220Cu;
        // 0x242210: 0x8e080434  lw          $t0, 0x434($s0) (Delay Slot)
        SET_GPR_S32(ctx, 8, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x242214u;
        goto label_242214;
    }
    ctx->pc = 0x24220Cu;
    {
        const bool branch_taken_0x24220c = (GPR_U64(ctx, 17) != GPR_U64(ctx, 2));
        if (branch_taken_0x24220c) {
            ctx->pc = 0x242210u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x24220Cu;
            // 0x242210: 0x8e080434  lw          $t0, 0x434($s0) (Delay Slot)
            SET_GPR_S32(ctx, 8, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x242240u;
            goto label_242240;
        }
    }
    ctx->pc = 0x242214u;
label_242214:
    // 0x242214: 0x8e050434  lw          $a1, 0x434($s0)
    ctx->pc = 0x242214u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_242218:
    // 0x242218: 0x8ca30000  lw          $v1, 0x0($a1)
    ctx->pc = 0x242218u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
label_24221c:
    // 0x24221c: 0x846400a0  lh          $a0, 0xA0($v1)
    ctx->pc = 0x24221cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 160)));
label_242220:
    // 0x242220: 0x8c6200a4  lw          $v0, 0xA4($v1)
    ctx->pc = 0x242220u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 164)));
label_242224:
    // 0x242224: 0x40f809  jalr        $v0
label_242228:
    if (ctx->pc == 0x242228u) {
        ctx->pc = 0x242228u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242224u;
        // 0x242228: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x24222Cu;
        goto label_24222c;
    }
    ctx->pc = 0x242224u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x24222Cu);
        ctx->pc = 0x242228u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242224u;
        // 0x242228: 0xa42021  addu        $a0, $a1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x242224u, 0x24222Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x24222Cu;
label_24222c:
    // 0x24222c: 0x8e03042c  lw          $v1, 0x42C($s0)
    ctx->pc = 0x24222cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1068)));
label_242230:
    // 0x242230: 0x752018  mult        $a0, $v1, $s5
    ctx->pc = 0x242230u;
    { int64_t result = (int64_t)GPR_S32(ctx, 3) * (int64_t)GPR_S32(ctx, 21); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 4, (int32_t)result); }
label_242234:
    // 0x242234: 0x901821  addu        $v1, $a0, $s0
    ctx->pc = 0x242234u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 16)));
label_242238:
    // 0x242238: 0xac620354  sw          $v0, 0x354($v1)
    ctx->pc = 0x242238u;
    WRITE32(ADD32(GPR_U32(ctx, 3), 852), GPR_U32(ctx, 2));
label_24223c:
    // 0x24223c: 0x8e080434  lw          $t0, 0x434($s0)
    ctx->pc = 0x24223cu;
    SET_GPR_S32(ctx, 8, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1076)));
label_242240:
    // 0x242240: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x242240u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_242244:
    // 0x242244: 0x280302d  daddu       $a2, $s4, $zero
    ctx->pc = 0x242244u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 20) + (uint64_t)GPR_U64(ctx, 0));
label_242248:
    // 0x242248: 0x24070064  addiu       $a3, $zero, 0x64
    ctx->pc = 0x242248u;
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 0), 100));
label_24224c:
    // 0x24224c: 0x8d020000  lw          $v0, 0x0($t0)
    ctx->pc = 0x24224cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 8), 0)));
label_242250:
    // 0x242250: 0x84440230  lh          $a0, 0x230($v0)
    ctx->pc = 0x242250u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 560)));
label_242254:
    // 0x242254: 0x8c430234  lw          $v1, 0x234($v0)
    ctx->pc = 0x242254u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 564)));
label_242258:
    // 0x242258: 0x60f809  jalr        $v1
label_24225c:
    if (ctx->pc == 0x24225Cu) {
        ctx->pc = 0x24225Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242258u;
        // 0x24225c: 0x1042021  addu        $a0, $t0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 8), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x242260u;
        goto label_242260;
    }
    ctx->pc = 0x242258u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x242260u);
        ctx->pc = 0x24225Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x242258u;
        // 0x24225c: 0x1042021  addu        $a0, $t0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 8), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x242258u, 0x242260u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x242260u;
label_242260:
    // 0x242260: 0x7bb00060  lq          $s0, 0x60($sp)
    ctx->pc = 0x242260u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 96)));
label_242264:
    // 0x242264: 0x7bb10050  lq          $s1, 0x50($sp)
    ctx->pc = 0x242264u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 80)));
label_242268:
    // 0x242268: 0x7bb20040  lq          $s2, 0x40($sp)
    ctx->pc = 0x242268u;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 64)));
label_24226c:
    // 0x24226c: 0x7bb30030  lq          $s3, 0x30($sp)
    ctx->pc = 0x24226cu;
    SET_GPR_VEC(ctx, 19, READ128(ADD32(GPR_U32(ctx, 29), 48)));
label_242270:
    // 0x242270: 0x7bb40020  lq          $s4, 0x20($sp)
    ctx->pc = 0x242270u;
    SET_GPR_VEC(ctx, 20, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_242274:
    // 0x242274: 0x7bb50010  lq          $s5, 0x10($sp)
    ctx->pc = 0x242274u;
    SET_GPR_VEC(ctx, 21, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_242278:
    // 0x242278: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x242278u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_24227c:
    // 0x24227c: 0x3e00008  jr          $ra
label_242280:
    if (ctx->pc == 0x242280u) {
        ctx->pc = 0x242280u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x24227Cu;
        // 0x242280: 0x27bd0070  addiu       $sp, $sp, 0x70 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 112));
        ctx->in_delay_slot = false;
        ctx->pc = 0x242284u;
        goto label_242284;
    }
    ctx->pc = 0x24227Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x242280u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x24227Cu;
        // 0x242280: 0x27bd0070  addiu       $sp, $sp, 0x70 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 112));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x24227Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x242284u;
label_242284:
    // 0x242284: 0x0  nop
    ctx->pc = 0x242284u;
    // NOP
    ctx->pc = 0x242288u;
}
