#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_003956E8
// Address: 0x3956e8 - 0x395750
void sub_003956E8_0x3956e8(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_003956E8_0x3956e8");
#endif

    ctx->pc = 0x3956e8u;

    // 0x3956e8: 0x8c8513e4  lw          $a1, 0x13E4($a0)
    ctx->pc = 0x3956e8u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 5092)));
    // 0x3956ec: 0x24a20040  addiu       $v0, $a1, 0x40
    ctx->pc = 0x3956ecu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 5), 64));
    // 0x3956f0: 0xd8a10000  lqc2        $vf1, 0x0($a1)
    ctx->pc = 0x3956f0u;
    ctx->vu0_vf[1] = _mm_castsi128_ps(READ128(ADD32(GPR_U32(ctx, 5), 0)));
    // 0x3956f4: 0xd8a20010  lqc2        $vf2, 0x10($a1)
    ctx->pc = 0x3956f4u;
    ctx->vu0_vf[2] = _mm_castsi128_ps(READ128(ADD32(GPR_U32(ctx, 5), 16)));
    // 0x3956f8: 0xd8a30020  lqc2        $vf3, 0x20($a1)
    ctx->pc = 0x3956f8u;
    ctx->vu0_vf[3] = _mm_castsi128_ps(READ128(ADD32(GPR_U32(ctx, 5), 32)));
    // 0x3956fc: 0xd8a40030  lqc2        $vf4, 0x30($a1)
    ctx->pc = 0x3956fcu;
    ctx->vu0_vf[4] = _mm_castsi128_ps(READ128(ADD32(GPR_U32(ctx, 5), 48)));
    // 0x395700: 0xf8410000  sqc2        $vf1, 0x0($v0)
    ctx->pc = 0x395700u;
    WRITE128(ADD32(GPR_U32(ctx, 2), 0), _mm_castps_si128(ctx->vu0_vf[1]));
    // 0x395704: 0xf8420010  sqc2        $vf2, 0x10($v0)
    ctx->pc = 0x395704u;
    WRITE128(ADD32(GPR_U32(ctx, 2), 16), _mm_castps_si128(ctx->vu0_vf[2]));
    // 0x395708: 0xf8430020  sqc2        $vf3, 0x20($v0)
    ctx->pc = 0x395708u;
    WRITE128(ADD32(GPR_U32(ctx, 2), 32), _mm_castps_si128(ctx->vu0_vf[3]));
    // 0x39570c: 0xf8440030  sqc2        $vf4, 0x30($v0)
    ctx->pc = 0x39570cu;
    WRITE128(ADD32(GPR_U32(ctx, 2), 48), _mm_castps_si128(ctx->vu0_vf[4]));
    // 0x395710: 0x8c8313e4  lw          $v1, 0x13E4($a0)
    ctx->pc = 0x395710u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 5092)));
    // 0x395714: 0x8c8213e0  lw          $v0, 0x13E0($a0)
    ctx->pc = 0x395714u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 5088)));
    // 0x395718: 0x24630040  addiu       $v1, $v1, 0x40
    ctx->pc = 0x395718u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 64));
    // 0x39571c: 0x24420001  addiu       $v0, $v0, 0x1
    ctx->pc = 0x39571cu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 1));
    // 0x395720: 0xac8313e4  sw          $v1, 0x13E4($a0)
    ctx->pc = 0x395720u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 5092), GPR_U32(ctx, 3));
    // 0x395724: 0x3e00008  jr          $ra
    ctx->pc = 0x395724u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x395728u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x395724u;
        // 0x395728: 0xac8213e0  sw          $v0, 0x13E0($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 5088), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x395724u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x39572Cu;
    // 0x39572c: 0x0  nop
    ctx->pc = 0x39572cu;
    // NOP
    // 0x395730: 0x8c8213e4  lw          $v0, 0x13E4($a0)
    ctx->pc = 0x395730u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 5092)));
    // 0x395734: 0x8c8313e0  lw          $v1, 0x13E0($a0)
    ctx->pc = 0x395734u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 5088)));
    // 0x395738: 0x2442ffc0  addiu       $v0, $v0, -0x40
    ctx->pc = 0x395738u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 4294967232));
    // 0x39573c: 0xac806b90  sw          $zero, 0x6B90($a0)
    ctx->pc = 0x39573cu;
    WRITE32(ADD32(GPR_U32(ctx, 4), 27536), GPR_U32(ctx, 0));
    // 0x395740: 0x2463ffff  addiu       $v1, $v1, -0x1
    ctx->pc = 0x395740u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 4294967295));
    // 0x395744: 0xac8213e4  sw          $v0, 0x13E4($a0)
    ctx->pc = 0x395744u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 5092), GPR_U32(ctx, 2));
    // 0x395748: 0x3e00008  jr          $ra
    ctx->pc = 0x395748u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x39574Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x395748u;
        // 0x39574c: 0xac8313e0  sw          $v1, 0x13E0($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 5088), GPR_U32(ctx, 3));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x395748u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x395750u;
}
