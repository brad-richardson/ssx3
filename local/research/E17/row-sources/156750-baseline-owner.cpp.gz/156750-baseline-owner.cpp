#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_001565C8
// Address: 0x1565c8 - 0x1567b8
void sub_001565C8_0x1565c8(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_001565C8_0x1565c8");
#endif

    switch (ctx->pc) {
        case 0x1565fcu: goto label_1565fc;
        case 0x15660cu: goto label_15660c;
        case 0x15661cu: goto label_15661c;
        case 0x15662cu: goto label_15662c;
        case 0x15663cu: goto label_15663c;
        case 0x15664cu: goto label_15664c;
        case 0x15665cu: goto label_15665c;
        case 0x15666cu: goto label_15666c;
        case 0x15667cu: goto label_15667c;
        case 0x15668cu: goto label_15668c;
        case 0x15669cu: goto label_15669c;
        case 0x1566acu: goto label_1566ac;
        case 0x1566bcu: goto label_1566bc;
        case 0x1566ccu: goto label_1566cc;
        default: break;
    }

    ctx->pc = 0x1565c8u;

    // 0x1565c8: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x1565c8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
    // 0x1565cc: 0x2ca2000e  sltiu       $v0, $a1, 0xE
    ctx->pc = 0x1565ccu;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 5) < (uint64_t)(int64_t)(int32_t)14) ? 1 : 0);
    // 0x1565d0: 0x10400040  beqz        $v0, . + 4 + (0x40 << 2)
    ctx->pc = 0x1565D0u;
    {
        const bool branch_taken_0x1565d0 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x1565D4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x1565D0u;
        // 0x1565d4: 0xffbf0000  sd          $ra, 0x0($sp) (Delay Slot)
        WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
        ctx->in_delay_slot = false;
        if (branch_taken_0x1565d0) {
            ctx->pc = 0x1566D4u;
            goto label_1566d4;
        }
    }
    ctx->pc = 0x1565D8u;
    // 0x1565d8: 0x3c020046  lui         $v0, 0x46
    ctx->pc = 0x1565d8u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)70 << 16));
    // 0x1565dc: 0x51880  sll         $v1, $a1, 2
    ctx->pc = 0x1565dcu;
    SET_GPR_S32(ctx, 3, (int32_t)SLL32(GPR_U32(ctx, 5), 2));
    // 0x1565e0: 0x2442a900  addiu       $v0, $v0, -0x5700
    ctx->pc = 0x1565e0u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 4294945024));
    // 0x1565e4: 0x621821  addu        $v1, $v1, $v0
    ctx->pc = 0x1565e4u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), GPR_U32(ctx, 2)));
    // 0x1565e8: 0x8c640000  lw          $a0, 0x0($v1)
    ctx->pc = 0x1565e8u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 0)));
    // 0x1565ec: 0x800008  jr          $a0
    ctx->pc = 0x1565ECu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 4);
        ctx->pc = jumpTarget;
        switch (jumpTarget) {
            case 0x1565F4u: goto label_1565f4;
            case 0x156604u: goto label_156604;
            case 0x156614u: goto label_156614;
            case 0x156624u: goto label_156624;
            case 0x156634u: goto label_156634;
            case 0x156644u: goto label_156644;
            case 0x156654u: goto label_156654;
            case 0x156664u: goto label_156664;
            case 0x156674u: goto label_156674;
            case 0x156684u: goto label_156684;
            case 0x156694u: goto label_156694;
            case 0x1566A4u: goto label_1566a4;
            case 0x1566B4u: goto label_1566b4;
            case 0x1566C4u: goto label_1566c4;
            default: break;
        }
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x1565ECu, 0x0u, PS2Runtime::GuestBranchKind::IndirectJump, "JR")) {
            return;
        }
    }
    ctx->pc = 0x1565F4u;
label_1565f4:
    // 0x1565f4: 0xc051236  jal         func_1448D8
    ctx->pc = 0x1565F4u;
    SET_GPR_U32(ctx, 31, 0x1565FCu);
    ctx->pc = 0x1448D8u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x1448D8u, 0x1565F4u, 0x1565FCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x1565FCu;
label_1565fc:
    // 0x1565fc: 0x10000037  b           . + 4 + (0x37 << 2)
    ctx->pc = 0x1565FCu;
    {
        const bool branch_taken_0x1565fc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156600u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x1565FCu;
        // 0x156600: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x1565fc) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156604u;
label_156604:
    // 0x156604: 0xc05165c  jal         func_145970
    ctx->pc = 0x156604u;
    SET_GPR_U32(ctx, 31, 0x15660Cu);
    ctx->pc = 0x145970u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x145970u, 0x156604u, 0x15660Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15660Cu;
label_15660c:
    // 0x15660c: 0x10000033  b           . + 4 + (0x33 << 2)
    ctx->pc = 0x15660Cu;
    {
        const bool branch_taken_0x15660c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156610u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15660Cu;
        // 0x156610: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15660c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156614u;
label_156614:
    // 0x156614: 0xc053b76  jal         func_14EDD8
    ctx->pc = 0x156614u;
    SET_GPR_U32(ctx, 31, 0x15661Cu);
    ctx->pc = 0x14EDD8u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x14EDD8u, 0x156614u, 0x15661Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15661Cu;
label_15661c:
    // 0x15661c: 0x1000002f  b           . + 4 + (0x2F << 2)
    ctx->pc = 0x15661Cu;
    {
        const bool branch_taken_0x15661c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156620u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15661Cu;
        // 0x156620: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15661c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156624u;
label_156624:
    // 0x156624: 0xc051fde  jal         func_147F78
    ctx->pc = 0x156624u;
    SET_GPR_U32(ctx, 31, 0x15662Cu);
    ctx->pc = 0x147F78u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x147F78u, 0x156624u, 0x15662Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15662Cu;
label_15662c:
    // 0x15662c: 0x1000002b  b           . + 4 + (0x2B << 2)
    ctx->pc = 0x15662Cu;
    {
        const bool branch_taken_0x15662c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156630u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15662Cu;
        // 0x156630: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15662c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156634u;
label_156634:
    // 0x156634: 0xc053c94  jal         func_14F250
    ctx->pc = 0x156634u;
    SET_GPR_U32(ctx, 31, 0x15663Cu);
    ctx->pc = 0x14F250u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x14F250u, 0x156634u, 0x15663Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15663Cu;
label_15663c:
    // 0x15663c: 0x10000027  b           . + 4 + (0x27 << 2)
    ctx->pc = 0x15663Cu;
    {
        const bool branch_taken_0x15663c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156640u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15663Cu;
        // 0x156640: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15663c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156644u;
label_156644:
    // 0x156644: 0xc05498e  jal         func_152638
    ctx->pc = 0x156644u;
    SET_GPR_U32(ctx, 31, 0x15664Cu);
    ctx->pc = 0x152638u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x152638u, 0x156644u, 0x15664Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15664Cu;
label_15664c:
    // 0x15664c: 0x10000023  b           . + 4 + (0x23 << 2)
    ctx->pc = 0x15664Cu;
    {
        const bool branch_taken_0x15664c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156650u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15664Cu;
        // 0x156650: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15664c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156654u;
label_156654:
    // 0x156654: 0xc053838  jal         func_14E0E0
    ctx->pc = 0x156654u;
    SET_GPR_U32(ctx, 31, 0x15665Cu);
    ctx->pc = 0x14E0E0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x14E0E0u, 0x156654u, 0x15665Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15665Cu;
label_15665c:
    // 0x15665c: 0x1000001f  b           . + 4 + (0x1F << 2)
    ctx->pc = 0x15665Cu;
    {
        const bool branch_taken_0x15665c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156660u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15665Cu;
        // 0x156660: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15665c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156664u;
label_156664:
    // 0x156664: 0xc055252  jal         func_154948
    ctx->pc = 0x156664u;
    SET_GPR_U32(ctx, 31, 0x15666Cu);
    ctx->pc = 0x154948u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x154948u, 0x156664u, 0x15666Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15666Cu;
label_15666c:
    // 0x15666c: 0x1000001b  b           . + 4 + (0x1B << 2)
    ctx->pc = 0x15666Cu;
    {
        const bool branch_taken_0x15666c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156670u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15666Cu;
        // 0x156670: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15666c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156674u;
label_156674:
    // 0x156674: 0xc052af8  jal         func_14ABE0
    ctx->pc = 0x156674u;
    SET_GPR_U32(ctx, 31, 0x15667Cu);
    ctx->pc = 0x14ABE0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x14ABE0u, 0x156674u, 0x15667Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15667Cu;
label_15667c:
    // 0x15667c: 0x10000017  b           . + 4 + (0x17 << 2)
    ctx->pc = 0x15667Cu;
    {
        const bool branch_taken_0x15667c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156680u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15667Cu;
        // 0x156680: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15667c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156684u;
label_156684:
    // 0x156684: 0xc053e40  jal         func_14F900
    ctx->pc = 0x156684u;
    SET_GPR_U32(ctx, 31, 0x15668Cu);
    ctx->pc = 0x14F900u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x14F900u, 0x156684u, 0x15668Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15668Cu;
label_15668c:
    // 0x15668c: 0x10000013  b           . + 4 + (0x13 << 2)
    ctx->pc = 0x15668Cu;
    {
        const bool branch_taken_0x15668c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x156690u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15668Cu;
        // 0x156690: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15668c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x156694u;
label_156694:
    // 0x156694: 0xc054236  jal         func_1508D8
    ctx->pc = 0x156694u;
    SET_GPR_U32(ctx, 31, 0x15669Cu);
    ctx->pc = 0x1508D8u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x1508D8u, 0x156694u, 0x15669Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x15669Cu;
label_15669c:
    // 0x15669c: 0x1000000f  b           . + 4 + (0xF << 2)
    ctx->pc = 0x15669Cu;
    {
        const bool branch_taken_0x15669c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x1566A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x15669Cu;
        // 0x1566a0: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x15669c) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x1566A4u;
label_1566a4:
    // 0x1566a4: 0xc054ca8  jal         func_1532A0
    ctx->pc = 0x1566A4u;
    SET_GPR_U32(ctx, 31, 0x1566ACu);
    ctx->pc = 0x1532A0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x1532A0u, 0x1566A4u, 0x1566ACu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x1566ACu;
label_1566ac:
    // 0x1566ac: 0x1000000b  b           . + 4 + (0xB << 2)
    ctx->pc = 0x1566ACu;
    {
        const bool branch_taken_0x1566ac = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x1566B0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x1566ACu;
        // 0x1566b0: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x1566ac) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x1566B4u;
label_1566b4:
    // 0x1566b4: 0xc055694  jal         func_155A50
    ctx->pc = 0x1566B4u;
    SET_GPR_U32(ctx, 31, 0x1566BCu);
    ctx->pc = 0x155A50u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x155A50u, 0x1566B4u, 0x1566BCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x1566BCu;
label_1566bc:
    // 0x1566bc: 0x10000007  b           . + 4 + (0x7 << 2)
    ctx->pc = 0x1566BCu;
    {
        const bool branch_taken_0x1566bc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x1566C0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x1566BCu;
        // 0x1566c0: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x1566bc) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x1566C4u;
label_1566c4:
    // 0x1566c4: 0xc055a70  jal         func_1569C0
    ctx->pc = 0x1566C4u;
    SET_GPR_U32(ctx, 31, 0x1566CCu);
    ctx->pc = 0x1569C0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x1569C0u, 0x1566C4u, 0x1566CCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x1566CCu;
label_1566cc:
    // 0x1566cc: 0x10000003  b           . + 4 + (0x3 << 2)
    ctx->pc = 0x1566CCu;
    {
        const bool branch_taken_0x1566cc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x1566D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x1566CCu;
        // 0x1566d0: 0xdfbf0000  ld          $ra, 0x0($sp) (Delay Slot)
        SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x1566cc) {
            ctx->pc = 0x1566DCu;
            goto label_1566dc;
        }
    }
    ctx->pc = 0x1566D4u;
label_1566d4:
    // 0x1566d4: 0x102d  daddu       $v0, $zero, $zero
    ctx->pc = 0x1566d4u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
    // 0x1566d8: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x1566d8u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_1566dc:
    // 0x1566dc: 0x3e00008  jr          $ra
    ctx->pc = 0x1566DCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x1566E0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x1566DCu;
        // 0x1566e0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x1566DCu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x1566E4u;
    // 0x1566e4: 0x0  nop
    ctx->pc = 0x1566e4u;
    // NOP
    // 0x1566e8: 0x8f82e0c4  lw          $v0, -0x1F3C($gp)
    ctx->pc = 0x1566e8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959300)));
    // 0x1566ec: 0x8f83e0d0  lw          $v1, -0x1F30($gp)
    ctx->pc = 0x1566ecu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959312)));
    // 0x1566f0: 0xac400008  sw          $zero, 0x8($v0)
    ctx->pc = 0x1566f0u;
    WRITE32(ADD32(GPR_U32(ctx, 2), 8), GPR_U32(ctx, 0));
    // 0x1566f4: 0x8f84e118  lw          $a0, -0x1EE8($gp)
    ctx->pc = 0x1566f4u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959384)));
    // 0x1566f8: 0xac600008  sw          $zero, 0x8($v1)
    ctx->pc = 0x1566f8u;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 0));
    // 0x1566fc: 0x8f82e0d4  lw          $v0, -0x1F2C($gp)
    ctx->pc = 0x1566fcu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959316)));
    // 0x156700: 0xac800008  sw          $zero, 0x8($a0)
    ctx->pc = 0x156700u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 0));
    // 0x156704: 0x8f83e11c  lw          $v1, -0x1EE4($gp)
    ctx->pc = 0x156704u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959388)));
    // 0x156708: 0xac400008  sw          $zero, 0x8($v0)
    ctx->pc = 0x156708u;
    WRITE32(ADD32(GPR_U32(ctx, 2), 8), GPR_U32(ctx, 0));
    // 0x15670c: 0x8f84e12c  lw          $a0, -0x1ED4($gp)
    ctx->pc = 0x15670cu;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959404)));
    // 0x156710: 0xac600008  sw          $zero, 0x8($v1)
    ctx->pc = 0x156710u;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 0));
    // 0x156714: 0x8f82e114  lw          $v0, -0x1EEC($gp)
    ctx->pc = 0x156714u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959380)));
    // 0x156718: 0xac800008  sw          $zero, 0x8($a0)
    ctx->pc = 0x156718u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 0));
    // 0x15671c: 0x8f83e0d8  lw          $v1, -0x1F28($gp)
    ctx->pc = 0x15671cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959320)));
    // 0x156720: 0xac400008  sw          $zero, 0x8($v0)
    ctx->pc = 0x156720u;
    WRITE32(ADD32(GPR_U32(ctx, 2), 8), GPR_U32(ctx, 0));
    // 0x156724: 0x8f84e120  lw          $a0, -0x1EE0($gp)
    ctx->pc = 0x156724u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959392)));
    // 0x156728: 0xac600008  sw          $zero, 0x8($v1)
    ctx->pc = 0x156728u;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 0));
    // 0x15672c: 0x8f85e124  lw          $a1, -0x1EDC($gp)
    ctx->pc = 0x15672cu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959396)));
    // 0x156730: 0xac800008  sw          $zero, 0x8($a0)
    ctx->pc = 0x156730u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 0));
    // 0x156734: 0x8f83e15c  lw          $v1, -0x1EA4($gp)
    ctx->pc = 0x156734u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959452)));
    // 0x156738: 0xaca00008  sw          $zero, 0x8($a1)
    ctx->pc = 0x156738u;
    WRITE32(ADD32(GPR_U32(ctx, 5), 8), GPR_U32(ctx, 0));
    // 0x15673c: 0x8f82e174  lw          $v0, -0x1E8C($gp)
    ctx->pc = 0x15673cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959476)));
    // 0x156740: 0xac600008  sw          $zero, 0x8($v1)
    ctx->pc = 0x156740u;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 0));
    // 0x156744: 0x3e00008  jr          $ra
    ctx->pc = 0x156744u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x156748u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x156744u;
        // 0x156748: 0xac400008  sw          $zero, 0x8($v0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 2), 8), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x156744u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x15674Cu;
    // 0x15674c: 0x0  nop
    ctx->pc = 0x15674cu;
    // NOP
    // 0x156750: 0x8f83e0c4  lw          $v1, -0x1F3C($gp)
    ctx->pc = 0x156750u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959300)));
    // 0x156754: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x156754u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
    // 0x156758: 0x8f84e0d0  lw          $a0, -0x1F30($gp)
    ctx->pc = 0x156758u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959312)));
    // 0x15675c: 0xac620008  sw          $v0, 0x8($v1)
    ctx->pc = 0x15675cu;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 2));
    // 0x156760: 0x8f85e118  lw          $a1, -0x1EE8($gp)
    ctx->pc = 0x156760u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959384)));
    // 0x156764: 0xac820008  sw          $v0, 0x8($a0)
    ctx->pc = 0x156764u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 2));
    // 0x156768: 0x8f83e0d4  lw          $v1, -0x1F2C($gp)
    ctx->pc = 0x156768u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959316)));
    // 0x15676c: 0xaca20008  sw          $v0, 0x8($a1)
    ctx->pc = 0x15676cu;
    WRITE32(ADD32(GPR_U32(ctx, 5), 8), GPR_U32(ctx, 2));
    // 0x156770: 0x8f84e11c  lw          $a0, -0x1EE4($gp)
    ctx->pc = 0x156770u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959388)));
    // 0x156774: 0xac620008  sw          $v0, 0x8($v1)
    ctx->pc = 0x156774u;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 2));
    // 0x156778: 0x8f85e12c  lw          $a1, -0x1ED4($gp)
    ctx->pc = 0x156778u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959404)));
    // 0x15677c: 0xac820008  sw          $v0, 0x8($a0)
    ctx->pc = 0x15677cu;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 2));
    // 0x156780: 0x8f83e114  lw          $v1, -0x1EEC($gp)
    ctx->pc = 0x156780u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959380)));
    // 0x156784: 0xaca20008  sw          $v0, 0x8($a1)
    ctx->pc = 0x156784u;
    WRITE32(ADD32(GPR_U32(ctx, 5), 8), GPR_U32(ctx, 2));
    // 0x156788: 0x8f84e0d8  lw          $a0, -0x1F28($gp)
    ctx->pc = 0x156788u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959320)));
    // 0x15678c: 0xac620008  sw          $v0, 0x8($v1)
    ctx->pc = 0x15678cu;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 2));
    // 0x156790: 0x8f85e120  lw          $a1, -0x1EE0($gp)
    ctx->pc = 0x156790u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959392)));
    // 0x156794: 0xac820008  sw          $v0, 0x8($a0)
    ctx->pc = 0x156794u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 2));
    // 0x156798: 0x8f86e124  lw          $a2, -0x1EDC($gp)
    ctx->pc = 0x156798u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959396)));
    // 0x15679c: 0xaca20008  sw          $v0, 0x8($a1)
    ctx->pc = 0x15679cu;
    WRITE32(ADD32(GPR_U32(ctx, 5), 8), GPR_U32(ctx, 2));
    // 0x1567a0: 0x8f84e15c  lw          $a0, -0x1EA4($gp)
    ctx->pc = 0x1567a0u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959452)));
    // 0x1567a4: 0xacc20008  sw          $v0, 0x8($a2)
    ctx->pc = 0x1567a4u;
    WRITE32(ADD32(GPR_U32(ctx, 6), 8), GPR_U32(ctx, 2));
    // 0x1567a8: 0x8f83e174  lw          $v1, -0x1E8C($gp)
    ctx->pc = 0x1567a8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959476)));
    // 0x1567ac: 0xac820008  sw          $v0, 0x8($a0)
    ctx->pc = 0x1567acu;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 2));
    // 0x1567b0: 0x3e00008  jr          $ra
    ctx->pc = 0x1567B0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x1567B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x1567B0u;
        // 0x1567b4: 0xac620008  sw          $v0, 0x8($v1) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x1567B0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x1567B8u;
}
