#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_0014F250
// Address: 0x14f250 - 0x14f418
void sub_0014F250_0x14f250(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_0014F250_0x14f250");
#endif

    switch (ctx->pc) {
        case 0x14f278u: goto label_14f278;
        case 0x14f294u: goto label_14f294;
        case 0x14f2c8u: goto label_14f2c8;
        case 0x14f31cu: goto label_14f31c;
        case 0x14f380u: goto label_14f380;
        case 0x14f3d4u: goto label_14f3d4;
        default: break;
    }

    ctx->pc = 0x14f250u;

    // 0x14f250: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x14f250u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
    // 0x14f254: 0x8f82e11c  lw          $v0, -0x1EE4($gp)
    ctx->pc = 0x14f254u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959388)));
    // 0x14f258: 0x1440000e  bnez        $v0, . + 4 + (0xE << 2)
    ctx->pc = 0x14F258u;
    {
        const bool branch_taken_0x14f258 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x14F25Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F258u;
        // 0x14f25c: 0xffbf0000  sd          $ra, 0x0($sp) (Delay Slot)
        WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
        ctx->in_delay_slot = false;
        if (branch_taken_0x14f258) {
            ctx->pc = 0x14F294u;
            goto label_14f294;
        }
    }
    ctx->pc = 0x14F260u;
    // 0x14f260: 0x3c050046  lui         $a1, 0x46
    ctx->pc = 0x14f260u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)70 << 16));
    // 0x14f264: 0x24040010  addiu       $a0, $zero, 0x10
    ctx->pc = 0x14f264u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 0), 16));
    // 0x14f268: 0x24a5a6b0  addiu       $a1, $a1, -0x5950
    ctx->pc = 0x14f268u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 4294944432));
    // 0x14f26c: 0x302d  daddu       $a2, $zero, $zero
    ctx->pc = 0x14f26cu;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
    // 0x14f270: 0xc0c5f5c  jal         func_317D70
    ctx->pc = 0x14F270u;
    SET_GPR_U32(ctx, 31, 0x14F278u);
    ctx->pc = 0x14F274u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x14F270u;
    // 0x14f274: 0x382d  daddu       $a3, $zero, $zero (Delay Slot)
    SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x317D70u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x317D70u, 0x14F270u, 0x14F278u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x14F278u;
label_14f278:
    // 0x14f278: 0x3c030046  lui         $v1, 0x46
    ctx->pc = 0x14f278u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)70 << 16));
    // 0x14f27c: 0x40202d  daddu       $a0, $v0, $zero
    ctx->pc = 0x14f27cu;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
    // 0x14f280: 0x2463adc8  addiu       $v1, $v1, -0x5238
    ctx->pc = 0x14f280u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 4294946248));
    // 0x14f284: 0xac43000c  sw          $v1, 0xC($v0)
    ctx->pc = 0x14f284u;
    WRITE32(ADD32(GPR_U32(ctx, 2), 12), GPR_U32(ctx, 3));
    // 0x14f288: 0xaf82e11c  sw          $v0, -0x1EE4($gp)
    ctx->pc = 0x14f288u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 4294959388), GPR_U32(ctx, 2));
    // 0x14f28c: 0xc053d06  jal         func_14F418
    ctx->pc = 0x14F28Cu;
    SET_GPR_U32(ctx, 31, 0x14F294u);
    ctx->pc = 0x14F290u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x14F28Cu;
    // 0x14f290: 0xac400008  sw          $zero, 0x8($v0) (Delay Slot)
    WRITE32(ADD32(GPR_U32(ctx, 2), 8), GPR_U32(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x14F418u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x14F418u, 0x14F28Cu, 0x14F294u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x14F294u;
label_14f294:
    // 0x14f294: 0x8f82e11c  lw          $v0, -0x1EE4($gp)
    ctx->pc = 0x14f294u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959388)));
    // 0x14f298: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x14f298u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
    // 0x14f29c: 0x3e00008  jr          $ra
    ctx->pc = 0x14F29Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x14F2A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F29Cu;
        // 0x14f2a0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x14F29Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x14F2A4u;
    // 0x14f2a4: 0x0  nop
    ctx->pc = 0x14f2a4u;
    // NOP
    // 0x14f2a8: 0x3c020053  lui         $v0, 0x53
    ctx->pc = 0x14f2a8u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)83 << 16));
    // 0x14f2ac: 0x3c030053  lui         $v1, 0x53
    ctx->pc = 0x14f2acu;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)83 << 16));
    // 0x14f2b0: 0x24445898  addiu       $a0, $v0, 0x5898
    ctx->pc = 0x14f2b0u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 2), 22680));
    // 0x14f2b4: 0x24635610  addiu       $v1, $v1, 0x5610
    ctx->pc = 0x14f2b4u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 22032));
    // 0x14f2b8: 0x641025  or          $v0, $v1, $a0
    ctx->pc = 0x14f2b8u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 3) | GPR_U64(ctx, 4));
    // 0x14f2bc: 0x30420007  andi        $v0, $v0, 0x7
    ctx->pc = 0x14f2bcu;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)7);
    // 0x14f2c0: 0x10400016  beqz        $v0, . + 4 + (0x16 << 2)
    ctx->pc = 0x14F2C0u;
    {
        const bool branch_taken_0x14f2c0 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x14F2C4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F2C0u;
        // 0x14f2c4: 0x24620280  addiu       $v0, $v1, 0x280 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 3), 640));
        ctx->in_delay_slot = false;
        if (branch_taken_0x14f2c0) {
            ctx->pc = 0x14F31Cu;
            goto label_14f31c;
        }
    }
    ctx->pc = 0x14F2C8u;
label_14f2c8:
    // 0x14f2c8: 0x68650007  ldl         $a1, 0x7($v1)
    ctx->pc = 0x14f2c8u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 7); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 5, (GPR_U64(ctx, 5) & keepMask) | (mem << shift)); }
    // 0x14f2cc: 0x6c650000  ldr         $a1, 0x0($v1)
    ctx->pc = 0x14f2ccu;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 0); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 5, (GPR_U64(ctx, 5) & keepMask) | (mem >> shift)); }
    // 0x14f2d0: 0x6866000f  ldl         $a2, 0xF($v1)
    ctx->pc = 0x14f2d0u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 15); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 6, (GPR_U64(ctx, 6) & keepMask) | (mem << shift)); }
    // 0x14f2d4: 0x6c660008  ldr         $a2, 0x8($v1)
    ctx->pc = 0x14f2d4u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 8); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 6, (GPR_U64(ctx, 6) & keepMask) | (mem >> shift)); }
    // 0x14f2d8: 0x68670017  ldl         $a3, 0x17($v1)
    ctx->pc = 0x14f2d8u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 23); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 7, (GPR_U64(ctx, 7) & keepMask) | (mem << shift)); }
    // 0x14f2dc: 0x6c670010  ldr         $a3, 0x10($v1)
    ctx->pc = 0x14f2dcu;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 16); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 7, (GPR_U64(ctx, 7) & keepMask) | (mem >> shift)); }
    // 0x14f2e0: 0x6868001f  ldl         $t0, 0x1F($v1)
    ctx->pc = 0x14f2e0u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 31); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 8, (GPR_U64(ctx, 8) & keepMask) | (mem << shift)); }
    // 0x14f2e4: 0x6c680018  ldr         $t0, 0x18($v1)
    ctx->pc = 0x14f2e4u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 24); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 8, (GPR_U64(ctx, 8) & keepMask) | (mem >> shift)); }
    // 0x14f2e8: 0xb0850007  sdl         $a1, 0x7($a0)
    ctx->pc = 0x14f2e8u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 7); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 5); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f2ec: 0xb4850000  sdr         $a1, 0x0($a0)
    ctx->pc = 0x14f2ecu;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 0); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 5); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f2f0: 0xb086000f  sdl         $a2, 0xF($a0)
    ctx->pc = 0x14f2f0u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 15); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 6); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f2f4: 0xb4860008  sdr         $a2, 0x8($a0)
    ctx->pc = 0x14f2f4u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 8); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 6); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f2f8: 0xb0870017  sdl         $a3, 0x17($a0)
    ctx->pc = 0x14f2f8u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 23); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 7); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f2fc: 0xb4870010  sdr         $a3, 0x10($a0)
    ctx->pc = 0x14f2fcu;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 16); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 7); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f300: 0xb088001f  sdl         $t0, 0x1F($a0)
    ctx->pc = 0x14f300u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 31); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 8); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f304: 0xb4880018  sdr         $t0, 0x18($a0)
    ctx->pc = 0x14f304u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 24); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 8); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f308: 0x24630020  addiu       $v1, $v1, 0x20
    ctx->pc = 0x14f308u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 32));
    // 0x14f30c: 0x1462ffee  bne         $v1, $v0, . + 4 + (-0x12 << 2)
    ctx->pc = 0x14F30Cu;
    {
        const bool branch_taken_0x14f30c = (GPR_U64(ctx, 3) != GPR_U64(ctx, 2));
        ctx->pc = 0x14F310u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F30Cu;
        // 0x14f310: 0x24840020  addiu       $a0, $a0, 0x20 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 32));
        ctx->in_delay_slot = false;
        if (branch_taken_0x14f30c) {
            ctx->pc = 0x14F2C8u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_14f2c8;
        }
    }
    ctx->pc = 0x14F314u;
    // 0x14f314: 0x1000000c  b           . + 4 + (0xC << 2)
    ctx->pc = 0x14F314u;
    {
        const bool branch_taken_0x14f314 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        if (branch_taken_0x14f314) {
            ctx->pc = 0x14F348u;
            goto label_14f348;
        }
    }
    ctx->pc = 0x14F31Cu;
label_14f31c:
    // 0x14f31c: 0xdc650000  ld          $a1, 0x0($v1)
    ctx->pc = 0x14f31cu;
    SET_GPR_U64(ctx, 5, READ64(ADD32(GPR_U32(ctx, 3), 0)));
    // 0x14f320: 0xdc660008  ld          $a2, 0x8($v1)
    ctx->pc = 0x14f320u;
    SET_GPR_U64(ctx, 6, READ64(ADD32(GPR_U32(ctx, 3), 8)));
    // 0x14f324: 0xdc670010  ld          $a3, 0x10($v1)
    ctx->pc = 0x14f324u;
    SET_GPR_U64(ctx, 7, READ64(ADD32(GPR_U32(ctx, 3), 16)));
    // 0x14f328: 0xdc680018  ld          $t0, 0x18($v1)
    ctx->pc = 0x14f328u;
    SET_GPR_U64(ctx, 8, READ64(ADD32(GPR_U32(ctx, 3), 24)));
    // 0x14f32c: 0xfc850000  sd          $a1, 0x0($a0)
    ctx->pc = 0x14f32cu;
    WRITE64(ADD32(GPR_U32(ctx, 4), 0), GPR_U64(ctx, 5));
    // 0x14f330: 0xfc860008  sd          $a2, 0x8($a0)
    ctx->pc = 0x14f330u;
    WRITE64(ADD32(GPR_U32(ctx, 4), 8), GPR_U64(ctx, 6));
    // 0x14f334: 0xfc870010  sd          $a3, 0x10($a0)
    ctx->pc = 0x14f334u;
    WRITE64(ADD32(GPR_U32(ctx, 4), 16), GPR_U64(ctx, 7));
    // 0x14f338: 0xfc880018  sd          $t0, 0x18($a0)
    ctx->pc = 0x14f338u;
    WRITE64(ADD32(GPR_U32(ctx, 4), 24), GPR_U64(ctx, 8));
    // 0x14f33c: 0x24630020  addiu       $v1, $v1, 0x20
    ctx->pc = 0x14f33cu;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 32));
    // 0x14f340: 0x1462fff6  bne         $v1, $v0, . + 4 + (-0xA << 2)
    ctx->pc = 0x14F340u;
    {
        const bool branch_taken_0x14f340 = (GPR_U64(ctx, 3) != GPR_U64(ctx, 2));
        ctx->pc = 0x14F344u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F340u;
        // 0x14f344: 0x24840020  addiu       $a0, $a0, 0x20 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 32));
        ctx->in_delay_slot = false;
        if (branch_taken_0x14f340) {
            ctx->pc = 0x14F31Cu;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_14f31c;
        }
    }
    ctx->pc = 0x14F348u;
label_14f348:
    // 0x14f348: 0x68620007  ldl         $v0, 0x7($v1)
    ctx->pc = 0x14f348u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 7); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 2, (GPR_U64(ctx, 2) & keepMask) | (mem << shift)); }
    // 0x14f34c: 0x6c620000  ldr         $v0, 0x0($v1)
    ctx->pc = 0x14f34cu;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 0); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 2, (GPR_U64(ctx, 2) & keepMask) | (mem >> shift)); }
    // 0x14f350: 0xb0820007  sdl         $v0, 0x7($a0)
    ctx->pc = 0x14f350u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 7); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 2); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f354: 0x3e00008  jr          $ra
    ctx->pc = 0x14F354u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x14F358u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F354u;
        // 0x14f358: 0xb4820000  sdr         $v0, 0x0($a0) (Delay Slot)
        { uint32_t addr = ADD32(GPR_U32(ctx, 4), 0); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 2); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x14F354u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x14F35Cu;
    // 0x14f35c: 0x0  nop
    ctx->pc = 0x14f35cu;
    // NOP
    // 0x14f360: 0x3c020053  lui         $v0, 0x53
    ctx->pc = 0x14f360u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)83 << 16));
    // 0x14f364: 0x3c030053  lui         $v1, 0x53
    ctx->pc = 0x14f364u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)83 << 16));
    // 0x14f368: 0x24445610  addiu       $a0, $v0, 0x5610
    ctx->pc = 0x14f368u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 2), 22032));
    // 0x14f36c: 0x24635898  addiu       $v1, $v1, 0x5898
    ctx->pc = 0x14f36cu;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 22680));
    // 0x14f370: 0x641025  or          $v0, $v1, $a0
    ctx->pc = 0x14f370u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 3) | GPR_U64(ctx, 4));
    // 0x14f374: 0x30420007  andi        $v0, $v0, 0x7
    ctx->pc = 0x14f374u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)7);
    // 0x14f378: 0x10400016  beqz        $v0, . + 4 + (0x16 << 2)
    ctx->pc = 0x14F378u;
    {
        const bool branch_taken_0x14f378 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x14F37Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F378u;
        // 0x14f37c: 0x24620280  addiu       $v0, $v1, 0x280 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 3), 640));
        ctx->in_delay_slot = false;
        if (branch_taken_0x14f378) {
            ctx->pc = 0x14F3D4u;
            goto label_14f3d4;
        }
    }
    ctx->pc = 0x14F380u;
label_14f380:
    // 0x14f380: 0x68650007  ldl         $a1, 0x7($v1)
    ctx->pc = 0x14f380u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 7); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 5, (GPR_U64(ctx, 5) & keepMask) | (mem << shift)); }
    // 0x14f384: 0x6c650000  ldr         $a1, 0x0($v1)
    ctx->pc = 0x14f384u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 0); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 5, (GPR_U64(ctx, 5) & keepMask) | (mem >> shift)); }
    // 0x14f388: 0x6866000f  ldl         $a2, 0xF($v1)
    ctx->pc = 0x14f388u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 15); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 6, (GPR_U64(ctx, 6) & keepMask) | (mem << shift)); }
    // 0x14f38c: 0x6c660008  ldr         $a2, 0x8($v1)
    ctx->pc = 0x14f38cu;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 8); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 6, (GPR_U64(ctx, 6) & keepMask) | (mem >> shift)); }
    // 0x14f390: 0x68670017  ldl         $a3, 0x17($v1)
    ctx->pc = 0x14f390u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 23); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 7, (GPR_U64(ctx, 7) & keepMask) | (mem << shift)); }
    // 0x14f394: 0x6c670010  ldr         $a3, 0x10($v1)
    ctx->pc = 0x14f394u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 16); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 7, (GPR_U64(ctx, 7) & keepMask) | (mem >> shift)); }
    // 0x14f398: 0x6868001f  ldl         $t0, 0x1F($v1)
    ctx->pc = 0x14f398u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 31); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 8, (GPR_U64(ctx, 8) & keepMask) | (mem << shift)); }
    // 0x14f39c: 0x6c680018  ldr         $t0, 0x18($v1)
    ctx->pc = 0x14f39cu;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 24); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 8, (GPR_U64(ctx, 8) & keepMask) | (mem >> shift)); }
    // 0x14f3a0: 0xb0850007  sdl         $a1, 0x7($a0)
    ctx->pc = 0x14f3a0u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 7); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 5); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f3a4: 0xb4850000  sdr         $a1, 0x0($a0)
    ctx->pc = 0x14f3a4u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 0); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 5); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f3a8: 0xb086000f  sdl         $a2, 0xF($a0)
    ctx->pc = 0x14f3a8u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 15); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 6); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f3ac: 0xb4860008  sdr         $a2, 0x8($a0)
    ctx->pc = 0x14f3acu;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 8); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 6); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f3b0: 0xb0870017  sdl         $a3, 0x17($a0)
    ctx->pc = 0x14f3b0u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 23); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 7); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f3b4: 0xb4870010  sdr         $a3, 0x10($a0)
    ctx->pc = 0x14f3b4u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 16); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 7); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f3b8: 0xb088001f  sdl         $t0, 0x1F($a0)
    ctx->pc = 0x14f3b8u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 31); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 8); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f3bc: 0xb4880018  sdr         $t0, 0x18($a0)
    ctx->pc = 0x14f3bcu;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 24); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 8); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f3c0: 0x24630020  addiu       $v1, $v1, 0x20
    ctx->pc = 0x14f3c0u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 32));
    // 0x14f3c4: 0x1462ffee  bne         $v1, $v0, . + 4 + (-0x12 << 2)
    ctx->pc = 0x14F3C4u;
    {
        const bool branch_taken_0x14f3c4 = (GPR_U64(ctx, 3) != GPR_U64(ctx, 2));
        ctx->pc = 0x14F3C8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F3C4u;
        // 0x14f3c8: 0x24840020  addiu       $a0, $a0, 0x20 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 32));
        ctx->in_delay_slot = false;
        if (branch_taken_0x14f3c4) {
            ctx->pc = 0x14F380u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_14f380;
        }
    }
    ctx->pc = 0x14F3CCu;
    // 0x14f3cc: 0x1000000c  b           . + 4 + (0xC << 2)
    ctx->pc = 0x14F3CCu;
    {
        const bool branch_taken_0x14f3cc = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        if (branch_taken_0x14f3cc) {
            ctx->pc = 0x14F400u;
            goto label_14f400;
        }
    }
    ctx->pc = 0x14F3D4u;
label_14f3d4:
    // 0x14f3d4: 0xdc650000  ld          $a1, 0x0($v1)
    ctx->pc = 0x14f3d4u;
    SET_GPR_U64(ctx, 5, READ64(ADD32(GPR_U32(ctx, 3), 0)));
    // 0x14f3d8: 0xdc660008  ld          $a2, 0x8($v1)
    ctx->pc = 0x14f3d8u;
    SET_GPR_U64(ctx, 6, READ64(ADD32(GPR_U32(ctx, 3), 8)));
    // 0x14f3dc: 0xdc670010  ld          $a3, 0x10($v1)
    ctx->pc = 0x14f3dcu;
    SET_GPR_U64(ctx, 7, READ64(ADD32(GPR_U32(ctx, 3), 16)));
    // 0x14f3e0: 0xdc680018  ld          $t0, 0x18($v1)
    ctx->pc = 0x14f3e0u;
    SET_GPR_U64(ctx, 8, READ64(ADD32(GPR_U32(ctx, 3), 24)));
    // 0x14f3e4: 0xfc850000  sd          $a1, 0x0($a0)
    ctx->pc = 0x14f3e4u;
    WRITE64(ADD32(GPR_U32(ctx, 4), 0), GPR_U64(ctx, 5));
    // 0x14f3e8: 0xfc860008  sd          $a2, 0x8($a0)
    ctx->pc = 0x14f3e8u;
    WRITE64(ADD32(GPR_U32(ctx, 4), 8), GPR_U64(ctx, 6));
    // 0x14f3ec: 0xfc870010  sd          $a3, 0x10($a0)
    ctx->pc = 0x14f3ecu;
    WRITE64(ADD32(GPR_U32(ctx, 4), 16), GPR_U64(ctx, 7));
    // 0x14f3f0: 0xfc880018  sd          $t0, 0x18($a0)
    ctx->pc = 0x14f3f0u;
    WRITE64(ADD32(GPR_U32(ctx, 4), 24), GPR_U64(ctx, 8));
    // 0x14f3f4: 0x24630020  addiu       $v1, $v1, 0x20
    ctx->pc = 0x14f3f4u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 32));
    // 0x14f3f8: 0x1462fff6  bne         $v1, $v0, . + 4 + (-0xA << 2)
    ctx->pc = 0x14F3F8u;
    {
        const bool branch_taken_0x14f3f8 = (GPR_U64(ctx, 3) != GPR_U64(ctx, 2));
        ctx->pc = 0x14F3FCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F3F8u;
        // 0x14f3fc: 0x24840020  addiu       $a0, $a0, 0x20 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 32));
        ctx->in_delay_slot = false;
        if (branch_taken_0x14f3f8) {
            ctx->pc = 0x14F3D4u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_14f3d4;
        }
    }
    ctx->pc = 0x14F400u;
label_14f400:
    // 0x14f400: 0x68620007  ldl         $v0, 0x7($v1)
    ctx->pc = 0x14f400u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 7); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = (7u - offset) << 3; uint64_t keepMask = (shift == 0) ? 0ull : ((1ull << shift) - 1ull); SET_GPR_U64(ctx, 2, (GPR_U64(ctx, 2) & keepMask) | (mem << shift)); }
    // 0x14f404: 0x6c620000  ldr         $v0, 0x0($v1)
    ctx->pc = 0x14f404u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 3), 0); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint64_t mem = READ64(aligned_addr); uint32_t shift = offset << 3; uint64_t keepMask = (offset == 0) ? 0ull : (0xFFFFFFFFFFFFFFFFull << ((8u - offset) << 3)); SET_GPR_U64(ctx, 2, (GPR_U64(ctx, 2) & keepMask) | (mem >> shift)); }
    // 0x14f408: 0xb0820007  sdl         $v0, 0x7($a0)
    ctx->pc = 0x14f408u;
    { uint32_t addr = ADD32(GPR_U32(ctx, 4), 7); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = (7u - offset) << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull >> shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 2); uint64_t new_data = (old_data & ~mask) | ((val >> shift) & mask); WRITE64(aligned_addr, new_data); }
    // 0x14f40c: 0x3e00008  jr          $ra
    ctx->pc = 0x14F40Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x14F410u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x14F40Cu;
        // 0x14f410: 0xb4820000  sdr         $v0, 0x0($a0) (Delay Slot)
        { uint32_t addr = ADD32(GPR_U32(ctx, 4), 0); uint32_t aligned_addr = addr & ~7u; uint32_t offset = addr & 7u; uint32_t shift = offset << 3; uint64_t mask = 0xFFFFFFFFFFFFFFFFull << shift; uint64_t old_data = READ64(aligned_addr); uint64_t val = GPR_U64(ctx, 2); uint64_t new_data = (old_data & ~mask) | ((val << shift) & mask); WRITE64(aligned_addr, new_data); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x14F40Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x14F414u;
    // 0x14f414: 0x0  nop
    ctx->pc = 0x14f414u;
    // NOP
    ctx->pc = 0x14f418u;
}
