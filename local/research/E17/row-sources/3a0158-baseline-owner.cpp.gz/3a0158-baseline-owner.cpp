#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_003A0048
// Address: 0x3a0048 - 0x3a0290
void sub_003A0048_0x3a0048(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_003A0048_0x3a0048");
#endif

    switch (ctx->pc) {
        case 0x3a0168u: goto label_3a0168;
        default: break;
    }

    ctx->pc = 0x3a0048u;

    // 0x3a0048: 0x30a3ffff  andi        $v1, $a1, 0xFFFF
    ctx->pc = 0x3a0048u;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 5) & (uint64_t)(uint16_t)65535);
    // 0x3a004c: 0x2c620011  sltiu       $v0, $v1, 0x11
    ctx->pc = 0x3a004cu;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 3) < (uint64_t)(int64_t)(int32_t)17) ? 1 : 0);
    // 0x3a0050: 0x1040003e  beqz        $v0, . + 4 + (0x3E << 2)
    ctx->pc = 0x3A0050u;
    {
        const bool branch_taken_0x3a0050 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A0054u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0050u;
        // 0x3a0054: 0x80302d  daddu       $a2, $a0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a0050) {
            ctx->pc = 0x3A014Cu;
            goto label_3a014c;
        }
    }
    ctx->pc = 0x3A0058u;
    // 0x3a0058: 0x3c020049  lui         $v0, 0x49
    ctx->pc = 0x3a0058u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)73 << 16));
    // 0x3a005c: 0x31880  sll         $v1, $v1, 2
    ctx->pc = 0x3a005cu;
    SET_GPR_S32(ctx, 3, (int32_t)SLL32(GPR_U32(ctx, 3), 2));
    // 0x3a0060: 0x24423fe0  addiu       $v0, $v0, 0x3FE0
    ctx->pc = 0x3a0060u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 16352));
    // 0x3a0064: 0x621821  addu        $v1, $v1, $v0
    ctx->pc = 0x3a0064u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), GPR_U32(ctx, 2)));
    // 0x3a0068: 0x8c640000  lw          $a0, 0x0($v1)
    ctx->pc = 0x3a0068u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 0)));
    // 0x3a006c: 0x800008  jr          $a0
    ctx->pc = 0x3A006Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 4);
        ctx->pc = jumpTarget;
        switch (jumpTarget) {
            case 0x3A0074u: goto label_3a0074;
            case 0x3A007Cu: goto label_3a007c;
            case 0x3A0084u: goto label_3a0084;
            case 0x3A0094u: goto label_3a0094;
            case 0x3A00A4u: goto label_3a00a4;
            case 0x3A00B4u: goto label_3a00b4;
            case 0x3A00C4u: goto label_3a00c4;
            case 0x3A00D4u: goto label_3a00d4;
            case 0x3A0100u: goto label_3a0100;
            case 0x3A0110u: goto label_3a0110;
            case 0x3A0120u: goto label_3a0120;
            case 0x3A0130u: goto label_3a0130;
            case 0x3A0140u: goto label_3a0140;
            case 0x3A0148u: goto label_3a0148;
            case 0x3A014Cu: goto label_3a014c;
            default: break;
        }
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A006Cu, 0x0u, PS2Runtime::GuestBranchKind::IndirectJump, "JR")) {
            return;
        }
    }
    ctx->pc = 0x3A0074u;
label_3a0074:
    // 0x3a0074: 0x3e00008  jr          $ra
    ctx->pc = 0x3A0074u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A0078u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0074u;
        // 0x3a0078: 0xe4cc0044  swc1        $f12, 0x44($a2) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 68), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A0074u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A007Cu;
label_3a007c:
    // 0x3a007c: 0x3e00008  jr          $ra
    ctx->pc = 0x3A007Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A0080u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A007Cu;
        // 0x3a0080: 0xe4cc0048  swc1        $f12, 0x48($a2) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 72), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A007Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A0084u;
label_3a0084:
    // 0x3a0084: 0xc780dac0  lwc1        $f0, -0x2540($gp)
    ctx->pc = 0x3a0084u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957760)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a0088: 0x46006002  mul.s       $f0, $f12, $f0
    ctx->pc = 0x3a0088u;
    ctx->f[0] = FPU_MUL_S(ctx->f[12], ctx->f[0]);
    // 0x3a008c: 0x3e00008  jr          $ra
    ctx->pc = 0x3A008Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A0090u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A008Cu;
        // 0x3a0090: 0xe4c00050  swc1        $f0, 0x50($a2) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 80), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A008Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A0094u;
label_3a0094:
    // 0x3a0094: 0xc780dac4  lwc1        $f0, -0x253C($gp)
    ctx->pc = 0x3a0094u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957764)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a0098: 0x46006002  mul.s       $f0, $f12, $f0
    ctx->pc = 0x3a0098u;
    ctx->f[0] = FPU_MUL_S(ctx->f[12], ctx->f[0]);
    // 0x3a009c: 0x3e00008  jr          $ra
    ctx->pc = 0x3A009Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A00A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A009Cu;
        // 0x3a00a0: 0xe4c00054  swc1        $f0, 0x54($a2) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 84), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A009Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A00A4u;
label_3a00a4:
    // 0x3a00a4: 0xc780dac8  lwc1        $f0, -0x2538($gp)
    ctx->pc = 0x3a00a4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957768)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a00a8: 0x46006002  mul.s       $f0, $f12, $f0
    ctx->pc = 0x3a00a8u;
    ctx->f[0] = FPU_MUL_S(ctx->f[12], ctx->f[0]);
    // 0x3a00ac: 0x3e00008  jr          $ra
    ctx->pc = 0x3A00ACu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A00B0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A00ACu;
        // 0x3a00b0: 0xe4c0002c  swc1        $f0, 0x2C($a2) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 44), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A00ACu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A00B4u;
label_3a00b4:
    // 0x3a00b4: 0xc780dacc  lwc1        $f0, -0x2534($gp)
    ctx->pc = 0x3a00b4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957772)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a00b8: 0x46006002  mul.s       $f0, $f12, $f0
    ctx->pc = 0x3a00b8u;
    ctx->f[0] = FPU_MUL_S(ctx->f[12], ctx->f[0]);
    // 0x3a00bc: 0x3e00008  jr          $ra
    ctx->pc = 0x3A00BCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A00C0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A00BCu;
        // 0x3a00c0: 0xe4c00030  swc1        $f0, 0x30($a2) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 48), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A00BCu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A00C4u;
label_3a00c4:
    // 0x3a00c4: 0xc780dad0  lwc1        $f0, -0x2530($gp)
    ctx->pc = 0x3a00c4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957776)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a00c8: 0x46006002  mul.s       $f0, $f12, $f0
    ctx->pc = 0x3a00c8u;
    ctx->f[0] = FPU_MUL_S(ctx->f[12], ctx->f[0]);
    // 0x3a00cc: 0x3e00008  jr          $ra
    ctx->pc = 0x3A00CCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A00D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A00CCu;
        // 0x3a00d0: 0xe4c00034  swc1        $f0, 0x34($a2) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 52), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A00CCu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A00D4u;
label_3a00d4:
    // 0x3a00d4: 0x46006024  .word       0x46006024                   # cvt.w.s     $f0, $f12 # 00000000 <InstrIdType: CPU_COP1_FPUS>
    ctx->pc = 0x3a00d4u;
    { int32_t tmp = FPU_CVT_W_S(ctx->f[12]); std::memcpy(&ctx->f[0], &tmp, sizeof(tmp)); }
    // 0x3a00d8: 0x44020000  mfc1        $v0, $f0
    ctx->pc = 0x3a00d8u;
    { uint32_t bits; std::memcpy(&bits, &ctx->f[0], sizeof(bits)); SET_GPR_U32(ctx, 2, bits); }
    // 0x3a00dc: 0x8cc40014  lw          $a0, 0x14($a2)
    ctx->pc = 0x3a00dcu;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 6), 20)));
    // 0x3a00e0: 0x3c03fff8  lui         $v1, 0xFFF8
    ctx->pc = 0x3a00e0u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)65528 << 16));
    // 0x3a00e4: 0x34631fff  ori         $v1, $v1, 0x1FFF
    ctx->pc = 0x3a00e4u;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 3) | (uint64_t)(uint16_t)8191);
    // 0x3a00e8: 0x3042003f  andi        $v0, $v0, 0x3F
    ctx->pc = 0x3a00e8u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)63);
    // 0x3a00ec: 0x832024  and         $a0, $a0, $v1
    ctx->pc = 0x3a00ecu;
    SET_GPR_U64(ctx, 4, GPR_U64(ctx, 4) & GPR_U64(ctx, 3));
    // 0x3a00f0: 0x21340  sll         $v0, $v0, 13
    ctx->pc = 0x3a00f0u;
    SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 2), 13));
    // 0x3a00f4: 0x822025  or          $a0, $a0, $v0
    ctx->pc = 0x3a00f4u;
    SET_GPR_U64(ctx, 4, GPR_U64(ctx, 4) | GPR_U64(ctx, 2));
    // 0x3a00f8: 0x3e00008  jr          $ra
    ctx->pc = 0x3A00F8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A00FCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A00F8u;
        // 0x3a00fc: 0xacc40014  sw          $a0, 0x14($a2) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 6), 20), GPR_U32(ctx, 4));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A00F8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A0100u;
label_3a0100:
    // 0x3a0100: 0xc780dad4  lwc1        $f0, -0x252C($gp)
    ctx->pc = 0x3a0100u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957780)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a0104: 0x46006002  mul.s       $f0, $f12, $f0
    ctx->pc = 0x3a0104u;
    ctx->f[0] = FPU_MUL_S(ctx->f[12], ctx->f[0]);
    // 0x3a0108: 0x3e00008  jr          $ra
    ctx->pc = 0x3A0108u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A010Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0108u;
        // 0x3a010c: 0xe4c0001c  swc1        $f0, 0x1C($a2) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 28), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A0108u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A0110u;
label_3a0110:
    // 0x3a0110: 0xc780dad8  lwc1        $f0, -0x2528($gp)
    ctx->pc = 0x3a0110u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957784)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a0114: 0x46006002  mul.s       $f0, $f12, $f0
    ctx->pc = 0x3a0114u;
    ctx->f[0] = FPU_MUL_S(ctx->f[12], ctx->f[0]);
    // 0x3a0118: 0x3e00008  jr          $ra
    ctx->pc = 0x3A0118u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A011Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0118u;
        // 0x3a011c: 0xe4c00020  swc1        $f0, 0x20($a2) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 32), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A0118u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A0120u;
label_3a0120:
    // 0x3a0120: 0xc780dadc  lwc1        $f0, -0x2524($gp)
    ctx->pc = 0x3a0120u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957788)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a0124: 0x46006002  mul.s       $f0, $f12, $f0
    ctx->pc = 0x3a0124u;
    ctx->f[0] = FPU_MUL_S(ctx->f[12], ctx->f[0]);
    // 0x3a0128: 0x3e00008  jr          $ra
    ctx->pc = 0x3A0128u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A012Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0128u;
        // 0x3a012c: 0xe4c00024  swc1        $f0, 0x24($a2) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 36), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A0128u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A0130u;
label_3a0130:
    // 0x3a0130: 0xc780dae0  lwc1        $f0, -0x2520($gp)
    ctx->pc = 0x3a0130u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957792)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a0134: 0x46006002  mul.s       $f0, $f12, $f0
    ctx->pc = 0x3a0134u;
    ctx->f[0] = FPU_MUL_S(ctx->f[12], ctx->f[0]);
    // 0x3a0138: 0x3e00008  jr          $ra
    ctx->pc = 0x3A0138u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A013Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0138u;
        // 0x3a013c: 0xe4c00028  swc1        $f0, 0x28($a2) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 40), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A0138u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A0140u;
label_3a0140:
    // 0x3a0140: 0x3e00008  jr          $ra
    ctx->pc = 0x3A0140u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3A0144u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0140u;
        // 0x3a0144: 0xe4cc0060  swc1        $f12, 0x60($a2) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 96), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A0140u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A0148u;
label_3a0148:
    // 0x3a0148: 0xe4cc0064  swc1        $f12, 0x64($a2)
    ctx->pc = 0x3a0148u;
    { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 100), bits); }
label_3a014c:
    // 0x3a014c: 0x3e00008  jr          $ra
    ctx->pc = 0x3A014Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A014Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A0154u;
    // 0x3a0154: 0x0  nop
    ctx->pc = 0x3a0154u;
    // NOP
    // 0x3a0158: 0x80382d  daddu       $a3, $a0, $zero
    ctx->pc = 0x3a0158u;
    SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
    // 0x3a015c: 0x10a00049  beqz        $a1, . + 4 + (0x49 << 2)
    ctx->pc = 0x3A015Cu;
    {
        const bool branch_taken_0x3a015c = (GPR_U64(ctx, 5) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A0160u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A015Cu;
        // 0x3a0160: 0x402d  daddu       $t0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 8, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a015c) {
            ctx->pc = 0x3A0284u;
            goto label_3a0284;
        }
    }
    ctx->pc = 0x3A0164u;
    // 0x3a0164: 0x0  nop
    ctx->pc = 0x3a0164u;
    // NOP
label_3a0168:
    // 0x3a0168: 0x84c30002  lh          $v1, 0x2($a2)
    ctx->pc = 0x3a0168u;
    SET_GPR_S32(ctx, 3, (int16_t)READ16(ADD32(GPR_U32(ctx, 6), 2)));
    // 0x3a016c: 0x84c40000  lh          $a0, 0x0($a2)
    ctx->pc = 0x3a016cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 6), 0)));
    // 0x3a0170: 0x44830800  mtc1        $v1, $f1
    ctx->pc = 0x3a0170u;
    { uint32_t bits = GPR_U32(ctx, 3); std::memcpy(&ctx->f[1], &bits, sizeof(bits)); }
    // 0x3a0174: 0x46800860  cvt.s.w     $f1, $f1
    ctx->pc = 0x3a0174u;
    { int32_t tmp; std::memcpy(&tmp, &ctx->f[1], sizeof(tmp)); ctx->f[1] = FPU_CVT_S_W(tmp); }
    // 0x3a0178: 0x2c820011  sltiu       $v0, $a0, 0x11
    ctx->pc = 0x3a0178u;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 4) < (uint64_t)(int64_t)(int32_t)17) ? 1 : 0);
    // 0x3a017c: 0x1040003d  beqz        $v0, . + 4 + (0x3D << 2)
    ctx->pc = 0x3A017Cu;
    {
        const bool branch_taken_0x3a017c = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A0180u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A017Cu;
        // 0x3a0180: 0x3c020049  lui         $v0, 0x49 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)73 << 16));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a017c) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A0184u;
    // 0x3a0184: 0x41880  sll         $v1, $a0, 2
    ctx->pc = 0x3a0184u;
    SET_GPR_S32(ctx, 3, (int32_t)SLL32(GPR_U32(ctx, 4), 2));
    // 0x3a0188: 0x24424030  addiu       $v0, $v0, 0x4030
    ctx->pc = 0x3a0188u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 16432));
    // 0x3a018c: 0x621821  addu        $v1, $v1, $v0
    ctx->pc = 0x3a018cu;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), GPR_U32(ctx, 2)));
    // 0x3a0190: 0x8c640000  lw          $a0, 0x0($v1)
    ctx->pc = 0x3a0190u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 0)));
    // 0x3a0194: 0x800008  jr          $a0
    ctx->pc = 0x3A0194u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 4);
        ctx->pc = jumpTarget;
        switch (jumpTarget) {
            case 0x3A019Cu: goto label_3a019c;
            case 0x3A01A4u: goto label_3a01a4;
            case 0x3A01ACu: goto label_3a01ac;
            case 0x3A01BCu: goto label_3a01bc;
            case 0x3A01CCu: goto label_3a01cc;
            case 0x3A01DCu: goto label_3a01dc;
            case 0x3A01ECu: goto label_3a01ec;
            case 0x3A01FCu: goto label_3a01fc;
            case 0x3A0228u: goto label_3a0228;
            case 0x3A0238u: goto label_3a0238;
            case 0x3A0248u: goto label_3a0248;
            case 0x3A0258u: goto label_3a0258;
            case 0x3A0268u: goto label_3a0268;
            case 0x3A0270u: goto label_3a0270;
            case 0x3A0274u: goto label_3a0274;
            default: break;
        }
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A0194u, 0x0u, PS2Runtime::GuestBranchKind::IndirectJump, "JR")) {
            return;
        }
    }
    ctx->pc = 0x3A019Cu;
label_3a019c:
    // 0x3a019c: 0x10000035  b           . + 4 + (0x35 << 2)
    ctx->pc = 0x3A019Cu;
    {
        const bool branch_taken_0x3a019c = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A01A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A019Cu;
        // 0x3a01a0: 0xe4e10044  swc1        $f1, 0x44($a3) (Delay Slot)
        { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 68), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a019c) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A01A4u;
label_3a01a4:
    // 0x3a01a4: 0x10000033  b           . + 4 + (0x33 << 2)
    ctx->pc = 0x3A01A4u;
    {
        const bool branch_taken_0x3a01a4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A01A8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A01A4u;
        // 0x3a01a8: 0xe4e10048  swc1        $f1, 0x48($a3) (Delay Slot)
        { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 72), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a01a4) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A01ACu;
label_3a01ac:
    // 0x3a01ac: 0xc780dae4  lwc1        $f0, -0x251C($gp)
    ctx->pc = 0x3a01acu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957796)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a01b0: 0x46000802  mul.s       $f0, $f1, $f0
    ctx->pc = 0x3a01b0u;
    ctx->f[0] = FPU_MUL_S(ctx->f[1], ctx->f[0]);
    // 0x3a01b4: 0x1000002f  b           . + 4 + (0x2F << 2)
    ctx->pc = 0x3A01B4u;
    {
        const bool branch_taken_0x3a01b4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A01B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A01B4u;
        // 0x3a01b8: 0xe4e00050  swc1        $f0, 0x50($a3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 80), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a01b4) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A01BCu;
label_3a01bc:
    // 0x3a01bc: 0xc780dae8  lwc1        $f0, -0x2518($gp)
    ctx->pc = 0x3a01bcu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957800)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a01c0: 0x46000802  mul.s       $f0, $f1, $f0
    ctx->pc = 0x3a01c0u;
    ctx->f[0] = FPU_MUL_S(ctx->f[1], ctx->f[0]);
    // 0x3a01c4: 0x1000002b  b           . + 4 + (0x2B << 2)
    ctx->pc = 0x3A01C4u;
    {
        const bool branch_taken_0x3a01c4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A01C8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A01C4u;
        // 0x3a01c8: 0xe4e00054  swc1        $f0, 0x54($a3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 84), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a01c4) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A01CCu;
label_3a01cc:
    // 0x3a01cc: 0xc780daec  lwc1        $f0, -0x2514($gp)
    ctx->pc = 0x3a01ccu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957804)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a01d0: 0x46000802  mul.s       $f0, $f1, $f0
    ctx->pc = 0x3a01d0u;
    ctx->f[0] = FPU_MUL_S(ctx->f[1], ctx->f[0]);
    // 0x3a01d4: 0x10000027  b           . + 4 + (0x27 << 2)
    ctx->pc = 0x3A01D4u;
    {
        const bool branch_taken_0x3a01d4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A01D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A01D4u;
        // 0x3a01d8: 0xe4e0002c  swc1        $f0, 0x2C($a3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 44), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a01d4) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A01DCu;
label_3a01dc:
    // 0x3a01dc: 0xc780daf0  lwc1        $f0, -0x2510($gp)
    ctx->pc = 0x3a01dcu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957808)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a01e0: 0x46000802  mul.s       $f0, $f1, $f0
    ctx->pc = 0x3a01e0u;
    ctx->f[0] = FPU_MUL_S(ctx->f[1], ctx->f[0]);
    // 0x3a01e4: 0x10000023  b           . + 4 + (0x23 << 2)
    ctx->pc = 0x3A01E4u;
    {
        const bool branch_taken_0x3a01e4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A01E8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A01E4u;
        // 0x3a01e8: 0xe4e00030  swc1        $f0, 0x30($a3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 48), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a01e4) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A01ECu;
label_3a01ec:
    // 0x3a01ec: 0xc780daf4  lwc1        $f0, -0x250C($gp)
    ctx->pc = 0x3a01ecu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957812)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a01f0: 0x46000802  mul.s       $f0, $f1, $f0
    ctx->pc = 0x3a01f0u;
    ctx->f[0] = FPU_MUL_S(ctx->f[1], ctx->f[0]);
    // 0x3a01f4: 0x1000001f  b           . + 4 + (0x1F << 2)
    ctx->pc = 0x3A01F4u;
    {
        const bool branch_taken_0x3a01f4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A01F8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A01F4u;
        // 0x3a01f8: 0xe4e00034  swc1        $f0, 0x34($a3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 52), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a01f4) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A01FCu;
label_3a01fc:
    // 0x3a01fc: 0x46000824  .word       0x46000824                   # cvt.w.s     $f0, $f1 # 00000000 <InstrIdType: CPU_COP1_FPUS>
    ctx->pc = 0x3a01fcu;
    { int32_t tmp = FPU_CVT_W_S(ctx->f[1]); std::memcpy(&ctx->f[0], &tmp, sizeof(tmp)); }
    // 0x3a0200: 0x44020000  mfc1        $v0, $f0
    ctx->pc = 0x3a0200u;
    { uint32_t bits; std::memcpy(&bits, &ctx->f[0], sizeof(bits)); SET_GPR_U32(ctx, 2, bits); }
    // 0x3a0204: 0x8ce40014  lw          $a0, 0x14($a3)
    ctx->pc = 0x3a0204u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 7), 20)));
    // 0x3a0208: 0x3c03fff8  lui         $v1, 0xFFF8
    ctx->pc = 0x3a0208u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)65528 << 16));
    // 0x3a020c: 0x34631fff  ori         $v1, $v1, 0x1FFF
    ctx->pc = 0x3a020cu;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 3) | (uint64_t)(uint16_t)8191);
    // 0x3a0210: 0x3042003f  andi        $v0, $v0, 0x3F
    ctx->pc = 0x3a0210u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)63);
    // 0x3a0214: 0x832024  and         $a0, $a0, $v1
    ctx->pc = 0x3a0214u;
    SET_GPR_U64(ctx, 4, GPR_U64(ctx, 4) & GPR_U64(ctx, 3));
    // 0x3a0218: 0x21340  sll         $v0, $v0, 13
    ctx->pc = 0x3a0218u;
    SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 2), 13));
    // 0x3a021c: 0x822025  or          $a0, $a0, $v0
    ctx->pc = 0x3a021cu;
    SET_GPR_U64(ctx, 4, GPR_U64(ctx, 4) | GPR_U64(ctx, 2));
    // 0x3a0220: 0x10000014  b           . + 4 + (0x14 << 2)
    ctx->pc = 0x3A0220u;
    {
        const bool branch_taken_0x3a0220 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A0224u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0220u;
        // 0x3a0224: 0xace40014  sw          $a0, 0x14($a3) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 7), 20), GPR_U32(ctx, 4));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a0220) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A0228u;
label_3a0228:
    // 0x3a0228: 0xc780daf8  lwc1        $f0, -0x2508($gp)
    ctx->pc = 0x3a0228u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957816)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a022c: 0x46000802  mul.s       $f0, $f1, $f0
    ctx->pc = 0x3a022cu;
    ctx->f[0] = FPU_MUL_S(ctx->f[1], ctx->f[0]);
    // 0x3a0230: 0x10000010  b           . + 4 + (0x10 << 2)
    ctx->pc = 0x3A0230u;
    {
        const bool branch_taken_0x3a0230 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A0234u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0230u;
        // 0x3a0234: 0xe4e0001c  swc1        $f0, 0x1C($a3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 28), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a0230) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A0238u;
label_3a0238:
    // 0x3a0238: 0xc780dafc  lwc1        $f0, -0x2504($gp)
    ctx->pc = 0x3a0238u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957820)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a023c: 0x46000802  mul.s       $f0, $f1, $f0
    ctx->pc = 0x3a023cu;
    ctx->f[0] = FPU_MUL_S(ctx->f[1], ctx->f[0]);
    // 0x3a0240: 0x1000000c  b           . + 4 + (0xC << 2)
    ctx->pc = 0x3A0240u;
    {
        const bool branch_taken_0x3a0240 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A0244u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0240u;
        // 0x3a0244: 0xe4e00020  swc1        $f0, 0x20($a3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 32), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a0240) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A0248u;
label_3a0248:
    // 0x3a0248: 0xc780db00  lwc1        $f0, -0x2500($gp)
    ctx->pc = 0x3a0248u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957824)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a024c: 0x46000802  mul.s       $f0, $f1, $f0
    ctx->pc = 0x3a024cu;
    ctx->f[0] = FPU_MUL_S(ctx->f[1], ctx->f[0]);
    // 0x3a0250: 0x10000008  b           . + 4 + (0x8 << 2)
    ctx->pc = 0x3A0250u;
    {
        const bool branch_taken_0x3a0250 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A0254u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0250u;
        // 0x3a0254: 0xe4e00024  swc1        $f0, 0x24($a3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 36), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a0250) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A0258u;
label_3a0258:
    // 0x3a0258: 0xc780db04  lwc1        $f0, -0x24FC($gp)
    ctx->pc = 0x3a0258u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294957828)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
    // 0x3a025c: 0x46000802  mul.s       $f0, $f1, $f0
    ctx->pc = 0x3a025cu;
    ctx->f[0] = FPU_MUL_S(ctx->f[1], ctx->f[0]);
    // 0x3a0260: 0x10000004  b           . + 4 + (0x4 << 2)
    ctx->pc = 0x3A0260u;
    {
        const bool branch_taken_0x3a0260 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A0264u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0260u;
        // 0x3a0264: 0xe4e00028  swc1        $f0, 0x28($a3) (Delay Slot)
        { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 40), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a0260) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A0268u;
label_3a0268:
    // 0x3a0268: 0x10000002  b           . + 4 + (0x2 << 2)
    ctx->pc = 0x3A0268u;
    {
        const bool branch_taken_0x3a0268 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3A026Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A0268u;
        // 0x3a026c: 0xe4e10060  swc1        $f1, 0x60($a3) (Delay Slot)
        { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 96), bits); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a0268) {
            ctx->pc = 0x3A0274u;
            goto label_3a0274;
        }
    }
    ctx->pc = 0x3A0270u;
label_3a0270:
    // 0x3a0270: 0xe4e10064  swc1        $f1, 0x64($a3)
    ctx->pc = 0x3a0270u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 100), bits); }
label_3a0274:
    // 0x3a0274: 0x25080001  addiu       $t0, $t0, 0x1
    ctx->pc = 0x3a0274u;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 8), 1));
    // 0x3a0278: 0x105102b  sltu        $v0, $t0, $a1
    ctx->pc = 0x3a0278u;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 8) < (uint64_t)GPR_U64(ctx, 5)) ? 1 : 0);
    // 0x3a027c: 0x1440ffba  bnez        $v0, . + 4 + (-0x46 << 2)
    ctx->pc = 0x3A027Cu;
    {
        const bool branch_taken_0x3a027c = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x3A0280u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3A027Cu;
        // 0x3a0280: 0x24c60004  addiu       $a2, $a2, 0x4 (Delay Slot)
        SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), 4));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3a027c) {
            ctx->pc = 0x3A0168u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_3a0168;
        }
    }
    ctx->pc = 0x3A0284u;
label_3a0284:
    // 0x3a0284: 0x3e00008  jr          $ra
    ctx->pc = 0x3A0284u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3A0284u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3A028Cu;
    // 0x3a028c: 0x0  nop
    ctx->pc = 0x3a028cu;
    // NOP
    ctx->pc = 0x3a0290u;
}
