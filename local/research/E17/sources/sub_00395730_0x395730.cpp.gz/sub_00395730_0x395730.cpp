#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_00395730
// Address: 0x395730 - 0x395750
void sub_00395730_0x395730(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_00395730_0x395730");
#endif

    ctx->pc = 0x395730u;

    // 0x395730: 0x8c8213e4  lw          $v0, 0x13E4($a0)
    ctx->pc = 0x395730u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 5092)));
    // 0x395734: 0x8c8313e0  lw          $v1, 0x13E0($a0)
    ctx->pc = 0x395734u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 5088)));
    // 0x395738: 0x2442ffc0  addiu       $v0, $v0, -0x40
    ctx->pc = 0x395738u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 4294967232));
    // 0x39573c: 0xac806b90  sw          $zero, 0x6B90($a0)
    ctx->pc = 0x39573cu;
    WRITE32(ADD32(GPR_U32(ctx, 4), 27536), GPR_U32(ctx, 0));
    // 0x395740: 0x2463ffff  addiu       $v1, $v1, -0x1
    ctx->pc = 0x395740u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 4294967295));
    // 0x395744: 0xac8213e4  sw          $v0, 0x13E4($a0)
    ctx->pc = 0x395744u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 5092), GPR_U32(ctx, 2));
    // 0x395748: 0x3e00008  jr          $ra
    ctx->pc = 0x395748u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x39574Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x395748u;
        // 0x39574c: 0xac8313e0  sw          $v1, 0x13E0($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 5088), GPR_U32(ctx, 3));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x395748u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x395750u;
}
