#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_00243A80
// Address: 0x243a80 - 0x243ab0
void sub_00243A80_0x243a80(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_00243A80_0x243a80");
#endif

    switch (ctx->pc) {
        case 0x243aa4u: goto label_243aa4;
        default: break;
    }

    ctx->pc = 0x243a80u;

    // 0x243a80: 0x3c020047  lui         $v0, 0x47
    ctx->pc = 0x243a80u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)71 << 16));
    // 0x243a84: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x243a84u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
    // 0x243a88: 0x2442d970  addiu       $v0, $v0, -0x2690
    ctx->pc = 0x243a88u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 4294957424));
    // 0x243a8c: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x243a8cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
    // 0x243a90: 0x30a50001  andi        $a1, $a1, 0x1
    ctx->pc = 0x243a90u;
    SET_GPR_U64(ctx, 5, GPR_U64(ctx, 5) & (uint64_t)(uint16_t)1);
    // 0x243a94: 0x10a00003  beqz        $a1, . + 4 + (0x3 << 2)
    ctx->pc = 0x243A94u;
    {
        const bool branch_taken_0x243a94 = (GPR_U64(ctx, 5) == GPR_U64(ctx, 0));
        ctx->pc = 0x243A98u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x243A94u;
        // 0x243a98: 0xac820000  sw          $v0, 0x0($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 0), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x243a94) {
            ctx->pc = 0x243AA4u;
            goto label_243aa4;
        }
    }
    ctx->pc = 0x243A9Cu;
    // 0x243a9c: 0xc0c5f94  jal         func_317E50
    ctx->pc = 0x243A9Cu;
    SET_GPR_U32(ctx, 31, 0x243AA4u);
    ctx->pc = 0x317E50u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x317E50u, 0x243A9Cu, 0x243AA4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x243AA4u;
label_243aa4:
    // 0x243aa4: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x243aa4u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
    // 0x243aa8: 0x3e00008  jr          $ra
    ctx->pc = 0x243AA8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x243AACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x243AA8u;
        // 0x243aac: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x243AA8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x243AB0u;
}
