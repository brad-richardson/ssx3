#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_00156750
// Address: 0x156750 - 0x1567b8
void sub_00156750_0x156750(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_00156750_0x156750");
#endif

    ctx->pc = 0x156750u;

    // 0x156750: 0x8f83e0c4  lw          $v1, -0x1F3C($gp)
    ctx->pc = 0x156750u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959300)));
    // 0x156754: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x156754u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
    // 0x156758: 0x8f84e0d0  lw          $a0, -0x1F30($gp)
    ctx->pc = 0x156758u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959312)));
    // 0x15675c: 0xac620008  sw          $v0, 0x8($v1)
    ctx->pc = 0x15675cu;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 2));
    // 0x156760: 0x8f85e118  lw          $a1, -0x1EE8($gp)
    ctx->pc = 0x156760u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959384)));
    // 0x156764: 0xac820008  sw          $v0, 0x8($a0)
    ctx->pc = 0x156764u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 2));
    // 0x156768: 0x8f83e0d4  lw          $v1, -0x1F2C($gp)
    ctx->pc = 0x156768u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959316)));
    // 0x15676c: 0xaca20008  sw          $v0, 0x8($a1)
    ctx->pc = 0x15676cu;
    WRITE32(ADD32(GPR_U32(ctx, 5), 8), GPR_U32(ctx, 2));
    // 0x156770: 0x8f84e11c  lw          $a0, -0x1EE4($gp)
    ctx->pc = 0x156770u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959388)));
    // 0x156774: 0xac620008  sw          $v0, 0x8($v1)
    ctx->pc = 0x156774u;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 2));
    // 0x156778: 0x8f85e12c  lw          $a1, -0x1ED4($gp)
    ctx->pc = 0x156778u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959404)));
    // 0x15677c: 0xac820008  sw          $v0, 0x8($a0)
    ctx->pc = 0x15677cu;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 2));
    // 0x156780: 0x8f83e114  lw          $v1, -0x1EEC($gp)
    ctx->pc = 0x156780u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959380)));
    // 0x156784: 0xaca20008  sw          $v0, 0x8($a1)
    ctx->pc = 0x156784u;
    WRITE32(ADD32(GPR_U32(ctx, 5), 8), GPR_U32(ctx, 2));
    // 0x156788: 0x8f84e0d8  lw          $a0, -0x1F28($gp)
    ctx->pc = 0x156788u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959320)));
    // 0x15678c: 0xac620008  sw          $v0, 0x8($v1)
    ctx->pc = 0x15678cu;
    WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 2));
    // 0x156790: 0x8f85e120  lw          $a1, -0x1EE0($gp)
    ctx->pc = 0x156790u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959392)));
    // 0x156794: 0xac820008  sw          $v0, 0x8($a0)
    ctx->pc = 0x156794u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 2));
    // 0x156798: 0x8f86e124  lw          $a2, -0x1EDC($gp)
    ctx->pc = 0x156798u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959396)));
    // 0x15679c: 0xaca20008  sw          $v0, 0x8($a1)
    ctx->pc = 0x15679cu;
    WRITE32(ADD32(GPR_U32(ctx, 5), 8), GPR_U32(ctx, 2));
    // 0x1567a0: 0x8f84e15c  lw          $a0, -0x1EA4($gp)
    ctx->pc = 0x1567a0u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959452)));
    // 0x1567a4: 0xacc20008  sw          $v0, 0x8($a2)
    ctx->pc = 0x1567a4u;
    WRITE32(ADD32(GPR_U32(ctx, 6), 8), GPR_U32(ctx, 2));
    // 0x1567a8: 0x8f83e174  lw          $v1, -0x1E8C($gp)
    ctx->pc = 0x1567a8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294959476)));
    // 0x1567ac: 0xac820008  sw          $v0, 0x8($a0)
    ctx->pc = 0x1567acu;
    WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 2));
    // 0x1567b0: 0x3e00008  jr          $ra
    ctx->pc = 0x1567B0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x1567B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x1567B0u;
        // 0x1567b4: 0xac620008  sw          $v0, 0x8($v1) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 3), 8), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x1567B0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x1567B8u;
}
