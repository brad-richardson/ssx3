#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_003B04F8
// Address: 0x3b04f8 - 0x3b0538
void sub_003B04F8_0x3b04f8(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_003B04F8_0x3b04f8");
#endif

    switch (ctx->pc) {
        case 0x3b04f8u: goto label_3b04f8;
        case 0x3b04fcu: goto label_3b04fc;
        case 0x3b0500u: goto label_3b0500;
        case 0x3b0504u: goto label_3b0504;
        case 0x3b0508u: goto label_3b0508;
        case 0x3b050cu: goto label_3b050c;
        case 0x3b0510u: goto label_3b0510;
        case 0x3b0514u: goto label_3b0514;
        case 0x3b0518u: goto label_3b0518;
        case 0x3b051cu: goto label_3b051c;
        case 0x3b0520u: goto label_3b0520;
        case 0x3b0524u: goto label_3b0524;
        case 0x3b0528u: goto label_3b0528;
        case 0x3b052cu: goto label_3b052c;
        case 0x3b0530u: goto label_3b0530;
        case 0x3b0534u: goto label_3b0534;
        default: break;
    }

    ctx->pc = 0x3b04f8u;

label_3b04f8:
    // 0x3b04f8: 0x80102d  daddu       $v0, $a0, $zero
    ctx->pc = 0x3b04f8u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_3b04fc:
    // 0x3b04fc: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x3b04fcu;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_3b0500:
    // 0x3b0500: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x3b0500u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_3b0504:
    // 0x3b0504: 0xa0202d  daddu       $a0, $a1, $zero
    ctx->pc = 0x3b0504u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_3b0508:
    // 0x3b0508: 0xac440014  sw          $a0, 0x14($v0)
    ctx->pc = 0x3b0508u;
    WRITE32(ADD32(GPR_U32(ctx, 2), 20), GPR_U32(ctx, 4));
label_3b050c:
    // 0x3b050c: 0x40282d  daddu       $a1, $v0, $zero
    ctx->pc = 0x3b050cu;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_3b0510:
    // 0x3b0510: 0xac460000  sw          $a2, 0x0($v0)
    ctx->pc = 0x3b0510u;
    WRITE32(ADD32(GPR_U32(ctx, 2), 0), GPR_U32(ctx, 6));
label_3b0514:
    // 0x3b0514: 0x8c830000  lw          $v1, 0x0($a0)
    ctx->pc = 0x3b0514u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_3b0518:
    // 0x3b0518: 0x84670010  lh          $a3, 0x10($v1)
    ctx->pc = 0x3b0518u;
    SET_GPR_S32(ctx, 7, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 16)));
label_3b051c:
    // 0x3b051c: 0x8c620014  lw          $v0, 0x14($v1)
    ctx->pc = 0x3b051cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 20)));
label_3b0520:
    // 0x3b0520: 0x40f809  jalr        $v0
label_3b0524:
    if (ctx->pc == 0x3B0524u) {
        ctx->pc = 0x3B0524u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0520u;
        // 0x3b0524: 0x872021  addu        $a0, $a0, $a3 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 7)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0528u;
        goto label_3b0528;
    }
    ctx->pc = 0x3B0520u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x3B0528u);
        ctx->pc = 0x3B0524u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0520u;
        // 0x3b0524: 0x872021  addu        $a0, $a0, $a3 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 7)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0520u, 0x3B0528u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x3B0528u;
label_3b0528:
    // 0x3b0528: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x3b0528u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_3b052c:
    // 0x3b052c: 0x3e00008  jr          $ra
label_3b0530:
    if (ctx->pc == 0x3B0530u) {
        ctx->pc = 0x3B0530u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B052Cu;
        // 0x3b0530: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0534u;
        goto label_3b0534;
    }
    ctx->pc = 0x3B052Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3B0530u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B052Cu;
        // 0x3b0530: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B052Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3B0534u;
label_3b0534:
    // 0x3b0534: 0x0  nop
    ctx->pc = 0x3b0534u;
    // NOP
    ctx->pc = 0x3b0538u;
}
