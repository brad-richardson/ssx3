#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_002C52D8
// Address: 0x2c52d8 - 0x2c5320
void sub_002C52D8_0x2c52d8(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_002C52D8_0x2c52d8");
#endif

    switch (ctx->pc) {
        case 0x2c52f0u: goto label_2c52f0;
        default: break;
    }

    ctx->pc = 0x2c52d8u;

    // 0x2c52d8: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2c52d8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
    // 0x2c52dc: 0x24840480  addiu       $a0, $a0, 0x480
    ctx->pc = 0x2c52dcu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 1152));
    // 0x2c52e0: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2c52e0u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
    // 0x2c52e4: 0x282d  daddu       $a1, $zero, $zero
    ctx->pc = 0x2c52e4u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
    // 0x2c52e8: 0xc0f9912  jal         func_3E6448
    ctx->pc = 0x2C52E8u;
    SET_GPR_U32(ctx, 31, 0x2C52F0u);
    ctx->pc = 0x2C52ECu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2C52E8u;
    // 0x2c52ec: 0x24060040  addiu       $a2, $zero, 0x40 (Delay Slot)
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 0), 64));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3E6448u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3E6448u, 0x2C52E8u, 0x2C52F0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2C52F0u;
label_2c52f0:
    // 0x2c52f0: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2c52f0u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
    // 0x2c52f4: 0x3e00008  jr          $ra
    ctx->pc = 0x2C52F4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C52F8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C52F4u;
        // 0x2c52f8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C52F4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C52FCu;
    // 0x2c52fc: 0x0  nop
    ctx->pc = 0x2c52fcu;
    // NOP
    // 0x2c5300: 0x24020014  addiu       $v0, $zero, 0x14
    ctx->pc = 0x2c5300u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 20));
    // 0x2c5304: 0x2403d8ee  addiu       $v1, $zero, -0x2712
    ctx->pc = 0x2c5304u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 4294957294));
    // 0x2c5308: 0xa23018  mult        $a2, $a1, $v0
    ctx->pc = 0x2c5308u;
    { int64_t result = (int64_t)GPR_S32(ctx, 5) * (int64_t)GPR_S32(ctx, 2); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 6, (int32_t)result); }
    // 0x2c530c: 0xc42021  addu        $a0, $a2, $a0
    ctx->pc = 0x2c530cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
    // 0x2c5310: 0x8c820184  lw          $v0, 0x184($a0)
    ctx->pc = 0x2c5310u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 388)));
    // 0x2c5314: 0x431026  xor         $v0, $v0, $v1
    ctx->pc = 0x2c5314u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) ^ GPR_U64(ctx, 3));
    // 0x2c5318: 0x3e00008  jr          $ra
    ctx->pc = 0x2C5318u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C531Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C5318u;
        // 0x2c531c: 0x2c420001  sltiu       $v0, $v0, 0x1 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 2) < (uint64_t)(int64_t)(int32_t)1) ? 1 : 0);
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C5318u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C5320u;
}
