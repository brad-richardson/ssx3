#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_0023EB50
// Address: 0x23eb50 - 0x23eb80
void sub_0023EB50_0x23eb50(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_0023EB50_0x23eb50");
#endif

    switch (ctx->pc) {
        case 0x23eb50u: goto label_23eb50;
        case 0x23eb54u: goto label_23eb54;
        case 0x23eb58u: goto label_23eb58;
        case 0x23eb5cu: goto label_23eb5c;
        case 0x23eb60u: goto label_23eb60;
        case 0x23eb64u: goto label_23eb64;
        case 0x23eb68u: goto label_23eb68;
        case 0x23eb6cu: goto label_23eb6c;
        case 0x23eb70u: goto label_23eb70;
        case 0x23eb74u: goto label_23eb74;
        case 0x23eb78u: goto label_23eb78;
        case 0x23eb7cu: goto label_23eb7c;
        default: break;
    }

    ctx->pc = 0x23eb50u;

label_23eb50:
    // 0x23eb50: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x23eb50u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_23eb54:
    // 0x23eb54: 0x24050004  addiu       $a1, $zero, 0x4
    ctx->pc = 0x23eb54u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 4));
label_23eb58:
    // 0x23eb58: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x23eb58u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_23eb5c:
    // 0x23eb5c: 0x8c820748  lw          $v0, 0x748($a0)
    ctx->pc = 0x23eb5cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 1864)));
label_23eb60:
    // 0x23eb60: 0x84430008  lh          $v1, 0x8($v0)
    ctx->pc = 0x23eb60u;
    SET_GPR_S32(ctx, 3, (int16_t)READ16(ADD32(GPR_U32(ctx, 2), 8)));
label_23eb64:
    // 0x23eb64: 0x8c46000c  lw          $a2, 0xC($v0)
    ctx->pc = 0x23eb64u;
    SET_GPR_S32(ctx, 6, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 12)));
label_23eb68:
    // 0x23eb68: 0xc0f809  jalr        $a2
label_23eb6c:
    if (ctx->pc == 0x23EB6Cu) {
        ctx->pc = 0x23EB6Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23EB68u;
        // 0x23eb6c: 0x832021  addu        $a0, $a0, $v1 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 3)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23EB70u;
        goto label_23eb70;
    }
    ctx->pc = 0x23EB68u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 6);
        SET_GPR_U32(ctx, 31, 0x23EB70u);
        ctx->pc = 0x23EB6Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23EB68u;
        // 0x23eb6c: 0x832021  addu        $a0, $a0, $v1 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 3)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23EB68u, 0x23EB70u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x23EB70u;
label_23eb70:
    // 0x23eb70: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x23eb70u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_23eb74:
    // 0x23eb74: 0x3e00008  jr          $ra
label_23eb78:
    if (ctx->pc == 0x23EB78u) {
        ctx->pc = 0x23EB78u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23EB74u;
        // 0x23eb78: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x23EB7Cu;
        goto label_23eb7c;
    }
    ctx->pc = 0x23EB74u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x23EB78u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x23EB74u;
        // 0x23eb78: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x23EB74u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x23EB7Cu;
label_23eb7c:
    // 0x23eb7c: 0x0  nop
    ctx->pc = 0x23eb7cu;
    // NOP
    ctx->pc = 0x23eb80u;
}
