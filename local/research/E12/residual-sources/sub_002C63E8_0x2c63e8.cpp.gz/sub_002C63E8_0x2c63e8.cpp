#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_002C63E8
// Address: 0x2c63e8 - 0x2c67e8
void sub_002C63E8_0x2c63e8(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_002C63E8_0x2c63e8");
#endif

    switch (ctx->pc) {
        case 0x2c63e8u: goto label_2c63e8;
        case 0x2c63ecu: goto label_2c63ec;
        case 0x2c63f0u: goto label_2c63f0;
        case 0x2c63f4u: goto label_2c63f4;
        case 0x2c63f8u: goto label_2c63f8;
        case 0x2c63fcu: goto label_2c63fc;
        case 0x2c6400u: goto label_2c6400;
        case 0x2c6404u: goto label_2c6404;
        case 0x2c6408u: goto label_2c6408;
        case 0x2c640cu: goto label_2c640c;
        case 0x2c6410u: goto label_2c6410;
        case 0x2c6414u: goto label_2c6414;
        case 0x2c6418u: goto label_2c6418;
        case 0x2c641cu: goto label_2c641c;
        case 0x2c6420u: goto label_2c6420;
        case 0x2c6424u: goto label_2c6424;
        case 0x2c6428u: goto label_2c6428;
        case 0x2c642cu: goto label_2c642c;
        case 0x2c6430u: goto label_2c6430;
        case 0x2c6434u: goto label_2c6434;
        case 0x2c6438u: goto label_2c6438;
        case 0x2c643cu: goto label_2c643c;
        case 0x2c6440u: goto label_2c6440;
        case 0x2c6444u: goto label_2c6444;
        case 0x2c6448u: goto label_2c6448;
        case 0x2c644cu: goto label_2c644c;
        case 0x2c6450u: goto label_2c6450;
        case 0x2c6454u: goto label_2c6454;
        case 0x2c6458u: goto label_2c6458;
        case 0x2c645cu: goto label_2c645c;
        case 0x2c6460u: goto label_2c6460;
        case 0x2c6464u: goto label_2c6464;
        case 0x2c6468u: goto label_2c6468;
        case 0x2c646cu: goto label_2c646c;
        case 0x2c6470u: goto label_2c6470;
        case 0x2c6474u: goto label_2c6474;
        case 0x2c6478u: goto label_2c6478;
        case 0x2c647cu: goto label_2c647c;
        case 0x2c6480u: goto label_2c6480;
        case 0x2c6484u: goto label_2c6484;
        case 0x2c6488u: goto label_2c6488;
        case 0x2c648cu: goto label_2c648c;
        case 0x2c6490u: goto label_2c6490;
        case 0x2c6494u: goto label_2c6494;
        case 0x2c6498u: goto label_2c6498;
        case 0x2c649cu: goto label_2c649c;
        case 0x2c64a0u: goto label_2c64a0;
        case 0x2c64a4u: goto label_2c64a4;
        case 0x2c64a8u: goto label_2c64a8;
        case 0x2c64acu: goto label_2c64ac;
        case 0x2c64b0u: goto label_2c64b0;
        case 0x2c64b4u: goto label_2c64b4;
        case 0x2c64b8u: goto label_2c64b8;
        case 0x2c64bcu: goto label_2c64bc;
        case 0x2c64c0u: goto label_2c64c0;
        case 0x2c64c4u: goto label_2c64c4;
        case 0x2c64c8u: goto label_2c64c8;
        case 0x2c64ccu: goto label_2c64cc;
        case 0x2c64d0u: goto label_2c64d0;
        case 0x2c64d4u: goto label_2c64d4;
        case 0x2c64d8u: goto label_2c64d8;
        case 0x2c64dcu: goto label_2c64dc;
        case 0x2c64e0u: goto label_2c64e0;
        case 0x2c64e4u: goto label_2c64e4;
        case 0x2c64e8u: goto label_2c64e8;
        case 0x2c64ecu: goto label_2c64ec;
        case 0x2c64f0u: goto label_2c64f0;
        case 0x2c64f4u: goto label_2c64f4;
        case 0x2c64f8u: goto label_2c64f8;
        case 0x2c64fcu: goto label_2c64fc;
        case 0x2c6500u: goto label_2c6500;
        case 0x2c6504u: goto label_2c6504;
        case 0x2c6508u: goto label_2c6508;
        case 0x2c650cu: goto label_2c650c;
        case 0x2c6510u: goto label_2c6510;
        case 0x2c6514u: goto label_2c6514;
        case 0x2c6518u: goto label_2c6518;
        case 0x2c651cu: goto label_2c651c;
        case 0x2c6520u: goto label_2c6520;
        case 0x2c6524u: goto label_2c6524;
        case 0x2c6528u: goto label_2c6528;
        case 0x2c652cu: goto label_2c652c;
        case 0x2c6530u: goto label_2c6530;
        case 0x2c6534u: goto label_2c6534;
        case 0x2c6538u: goto label_2c6538;
        case 0x2c653cu: goto label_2c653c;
        case 0x2c6540u: goto label_2c6540;
        case 0x2c6544u: goto label_2c6544;
        case 0x2c6548u: goto label_2c6548;
        case 0x2c654cu: goto label_2c654c;
        case 0x2c6550u: goto label_2c6550;
        case 0x2c6554u: goto label_2c6554;
        case 0x2c6558u: goto label_2c6558;
        case 0x2c655cu: goto label_2c655c;
        case 0x2c6560u: goto label_2c6560;
        case 0x2c6564u: goto label_2c6564;
        case 0x2c6568u: goto label_2c6568;
        case 0x2c656cu: goto label_2c656c;
        case 0x2c6570u: goto label_2c6570;
        case 0x2c6574u: goto label_2c6574;
        case 0x2c6578u: goto label_2c6578;
        case 0x2c657cu: goto label_2c657c;
        case 0x2c6580u: goto label_2c6580;
        case 0x2c6584u: goto label_2c6584;
        case 0x2c6588u: goto label_2c6588;
        case 0x2c658cu: goto label_2c658c;
        case 0x2c6590u: goto label_2c6590;
        case 0x2c6594u: goto label_2c6594;
        case 0x2c6598u: goto label_2c6598;
        case 0x2c659cu: goto label_2c659c;
        case 0x2c65a0u: goto label_2c65a0;
        case 0x2c65a4u: goto label_2c65a4;
        case 0x2c65a8u: goto label_2c65a8;
        case 0x2c65acu: goto label_2c65ac;
        case 0x2c65b0u: goto label_2c65b0;
        case 0x2c65b4u: goto label_2c65b4;
        case 0x2c65b8u: goto label_2c65b8;
        case 0x2c65bcu: goto label_2c65bc;
        case 0x2c65c0u: goto label_2c65c0;
        case 0x2c65c4u: goto label_2c65c4;
        case 0x2c65c8u: goto label_2c65c8;
        case 0x2c65ccu: goto label_2c65cc;
        case 0x2c65d0u: goto label_2c65d0;
        case 0x2c65d4u: goto label_2c65d4;
        case 0x2c65d8u: goto label_2c65d8;
        case 0x2c65dcu: goto label_2c65dc;
        case 0x2c65e0u: goto label_2c65e0;
        case 0x2c65e4u: goto label_2c65e4;
        case 0x2c65e8u: goto label_2c65e8;
        case 0x2c65ecu: goto label_2c65ec;
        case 0x2c65f0u: goto label_2c65f0;
        case 0x2c65f4u: goto label_2c65f4;
        case 0x2c65f8u: goto label_2c65f8;
        case 0x2c65fcu: goto label_2c65fc;
        case 0x2c6600u: goto label_2c6600;
        case 0x2c6604u: goto label_2c6604;
        case 0x2c6608u: goto label_2c6608;
        case 0x2c660cu: goto label_2c660c;
        case 0x2c6610u: goto label_2c6610;
        case 0x2c6614u: goto label_2c6614;
        case 0x2c6618u: goto label_2c6618;
        case 0x2c661cu: goto label_2c661c;
        case 0x2c6620u: goto label_2c6620;
        case 0x2c6624u: goto label_2c6624;
        case 0x2c6628u: goto label_2c6628;
        case 0x2c662cu: goto label_2c662c;
        case 0x2c6630u: goto label_2c6630;
        case 0x2c6634u: goto label_2c6634;
        case 0x2c6638u: goto label_2c6638;
        case 0x2c663cu: goto label_2c663c;
        case 0x2c6640u: goto label_2c6640;
        case 0x2c6644u: goto label_2c6644;
        case 0x2c6648u: goto label_2c6648;
        case 0x2c664cu: goto label_2c664c;
        case 0x2c6650u: goto label_2c6650;
        case 0x2c6654u: goto label_2c6654;
        case 0x2c6658u: goto label_2c6658;
        case 0x2c665cu: goto label_2c665c;
        case 0x2c6660u: goto label_2c6660;
        case 0x2c6664u: goto label_2c6664;
        case 0x2c6668u: goto label_2c6668;
        case 0x2c666cu: goto label_2c666c;
        case 0x2c6670u: goto label_2c6670;
        case 0x2c6674u: goto label_2c6674;
        case 0x2c6678u: goto label_2c6678;
        case 0x2c667cu: goto label_2c667c;
        case 0x2c6680u: goto label_2c6680;
        case 0x2c6684u: goto label_2c6684;
        case 0x2c6688u: goto label_2c6688;
        case 0x2c668cu: goto label_2c668c;
        case 0x2c6690u: goto label_2c6690;
        case 0x2c6694u: goto label_2c6694;
        case 0x2c6698u: goto label_2c6698;
        case 0x2c669cu: goto label_2c669c;
        case 0x2c66a0u: goto label_2c66a0;
        case 0x2c66a4u: goto label_2c66a4;
        case 0x2c66a8u: goto label_2c66a8;
        case 0x2c66acu: goto label_2c66ac;
        case 0x2c66b0u: goto label_2c66b0;
        case 0x2c66b4u: goto label_2c66b4;
        case 0x2c66b8u: goto label_2c66b8;
        case 0x2c66bcu: goto label_2c66bc;
        case 0x2c66c0u: goto label_2c66c0;
        case 0x2c66c4u: goto label_2c66c4;
        case 0x2c66c8u: goto label_2c66c8;
        case 0x2c66ccu: goto label_2c66cc;
        case 0x2c66d0u: goto label_2c66d0;
        case 0x2c66d4u: goto label_2c66d4;
        case 0x2c66d8u: goto label_2c66d8;
        case 0x2c66dcu: goto label_2c66dc;
        case 0x2c66e0u: goto label_2c66e0;
        case 0x2c66e4u: goto label_2c66e4;
        case 0x2c66e8u: goto label_2c66e8;
        case 0x2c66ecu: goto label_2c66ec;
        case 0x2c66f0u: goto label_2c66f0;
        case 0x2c66f4u: goto label_2c66f4;
        case 0x2c66f8u: goto label_2c66f8;
        case 0x2c66fcu: goto label_2c66fc;
        case 0x2c6700u: goto label_2c6700;
        case 0x2c6704u: goto label_2c6704;
        case 0x2c6708u: goto label_2c6708;
        case 0x2c670cu: goto label_2c670c;
        case 0x2c6710u: goto label_2c6710;
        case 0x2c6714u: goto label_2c6714;
        case 0x2c6718u: goto label_2c6718;
        case 0x2c671cu: goto label_2c671c;
        case 0x2c6720u: goto label_2c6720;
        case 0x2c6724u: goto label_2c6724;
        case 0x2c6728u: goto label_2c6728;
        case 0x2c672cu: goto label_2c672c;
        case 0x2c6730u: goto label_2c6730;
        case 0x2c6734u: goto label_2c6734;
        case 0x2c6738u: goto label_2c6738;
        case 0x2c673cu: goto label_2c673c;
        case 0x2c6740u: goto label_2c6740;
        case 0x2c6744u: goto label_2c6744;
        case 0x2c6748u: goto label_2c6748;
        case 0x2c674cu: goto label_2c674c;
        case 0x2c6750u: goto label_2c6750;
        case 0x2c6754u: goto label_2c6754;
        case 0x2c6758u: goto label_2c6758;
        case 0x2c675cu: goto label_2c675c;
        case 0x2c6760u: goto label_2c6760;
        case 0x2c6764u: goto label_2c6764;
        case 0x2c6768u: goto label_2c6768;
        case 0x2c676cu: goto label_2c676c;
        case 0x2c6770u: goto label_2c6770;
        case 0x2c6774u: goto label_2c6774;
        case 0x2c6778u: goto label_2c6778;
        case 0x2c677cu: goto label_2c677c;
        case 0x2c6780u: goto label_2c6780;
        case 0x2c6784u: goto label_2c6784;
        case 0x2c6788u: goto label_2c6788;
        case 0x2c678cu: goto label_2c678c;
        case 0x2c6790u: goto label_2c6790;
        case 0x2c6794u: goto label_2c6794;
        case 0x2c6798u: goto label_2c6798;
        case 0x2c679cu: goto label_2c679c;
        case 0x2c67a0u: goto label_2c67a0;
        case 0x2c67a4u: goto label_2c67a4;
        case 0x2c67a8u: goto label_2c67a8;
        case 0x2c67acu: goto label_2c67ac;
        case 0x2c67b0u: goto label_2c67b0;
        case 0x2c67b4u: goto label_2c67b4;
        case 0x2c67b8u: goto label_2c67b8;
        case 0x2c67bcu: goto label_2c67bc;
        case 0x2c67c0u: goto label_2c67c0;
        case 0x2c67c4u: goto label_2c67c4;
        case 0x2c67c8u: goto label_2c67c8;
        case 0x2c67ccu: goto label_2c67cc;
        case 0x2c67d0u: goto label_2c67d0;
        case 0x2c67d4u: goto label_2c67d4;
        case 0x2c67d8u: goto label_2c67d8;
        case 0x2c67dcu: goto label_2c67dc;
        case 0x2c67e0u: goto label_2c67e0;
        case 0x2c67e4u: goto label_2c67e4;
        default: break;
    }

    ctx->pc = 0x2c63e8u;

label_2c63e8:
    // 0x2c63e8: 0x24a2270f  addiu       $v0, $a1, 0x270F
    ctx->pc = 0x2c63e8u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 5), 9999));
label_2c63ec:
    // 0x2c63ec: 0x3e00008  jr          $ra
label_2c63f0:
    if (ctx->pc == 0x2C63F0u) {
        ctx->pc = 0x2C63F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C63ECu;
        // 0x2c63f0: 0x2c422706  sltiu       $v0, $v0, 0x2706 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 2) < (uint64_t)(int64_t)(int32_t)9990) ? 1 : 0);
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C63F4u;
        goto label_2c63f4;
    }
    ctx->pc = 0x2C63ECu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C63F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C63ECu;
        // 0x2c63f0: 0x2c422706  sltiu       $v0, $v0, 0x2706 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 2) < (uint64_t)(int64_t)(int32_t)9990) ? 1 : 0);
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C63ECu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C63F4u;
label_2c63f4:
    // 0x2c63f4: 0x0  nop
    ctx->pc = 0x2c63f4u;
    // NOP
label_2c63f8:
    // 0x2c63f8: 0x27bdff90  addiu       $sp, $sp, -0x70
    ctx->pc = 0x2c63f8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967184));
label_2c63fc:
    // 0x2c63fc: 0x7fb00060  sq          $s0, 0x60($sp)
    ctx->pc = 0x2c63fcu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 96), GPR_VEC(ctx, 16));
label_2c6400:
    // 0x2c6400: 0x3a0202d  daddu       $a0, $sp, $zero
    ctx->pc = 0x2c6400u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
label_2c6404:
    // 0x2c6404: 0xa0802d  daddu       $s0, $a1, $zero
    ctx->pc = 0x2c6404u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_2c6408:
    // 0x2c6408: 0x7fb30030  sq          $s3, 0x30($sp)
    ctx->pc = 0x2c6408u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 48), GPR_VEC(ctx, 19));
label_2c640c:
    // 0x2c640c: 0x3c05004a  lui         $a1, 0x4A
    ctx->pc = 0x2c640cu;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)74 << 16));
label_2c6410:
    // 0x2c6410: 0x7fb20040  sq          $s2, 0x40($sp)
    ctx->pc = 0x2c6410u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 64), GPR_VEC(ctx, 18));
label_2c6414:
    // 0x2c6414: 0x7fb10050  sq          $s1, 0x50($sp)
    ctx->pc = 0x2c6414u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 80), GPR_VEC(ctx, 17));
label_2c6418:
    // 0x2c6418: 0xc0982d  daddu       $s3, $a2, $zero
    ctx->pc = 0x2c6418u;
    SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
label_2c641c:
    // 0x2c641c: 0xffbf0020  sd          $ra, 0x20($sp)
    ctx->pc = 0x2c641cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 32), GPR_U64(ctx, 31));
label_2c6420:
    // 0x2c6420: 0xc0b0950  jal         func_2C2540
label_2c6424:
    if (ctx->pc == 0x2C6424u) {
        ctx->pc = 0x2C6424u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6420u;
        // 0x2c6424: 0x24a53970  addiu       $a1, $a1, 0x3970 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 14704));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6428u;
        goto label_2c6428;
    }
    ctx->pc = 0x2C6420u;
    SET_GPR_U32(ctx, 31, 0x2C6428u);
    ctx->pc = 0x2C6424u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2C6420u;
    // 0x2c6424: 0x24a53970  addiu       $a1, $a1, 0x3970 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 14704));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2540u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2540u, 0x2C6420u, 0x2C6428u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2C6428u;
label_2c6428:
    // 0x2c6428: 0x27b20010  addiu       $s2, $sp, 0x10
    ctx->pc = 0x2c6428u;
    SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
label_2c642c:
    // 0x2c642c: 0x3a0282d  daddu       $a1, $sp, $zero
    ctx->pc = 0x2c642cu;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 29) + (uint64_t)GPR_U64(ctx, 0));
label_2c6430:
    // 0x2c6430: 0x240202d  daddu       $a0, $s2, $zero
    ctx->pc = 0x2c6430u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_2c6434:
    // 0x2c6434: 0xc0b09b4  jal         func_2C26D0
label_2c6438:
    if (ctx->pc == 0x2C6438u) {
        ctx->pc = 0x2C6438u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6434u;
        // 0x2c6438: 0x26060001  addiu       $a2, $s0, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 16), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C643Cu;
        goto label_2c643c;
    }
    ctx->pc = 0x2C6434u;
    SET_GPR_U32(ctx, 31, 0x2C643Cu);
    ctx->pc = 0x2C6438u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2C6434u;
    // 0x2c6438: 0x26060001  addiu       $a2, $s0, 0x1 (Delay Slot)
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 16), 1));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C26D0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C26D0u, 0x2C6434u, 0x2C643Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2C643Cu;
label_2c643c:
    // 0x2c643c: 0x2a020002  slti        $v0, $s0, 0x2
    ctx->pc = 0x2c643cu;
    SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 16) < (int64_t)(int32_t)2) ? 1 : 0);
label_2c6440:
    // 0x2c6440: 0x50400013  beql        $v0, $zero, . + 4 + (0x13 << 2)
label_2c6444:
    if (ctx->pc == 0x2C6444u) {
        ctx->pc = 0x2C6444u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6440u;
        // 0x2c6444: 0x7bb00060  lq          $s0, 0x60($sp) (Delay Slot)
        SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 96)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6448u;
        goto label_2c6448;
    }
    ctx->pc = 0x2C6440u;
    {
        const bool branch_taken_0x2c6440 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x2c6440) {
            ctx->pc = 0x2C6444u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C6440u;
            // 0x2c6444: 0x7bb00060  lq          $s0, 0x60($sp) (Delay Slot)
            SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 96)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C6490u;
            goto label_2c6490;
        }
    }
    ctx->pc = 0x2C6448u;
label_2c6448:
    // 0x2c6448: 0x6000010  bltz        $s0, . + 4 + (0x10 << 2)
label_2c644c:
    if (ctx->pc == 0x2C644Cu) {
        ctx->pc = 0x2C644Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6448u;
        // 0x2c644c: 0x8f82f7b8  lw          $v0, -0x848($gp) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294965176)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6450u;
        goto label_2c6450;
    }
    ctx->pc = 0x2C6448u;
    {
        const bool branch_taken_0x2c6448 = (GPR_S32(ctx, 16) < 0);
        ctx->pc = 0x2C644Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6448u;
        // 0x2c644c: 0x8f82f7b8  lw          $v0, -0x848($gp) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 4294965176)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c6448) {
            ctx->pc = 0x2C648Cu;
            goto label_2c648c;
        }
    }
    ctx->pc = 0x2C6450u;
label_2c6450:
    // 0x2c6450: 0x3c040048  lui         $a0, 0x48
    ctx->pc = 0x2c6450u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)72 << 16));
label_2c6454:
    // 0x2c6454: 0x248464e8  addiu       $a0, $a0, 0x64E8
    ctx->pc = 0x2c6454u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 25832));
label_2c6458:
    // 0x2c6458: 0x8c50008c  lw          $s0, 0x8C($v0)
    ctx->pc = 0x2c6458u;
    SET_GPR_S32(ctx, 16, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 140)));
label_2c645c:
    // 0x2c645c: 0x8e110004  lw          $s1, 0x4($s0)
    ctx->pc = 0x2c645cu;
    SET_GPR_S32(ctx, 17, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 4)));
label_2c6460:
    // 0x2c6460: 0x86220020  lh          $v0, 0x20($s1)
    ctx->pc = 0x2c6460u;
    SET_GPR_S32(ctx, 2, (int16_t)READ16(ADD32(GPR_U32(ctx, 17), 32)));
label_2c6464:
    // 0x2c6464: 0xc0c5d9c  jal         func_317670
label_2c6468:
    if (ctx->pc == 0x2C6468u) {
        ctx->pc = 0x2C6468u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6464u;
        // 0x2c6468: 0x2028021  addu        $s0, $s0, $v0 (Delay Slot)
        SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 2)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C646Cu;
        goto label_2c646c;
    }
    ctx->pc = 0x2C6464u;
    SET_GPR_U32(ctx, 31, 0x2C646Cu);
    ctx->pc = 0x2C6468u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2C6464u;
    // 0x2c6468: 0x2028021  addu        $s0, $s0, $v0 (Delay Slot)
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 2)));
    ctx->in_delay_slot = false;
    ctx->pc = 0x317670u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x317670u, 0x2C6464u, 0x2C646Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2C646Cu;
label_2c646c:
    // 0x2c646c: 0x8e230024  lw          $v1, 0x24($s1)
    ctx->pc = 0x2c646cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 36)));
label_2c6470:
    // 0x2c6470: 0x200202d  daddu       $a0, $s0, $zero
    ctx->pc = 0x2c6470u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2c6474:
    // 0x2c6474: 0x60f809  jalr        $v1
label_2c6478:
    if (ctx->pc == 0x2C6478u) {
        ctx->pc = 0x2C6478u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6474u;
        // 0x2c6478: 0x40282d  daddu       $a1, $v0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C647Cu;
        goto label_2c647c;
    }
    ctx->pc = 0x2C6474u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x2C647Cu);
        ctx->pc = 0x2C6478u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6474u;
        // 0x2c6478: 0x40282d  daddu       $a1, $v0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6474u, 0x2C647Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2C647Cu;
label_2c647c:
    // 0x2c647c: 0x260202d  daddu       $a0, $s3, $zero
    ctx->pc = 0x2c647cu;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
label_2c6480:
    // 0x2c6480: 0x40282d  daddu       $a1, $v0, $zero
    ctx->pc = 0x2c6480u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_2c6484:
    // 0x2c6484: 0xc0b09b4  jal         func_2C26D0
label_2c6488:
    if (ctx->pc == 0x2C6488u) {
        ctx->pc = 0x2C6488u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6484u;
        // 0x2c6488: 0x240302d  daddu       $a2, $s2, $zero (Delay Slot)
        SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C648Cu;
        goto label_2c648c;
    }
    ctx->pc = 0x2C6484u;
    SET_GPR_U32(ctx, 31, 0x2C648Cu);
    ctx->pc = 0x2C6488u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2C6484u;
    // 0x2c6488: 0x240302d  daddu       $a2, $s2, $zero (Delay Slot)
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C26D0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C26D0u, 0x2C6484u, 0x2C648Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2C648Cu;
label_2c648c:
    // 0x2c648c: 0x7bb00060  lq          $s0, 0x60($sp)
    ctx->pc = 0x2c648cu;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 96)));
label_2c6490:
    // 0x2c6490: 0x7bb10050  lq          $s1, 0x50($sp)
    ctx->pc = 0x2c6490u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 80)));
label_2c6494:
    // 0x2c6494: 0x7bb20040  lq          $s2, 0x40($sp)
    ctx->pc = 0x2c6494u;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 64)));
label_2c6498:
    // 0x2c6498: 0x7bb30030  lq          $s3, 0x30($sp)
    ctx->pc = 0x2c6498u;
    SET_GPR_VEC(ctx, 19, READ128(ADD32(GPR_U32(ctx, 29), 48)));
label_2c649c:
    // 0x2c649c: 0xdfbf0020  ld          $ra, 0x20($sp)
    ctx->pc = 0x2c649cu;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 32)));
label_2c64a0:
    // 0x2c64a0: 0x3e00008  jr          $ra
label_2c64a4:
    if (ctx->pc == 0x2C64A4u) {
        ctx->pc = 0x2C64A4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C64A0u;
        // 0x2c64a4: 0x27bd0070  addiu       $sp, $sp, 0x70 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 112));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C64A8u;
        goto label_2c64a8;
    }
    ctx->pc = 0x2C64A0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C64A4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C64A0u;
        // 0x2c64a4: 0x27bd0070  addiu       $sp, $sp, 0x70 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 112));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C64A0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C64A8u;
label_2c64a8:
    // 0x2c64a8: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2c64a8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2c64ac:
    // 0x2c64ac: 0x3c05004a  lui         $a1, 0x4A
    ctx->pc = 0x2c64acu;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)74 << 16));
label_2c64b0:
    // 0x2c64b0: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2c64b0u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2c64b4:
    // 0x2c64b4: 0xc0202d  daddu       $a0, $a2, $zero
    ctx->pc = 0x2c64b4u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
label_2c64b8:
    // 0x2c64b8: 0xc0b0950  jal         func_2C2540
label_2c64bc:
    if (ctx->pc == 0x2C64BCu) {
        ctx->pc = 0x2C64BCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C64B8u;
        // 0x2c64bc: 0x24a53968  addiu       $a1, $a1, 0x3968 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 14696));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C64C0u;
        goto label_2c64c0;
    }
    ctx->pc = 0x2C64B8u;
    SET_GPR_U32(ctx, 31, 0x2C64C0u);
    ctx->pc = 0x2C64BCu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2C64B8u;
    // 0x2c64bc: 0x24a53968  addiu       $a1, $a1, 0x3968 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 14696));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2540u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2540u, 0x2C64B8u, 0x2C64C0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2C64C0u;
label_2c64c0:
    // 0x2c64c0: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2c64c0u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2c64c4:
    // 0x2c64c4: 0x3e00008  jr          $ra
label_2c64c8:
    if (ctx->pc == 0x2C64C8u) {
        ctx->pc = 0x2C64C8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C64C4u;
        // 0x2c64c8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C64CCu;
        goto label_2c64cc;
    }
    ctx->pc = 0x2C64C4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C64C8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C64C4u;
        // 0x2c64c8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C64C4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C64CCu;
label_2c64cc:
    // 0x2c64cc: 0x0  nop
    ctx->pc = 0x2c64ccu;
    // NOP
label_2c64d0:
    // 0x2c64d0: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2c64d0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2c64d4:
    // 0x2c64d4: 0x3c05004a  lui         $a1, 0x4A
    ctx->pc = 0x2c64d4u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)74 << 16));
label_2c64d8:
    // 0x2c64d8: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2c64d8u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2c64dc:
    // 0x2c64dc: 0xc0202d  daddu       $a0, $a2, $zero
    ctx->pc = 0x2c64dcu;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
label_2c64e0:
    // 0x2c64e0: 0xc0b0950  jal         func_2C2540
label_2c64e4:
    if (ctx->pc == 0x2C64E4u) {
        ctx->pc = 0x2C64E4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C64E0u;
        // 0x2c64e4: 0x24a53968  addiu       $a1, $a1, 0x3968 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 14696));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C64E8u;
        goto label_2c64e8;
    }
    ctx->pc = 0x2C64E0u;
    SET_GPR_U32(ctx, 31, 0x2C64E8u);
    ctx->pc = 0x2C64E4u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2C64E0u;
    // 0x2c64e4: 0x24a53968  addiu       $a1, $a1, 0x3968 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 14696));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C2540u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C2540u, 0x2C64E0u, 0x2C64E8u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2C64E8u;
label_2c64e8:
    // 0x2c64e8: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2c64e8u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2c64ec:
    // 0x2c64ec: 0x3e00008  jr          $ra
label_2c64f0:
    if (ctx->pc == 0x2C64F0u) {
        ctx->pc = 0x2C64F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C64ECu;
        // 0x2c64f0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C64F4u;
        goto label_2c64f4;
    }
    ctx->pc = 0x2C64ECu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C64F0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C64ECu;
        // 0x2c64f0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C64ECu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C64F4u;
label_2c64f4:
    // 0x2c64f4: 0x0  nop
    ctx->pc = 0x2c64f4u;
    // NOP
label_2c64f8:
    // 0x2c64f8: 0x27bdff60  addiu       $sp, $sp, -0xA0
    ctx->pc = 0x2c64f8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967136));
label_2c64fc:
    // 0x2c64fc: 0x7fb10080  sq          $s1, 0x80($sp)
    ctx->pc = 0x2c64fcu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 128), GPR_VEC(ctx, 17));
label_2c6500:
    // 0x2c6500: 0x7fb30060  sq          $s3, 0x60($sp)
    ctx->pc = 0x2c6500u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 96), GPR_VEC(ctx, 19));
label_2c6504:
    // 0x2c6504: 0x80882d  daddu       $s1, $a0, $zero
    ctx->pc = 0x2c6504u;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2c6508:
    // 0x2c6508: 0x7fb00090  sq          $s0, 0x90($sp)
    ctx->pc = 0x2c6508u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 144), GPR_VEC(ctx, 16));
label_2c650c:
    // 0x2c650c: 0x2413ffff  addiu       $s3, $zero, -0x1
    ctx->pc = 0x2c650cu;
    SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
label_2c6510:
    // 0x2c6510: 0x7fb20070  sq          $s2, 0x70($sp)
    ctx->pc = 0x2c6510u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 112), GPR_VEC(ctx, 18));
label_2c6514:
    // 0x2c6514: 0x7fb40050  sq          $s4, 0x50($sp)
    ctx->pc = 0x2c6514u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 80), GPR_VEC(ctx, 20));
label_2c6518:
    // 0x2c6518: 0x7fb50040  sq          $s5, 0x40($sp)
    ctx->pc = 0x2c6518u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 64), GPR_VEC(ctx, 21));
label_2c651c:
    // 0x2c651c: 0x7fb60030  sq          $s6, 0x30($sp)
    ctx->pc = 0x2c651cu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 48), GPR_VEC(ctx, 22));
label_2c6520:
    // 0x2c6520: 0x7fb70020  sq          $s7, 0x20($sp)
    ctx->pc = 0x2c6520u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 23));
label_2c6524:
    // 0x2c6524: 0x7fbe0010  sq          $fp, 0x10($sp)
    ctx->pc = 0x2c6524u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 30));
label_2c6528:
    // 0x2c6528: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2c6528u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2c652c:
    // 0x2c652c: 0x8e230000  lw          $v1, 0x0($s1)
    ctx->pc = 0x2c652cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 0)));
label_2c6530:
    // 0x2c6530: 0x846401b8  lh          $a0, 0x1B8($v1)
    ctx->pc = 0x2c6530u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 440)));
label_2c6534:
    // 0x2c6534: 0x8c6201bc  lw          $v0, 0x1BC($v1)
    ctx->pc = 0x2c6534u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 444)));
label_2c6538:
    // 0x2c6538: 0x40f809  jalr        $v0
label_2c653c:
    if (ctx->pc == 0x2C653Cu) {
        ctx->pc = 0x2C653Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6538u;
        // 0x2c653c: 0x2242021  addu        $a0, $s1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 17), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6540u;
        goto label_2c6540;
    }
    ctx->pc = 0x2C6538u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2C6540u);
        ctx->pc = 0x2C653Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6538u;
        // 0x2c653c: 0x2242021  addu        $a0, $s1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 17), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6538u, 0x2C6540u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2C6540u;
label_2c6540:
    // 0x2c6540: 0x14400003  bnez        $v0, . + 4 + (0x3 << 2)
label_2c6544:
    if (ctx->pc == 0x2C6544u) {
        ctx->pc = 0x2C6544u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6540u;
        // 0x2c6544: 0x902d  daddu       $s2, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 18, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6548u;
        goto label_2c6548;
    }
    ctx->pc = 0x2C6540u;
    {
        const bool branch_taken_0x2c6540 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x2C6544u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6540u;
        // 0x2c6544: 0x902d  daddu       $s2, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 18, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c6540) {
            ctx->pc = 0x2C6550u;
            goto label_2c6550;
        }
    }
    ctx->pc = 0x2C6548u;
label_2c6548:
    // 0x2c6548: 0x1000004f  b           . + 4 + (0x4F << 2)
label_2c654c:
    if (ctx->pc == 0x2C654Cu) {
        ctx->pc = 0x2C654Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6548u;
        // 0x2c654c: 0x2402ffff  addiu       $v0, $zero, -0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6550u;
        goto label_2c6550;
    }
    ctx->pc = 0x2C6548u;
    {
        const bool branch_taken_0x2c6548 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x2C654Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6548u;
        // 0x2c654c: 0x2402ffff  addiu       $v0, $zero, -0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c6548) {
            ctx->pc = 0x2C6688u;
            goto label_2c6688;
        }
    }
    ctx->pc = 0x2C6550u;
label_2c6550:
    // 0x2c6550: 0x241e0078  addiu       $fp, $zero, 0x78
    ctx->pc = 0x2c6550u;
    SET_GPR_S32(ctx, 30, (int32_t)ADD32(GPR_U32(ctx, 0), 120));
label_2c6554:
    // 0x2c6554: 0x24170e10  addiu       $s7, $zero, 0xE10
    ctx->pc = 0x2c6554u;
    SET_GPR_S32(ctx, 23, (int32_t)ADD32(GPR_U32(ctx, 0), 3600));
label_2c6558:
    // 0x2c6558: 0x2416003c  addiu       $s6, $zero, 0x3C
    ctx->pc = 0x2c6558u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 0), 60));
label_2c655c:
    // 0x2c655c: 0x220802d  daddu       $s0, $s1, $zero
    ctx->pc = 0x2c655cu;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_2c6560:
    // 0x2c6560: 0x263401a4  addiu       $s4, $s1, 0x1A4
    ctx->pc = 0x2c6560u;
    SET_GPR_S32(ctx, 20, (int32_t)ADD32(GPR_U32(ctx, 17), 420));
label_2c6564:
    // 0x2c6564: 0xa82d  daddu       $s5, $zero, $zero
    ctx->pc = 0x2c6564u;
    SET_GPR_U64(ctx, 21, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_2c6568:
    // 0x2c6568: 0x8e820000  lw          $v0, 0x0($s4)
    ctx->pc = 0x2c6568u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 20), 0)));
label_2c656c:
    // 0x2c656c: 0x54400040  bnel        $v0, $zero, . + 4 + (0x40 << 2)
label_2c6570:
    if (ctx->pc == 0x2C6570u) {
        ctx->pc = 0x2C6570u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C656Cu;
        // 0x2c6570: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6574u;
        goto label_2c6574;
    }
    ctx->pc = 0x2C656Cu;
    {
        const bool branch_taken_0x2c656c = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c656c) {
            ctx->pc = 0x2C6570u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C656Cu;
            // 0x2c6570: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
            SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C6670u;
            goto label_2c6670;
        }
    }
    ctx->pc = 0x2C6574u;
label_2c6574:
    // 0x2c6574: 0x2351021  addu        $v0, $s1, $s5
    ctx->pc = 0x2c6574u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 17), GPR_U32(ctx, 21)));
label_2c6578:
    // 0x2c6578: 0x8c4301a8  lw          $v1, 0x1A8($v0)
    ctx->pc = 0x2c6578u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 424)));
label_2c657c:
    // 0x2c657c: 0x5460003c  bnel        $v1, $zero, . + 4 + (0x3C << 2)
label_2c6580:
    if (ctx->pc == 0x2C6580u) {
        ctx->pc = 0x2C6580u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C657Cu;
        // 0x2c6580: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6584u;
        goto label_2c6584;
    }
    ctx->pc = 0x2C657Cu;
    {
        const bool branch_taken_0x2c657c = (GPR_U64(ctx, 3) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c657c) {
            ctx->pc = 0x2C6580u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C657Cu;
            // 0x2c6580: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
            SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C6670u;
            goto label_2c6670;
        }
    }
    ctx->pc = 0x2C6584u;
label_2c6584:
    // 0x2c6584: 0x8e230000  lw          $v1, 0x0($s1)
    ctx->pc = 0x2c6584u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 0)));
label_2c6588:
    // 0x2c6588: 0x240282d  daddu       $a1, $s2, $zero
    ctx->pc = 0x2c6588u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_2c658c:
    // 0x2c658c: 0x84640218  lh          $a0, 0x218($v1)
    ctx->pc = 0x2c658cu;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 536)));
label_2c6590:
    // 0x2c6590: 0x8c62021c  lw          $v0, 0x21C($v1)
    ctx->pc = 0x2c6590u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 540)));
label_2c6594:
    // 0x2c6594: 0x40f809  jalr        $v0
label_2c6598:
    if (ctx->pc == 0x2C6598u) {
        ctx->pc = 0x2C6598u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6594u;
        // 0x2c6598: 0x2242021  addu        $a0, $s1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 17), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C659Cu;
        goto label_2c659c;
    }
    ctx->pc = 0x2C6594u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2C659Cu);
        ctx->pc = 0x2C6598u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6594u;
        // 0x2c6598: 0x2242021  addu        $a0, $s1, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 17), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6594u, 0x2C659Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2C659Cu;
label_2c659c:
    // 0x2c659c: 0x10400033  beqz        $v0, . + 4 + (0x33 << 2)
label_2c65a0:
    if (ctx->pc == 0x2C65A0u) {
        ctx->pc = 0x2C65A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C659Cu;
        // 0x2c65a0: 0x2351021  addu        $v0, $s1, $s5 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 17), GPR_U32(ctx, 21)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C65A4u;
        goto label_2c65a4;
    }
    ctx->pc = 0x2C659Cu;
    {
        const bool branch_taken_0x2c659c = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x2C65A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C659Cu;
        // 0x2c65a0: 0x2351021  addu        $v0, $s1, $s5 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 17), GPR_U32(ctx, 21)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c659c) {
            ctx->pc = 0x2C666Cu;
            goto label_2c666c;
        }
    }
    ctx->pc = 0x2C65A4u;
label_2c65a4:
    // 0x2c65a4: 0x8c4301ac  lw          $v1, 0x1AC($v0)
    ctx->pc = 0x2c65a4u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 428)));
label_2c65a8:
    // 0x2c65a8: 0x54600031  bnel        $v1, $zero, . + 4 + (0x31 << 2)
label_2c65ac:
    if (ctx->pc == 0x2C65ACu) {
        ctx->pc = 0x2C65ACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C65A8u;
        // 0x2c65ac: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C65B0u;
        goto label_2c65b0;
    }
    ctx->pc = 0x2C65A8u;
    {
        const bool branch_taken_0x2c65a8 = (GPR_U64(ctx, 3) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c65a8) {
            ctx->pc = 0x2C65ACu;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C65A8u;
            // 0x2c65ac: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
            SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C6670u;
            goto label_2c6670;
        }
    }
    ctx->pc = 0x2C65B0u;
label_2c65b0:
    // 0x2c65b0: 0x2402ffff  addiu       $v0, $zero, -0x1
    ctx->pc = 0x2c65b0u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
label_2c65b4:
    // 0x2c65b4: 0x1262002c  beq         $s3, $v0, . + 4 + (0x2C << 2)
label_2c65b8:
    if (ctx->pc == 0x2C65B8u) {
        ctx->pc = 0x2C65B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C65B4u;
        // 0x2c65b8: 0x27e1018  mult        $v0, $s3, $fp (Delay Slot)
        { int64_t result = (int64_t)GPR_S32(ctx, 19) * (int64_t)GPR_S32(ctx, 30); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 2, (int32_t)result); }
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C65BCu;
        goto label_2c65bc;
    }
    ctx->pc = 0x2C65B4u;
    {
        const bool branch_taken_0x2c65b4 = (GPR_U64(ctx, 19) == GPR_U64(ctx, 2));
        ctx->pc = 0x2C65B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C65B4u;
        // 0x2c65b8: 0x27e1018  mult        $v0, $s3, $fp (Delay Slot)
        { int64_t result = (int64_t)GPR_S32(ctx, 19) * (int64_t)GPR_S32(ctx, 30); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 2, (int32_t)result); }
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c65b4) {
            ctx->pc = 0x2C6668u;
            goto label_2c6668;
        }
    }
    ctx->pc = 0x2C65BCu;
label_2c65bc:
    // 0x2c65bc: 0x92060215  lbu         $a2, 0x215($s0)
    ctx->pc = 0x2c65bcu;
    SET_GPR_U32(ctx, 6, (uint8_t)READ8(ADD32(GPR_U32(ctx, 16), 533)));
label_2c65c0:
    // 0x2c65c0: 0x92050214  lbu         $a1, 0x214($s0)
    ctx->pc = 0x2c65c0u;
    SET_GPR_U32(ctx, 5, (uint8_t)READ8(ADD32(GPR_U32(ctx, 16), 532)));
label_2c65c4:
    // 0x2c65c4: 0xd73018  mult        $a2, $a2, $s7
    ctx->pc = 0x2c65c4u;
    { int64_t result = (int64_t)GPR_S32(ctx, 6) * (int64_t)GPR_S32(ctx, 23); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 6, (int32_t)result); }
label_2c65c8:
    // 0x2c65c8: 0x960a0218  lhu         $t2, 0x218($s0)
    ctx->pc = 0x2c65c8u;
    SET_GPR_U32(ctx, 10, (uint16_t)READ16(ADD32(GPR_U32(ctx, 16), 536)));
label_2c65cc:
    // 0x2c65cc: 0xb62818  mult        $a1, $a1, $s6
    ctx->pc = 0x2c65ccu;
    { int64_t result = (int64_t)GPR_S32(ctx, 5) * (int64_t)GPR_S32(ctx, 22); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 5, (int32_t)result); }
label_2c65d0:
    // 0x2c65d0: 0x920c0216  lbu         $t4, 0x216($s0)
    ctx->pc = 0x2c65d0u;
    SET_GPR_U32(ctx, 12, (uint8_t)READ8(ADD32(GPR_U32(ctx, 16), 534)));
label_2c65d4:
    // 0x2c65d4: 0x512021  addu        $a0, $v0, $s1
    ctx->pc = 0x2c65d4u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 2), GPR_U32(ctx, 17)));
label_2c65d8:
    // 0x2c65d8: 0x90820215  lbu         $v0, 0x215($a0)
    ctx->pc = 0x2c65d8u;
    SET_GPR_U32(ctx, 2, (uint8_t)READ8(ADD32(GPR_U32(ctx, 4), 533)));
label_2c65dc:
    // 0x2c65dc: 0x90830214  lbu         $v1, 0x214($a0)
    ctx->pc = 0x2c65dcu;
    SET_GPR_U32(ctx, 3, (uint8_t)READ8(ADD32(GPR_U32(ctx, 4), 532)));
label_2c65e0:
    // 0x2c65e0: 0x571018  mult        $v0, $v0, $s7
    ctx->pc = 0x2c65e0u;
    { int64_t result = (int64_t)GPR_S32(ctx, 2) * (int64_t)GPR_S32(ctx, 23); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 2, (int32_t)result); }
label_2c65e4:
    // 0x2c65e4: 0xc53021  addu        $a2, $a2, $a1
    ctx->pc = 0x2c65e4u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 5)));
label_2c65e8:
    // 0x2c65e8: 0x761818  mult        $v1, $v1, $s6
    ctx->pc = 0x2c65e8u;
    { int64_t result = (int64_t)GPR_S32(ctx, 3) * (int64_t)GPR_S32(ctx, 22); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 3, (int32_t)result); }
label_2c65ec:
    // 0x2c65ec: 0x90850213  lbu         $a1, 0x213($a0)
    ctx->pc = 0x2c65ecu;
    SET_GPR_U32(ctx, 5, (uint8_t)READ8(ADD32(GPR_U32(ctx, 4), 531)));
label_2c65f0:
    // 0x2c65f0: 0x94880218  lhu         $t0, 0x218($a0)
    ctx->pc = 0x2c65f0u;
    SET_GPR_U32(ctx, 8, (uint16_t)READ16(ADD32(GPR_U32(ctx, 4), 536)));
label_2c65f4:
    // 0x2c65f4: 0x908b0216  lbu         $t3, 0x216($a0)
    ctx->pc = 0x2c65f4u;
    SET_GPR_U32(ctx, 11, (uint8_t)READ8(ADD32(GPR_U32(ctx, 4), 534)));
label_2c65f8:
    // 0x2c65f8: 0xc53021  addu        $a2, $a2, $a1
    ctx->pc = 0x2c65f8u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 5)));
label_2c65fc:
    // 0x2c65fc: 0x90890217  lbu         $t1, 0x217($a0)
    ctx->pc = 0x2c65fcu;
    SET_GPR_U32(ctx, 9, (uint8_t)READ8(ADD32(GPR_U32(ctx, 4), 535)));
label_2c6600:
    // 0x2c6600: 0x148382b  sltu        $a3, $t2, $t0
    ctx->pc = 0x2c6600u;
    SET_GPR_U64(ctx, 7, ((uint64_t)GPR_U64(ctx, 10) < (uint64_t)GPR_U64(ctx, 8)) ? 1 : 0);
label_2c6604:
    // 0x2c6604: 0x431021  addu        $v0, $v0, $v1
    ctx->pc = 0x2c6604u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), GPR_U32(ctx, 3)));
label_2c6608:
    // 0x2c6608: 0x92040217  lbu         $a0, 0x217($s0)
    ctx->pc = 0x2c6608u;
    SET_GPR_U32(ctx, 4, (uint8_t)READ8(ADD32(GPR_U32(ctx, 16), 535)));
label_2c660c:
    // 0x2c660c: 0x14e00017  bnez        $a3, . + 4 + (0x17 << 2)
label_2c6610:
    if (ctx->pc == 0x2C6610u) {
        ctx->pc = 0x2C6610u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C660Cu;
        // 0x2c6610: 0x451821  addu        $v1, $v0, $a1 (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 2), GPR_U32(ctx, 5)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6614u;
        goto label_2c6614;
    }
    ctx->pc = 0x2C660Cu;
    {
        const bool branch_taken_0x2c660c = (GPR_U64(ctx, 7) != GPR_U64(ctx, 0));
        ctx->pc = 0x2C6610u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C660Cu;
        // 0x2c6610: 0x451821  addu        $v1, $v0, $a1 (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 2), GPR_U32(ctx, 5)));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c660c) {
            ctx->pc = 0x2C666Cu;
            goto label_2c666c;
        }
    }
    ctx->pc = 0x2C6614u;
label_2c6614:
    // 0x2c6614: 0x10a102b  sltu        $v0, $t0, $t2
    ctx->pc = 0x2c6614u;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 8) < (uint64_t)GPR_U64(ctx, 10)) ? 1 : 0);
label_2c6618:
    // 0x2c6618: 0x54400014  bnel        $v0, $zero, . + 4 + (0x14 << 2)
label_2c661c:
    if (ctx->pc == 0x2C661Cu) {
        ctx->pc = 0x2C661Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6618u;
        // 0x2c661c: 0x240982d  daddu       $s3, $s2, $zero (Delay Slot)
        SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6620u;
        goto label_2c6620;
    }
    ctx->pc = 0x2C6618u;
    {
        const bool branch_taken_0x2c6618 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c6618) {
            ctx->pc = 0x2C661Cu;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C6618u;
            // 0x2c661c: 0x240982d  daddu       $s3, $s2, $zero (Delay Slot)
            SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C666Cu;
            goto label_2c666c;
        }
    }
    ctx->pc = 0x2C6620u;
label_2c6620:
    // 0x2c6620: 0x89102b  sltu        $v0, $a0, $t1
    ctx->pc = 0x2c6620u;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 4) < (uint64_t)GPR_U64(ctx, 9)) ? 1 : 0);
label_2c6624:
    // 0x2c6624: 0x54400012  bnel        $v0, $zero, . + 4 + (0x12 << 2)
label_2c6628:
    if (ctx->pc == 0x2C6628u) {
        ctx->pc = 0x2C6628u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6624u;
        // 0x2c6628: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C662Cu;
        goto label_2c662c;
    }
    ctx->pc = 0x2C6624u;
    {
        const bool branch_taken_0x2c6624 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c6624) {
            ctx->pc = 0x2C6628u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C6624u;
            // 0x2c6628: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
            SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C6670u;
            goto label_2c6670;
        }
    }
    ctx->pc = 0x2C662Cu;
label_2c662c:
    // 0x2c662c: 0x124102b  sltu        $v0, $t1, $a0
    ctx->pc = 0x2c662cu;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 9) < (uint64_t)GPR_U64(ctx, 4)) ? 1 : 0);
label_2c6630:
    // 0x2c6630: 0x5440000e  bnel        $v0, $zero, . + 4 + (0xE << 2)
label_2c6634:
    if (ctx->pc == 0x2C6634u) {
        ctx->pc = 0x2C6634u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6630u;
        // 0x2c6634: 0x240982d  daddu       $s3, $s2, $zero (Delay Slot)
        SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6638u;
        goto label_2c6638;
    }
    ctx->pc = 0x2C6630u;
    {
        const bool branch_taken_0x2c6630 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c6630) {
            ctx->pc = 0x2C6634u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C6630u;
            // 0x2c6634: 0x240982d  daddu       $s3, $s2, $zero (Delay Slot)
            SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C666Cu;
            goto label_2c666c;
        }
    }
    ctx->pc = 0x2C6638u;
label_2c6638:
    // 0x2c6638: 0x18b102b  sltu        $v0, $t4, $t3
    ctx->pc = 0x2c6638u;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 12) < (uint64_t)GPR_U64(ctx, 11)) ? 1 : 0);
label_2c663c:
    // 0x2c663c: 0x5440000c  bnel        $v0, $zero, . + 4 + (0xC << 2)
label_2c6640:
    if (ctx->pc == 0x2C6640u) {
        ctx->pc = 0x2C6640u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C663Cu;
        // 0x2c6640: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6644u;
        goto label_2c6644;
    }
    ctx->pc = 0x2C663Cu;
    {
        const bool branch_taken_0x2c663c = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c663c) {
            ctx->pc = 0x2C6640u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C663Cu;
            // 0x2c6640: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
            SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C6670u;
            goto label_2c6670;
        }
    }
    ctx->pc = 0x2C6644u;
label_2c6644:
    // 0x2c6644: 0x16c102b  sltu        $v0, $t3, $t4
    ctx->pc = 0x2c6644u;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 11) < (uint64_t)GPR_U64(ctx, 12)) ? 1 : 0);
label_2c6648:
    // 0x2c6648: 0x54400008  bnel        $v0, $zero, . + 4 + (0x8 << 2)
label_2c664c:
    if (ctx->pc == 0x2C664Cu) {
        ctx->pc = 0x2C664Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6648u;
        // 0x2c664c: 0x240982d  daddu       $s3, $s2, $zero (Delay Slot)
        SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6650u;
        goto label_2c6650;
    }
    ctx->pc = 0x2C6648u;
    {
        const bool branch_taken_0x2c6648 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c6648) {
            ctx->pc = 0x2C664Cu;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C6648u;
            // 0x2c664c: 0x240982d  daddu       $s3, $s2, $zero (Delay Slot)
            SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C666Cu;
            goto label_2c666c;
        }
    }
    ctx->pc = 0x2C6650u;
label_2c6650:
    // 0x2c6650: 0xc3102b  sltu        $v0, $a2, $v1
    ctx->pc = 0x2c6650u;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 6) < (uint64_t)GPR_U64(ctx, 3)) ? 1 : 0);
label_2c6654:
    // 0x2c6654: 0x54400006  bnel        $v0, $zero, . + 4 + (0x6 << 2)
label_2c6658:
    if (ctx->pc == 0x2C6658u) {
        ctx->pc = 0x2C6658u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6654u;
        // 0x2c6658: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C665Cu;
        goto label_2c665c;
    }
    ctx->pc = 0x2C6654u;
    {
        const bool branch_taken_0x2c6654 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        if (branch_taken_0x2c6654) {
            ctx->pc = 0x2C6658u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x2C6654u;
            // 0x2c6658: 0x26520001  addiu       $s2, $s2, 0x1 (Delay Slot)
            SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
            ctx->in_delay_slot = false;
            ctx->pc = 0x2C6670u;
            goto label_2c6670;
        }
    }
    ctx->pc = 0x2C665Cu;
label_2c665c:
    // 0x2c665c: 0x66102b  sltu        $v0, $v1, $a2
    ctx->pc = 0x2c665cu;
    SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 3) < (uint64_t)GPR_U64(ctx, 6)) ? 1 : 0);
label_2c6660:
    // 0x2c6660: 0x10000002  b           . + 4 + (0x2 << 2)
label_2c6664:
    if (ctx->pc == 0x2C6664u) {
        ctx->pc = 0x2C6664u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6660u;
        // 0x2c6664: 0x242980b  movn        $s3, $s2, $v0 (Delay Slot)
        if (GPR_U64(ctx, 2) != 0) SET_GPR_VEC(ctx, 19, GPR_VEC(ctx, 18));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6668u;
        goto label_2c6668;
    }
    ctx->pc = 0x2C6660u;
    {
        const bool branch_taken_0x2c6660 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x2C6664u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6660u;
        // 0x2c6664: 0x242980b  movn        $s3, $s2, $v0 (Delay Slot)
        if (GPR_U64(ctx, 2) != 0) SET_GPR_VEC(ctx, 19, GPR_VEC(ctx, 18));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c6660) {
            ctx->pc = 0x2C666Cu;
            goto label_2c666c;
        }
    }
    ctx->pc = 0x2C6668u;
label_2c6668:
    // 0x2c6668: 0x240982d  daddu       $s3, $s2, $zero
    ctx->pc = 0x2c6668u;
    SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_2c666c:
    // 0x2c666c: 0x26520001  addiu       $s2, $s2, 0x1
    ctx->pc = 0x2c666cu;
    SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 18), 1));
label_2c6670:
    // 0x2c6670: 0x26100078  addiu       $s0, $s0, 0x78
    ctx->pc = 0x2c6670u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 120));
label_2c6674:
    // 0x2c6674: 0x26940078  addiu       $s4, $s4, 0x78
    ctx->pc = 0x2c6674u;
    SET_GPR_S32(ctx, 20, (int32_t)ADD32(GPR_U32(ctx, 20), 120));
label_2c6678:
    // 0x2c6678: 0x2a420006  slti        $v0, $s2, 0x6
    ctx->pc = 0x2c6678u;
    SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 18) < (int64_t)(int32_t)6) ? 1 : 0);
label_2c667c:
    // 0x2c667c: 0x1440ffba  bnez        $v0, . + 4 + (-0x46 << 2)
label_2c6680:
    if (ctx->pc == 0x2C6680u) {
        ctx->pc = 0x2C6680u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C667Cu;
        // 0x2c6680: 0x26b50078  addiu       $s5, $s5, 0x78 (Delay Slot)
        SET_GPR_S32(ctx, 21, (int32_t)ADD32(GPR_U32(ctx, 21), 120));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6684u;
        goto label_2c6684;
    }
    ctx->pc = 0x2C667Cu;
    {
        const bool branch_taken_0x2c667c = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x2C6680u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C667Cu;
        // 0x2c6680: 0x26b50078  addiu       $s5, $s5, 0x78 (Delay Slot)
        SET_GPR_S32(ctx, 21, (int32_t)ADD32(GPR_U32(ctx, 21), 120));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c667c) {
            ctx->pc = 0x2C6568u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_2c6568;
        }
    }
    ctx->pc = 0x2C6684u;
label_2c6684:
    // 0x2c6684: 0x260102d  daddu       $v0, $s3, $zero
    ctx->pc = 0x2c6684u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
label_2c6688:
    // 0x2c6688: 0x7bb00090  lq          $s0, 0x90($sp)
    ctx->pc = 0x2c6688u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 144)));
label_2c668c:
    // 0x2c668c: 0x7bb10080  lq          $s1, 0x80($sp)
    ctx->pc = 0x2c668cu;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 128)));
label_2c6690:
    // 0x2c6690: 0x7bb20070  lq          $s2, 0x70($sp)
    ctx->pc = 0x2c6690u;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 112)));
label_2c6694:
    // 0x2c6694: 0x7bb30060  lq          $s3, 0x60($sp)
    ctx->pc = 0x2c6694u;
    SET_GPR_VEC(ctx, 19, READ128(ADD32(GPR_U32(ctx, 29), 96)));
label_2c6698:
    // 0x2c6698: 0x7bb40050  lq          $s4, 0x50($sp)
    ctx->pc = 0x2c6698u;
    SET_GPR_VEC(ctx, 20, READ128(ADD32(GPR_U32(ctx, 29), 80)));
label_2c669c:
    // 0x2c669c: 0x7bb50040  lq          $s5, 0x40($sp)
    ctx->pc = 0x2c669cu;
    SET_GPR_VEC(ctx, 21, READ128(ADD32(GPR_U32(ctx, 29), 64)));
label_2c66a0:
    // 0x2c66a0: 0x7bb60030  lq          $s6, 0x30($sp)
    ctx->pc = 0x2c66a0u;
    SET_GPR_VEC(ctx, 22, READ128(ADD32(GPR_U32(ctx, 29), 48)));
label_2c66a4:
    // 0x2c66a4: 0x7bb70020  lq          $s7, 0x20($sp)
    ctx->pc = 0x2c66a4u;
    SET_GPR_VEC(ctx, 23, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_2c66a8:
    // 0x2c66a8: 0x7bbe0010  lq          $fp, 0x10($sp)
    ctx->pc = 0x2c66a8u;
    SET_GPR_VEC(ctx, 30, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_2c66ac:
    // 0x2c66ac: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2c66acu;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2c66b0:
    // 0x2c66b0: 0x3e00008  jr          $ra
label_2c66b4:
    if (ctx->pc == 0x2C66B4u) {
        ctx->pc = 0x2C66B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C66B0u;
        // 0x2c66b4: 0x27bd00a0  addiu       $sp, $sp, 0xA0 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 160));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C66B8u;
        goto label_2c66b8;
    }
    ctx->pc = 0x2C66B0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C66B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C66B0u;
        // 0x2c66b4: 0x27bd00a0  addiu       $sp, $sp, 0xA0 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 160));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C66B0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C66B8u;
label_2c66b8:
    // 0x2c66b8: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2c66b8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2c66bc:
    // 0x2c66bc: 0x14c00003  bnez        $a2, . + 4 + (0x3 << 2)
label_2c66c0:
    if (ctx->pc == 0x2C66C0u) {
        ctx->pc = 0x2C66C0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C66BCu;
        // 0x2c66c0: 0xffbf0000  sd          $ra, 0x0($sp) (Delay Slot)
        WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C66C4u;
        goto label_2c66c4;
    }
    ctx->pc = 0x2C66BCu;
    {
        const bool branch_taken_0x2c66bc = (GPR_U64(ctx, 6) != GPR_U64(ctx, 0));
        ctx->pc = 0x2C66C0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C66BCu;
        // 0x2c66c0: 0xffbf0000  sd          $ra, 0x0($sp) (Delay Slot)
        WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2c66bc) {
            ctx->pc = 0x2C66CCu;
            goto label_2c66cc;
        }
    }
    ctx->pc = 0x2C66C4u;
label_2c66c4:
    // 0x2c66c4: 0xc1059bd  jal         func_4166F4
label_2c66c8:
    if (ctx->pc == 0x2C66C8u) {
        ctx->pc = 0x2C66C8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C66C4u;
        // 0x2c66c8: 0x248414c0  addiu       $a0, $a0, 0x14C0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 5312));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C66CCu;
        goto label_2c66cc;
    }
    ctx->pc = 0x2C66C4u;
    SET_GPR_U32(ctx, 31, 0x2C66CCu);
    ctx->pc = 0x2C66C8u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2C66C4u;
    // 0x2c66c8: 0x248414c0  addiu       $a0, $a0, 0x14C0 (Delay Slot)
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 5312));
    ctx->in_delay_slot = false;
    ctx->pc = 0x4166F4u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x4166F4u, 0x2C66C4u, 0x2C66CCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2C66CCu;
label_2c66cc:
    // 0x2c66cc: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2c66ccu;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2c66d0:
    // 0x2c66d0: 0x3e00008  jr          $ra
label_2c66d4:
    if (ctx->pc == 0x2C66D4u) {
        ctx->pc = 0x2C66D4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C66D0u;
        // 0x2c66d4: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C66D8u;
        goto label_2c66d8;
    }
    ctx->pc = 0x2C66D0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C66D4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C66D0u;
        // 0x2c66d4: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C66D0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C66D8u;
label_2c66d8:
    // 0x2c66d8: 0x8c83000c  lw          $v1, 0xC($a0)
    ctx->pc = 0x2c66d8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
label_2c66dc:
    // 0x2c66dc: 0x24020014  addiu       $v0, $zero, 0x14
    ctx->pc = 0x2c66dcu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 20));
label_2c66e0:
    // 0x2c66e0: 0x2405fff5  addiu       $a1, $zero, -0xB
    ctx->pc = 0x2c66e0u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967285));
label_2c66e4:
    // 0x2c66e4: 0x623018  mult        $a2, $v1, $v0
    ctx->pc = 0x2c66e4u;
    { int64_t result = (int64_t)GPR_S32(ctx, 3) * (int64_t)GPR_S32(ctx, 2); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 6, (int32_t)result); }
label_2c66e8:
    // 0x2c66e8: 0xc41821  addu        $v1, $a2, $a0
    ctx->pc = 0x2c66e8u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 4)));
label_2c66ec:
    // 0x2c66ec: 0x8c620184  lw          $v0, 0x184($v1)
    ctx->pc = 0x2c66ecu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 388)));
label_2c66f0:
    // 0x2c66f0: 0x451026  xor         $v0, $v0, $a1
    ctx->pc = 0x2c66f0u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) ^ GPR_U64(ctx, 5));
label_2c66f4:
    // 0x2c66f4: 0x3e00008  jr          $ra
label_2c66f8:
    if (ctx->pc == 0x2C66F8u) {
        ctx->pc = 0x2C66F8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C66F4u;
        // 0x2c66f8: 0x2c420001  sltiu       $v0, $v0, 0x1 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 2) < (uint64_t)(int64_t)(int32_t)1) ? 1 : 0);
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C66FCu;
        goto label_2c66fc;
    }
    ctx->pc = 0x2C66F4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C66F8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C66F4u;
        // 0x2c66f8: 0x2c420001  sltiu       $v0, $v0, 0x1 (Delay Slot)
        SET_GPR_U64(ctx, 2, ((uint64_t)GPR_U64(ctx, 2) < (uint64_t)(int64_t)(int32_t)1) ? 1 : 0);
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C66F4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C66FCu;
label_2c66fc:
    // 0x2c66fc: 0x0  nop
    ctx->pc = 0x2c66fcu;
    // NOP
label_2c6700:
    // 0x2c6700: 0x3e00008  jr          $ra
label_2c6704:
    if (ctx->pc == 0x2C6704u) {
        ctx->pc = 0x2C6704u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6700u;
        // 0x2c6704: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6708u;
        goto label_2c6708;
    }
    ctx->pc = 0x2C6700u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C6704u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6700u;
        // 0x2c6704: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6700u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C6708u;
label_2c6708:
    // 0x2c6708: 0x3e00008  jr          $ra
label_2c670c:
    if (ctx->pc == 0x2C670Cu) {
        ctx->pc = 0x2C670Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6708u;
        // 0x2c670c: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6710u;
        goto label_2c6710;
    }
    ctx->pc = 0x2C6708u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C670Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6708u;
        // 0x2c670c: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6708u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C6710u;
label_2c6710:
    // 0x2c6710: 0x3e00008  jr          $ra
label_2c6714:
    if (ctx->pc == 0x2C6714u) {
        ctx->pc = 0x2C6714u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6710u;
        // 0x2c6714: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6718u;
        goto label_2c6718;
    }
    ctx->pc = 0x2C6710u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C6714u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6710u;
        // 0x2c6714: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6710u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C6718u;
label_2c6718:
    // 0x2c6718: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2c6718u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2c671c:
    // 0x2c671c: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2c671cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2c6720:
    // 0x2c6720: 0x8c830000  lw          $v1, 0x0($a0)
    ctx->pc = 0x2c6720u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_2c6724:
    // 0x2c6724: 0x8c85000c  lw          $a1, 0xC($a0)
    ctx->pc = 0x2c6724u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
label_2c6728:
    // 0x2c6728: 0x846601e8  lh          $a2, 0x1E8($v1)
    ctx->pc = 0x2c6728u;
    SET_GPR_S32(ctx, 6, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 488)));
label_2c672c:
    // 0x2c672c: 0x8c6201ec  lw          $v0, 0x1EC($v1)
    ctx->pc = 0x2c672cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 492)));
label_2c6730:
    // 0x2c6730: 0x40f809  jalr        $v0
label_2c6734:
    if (ctx->pc == 0x2C6734u) {
        ctx->pc = 0x2C6734u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6730u;
        // 0x2c6734: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6738u;
        goto label_2c6738;
    }
    ctx->pc = 0x2C6730u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2C6738u);
        ctx->pc = 0x2C6734u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6730u;
        // 0x2c6734: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6730u, 0x2C6738u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2C6738u;
label_2c6738:
    // 0x2c6738: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2c6738u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2c673c:
    // 0x2c673c: 0x3e00008  jr          $ra
label_2c6740:
    if (ctx->pc == 0x2C6740u) {
        ctx->pc = 0x2C6740u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C673Cu;
        // 0x2c6740: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6744u;
        goto label_2c6744;
    }
    ctx->pc = 0x2C673Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C6740u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C673Cu;
        // 0x2c6740: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C673Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C6744u;
label_2c6744:
    // 0x2c6744: 0x0  nop
    ctx->pc = 0x2c6744u;
    // NOP
label_2c6748:
    // 0x2c6748: 0x3e00008  jr          $ra
label_2c674c:
    if (ctx->pc == 0x2C674Cu) {
        ctx->pc = 0x2C674Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6748u;
        // 0x2c674c: 0x24024000  addiu       $v0, $zero, 0x4000 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 16384));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6750u;
        goto label_2c6750;
    }
    ctx->pc = 0x2C6748u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C674Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6748u;
        // 0x2c674c: 0x24024000  addiu       $v0, $zero, 0x4000 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 16384));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6748u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C6750u;
label_2c6750:
    // 0x2c6750: 0x3e00008  jr          $ra
label_2c6754:
    if (ctx->pc == 0x2C6754u) {
        ctx->pc = 0x2C6754u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6750u;
        // 0x2c6754: 0x2402ffff  addiu       $v0, $zero, -0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6758u;
        goto label_2c6758;
    }
    ctx->pc = 0x2C6750u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C6754u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6750u;
        // 0x2c6754: 0x2402ffff  addiu       $v0, $zero, -0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6750u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C6758u;
label_2c6758:
    // 0x2c6758: 0x24a303ff  addiu       $v1, $a1, 0x3FF
    ctx->pc = 0x2c6758u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 5), 1023));
label_2c675c:
    // 0x2c675c: 0x2402ffff  addiu       $v0, $zero, -0x1
    ctx->pc = 0x2c675cu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
label_2c6760:
    // 0x2c6760: 0x43102a  slt         $v0, $v0, $v1
    ctx->pc = 0x2c6760u;
    SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 2) < (int64_t)GPR_S64(ctx, 3)) ? 1 : 0);
label_2c6764:
    // 0x2c6764: 0x24a507fe  addiu       $a1, $a1, 0x7FE
    ctx->pc = 0x2c6764u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 2046));
label_2c6768:
    // 0x2c6768: 0x62280b  movn        $a1, $v1, $v0
    ctx->pc = 0x2c6768u;
    if (GPR_U64(ctx, 2) != 0) SET_GPR_VEC(ctx, 5, GPR_VEC(ctx, 3));
label_2c676c:
    // 0x2c676c: 0x52a83  sra         $a1, $a1, 10
    ctx->pc = 0x2c676cu;
    SET_GPR_S32(ctx, 5, SRA32(GPR_S32(ctx, 5), 10));
label_2c6770:
    // 0x2c6770: 0x3e00008  jr          $ra
label_2c6774:
    if (ctx->pc == 0x2C6774u) {
        ctx->pc = 0x2C6774u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6770u;
        // 0x2c6774: 0x24a2004d  addiu       $v0, $a1, 0x4D (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 5), 77));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6778u;
        goto label_2c6778;
    }
    ctx->pc = 0x2C6770u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C6774u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6770u;
        // 0x2c6774: 0x24a2004d  addiu       $v0, $a1, 0x4D (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 5), 77));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6770u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C6778u;
label_2c6778:
    // 0x2c6778: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2c6778u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2c677c:
    // 0x2c677c: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2c677cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2c6780:
    // 0x2c6780: 0x8c830000  lw          $v1, 0x0($a0)
    ctx->pc = 0x2c6780u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_2c6784:
    // 0x2c6784: 0x8c850024  lw          $a1, 0x24($a0)
    ctx->pc = 0x2c6784u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 36)));
label_2c6788:
    // 0x2c6788: 0x846600b0  lh          $a2, 0xB0($v1)
    ctx->pc = 0x2c6788u;
    SET_GPR_S32(ctx, 6, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 176)));
label_2c678c:
    // 0x2c678c: 0x8c6200b4  lw          $v0, 0xB4($v1)
    ctx->pc = 0x2c678cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 180)));
label_2c6790:
    // 0x2c6790: 0x40f809  jalr        $v0
label_2c6794:
    if (ctx->pc == 0x2C6794u) {
        ctx->pc = 0x2C6794u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6790u;
        // 0x2c6794: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C6798u;
        goto label_2c6798;
    }
    ctx->pc = 0x2C6790u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2C6798u);
        ctx->pc = 0x2C6794u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C6790u;
        // 0x2c6794: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C6790u, 0x2C6798u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2C6798u;
label_2c6798:
    // 0x2c6798: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2c6798u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2c679c:
    // 0x2c679c: 0x3e00008  jr          $ra
label_2c67a0:
    if (ctx->pc == 0x2C67A0u) {
        ctx->pc = 0x2C67A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C679Cu;
        // 0x2c67a0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C67A4u;
        goto label_2c67a4;
    }
    ctx->pc = 0x2C679Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C67A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C679Cu;
        // 0x2c67a0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C679Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C67A4u;
label_2c67a4:
    // 0x2c67a4: 0x0  nop
    ctx->pc = 0x2c67a4u;
    // NOP
label_2c67a8:
    // 0x2c67a8: 0x3e00008  jr          $ra
label_2c67ac:
    if (ctx->pc == 0x2C67ACu) {
        ctx->pc = 0x2C67ACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C67A8u;
        // 0x2c67ac: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C67B0u;
        goto label_2c67b0;
    }
    ctx->pc = 0x2C67A8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C67ACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C67A8u;
        // 0x2c67ac: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C67A8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C67B0u;
label_2c67b0:
    // 0x2c67b0: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2c67b0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2c67b4:
    // 0x2c67b4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2c67b4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2c67b8:
    // 0x2c67b8: 0x8c830000  lw          $v1, 0x0($a0)
    ctx->pc = 0x2c67b8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_2c67bc:
    // 0x2c67bc: 0x8c85000c  lw          $a1, 0xC($a0)
    ctx->pc = 0x2c67bcu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
label_2c67c0:
    // 0x2c67c0: 0x84660190  lh          $a2, 0x190($v1)
    ctx->pc = 0x2c67c0u;
    SET_GPR_S32(ctx, 6, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 400)));
label_2c67c4:
    // 0x2c67c4: 0x8c620194  lw          $v0, 0x194($v1)
    ctx->pc = 0x2c67c4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 404)));
label_2c67c8:
    // 0x2c67c8: 0x40f809  jalr        $v0
label_2c67cc:
    if (ctx->pc == 0x2C67CCu) {
        ctx->pc = 0x2C67CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C67C8u;
        // 0x2c67cc: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C67D0u;
        goto label_2c67d0;
    }
    ctx->pc = 0x2C67C8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2C67D0u);
        ctx->pc = 0x2C67CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C67C8u;
        // 0x2c67cc: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C67C8u, 0x2C67D0u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2C67D0u;
label_2c67d0:
    // 0x2c67d0: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2c67d0u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2c67d4:
    // 0x2c67d4: 0x3e00008  jr          $ra
label_2c67d8:
    if (ctx->pc == 0x2C67D8u) {
        ctx->pc = 0x2C67D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C67D4u;
        // 0x2c67d8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C67DCu;
        goto label_2c67dc;
    }
    ctx->pc = 0x2C67D4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C67D8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C67D4u;
        // 0x2c67d8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C67D4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2C67DCu;
label_2c67dc:
    // 0x2c67dc: 0x0  nop
    ctx->pc = 0x2c67dcu;
    // NOP
label_2c67e0:
    // 0x2c67e0: 0x3e00008  jr          $ra
label_2c67e4:
    if (ctx->pc == 0x2C67E4u) {
        ctx->pc = 0x2C67E4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C67E0u;
        // 0x2c67e4: 0x2402ffff  addiu       $v0, $zero, -0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2C67E8u;
        goto label_fallthrough_0x2c67e0;
    }
    ctx->pc = 0x2C67E0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2C67E4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2C67E0u;
        // 0x2c67e4: 0x2402ffff  addiu       $v0, $zero, -0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2C67E0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
label_fallthrough_0x2c67e0:
    ctx->pc = 0x2C67E8u;
}
