#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_002D2988
// Address: 0x2d2988 - 0x2d40c0
void sub_002D2988_0x2d2988(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_002D2988_0x2d2988");
#endif

    switch (ctx->pc) {
        case 0x2d2988u: goto label_2d2988;
        case 0x2d298cu: goto label_2d298c;
        case 0x2d2990u: goto label_2d2990;
        case 0x2d2994u: goto label_2d2994;
        case 0x2d2998u: goto label_2d2998;
        case 0x2d299cu: goto label_2d299c;
        case 0x2d29a0u: goto label_2d29a0;
        case 0x2d29a4u: goto label_2d29a4;
        case 0x2d29a8u: goto label_2d29a8;
        case 0x2d29acu: goto label_2d29ac;
        case 0x2d29b0u: goto label_2d29b0;
        case 0x2d29b4u: goto label_2d29b4;
        case 0x2d29b8u: goto label_2d29b8;
        case 0x2d29bcu: goto label_2d29bc;
        case 0x2d29c0u: goto label_2d29c0;
        case 0x2d29c4u: goto label_2d29c4;
        case 0x2d29c8u: goto label_2d29c8;
        case 0x2d29ccu: goto label_2d29cc;
        case 0x2d29d0u: goto label_2d29d0;
        case 0x2d29d4u: goto label_2d29d4;
        case 0x2d29d8u: goto label_2d29d8;
        case 0x2d29dcu: goto label_2d29dc;
        case 0x2d29e0u: goto label_2d29e0;
        case 0x2d29e4u: goto label_2d29e4;
        case 0x2d29e8u: goto label_2d29e8;
        case 0x2d29ecu: goto label_2d29ec;
        case 0x2d29f0u: goto label_2d29f0;
        case 0x2d29f4u: goto label_2d29f4;
        case 0x2d29f8u: goto label_2d29f8;
        case 0x2d29fcu: goto label_2d29fc;
        case 0x2d2a00u: goto label_2d2a00;
        case 0x2d2a04u: goto label_2d2a04;
        case 0x2d2a08u: goto label_2d2a08;
        case 0x2d2a0cu: goto label_2d2a0c;
        case 0x2d2a10u: goto label_2d2a10;
        case 0x2d2a14u: goto label_2d2a14;
        case 0x2d2a18u: goto label_2d2a18;
        case 0x2d2a1cu: goto label_2d2a1c;
        case 0x2d2a20u: goto label_2d2a20;
        case 0x2d2a24u: goto label_2d2a24;
        case 0x2d2a28u: goto label_2d2a28;
        case 0x2d2a2cu: goto label_2d2a2c;
        case 0x2d2a30u: goto label_2d2a30;
        case 0x2d2a34u: goto label_2d2a34;
        case 0x2d2a38u: goto label_2d2a38;
        case 0x2d2a3cu: goto label_2d2a3c;
        case 0x2d2a40u: goto label_2d2a40;
        case 0x2d2a44u: goto label_2d2a44;
        case 0x2d2a48u: goto label_2d2a48;
        case 0x2d2a4cu: goto label_2d2a4c;
        case 0x2d2a50u: goto label_2d2a50;
        case 0x2d2a54u: goto label_2d2a54;
        case 0x2d2a58u: goto label_2d2a58;
        case 0x2d2a5cu: goto label_2d2a5c;
        case 0x2d2a60u: goto label_2d2a60;
        case 0x2d2a64u: goto label_2d2a64;
        case 0x2d2a68u: goto label_2d2a68;
        case 0x2d2a6cu: goto label_2d2a6c;
        case 0x2d2a70u: goto label_2d2a70;
        case 0x2d2a74u: goto label_2d2a74;
        case 0x2d2a78u: goto label_2d2a78;
        case 0x2d2a7cu: goto label_2d2a7c;
        case 0x2d2a80u: goto label_2d2a80;
        case 0x2d2a84u: goto label_2d2a84;
        case 0x2d2a88u: goto label_2d2a88;
        case 0x2d2a8cu: goto label_2d2a8c;
        case 0x2d2a90u: goto label_2d2a90;
        case 0x2d2a94u: goto label_2d2a94;
        case 0x2d2a98u: goto label_2d2a98;
        case 0x2d2a9cu: goto label_2d2a9c;
        case 0x2d2aa0u: goto label_2d2aa0;
        case 0x2d2aa4u: goto label_2d2aa4;
        case 0x2d2aa8u: goto label_2d2aa8;
        case 0x2d2aacu: goto label_2d2aac;
        case 0x2d2ab0u: goto label_2d2ab0;
        case 0x2d2ab4u: goto label_2d2ab4;
        case 0x2d2ab8u: goto label_2d2ab8;
        case 0x2d2abcu: goto label_2d2abc;
        case 0x2d2ac0u: goto label_2d2ac0;
        case 0x2d2ac4u: goto label_2d2ac4;
        case 0x2d2ac8u: goto label_2d2ac8;
        case 0x2d2accu: goto label_2d2acc;
        case 0x2d2ad0u: goto label_2d2ad0;
        case 0x2d2ad4u: goto label_2d2ad4;
        case 0x2d2ad8u: goto label_2d2ad8;
        case 0x2d2adcu: goto label_2d2adc;
        case 0x2d2ae0u: goto label_2d2ae0;
        case 0x2d2ae4u: goto label_2d2ae4;
        case 0x2d2ae8u: goto label_2d2ae8;
        case 0x2d2aecu: goto label_2d2aec;
        case 0x2d2af0u: goto label_2d2af0;
        case 0x2d2af4u: goto label_2d2af4;
        case 0x2d2af8u: goto label_2d2af8;
        case 0x2d2afcu: goto label_2d2afc;
        case 0x2d2b00u: goto label_2d2b00;
        case 0x2d2b04u: goto label_2d2b04;
        case 0x2d2b08u: goto label_2d2b08;
        case 0x2d2b0cu: goto label_2d2b0c;
        case 0x2d2b10u: goto label_2d2b10;
        case 0x2d2b14u: goto label_2d2b14;
        case 0x2d2b18u: goto label_2d2b18;
        case 0x2d2b1cu: goto label_2d2b1c;
        case 0x2d2b20u: goto label_2d2b20;
        case 0x2d2b24u: goto label_2d2b24;
        case 0x2d2b28u: goto label_2d2b28;
        case 0x2d2b2cu: goto label_2d2b2c;
        case 0x2d2b30u: goto label_2d2b30;
        case 0x2d2b34u: goto label_2d2b34;
        case 0x2d2b38u: goto label_2d2b38;
        case 0x2d2b3cu: goto label_2d2b3c;
        case 0x2d2b40u: goto label_2d2b40;
        case 0x2d2b44u: goto label_2d2b44;
        case 0x2d2b48u: goto label_2d2b48;
        case 0x2d2b4cu: goto label_2d2b4c;
        case 0x2d2b50u: goto label_2d2b50;
        case 0x2d2b54u: goto label_2d2b54;
        case 0x2d2b58u: goto label_2d2b58;
        case 0x2d2b5cu: goto label_2d2b5c;
        case 0x2d2b60u: goto label_2d2b60;
        case 0x2d2b64u: goto label_2d2b64;
        case 0x2d2b68u: goto label_2d2b68;
        case 0x2d2b6cu: goto label_2d2b6c;
        case 0x2d2b70u: goto label_2d2b70;
        case 0x2d2b74u: goto label_2d2b74;
        case 0x2d2b78u: goto label_2d2b78;
        case 0x2d2b7cu: goto label_2d2b7c;
        case 0x2d2b80u: goto label_2d2b80;
        case 0x2d2b84u: goto label_2d2b84;
        case 0x2d2b88u: goto label_2d2b88;
        case 0x2d2b8cu: goto label_2d2b8c;
        case 0x2d2b90u: goto label_2d2b90;
        case 0x2d2b94u: goto label_2d2b94;
        case 0x2d2b98u: goto label_2d2b98;
        case 0x2d2b9cu: goto label_2d2b9c;
        case 0x2d2ba0u: goto label_2d2ba0;
        case 0x2d2ba4u: goto label_2d2ba4;
        case 0x2d2ba8u: goto label_2d2ba8;
        case 0x2d2bacu: goto label_2d2bac;
        case 0x2d2bb0u: goto label_2d2bb0;
        case 0x2d2bb4u: goto label_2d2bb4;
        case 0x2d2bb8u: goto label_2d2bb8;
        case 0x2d2bbcu: goto label_2d2bbc;
        case 0x2d2bc0u: goto label_2d2bc0;
        case 0x2d2bc4u: goto label_2d2bc4;
        case 0x2d2bc8u: goto label_2d2bc8;
        case 0x2d2bccu: goto label_2d2bcc;
        case 0x2d2bd0u: goto label_2d2bd0;
        case 0x2d2bd4u: goto label_2d2bd4;
        case 0x2d2bd8u: goto label_2d2bd8;
        case 0x2d2bdcu: goto label_2d2bdc;
        case 0x2d2be0u: goto label_2d2be0;
        case 0x2d2be4u: goto label_2d2be4;
        case 0x2d2be8u: goto label_2d2be8;
        case 0x2d2becu: goto label_2d2bec;
        case 0x2d2bf0u: goto label_2d2bf0;
        case 0x2d2bf4u: goto label_2d2bf4;
        case 0x2d2bf8u: goto label_2d2bf8;
        case 0x2d2bfcu: goto label_2d2bfc;
        case 0x2d2c00u: goto label_2d2c00;
        case 0x2d2c04u: goto label_2d2c04;
        case 0x2d2c08u: goto label_2d2c08;
        case 0x2d2c0cu: goto label_2d2c0c;
        case 0x2d2c10u: goto label_2d2c10;
        case 0x2d2c14u: goto label_2d2c14;
        case 0x2d2c18u: goto label_2d2c18;
        case 0x2d2c1cu: goto label_2d2c1c;
        case 0x2d2c20u: goto label_2d2c20;
        case 0x2d2c24u: goto label_2d2c24;
        case 0x2d2c28u: goto label_2d2c28;
        case 0x2d2c2cu: goto label_2d2c2c;
        case 0x2d2c30u: goto label_2d2c30;
        case 0x2d2c34u: goto label_2d2c34;
        case 0x2d2c38u: goto label_2d2c38;
        case 0x2d2c3cu: goto label_2d2c3c;
        case 0x2d2c40u: goto label_2d2c40;
        case 0x2d2c44u: goto label_2d2c44;
        case 0x2d2c48u: goto label_2d2c48;
        case 0x2d2c4cu: goto label_2d2c4c;
        case 0x2d2c50u: goto label_2d2c50;
        case 0x2d2c54u: goto label_2d2c54;
        case 0x2d2c58u: goto label_2d2c58;
        case 0x2d2c5cu: goto label_2d2c5c;
        case 0x2d2c60u: goto label_2d2c60;
        case 0x2d2c64u: goto label_2d2c64;
        case 0x2d2c68u: goto label_2d2c68;
        case 0x2d2c6cu: goto label_2d2c6c;
        case 0x2d2c70u: goto label_2d2c70;
        case 0x2d2c74u: goto label_2d2c74;
        case 0x2d2c78u: goto label_2d2c78;
        case 0x2d2c7cu: goto label_2d2c7c;
        case 0x2d2c80u: goto label_2d2c80;
        case 0x2d2c84u: goto label_2d2c84;
        case 0x2d2c88u: goto label_2d2c88;
        case 0x2d2c8cu: goto label_2d2c8c;
        case 0x2d2c90u: goto label_2d2c90;
        case 0x2d2c94u: goto label_2d2c94;
        case 0x2d2c98u: goto label_2d2c98;
        case 0x2d2c9cu: goto label_2d2c9c;
        case 0x2d2ca0u: goto label_2d2ca0;
        case 0x2d2ca4u: goto label_2d2ca4;
        case 0x2d2ca8u: goto label_2d2ca8;
        case 0x2d2cacu: goto label_2d2cac;
        case 0x2d2cb0u: goto label_2d2cb0;
        case 0x2d2cb4u: goto label_2d2cb4;
        case 0x2d2cb8u: goto label_2d2cb8;
        case 0x2d2cbcu: goto label_2d2cbc;
        case 0x2d2cc0u: goto label_2d2cc0;
        case 0x2d2cc4u: goto label_2d2cc4;
        case 0x2d2cc8u: goto label_2d2cc8;
        case 0x2d2cccu: goto label_2d2ccc;
        case 0x2d2cd0u: goto label_2d2cd0;
        case 0x2d2cd4u: goto label_2d2cd4;
        case 0x2d2cd8u: goto label_2d2cd8;
        case 0x2d2cdcu: goto label_2d2cdc;
        case 0x2d2ce0u: goto label_2d2ce0;
        case 0x2d2ce4u: goto label_2d2ce4;
        case 0x2d2ce8u: goto label_2d2ce8;
        case 0x2d2cecu: goto label_2d2cec;
        case 0x2d2cf0u: goto label_2d2cf0;
        case 0x2d2cf4u: goto label_2d2cf4;
        case 0x2d2cf8u: goto label_2d2cf8;
        case 0x2d2cfcu: goto label_2d2cfc;
        case 0x2d2d00u: goto label_2d2d00;
        case 0x2d2d04u: goto label_2d2d04;
        case 0x2d2d08u: goto label_2d2d08;
        case 0x2d2d0cu: goto label_2d2d0c;
        case 0x2d2d10u: goto label_2d2d10;
        case 0x2d2d14u: goto label_2d2d14;
        case 0x2d2d18u: goto label_2d2d18;
        case 0x2d2d1cu: goto label_2d2d1c;
        case 0x2d2d20u: goto label_2d2d20;
        case 0x2d2d24u: goto label_2d2d24;
        case 0x2d2d28u: goto label_2d2d28;
        case 0x2d2d2cu: goto label_2d2d2c;
        case 0x2d2d30u: goto label_2d2d30;
        case 0x2d2d34u: goto label_2d2d34;
        case 0x2d2d38u: goto label_2d2d38;
        case 0x2d2d3cu: goto label_2d2d3c;
        case 0x2d2d40u: goto label_2d2d40;
        case 0x2d2d44u: goto label_2d2d44;
        case 0x2d2d48u: goto label_2d2d48;
        case 0x2d2d4cu: goto label_2d2d4c;
        case 0x2d2d50u: goto label_2d2d50;
        case 0x2d2d54u: goto label_2d2d54;
        case 0x2d2d58u: goto label_2d2d58;
        case 0x2d2d5cu: goto label_2d2d5c;
        case 0x2d2d60u: goto label_2d2d60;
        case 0x2d2d64u: goto label_2d2d64;
        case 0x2d2d68u: goto label_2d2d68;
        case 0x2d2d6cu: goto label_2d2d6c;
        case 0x2d2d70u: goto label_2d2d70;
        case 0x2d2d74u: goto label_2d2d74;
        case 0x2d2d78u: goto label_2d2d78;
        case 0x2d2d7cu: goto label_2d2d7c;
        case 0x2d2d80u: goto label_2d2d80;
        case 0x2d2d84u: goto label_2d2d84;
        case 0x2d2d88u: goto label_2d2d88;
        case 0x2d2d8cu: goto label_2d2d8c;
        case 0x2d2d90u: goto label_2d2d90;
        case 0x2d2d94u: goto label_2d2d94;
        case 0x2d2d98u: goto label_2d2d98;
        case 0x2d2d9cu: goto label_2d2d9c;
        case 0x2d2da0u: goto label_2d2da0;
        case 0x2d2da4u: goto label_2d2da4;
        case 0x2d2da8u: goto label_2d2da8;
        case 0x2d2dacu: goto label_2d2dac;
        case 0x2d2db0u: goto label_2d2db0;
        case 0x2d2db4u: goto label_2d2db4;
        case 0x2d2db8u: goto label_2d2db8;
        case 0x2d2dbcu: goto label_2d2dbc;
        case 0x2d2dc0u: goto label_2d2dc0;
        case 0x2d2dc4u: goto label_2d2dc4;
        case 0x2d2dc8u: goto label_2d2dc8;
        case 0x2d2dccu: goto label_2d2dcc;
        case 0x2d2dd0u: goto label_2d2dd0;
        case 0x2d2dd4u: goto label_2d2dd4;
        case 0x2d2dd8u: goto label_2d2dd8;
        case 0x2d2ddcu: goto label_2d2ddc;
        case 0x2d2de0u: goto label_2d2de0;
        case 0x2d2de4u: goto label_2d2de4;
        case 0x2d2de8u: goto label_2d2de8;
        case 0x2d2decu: goto label_2d2dec;
        case 0x2d2df0u: goto label_2d2df0;
        case 0x2d2df4u: goto label_2d2df4;
        case 0x2d2df8u: goto label_2d2df8;
        case 0x2d2dfcu: goto label_2d2dfc;
        case 0x2d2e00u: goto label_2d2e00;
        case 0x2d2e04u: goto label_2d2e04;
        case 0x2d2e08u: goto label_2d2e08;
        case 0x2d2e0cu: goto label_2d2e0c;
        case 0x2d2e10u: goto label_2d2e10;
        case 0x2d2e14u: goto label_2d2e14;
        case 0x2d2e18u: goto label_2d2e18;
        case 0x2d2e1cu: goto label_2d2e1c;
        case 0x2d2e20u: goto label_2d2e20;
        case 0x2d2e24u: goto label_2d2e24;
        case 0x2d2e28u: goto label_2d2e28;
        case 0x2d2e2cu: goto label_2d2e2c;
        case 0x2d2e30u: goto label_2d2e30;
        case 0x2d2e34u: goto label_2d2e34;
        case 0x2d2e38u: goto label_2d2e38;
        case 0x2d2e3cu: goto label_2d2e3c;
        case 0x2d2e40u: goto label_2d2e40;
        case 0x2d2e44u: goto label_2d2e44;
        case 0x2d2e48u: goto label_2d2e48;
        case 0x2d2e4cu: goto label_2d2e4c;
        case 0x2d2e50u: goto label_2d2e50;
        case 0x2d2e54u: goto label_2d2e54;
        case 0x2d2e58u: goto label_2d2e58;
        case 0x2d2e5cu: goto label_2d2e5c;
        case 0x2d2e60u: goto label_2d2e60;
        case 0x2d2e64u: goto label_2d2e64;
        case 0x2d2e68u: goto label_2d2e68;
        case 0x2d2e6cu: goto label_2d2e6c;
        case 0x2d2e70u: goto label_2d2e70;
        case 0x2d2e74u: goto label_2d2e74;
        case 0x2d2e78u: goto label_2d2e78;
        case 0x2d2e7cu: goto label_2d2e7c;
        case 0x2d2e80u: goto label_2d2e80;
        case 0x2d2e84u: goto label_2d2e84;
        case 0x2d2e88u: goto label_2d2e88;
        case 0x2d2e8cu: goto label_2d2e8c;
        case 0x2d2e90u: goto label_2d2e90;
        case 0x2d2e94u: goto label_2d2e94;
        case 0x2d2e98u: goto label_2d2e98;
        case 0x2d2e9cu: goto label_2d2e9c;
        case 0x2d2ea0u: goto label_2d2ea0;
        case 0x2d2ea4u: goto label_2d2ea4;
        case 0x2d2ea8u: goto label_2d2ea8;
        case 0x2d2eacu: goto label_2d2eac;
        case 0x2d2eb0u: goto label_2d2eb0;
        case 0x2d2eb4u: goto label_2d2eb4;
        case 0x2d2eb8u: goto label_2d2eb8;
        case 0x2d2ebcu: goto label_2d2ebc;
        case 0x2d2ec0u: goto label_2d2ec0;
        case 0x2d2ec4u: goto label_2d2ec4;
        case 0x2d2ec8u: goto label_2d2ec8;
        case 0x2d2eccu: goto label_2d2ecc;
        case 0x2d2ed0u: goto label_2d2ed0;
        case 0x2d2ed4u: goto label_2d2ed4;
        case 0x2d2ed8u: goto label_2d2ed8;
        case 0x2d2edcu: goto label_2d2edc;
        case 0x2d2ee0u: goto label_2d2ee0;
        case 0x2d2ee4u: goto label_2d2ee4;
        case 0x2d2ee8u: goto label_2d2ee8;
        case 0x2d2eecu: goto label_2d2eec;
        case 0x2d2ef0u: goto label_2d2ef0;
        case 0x2d2ef4u: goto label_2d2ef4;
        case 0x2d2ef8u: goto label_2d2ef8;
        case 0x2d2efcu: goto label_2d2efc;
        case 0x2d2f00u: goto label_2d2f00;
        case 0x2d2f04u: goto label_2d2f04;
        case 0x2d2f08u: goto label_2d2f08;
        case 0x2d2f0cu: goto label_2d2f0c;
        case 0x2d2f10u: goto label_2d2f10;
        case 0x2d2f14u: goto label_2d2f14;
        case 0x2d2f18u: goto label_2d2f18;
        case 0x2d2f1cu: goto label_2d2f1c;
        case 0x2d2f20u: goto label_2d2f20;
        case 0x2d2f24u: goto label_2d2f24;
        case 0x2d2f28u: goto label_2d2f28;
        case 0x2d2f2cu: goto label_2d2f2c;
        case 0x2d2f30u: goto label_2d2f30;
        case 0x2d2f34u: goto label_2d2f34;
        case 0x2d2f38u: goto label_2d2f38;
        case 0x2d2f3cu: goto label_2d2f3c;
        case 0x2d2f40u: goto label_2d2f40;
        case 0x2d2f44u: goto label_2d2f44;
        case 0x2d2f48u: goto label_2d2f48;
        case 0x2d2f4cu: goto label_2d2f4c;
        case 0x2d2f50u: goto label_2d2f50;
        case 0x2d2f54u: goto label_2d2f54;
        case 0x2d2f58u: goto label_2d2f58;
        case 0x2d2f5cu: goto label_2d2f5c;
        case 0x2d2f60u: goto label_2d2f60;
        case 0x2d2f64u: goto label_2d2f64;
        case 0x2d2f68u: goto label_2d2f68;
        case 0x2d2f6cu: goto label_2d2f6c;
        case 0x2d2f70u: goto label_2d2f70;
        case 0x2d2f74u: goto label_2d2f74;
        case 0x2d2f78u: goto label_2d2f78;
        case 0x2d2f7cu: goto label_2d2f7c;
        case 0x2d2f80u: goto label_2d2f80;
        case 0x2d2f84u: goto label_2d2f84;
        case 0x2d2f88u: goto label_2d2f88;
        case 0x2d2f8cu: goto label_2d2f8c;
        case 0x2d2f90u: goto label_2d2f90;
        case 0x2d2f94u: goto label_2d2f94;
        case 0x2d2f98u: goto label_2d2f98;
        case 0x2d2f9cu: goto label_2d2f9c;
        case 0x2d2fa0u: goto label_2d2fa0;
        case 0x2d2fa4u: goto label_2d2fa4;
        case 0x2d2fa8u: goto label_2d2fa8;
        case 0x2d2facu: goto label_2d2fac;
        case 0x2d2fb0u: goto label_2d2fb0;
        case 0x2d2fb4u: goto label_2d2fb4;
        case 0x2d2fb8u: goto label_2d2fb8;
        case 0x2d2fbcu: goto label_2d2fbc;
        case 0x2d2fc0u: goto label_2d2fc0;
        case 0x2d2fc4u: goto label_2d2fc4;
        case 0x2d2fc8u: goto label_2d2fc8;
        case 0x2d2fccu: goto label_2d2fcc;
        case 0x2d2fd0u: goto label_2d2fd0;
        case 0x2d2fd4u: goto label_2d2fd4;
        case 0x2d2fd8u: goto label_2d2fd8;
        case 0x2d2fdcu: goto label_2d2fdc;
        case 0x2d2fe0u: goto label_2d2fe0;
        case 0x2d2fe4u: goto label_2d2fe4;
        case 0x2d2fe8u: goto label_2d2fe8;
        case 0x2d2fecu: goto label_2d2fec;
        case 0x2d2ff0u: goto label_2d2ff0;
        case 0x2d2ff4u: goto label_2d2ff4;
        case 0x2d2ff8u: goto label_2d2ff8;
        case 0x2d2ffcu: goto label_2d2ffc;
        case 0x2d3000u: goto label_2d3000;
        case 0x2d3004u: goto label_2d3004;
        case 0x2d3008u: goto label_2d3008;
        case 0x2d300cu: goto label_2d300c;
        case 0x2d3010u: goto label_2d3010;
        case 0x2d3014u: goto label_2d3014;
        case 0x2d3018u: goto label_2d3018;
        case 0x2d301cu: goto label_2d301c;
        case 0x2d3020u: goto label_2d3020;
        case 0x2d3024u: goto label_2d3024;
        case 0x2d3028u: goto label_2d3028;
        case 0x2d302cu: goto label_2d302c;
        case 0x2d3030u: goto label_2d3030;
        case 0x2d3034u: goto label_2d3034;
        case 0x2d3038u: goto label_2d3038;
        case 0x2d303cu: goto label_2d303c;
        case 0x2d3040u: goto label_2d3040;
        case 0x2d3044u: goto label_2d3044;
        case 0x2d3048u: goto label_2d3048;
        case 0x2d304cu: goto label_2d304c;
        case 0x2d3050u: goto label_2d3050;
        case 0x2d3054u: goto label_2d3054;
        case 0x2d3058u: goto label_2d3058;
        case 0x2d305cu: goto label_2d305c;
        case 0x2d3060u: goto label_2d3060;
        case 0x2d3064u: goto label_2d3064;
        case 0x2d3068u: goto label_2d3068;
        case 0x2d306cu: goto label_2d306c;
        case 0x2d3070u: goto label_2d3070;
        case 0x2d3074u: goto label_2d3074;
        case 0x2d3078u: goto label_2d3078;
        case 0x2d307cu: goto label_2d307c;
        case 0x2d3080u: goto label_2d3080;
        case 0x2d3084u: goto label_2d3084;
        case 0x2d3088u: goto label_2d3088;
        case 0x2d308cu: goto label_2d308c;
        case 0x2d3090u: goto label_2d3090;
        case 0x2d3094u: goto label_2d3094;
        case 0x2d3098u: goto label_2d3098;
        case 0x2d309cu: goto label_2d309c;
        case 0x2d30a0u: goto label_2d30a0;
        case 0x2d30a4u: goto label_2d30a4;
        case 0x2d30a8u: goto label_2d30a8;
        case 0x2d30acu: goto label_2d30ac;
        case 0x2d30b0u: goto label_2d30b0;
        case 0x2d30b4u: goto label_2d30b4;
        case 0x2d30b8u: goto label_2d30b8;
        case 0x2d30bcu: goto label_2d30bc;
        case 0x2d30c0u: goto label_2d30c0;
        case 0x2d30c4u: goto label_2d30c4;
        case 0x2d30c8u: goto label_2d30c8;
        case 0x2d30ccu: goto label_2d30cc;
        case 0x2d30d0u: goto label_2d30d0;
        case 0x2d30d4u: goto label_2d30d4;
        case 0x2d30d8u: goto label_2d30d8;
        case 0x2d30dcu: goto label_2d30dc;
        case 0x2d30e0u: goto label_2d30e0;
        case 0x2d30e4u: goto label_2d30e4;
        case 0x2d30e8u: goto label_2d30e8;
        case 0x2d30ecu: goto label_2d30ec;
        case 0x2d30f0u: goto label_2d30f0;
        case 0x2d30f4u: goto label_2d30f4;
        case 0x2d30f8u: goto label_2d30f8;
        case 0x2d30fcu: goto label_2d30fc;
        case 0x2d3100u: goto label_2d3100;
        case 0x2d3104u: goto label_2d3104;
        case 0x2d3108u: goto label_2d3108;
        case 0x2d310cu: goto label_2d310c;
        case 0x2d3110u: goto label_2d3110;
        case 0x2d3114u: goto label_2d3114;
        case 0x2d3118u: goto label_2d3118;
        case 0x2d311cu: goto label_2d311c;
        case 0x2d3120u: goto label_2d3120;
        case 0x2d3124u: goto label_2d3124;
        case 0x2d3128u: goto label_2d3128;
        case 0x2d312cu: goto label_2d312c;
        case 0x2d3130u: goto label_2d3130;
        case 0x2d3134u: goto label_2d3134;
        case 0x2d3138u: goto label_2d3138;
        case 0x2d313cu: goto label_2d313c;
        case 0x2d3140u: goto label_2d3140;
        case 0x2d3144u: goto label_2d3144;
        case 0x2d3148u: goto label_2d3148;
        case 0x2d314cu: goto label_2d314c;
        case 0x2d3150u: goto label_2d3150;
        case 0x2d3154u: goto label_2d3154;
        case 0x2d3158u: goto label_2d3158;
        case 0x2d315cu: goto label_2d315c;
        case 0x2d3160u: goto label_2d3160;
        case 0x2d3164u: goto label_2d3164;
        case 0x2d3168u: goto label_2d3168;
        case 0x2d316cu: goto label_2d316c;
        case 0x2d3170u: goto label_2d3170;
        case 0x2d3174u: goto label_2d3174;
        case 0x2d3178u: goto label_2d3178;
        case 0x2d317cu: goto label_2d317c;
        case 0x2d3180u: goto label_2d3180;
        case 0x2d3184u: goto label_2d3184;
        case 0x2d3188u: goto label_2d3188;
        case 0x2d318cu: goto label_2d318c;
        case 0x2d3190u: goto label_2d3190;
        case 0x2d3194u: goto label_2d3194;
        case 0x2d3198u: goto label_2d3198;
        case 0x2d319cu: goto label_2d319c;
        case 0x2d31a0u: goto label_2d31a0;
        case 0x2d31a4u: goto label_2d31a4;
        case 0x2d31a8u: goto label_2d31a8;
        case 0x2d31acu: goto label_2d31ac;
        case 0x2d31b0u: goto label_2d31b0;
        case 0x2d31b4u: goto label_2d31b4;
        case 0x2d31b8u: goto label_2d31b8;
        case 0x2d31bcu: goto label_2d31bc;
        case 0x2d31c0u: goto label_2d31c0;
        case 0x2d31c4u: goto label_2d31c4;
        case 0x2d31c8u: goto label_2d31c8;
        case 0x2d31ccu: goto label_2d31cc;
        case 0x2d31d0u: goto label_2d31d0;
        case 0x2d31d4u: goto label_2d31d4;
        case 0x2d31d8u: goto label_2d31d8;
        case 0x2d31dcu: goto label_2d31dc;
        case 0x2d31e0u: goto label_2d31e0;
        case 0x2d31e4u: goto label_2d31e4;
        case 0x2d31e8u: goto label_2d31e8;
        case 0x2d31ecu: goto label_2d31ec;
        case 0x2d31f0u: goto label_2d31f0;
        case 0x2d31f4u: goto label_2d31f4;
        case 0x2d31f8u: goto label_2d31f8;
        case 0x2d31fcu: goto label_2d31fc;
        case 0x2d3200u: goto label_2d3200;
        case 0x2d3204u: goto label_2d3204;
        case 0x2d3208u: goto label_2d3208;
        case 0x2d320cu: goto label_2d320c;
        case 0x2d3210u: goto label_2d3210;
        case 0x2d3214u: goto label_2d3214;
        case 0x2d3218u: goto label_2d3218;
        case 0x2d321cu: goto label_2d321c;
        case 0x2d3220u: goto label_2d3220;
        case 0x2d3224u: goto label_2d3224;
        case 0x2d3228u: goto label_2d3228;
        case 0x2d322cu: goto label_2d322c;
        case 0x2d3230u: goto label_2d3230;
        case 0x2d3234u: goto label_2d3234;
        case 0x2d3238u: goto label_2d3238;
        case 0x2d323cu: goto label_2d323c;
        case 0x2d3240u: goto label_2d3240;
        case 0x2d3244u: goto label_2d3244;
        case 0x2d3248u: goto label_2d3248;
        case 0x2d324cu: goto label_2d324c;
        case 0x2d3250u: goto label_2d3250;
        case 0x2d3254u: goto label_2d3254;
        case 0x2d3258u: goto label_2d3258;
        case 0x2d325cu: goto label_2d325c;
        case 0x2d3260u: goto label_2d3260;
        case 0x2d3264u: goto label_2d3264;
        case 0x2d3268u: goto label_2d3268;
        case 0x2d326cu: goto label_2d326c;
        case 0x2d3270u: goto label_2d3270;
        case 0x2d3274u: goto label_2d3274;
        case 0x2d3278u: goto label_2d3278;
        case 0x2d327cu: goto label_2d327c;
        case 0x2d3280u: goto label_2d3280;
        case 0x2d3284u: goto label_2d3284;
        case 0x2d3288u: goto label_2d3288;
        case 0x2d328cu: goto label_2d328c;
        case 0x2d3290u: goto label_2d3290;
        case 0x2d3294u: goto label_2d3294;
        case 0x2d3298u: goto label_2d3298;
        case 0x2d329cu: goto label_2d329c;
        case 0x2d32a0u: goto label_2d32a0;
        case 0x2d32a4u: goto label_2d32a4;
        case 0x2d32a8u: goto label_2d32a8;
        case 0x2d32acu: goto label_2d32ac;
        case 0x2d32b0u: goto label_2d32b0;
        case 0x2d32b4u: goto label_2d32b4;
        case 0x2d32b8u: goto label_2d32b8;
        case 0x2d32bcu: goto label_2d32bc;
        case 0x2d32c0u: goto label_2d32c0;
        case 0x2d32c4u: goto label_2d32c4;
        case 0x2d32c8u: goto label_2d32c8;
        case 0x2d32ccu: goto label_2d32cc;
        case 0x2d32d0u: goto label_2d32d0;
        case 0x2d32d4u: goto label_2d32d4;
        case 0x2d32d8u: goto label_2d32d8;
        case 0x2d32dcu: goto label_2d32dc;
        case 0x2d32e0u: goto label_2d32e0;
        case 0x2d32e4u: goto label_2d32e4;
        case 0x2d32e8u: goto label_2d32e8;
        case 0x2d32ecu: goto label_2d32ec;
        case 0x2d32f0u: goto label_2d32f0;
        case 0x2d32f4u: goto label_2d32f4;
        case 0x2d32f8u: goto label_2d32f8;
        case 0x2d32fcu: goto label_2d32fc;
        case 0x2d3300u: goto label_2d3300;
        case 0x2d3304u: goto label_2d3304;
        case 0x2d3308u: goto label_2d3308;
        case 0x2d330cu: goto label_2d330c;
        case 0x2d3310u: goto label_2d3310;
        case 0x2d3314u: goto label_2d3314;
        case 0x2d3318u: goto label_2d3318;
        case 0x2d331cu: goto label_2d331c;
        case 0x2d3320u: goto label_2d3320;
        case 0x2d3324u: goto label_2d3324;
        case 0x2d3328u: goto label_2d3328;
        case 0x2d332cu: goto label_2d332c;
        case 0x2d3330u: goto label_2d3330;
        case 0x2d3334u: goto label_2d3334;
        case 0x2d3338u: goto label_2d3338;
        case 0x2d333cu: goto label_2d333c;
        case 0x2d3340u: goto label_2d3340;
        case 0x2d3344u: goto label_2d3344;
        case 0x2d3348u: goto label_2d3348;
        case 0x2d334cu: goto label_2d334c;
        case 0x2d3350u: goto label_2d3350;
        case 0x2d3354u: goto label_2d3354;
        case 0x2d3358u: goto label_2d3358;
        case 0x2d335cu: goto label_2d335c;
        case 0x2d3360u: goto label_2d3360;
        case 0x2d3364u: goto label_2d3364;
        case 0x2d3368u: goto label_2d3368;
        case 0x2d336cu: goto label_2d336c;
        case 0x2d3370u: goto label_2d3370;
        case 0x2d3374u: goto label_2d3374;
        case 0x2d3378u: goto label_2d3378;
        case 0x2d337cu: goto label_2d337c;
        case 0x2d3380u: goto label_2d3380;
        case 0x2d3384u: goto label_2d3384;
        case 0x2d3388u: goto label_2d3388;
        case 0x2d338cu: goto label_2d338c;
        case 0x2d3390u: goto label_2d3390;
        case 0x2d3394u: goto label_2d3394;
        case 0x2d3398u: goto label_2d3398;
        case 0x2d339cu: goto label_2d339c;
        case 0x2d33a0u: goto label_2d33a0;
        case 0x2d33a4u: goto label_2d33a4;
        case 0x2d33a8u: goto label_2d33a8;
        case 0x2d33acu: goto label_2d33ac;
        case 0x2d33b0u: goto label_2d33b0;
        case 0x2d33b4u: goto label_2d33b4;
        case 0x2d33b8u: goto label_2d33b8;
        case 0x2d33bcu: goto label_2d33bc;
        case 0x2d33c0u: goto label_2d33c0;
        case 0x2d33c4u: goto label_2d33c4;
        case 0x2d33c8u: goto label_2d33c8;
        case 0x2d33ccu: goto label_2d33cc;
        case 0x2d33d0u: goto label_2d33d0;
        case 0x2d33d4u: goto label_2d33d4;
        case 0x2d33d8u: goto label_2d33d8;
        case 0x2d33dcu: goto label_2d33dc;
        case 0x2d33e0u: goto label_2d33e0;
        case 0x2d33e4u: goto label_2d33e4;
        case 0x2d33e8u: goto label_2d33e8;
        case 0x2d33ecu: goto label_2d33ec;
        case 0x2d33f0u: goto label_2d33f0;
        case 0x2d33f4u: goto label_2d33f4;
        case 0x2d33f8u: goto label_2d33f8;
        case 0x2d33fcu: goto label_2d33fc;
        case 0x2d3400u: goto label_2d3400;
        case 0x2d3404u: goto label_2d3404;
        case 0x2d3408u: goto label_2d3408;
        case 0x2d340cu: goto label_2d340c;
        case 0x2d3410u: goto label_2d3410;
        case 0x2d3414u: goto label_2d3414;
        case 0x2d3418u: goto label_2d3418;
        case 0x2d341cu: goto label_2d341c;
        case 0x2d3420u: goto label_2d3420;
        case 0x2d3424u: goto label_2d3424;
        case 0x2d3428u: goto label_2d3428;
        case 0x2d342cu: goto label_2d342c;
        case 0x2d3430u: goto label_2d3430;
        case 0x2d3434u: goto label_2d3434;
        case 0x2d3438u: goto label_2d3438;
        case 0x2d343cu: goto label_2d343c;
        case 0x2d3440u: goto label_2d3440;
        case 0x2d3444u: goto label_2d3444;
        case 0x2d3448u: goto label_2d3448;
        case 0x2d344cu: goto label_2d344c;
        case 0x2d3450u: goto label_2d3450;
        case 0x2d3454u: goto label_2d3454;
        case 0x2d3458u: goto label_2d3458;
        case 0x2d345cu: goto label_2d345c;
        case 0x2d3460u: goto label_2d3460;
        case 0x2d3464u: goto label_2d3464;
        case 0x2d3468u: goto label_2d3468;
        case 0x2d346cu: goto label_2d346c;
        case 0x2d3470u: goto label_2d3470;
        case 0x2d3474u: goto label_2d3474;
        case 0x2d3478u: goto label_2d3478;
        case 0x2d347cu: goto label_2d347c;
        case 0x2d3480u: goto label_2d3480;
        case 0x2d3484u: goto label_2d3484;
        case 0x2d3488u: goto label_2d3488;
        case 0x2d348cu: goto label_2d348c;
        case 0x2d3490u: goto label_2d3490;
        case 0x2d3494u: goto label_2d3494;
        case 0x2d3498u: goto label_2d3498;
        case 0x2d349cu: goto label_2d349c;
        case 0x2d34a0u: goto label_2d34a0;
        case 0x2d34a4u: goto label_2d34a4;
        case 0x2d34a8u: goto label_2d34a8;
        case 0x2d34acu: goto label_2d34ac;
        case 0x2d34b0u: goto label_2d34b0;
        case 0x2d34b4u: goto label_2d34b4;
        case 0x2d34b8u: goto label_2d34b8;
        case 0x2d34bcu: goto label_2d34bc;
        case 0x2d34c0u: goto label_2d34c0;
        case 0x2d34c4u: goto label_2d34c4;
        case 0x2d34c8u: goto label_2d34c8;
        case 0x2d34ccu: goto label_2d34cc;
        case 0x2d34d0u: goto label_2d34d0;
        case 0x2d34d4u: goto label_2d34d4;
        case 0x2d34d8u: goto label_2d34d8;
        case 0x2d34dcu: goto label_2d34dc;
        case 0x2d34e0u: goto label_2d34e0;
        case 0x2d34e4u: goto label_2d34e4;
        case 0x2d34e8u: goto label_2d34e8;
        case 0x2d34ecu: goto label_2d34ec;
        case 0x2d34f0u: goto label_2d34f0;
        case 0x2d34f4u: goto label_2d34f4;
        case 0x2d34f8u: goto label_2d34f8;
        case 0x2d34fcu: goto label_2d34fc;
        case 0x2d3500u: goto label_2d3500;
        case 0x2d3504u: goto label_2d3504;
        case 0x2d3508u: goto label_2d3508;
        case 0x2d350cu: goto label_2d350c;
        case 0x2d3510u: goto label_2d3510;
        case 0x2d3514u: goto label_2d3514;
        case 0x2d3518u: goto label_2d3518;
        case 0x2d351cu: goto label_2d351c;
        case 0x2d3520u: goto label_2d3520;
        case 0x2d3524u: goto label_2d3524;
        case 0x2d3528u: goto label_2d3528;
        case 0x2d352cu: goto label_2d352c;
        case 0x2d3530u: goto label_2d3530;
        case 0x2d3534u: goto label_2d3534;
        case 0x2d3538u: goto label_2d3538;
        case 0x2d353cu: goto label_2d353c;
        case 0x2d3540u: goto label_2d3540;
        case 0x2d3544u: goto label_2d3544;
        case 0x2d3548u: goto label_2d3548;
        case 0x2d354cu: goto label_2d354c;
        case 0x2d3550u: goto label_2d3550;
        case 0x2d3554u: goto label_2d3554;
        case 0x2d3558u: goto label_2d3558;
        case 0x2d355cu: goto label_2d355c;
        case 0x2d3560u: goto label_2d3560;
        case 0x2d3564u: goto label_2d3564;
        case 0x2d3568u: goto label_2d3568;
        case 0x2d356cu: goto label_2d356c;
        case 0x2d3570u: goto label_2d3570;
        case 0x2d3574u: goto label_2d3574;
        case 0x2d3578u: goto label_2d3578;
        case 0x2d357cu: goto label_2d357c;
        case 0x2d3580u: goto label_2d3580;
        case 0x2d3584u: goto label_2d3584;
        case 0x2d3588u: goto label_2d3588;
        case 0x2d358cu: goto label_2d358c;
        case 0x2d3590u: goto label_2d3590;
        case 0x2d3594u: goto label_2d3594;
        case 0x2d3598u: goto label_2d3598;
        case 0x2d359cu: goto label_2d359c;
        case 0x2d35a0u: goto label_2d35a0;
        case 0x2d35a4u: goto label_2d35a4;
        case 0x2d35a8u: goto label_2d35a8;
        case 0x2d35acu: goto label_2d35ac;
        case 0x2d35b0u: goto label_2d35b0;
        case 0x2d35b4u: goto label_2d35b4;
        case 0x2d35b8u: goto label_2d35b8;
        case 0x2d35bcu: goto label_2d35bc;
        case 0x2d35c0u: goto label_2d35c0;
        case 0x2d35c4u: goto label_2d35c4;
        case 0x2d35c8u: goto label_2d35c8;
        case 0x2d35ccu: goto label_2d35cc;
        case 0x2d35d0u: goto label_2d35d0;
        case 0x2d35d4u: goto label_2d35d4;
        case 0x2d35d8u: goto label_2d35d8;
        case 0x2d35dcu: goto label_2d35dc;
        case 0x2d35e0u: goto label_2d35e0;
        case 0x2d35e4u: goto label_2d35e4;
        case 0x2d35e8u: goto label_2d35e8;
        case 0x2d35ecu: goto label_2d35ec;
        case 0x2d35f0u: goto label_2d35f0;
        case 0x2d35f4u: goto label_2d35f4;
        case 0x2d35f8u: goto label_2d35f8;
        case 0x2d35fcu: goto label_2d35fc;
        case 0x2d3600u: goto label_2d3600;
        case 0x2d3604u: goto label_2d3604;
        case 0x2d3608u: goto label_2d3608;
        case 0x2d360cu: goto label_2d360c;
        case 0x2d3610u: goto label_2d3610;
        case 0x2d3614u: goto label_2d3614;
        case 0x2d3618u: goto label_2d3618;
        case 0x2d361cu: goto label_2d361c;
        case 0x2d3620u: goto label_2d3620;
        case 0x2d3624u: goto label_2d3624;
        case 0x2d3628u: goto label_2d3628;
        case 0x2d362cu: goto label_2d362c;
        case 0x2d3630u: goto label_2d3630;
        case 0x2d3634u: goto label_2d3634;
        case 0x2d3638u: goto label_2d3638;
        case 0x2d363cu: goto label_2d363c;
        case 0x2d3640u: goto label_2d3640;
        case 0x2d3644u: goto label_2d3644;
        case 0x2d3648u: goto label_2d3648;
        case 0x2d364cu: goto label_2d364c;
        case 0x2d3650u: goto label_2d3650;
        case 0x2d3654u: goto label_2d3654;
        case 0x2d3658u: goto label_2d3658;
        case 0x2d365cu: goto label_2d365c;
        case 0x2d3660u: goto label_2d3660;
        case 0x2d3664u: goto label_2d3664;
        case 0x2d3668u: goto label_2d3668;
        case 0x2d366cu: goto label_2d366c;
        case 0x2d3670u: goto label_2d3670;
        case 0x2d3674u: goto label_2d3674;
        case 0x2d3678u: goto label_2d3678;
        case 0x2d367cu: goto label_2d367c;
        case 0x2d3680u: goto label_2d3680;
        case 0x2d3684u: goto label_2d3684;
        case 0x2d3688u: goto label_2d3688;
        case 0x2d368cu: goto label_2d368c;
        case 0x2d3690u: goto label_2d3690;
        case 0x2d3694u: goto label_2d3694;
        case 0x2d3698u: goto label_2d3698;
        case 0x2d369cu: goto label_2d369c;
        case 0x2d36a0u: goto label_2d36a0;
        case 0x2d36a4u: goto label_2d36a4;
        case 0x2d36a8u: goto label_2d36a8;
        case 0x2d36acu: goto label_2d36ac;
        case 0x2d36b0u: goto label_2d36b0;
        case 0x2d36b4u: goto label_2d36b4;
        case 0x2d36b8u: goto label_2d36b8;
        case 0x2d36bcu: goto label_2d36bc;
        case 0x2d36c0u: goto label_2d36c0;
        case 0x2d36c4u: goto label_2d36c4;
        case 0x2d36c8u: goto label_2d36c8;
        case 0x2d36ccu: goto label_2d36cc;
        case 0x2d36d0u: goto label_2d36d0;
        case 0x2d36d4u: goto label_2d36d4;
        case 0x2d36d8u: goto label_2d36d8;
        case 0x2d36dcu: goto label_2d36dc;
        case 0x2d36e0u: goto label_2d36e0;
        case 0x2d36e4u: goto label_2d36e4;
        case 0x2d36e8u: goto label_2d36e8;
        case 0x2d36ecu: goto label_2d36ec;
        case 0x2d36f0u: goto label_2d36f0;
        case 0x2d36f4u: goto label_2d36f4;
        case 0x2d36f8u: goto label_2d36f8;
        case 0x2d36fcu: goto label_2d36fc;
        case 0x2d3700u: goto label_2d3700;
        case 0x2d3704u: goto label_2d3704;
        case 0x2d3708u: goto label_2d3708;
        case 0x2d370cu: goto label_2d370c;
        case 0x2d3710u: goto label_2d3710;
        case 0x2d3714u: goto label_2d3714;
        case 0x2d3718u: goto label_2d3718;
        case 0x2d371cu: goto label_2d371c;
        case 0x2d3720u: goto label_2d3720;
        case 0x2d3724u: goto label_2d3724;
        case 0x2d3728u: goto label_2d3728;
        case 0x2d372cu: goto label_2d372c;
        case 0x2d3730u: goto label_2d3730;
        case 0x2d3734u: goto label_2d3734;
        case 0x2d3738u: goto label_2d3738;
        case 0x2d373cu: goto label_2d373c;
        case 0x2d3740u: goto label_2d3740;
        case 0x2d3744u: goto label_2d3744;
        case 0x2d3748u: goto label_2d3748;
        case 0x2d374cu: goto label_2d374c;
        case 0x2d3750u: goto label_2d3750;
        case 0x2d3754u: goto label_2d3754;
        case 0x2d3758u: goto label_2d3758;
        case 0x2d375cu: goto label_2d375c;
        case 0x2d3760u: goto label_2d3760;
        case 0x2d3764u: goto label_2d3764;
        case 0x2d3768u: goto label_2d3768;
        case 0x2d376cu: goto label_2d376c;
        case 0x2d3770u: goto label_2d3770;
        case 0x2d3774u: goto label_2d3774;
        case 0x2d3778u: goto label_2d3778;
        case 0x2d377cu: goto label_2d377c;
        case 0x2d3780u: goto label_2d3780;
        case 0x2d3784u: goto label_2d3784;
        case 0x2d3788u: goto label_2d3788;
        case 0x2d378cu: goto label_2d378c;
        case 0x2d3790u: goto label_2d3790;
        case 0x2d3794u: goto label_2d3794;
        case 0x2d3798u: goto label_2d3798;
        case 0x2d379cu: goto label_2d379c;
        case 0x2d37a0u: goto label_2d37a0;
        case 0x2d37a4u: goto label_2d37a4;
        case 0x2d37a8u: goto label_2d37a8;
        case 0x2d37acu: goto label_2d37ac;
        case 0x2d37b0u: goto label_2d37b0;
        case 0x2d37b4u: goto label_2d37b4;
        case 0x2d37b8u: goto label_2d37b8;
        case 0x2d37bcu: goto label_2d37bc;
        case 0x2d37c0u: goto label_2d37c0;
        case 0x2d37c4u: goto label_2d37c4;
        case 0x2d37c8u: goto label_2d37c8;
        case 0x2d37ccu: goto label_2d37cc;
        case 0x2d37d0u: goto label_2d37d0;
        case 0x2d37d4u: goto label_2d37d4;
        case 0x2d37d8u: goto label_2d37d8;
        case 0x2d37dcu: goto label_2d37dc;
        case 0x2d37e0u: goto label_2d37e0;
        case 0x2d37e4u: goto label_2d37e4;
        case 0x2d37e8u: goto label_2d37e8;
        case 0x2d37ecu: goto label_2d37ec;
        case 0x2d37f0u: goto label_2d37f0;
        case 0x2d37f4u: goto label_2d37f4;
        case 0x2d37f8u: goto label_2d37f8;
        case 0x2d37fcu: goto label_2d37fc;
        case 0x2d3800u: goto label_2d3800;
        case 0x2d3804u: goto label_2d3804;
        case 0x2d3808u: goto label_2d3808;
        case 0x2d380cu: goto label_2d380c;
        case 0x2d3810u: goto label_2d3810;
        case 0x2d3814u: goto label_2d3814;
        case 0x2d3818u: goto label_2d3818;
        case 0x2d381cu: goto label_2d381c;
        case 0x2d3820u: goto label_2d3820;
        case 0x2d3824u: goto label_2d3824;
        case 0x2d3828u: goto label_2d3828;
        case 0x2d382cu: goto label_2d382c;
        case 0x2d3830u: goto label_2d3830;
        case 0x2d3834u: goto label_2d3834;
        case 0x2d3838u: goto label_2d3838;
        case 0x2d383cu: goto label_2d383c;
        case 0x2d3840u: goto label_2d3840;
        case 0x2d3844u: goto label_2d3844;
        case 0x2d3848u: goto label_2d3848;
        case 0x2d384cu: goto label_2d384c;
        case 0x2d3850u: goto label_2d3850;
        case 0x2d3854u: goto label_2d3854;
        case 0x2d3858u: goto label_2d3858;
        case 0x2d385cu: goto label_2d385c;
        case 0x2d3860u: goto label_2d3860;
        case 0x2d3864u: goto label_2d3864;
        case 0x2d3868u: goto label_2d3868;
        case 0x2d386cu: goto label_2d386c;
        case 0x2d3870u: goto label_2d3870;
        case 0x2d3874u: goto label_2d3874;
        case 0x2d3878u: goto label_2d3878;
        case 0x2d387cu: goto label_2d387c;
        case 0x2d3880u: goto label_2d3880;
        case 0x2d3884u: goto label_2d3884;
        case 0x2d3888u: goto label_2d3888;
        case 0x2d388cu: goto label_2d388c;
        case 0x2d3890u: goto label_2d3890;
        case 0x2d3894u: goto label_2d3894;
        case 0x2d3898u: goto label_2d3898;
        case 0x2d389cu: goto label_2d389c;
        case 0x2d38a0u: goto label_2d38a0;
        case 0x2d38a4u: goto label_2d38a4;
        case 0x2d38a8u: goto label_2d38a8;
        case 0x2d38acu: goto label_2d38ac;
        case 0x2d38b0u: goto label_2d38b0;
        case 0x2d38b4u: goto label_2d38b4;
        case 0x2d38b8u: goto label_2d38b8;
        case 0x2d38bcu: goto label_2d38bc;
        case 0x2d38c0u: goto label_2d38c0;
        case 0x2d38c4u: goto label_2d38c4;
        case 0x2d38c8u: goto label_2d38c8;
        case 0x2d38ccu: goto label_2d38cc;
        case 0x2d38d0u: goto label_2d38d0;
        case 0x2d38d4u: goto label_2d38d4;
        case 0x2d38d8u: goto label_2d38d8;
        case 0x2d38dcu: goto label_2d38dc;
        case 0x2d38e0u: goto label_2d38e0;
        case 0x2d38e4u: goto label_2d38e4;
        case 0x2d38e8u: goto label_2d38e8;
        case 0x2d38ecu: goto label_2d38ec;
        case 0x2d38f0u: goto label_2d38f0;
        case 0x2d38f4u: goto label_2d38f4;
        case 0x2d38f8u: goto label_2d38f8;
        case 0x2d38fcu: goto label_2d38fc;
        case 0x2d3900u: goto label_2d3900;
        case 0x2d3904u: goto label_2d3904;
        case 0x2d3908u: goto label_2d3908;
        case 0x2d390cu: goto label_2d390c;
        case 0x2d3910u: goto label_2d3910;
        case 0x2d3914u: goto label_2d3914;
        case 0x2d3918u: goto label_2d3918;
        case 0x2d391cu: goto label_2d391c;
        case 0x2d3920u: goto label_2d3920;
        case 0x2d3924u: goto label_2d3924;
        case 0x2d3928u: goto label_2d3928;
        case 0x2d392cu: goto label_2d392c;
        case 0x2d3930u: goto label_2d3930;
        case 0x2d3934u: goto label_2d3934;
        case 0x2d3938u: goto label_2d3938;
        case 0x2d393cu: goto label_2d393c;
        case 0x2d3940u: goto label_2d3940;
        case 0x2d3944u: goto label_2d3944;
        case 0x2d3948u: goto label_2d3948;
        case 0x2d394cu: goto label_2d394c;
        case 0x2d3950u: goto label_2d3950;
        case 0x2d3954u: goto label_2d3954;
        case 0x2d3958u: goto label_2d3958;
        case 0x2d395cu: goto label_2d395c;
        case 0x2d3960u: goto label_2d3960;
        case 0x2d3964u: goto label_2d3964;
        case 0x2d3968u: goto label_2d3968;
        case 0x2d396cu: goto label_2d396c;
        case 0x2d3970u: goto label_2d3970;
        case 0x2d3974u: goto label_2d3974;
        case 0x2d3978u: goto label_2d3978;
        case 0x2d397cu: goto label_2d397c;
        case 0x2d3980u: goto label_2d3980;
        case 0x2d3984u: goto label_2d3984;
        case 0x2d3988u: goto label_2d3988;
        case 0x2d398cu: goto label_2d398c;
        case 0x2d3990u: goto label_2d3990;
        case 0x2d3994u: goto label_2d3994;
        case 0x2d3998u: goto label_2d3998;
        case 0x2d399cu: goto label_2d399c;
        case 0x2d39a0u: goto label_2d39a0;
        case 0x2d39a4u: goto label_2d39a4;
        case 0x2d39a8u: goto label_2d39a8;
        case 0x2d39acu: goto label_2d39ac;
        case 0x2d39b0u: goto label_2d39b0;
        case 0x2d39b4u: goto label_2d39b4;
        case 0x2d39b8u: goto label_2d39b8;
        case 0x2d39bcu: goto label_2d39bc;
        case 0x2d39c0u: goto label_2d39c0;
        case 0x2d39c4u: goto label_2d39c4;
        case 0x2d39c8u: goto label_2d39c8;
        case 0x2d39ccu: goto label_2d39cc;
        case 0x2d39d0u: goto label_2d39d0;
        case 0x2d39d4u: goto label_2d39d4;
        case 0x2d39d8u: goto label_2d39d8;
        case 0x2d39dcu: goto label_2d39dc;
        case 0x2d39e0u: goto label_2d39e0;
        case 0x2d39e4u: goto label_2d39e4;
        case 0x2d39e8u: goto label_2d39e8;
        case 0x2d39ecu: goto label_2d39ec;
        case 0x2d39f0u: goto label_2d39f0;
        case 0x2d39f4u: goto label_2d39f4;
        case 0x2d39f8u: goto label_2d39f8;
        case 0x2d39fcu: goto label_2d39fc;
        case 0x2d3a00u: goto label_2d3a00;
        case 0x2d3a04u: goto label_2d3a04;
        case 0x2d3a08u: goto label_2d3a08;
        case 0x2d3a0cu: goto label_2d3a0c;
        case 0x2d3a10u: goto label_2d3a10;
        case 0x2d3a14u: goto label_2d3a14;
        case 0x2d3a18u: goto label_2d3a18;
        case 0x2d3a1cu: goto label_2d3a1c;
        case 0x2d3a20u: goto label_2d3a20;
        case 0x2d3a24u: goto label_2d3a24;
        case 0x2d3a28u: goto label_2d3a28;
        case 0x2d3a2cu: goto label_2d3a2c;
        case 0x2d3a30u: goto label_2d3a30;
        case 0x2d3a34u: goto label_2d3a34;
        case 0x2d3a38u: goto label_2d3a38;
        case 0x2d3a3cu: goto label_2d3a3c;
        case 0x2d3a40u: goto label_2d3a40;
        case 0x2d3a44u: goto label_2d3a44;
        case 0x2d3a48u: goto label_2d3a48;
        case 0x2d3a4cu: goto label_2d3a4c;
        case 0x2d3a50u: goto label_2d3a50;
        case 0x2d3a54u: goto label_2d3a54;
        case 0x2d3a58u: goto label_2d3a58;
        case 0x2d3a5cu: goto label_2d3a5c;
        case 0x2d3a60u: goto label_2d3a60;
        case 0x2d3a64u: goto label_2d3a64;
        case 0x2d3a68u: goto label_2d3a68;
        case 0x2d3a6cu: goto label_2d3a6c;
        case 0x2d3a70u: goto label_2d3a70;
        case 0x2d3a74u: goto label_2d3a74;
        case 0x2d3a78u: goto label_2d3a78;
        case 0x2d3a7cu: goto label_2d3a7c;
        case 0x2d3a80u: goto label_2d3a80;
        case 0x2d3a84u: goto label_2d3a84;
        case 0x2d3a88u: goto label_2d3a88;
        case 0x2d3a8cu: goto label_2d3a8c;
        case 0x2d3a90u: goto label_2d3a90;
        case 0x2d3a94u: goto label_2d3a94;
        case 0x2d3a98u: goto label_2d3a98;
        case 0x2d3a9cu: goto label_2d3a9c;
        case 0x2d3aa0u: goto label_2d3aa0;
        case 0x2d3aa4u: goto label_2d3aa4;
        case 0x2d3aa8u: goto label_2d3aa8;
        case 0x2d3aacu: goto label_2d3aac;
        case 0x2d3ab0u: goto label_2d3ab0;
        case 0x2d3ab4u: goto label_2d3ab4;
        case 0x2d3ab8u: goto label_2d3ab8;
        case 0x2d3abcu: goto label_2d3abc;
        case 0x2d3ac0u: goto label_2d3ac0;
        case 0x2d3ac4u: goto label_2d3ac4;
        case 0x2d3ac8u: goto label_2d3ac8;
        case 0x2d3accu: goto label_2d3acc;
        case 0x2d3ad0u: goto label_2d3ad0;
        case 0x2d3ad4u: goto label_2d3ad4;
        case 0x2d3ad8u: goto label_2d3ad8;
        case 0x2d3adcu: goto label_2d3adc;
        case 0x2d3ae0u: goto label_2d3ae0;
        case 0x2d3ae4u: goto label_2d3ae4;
        case 0x2d3ae8u: goto label_2d3ae8;
        case 0x2d3aecu: goto label_2d3aec;
        case 0x2d3af0u: goto label_2d3af0;
        case 0x2d3af4u: goto label_2d3af4;
        case 0x2d3af8u: goto label_2d3af8;
        case 0x2d3afcu: goto label_2d3afc;
        case 0x2d3b00u: goto label_2d3b00;
        case 0x2d3b04u: goto label_2d3b04;
        case 0x2d3b08u: goto label_2d3b08;
        case 0x2d3b0cu: goto label_2d3b0c;
        case 0x2d3b10u: goto label_2d3b10;
        case 0x2d3b14u: goto label_2d3b14;
        case 0x2d3b18u: goto label_2d3b18;
        case 0x2d3b1cu: goto label_2d3b1c;
        case 0x2d3b20u: goto label_2d3b20;
        case 0x2d3b24u: goto label_2d3b24;
        case 0x2d3b28u: goto label_2d3b28;
        case 0x2d3b2cu: goto label_2d3b2c;
        case 0x2d3b30u: goto label_2d3b30;
        case 0x2d3b34u: goto label_2d3b34;
        case 0x2d3b38u: goto label_2d3b38;
        case 0x2d3b3cu: goto label_2d3b3c;
        case 0x2d3b40u: goto label_2d3b40;
        case 0x2d3b44u: goto label_2d3b44;
        case 0x2d3b48u: goto label_2d3b48;
        case 0x2d3b4cu: goto label_2d3b4c;
        case 0x2d3b50u: goto label_2d3b50;
        case 0x2d3b54u: goto label_2d3b54;
        case 0x2d3b58u: goto label_2d3b58;
        case 0x2d3b5cu: goto label_2d3b5c;
        case 0x2d3b60u: goto label_2d3b60;
        case 0x2d3b64u: goto label_2d3b64;
        case 0x2d3b68u: goto label_2d3b68;
        case 0x2d3b6cu: goto label_2d3b6c;
        case 0x2d3b70u: goto label_2d3b70;
        case 0x2d3b74u: goto label_2d3b74;
        case 0x2d3b78u: goto label_2d3b78;
        case 0x2d3b7cu: goto label_2d3b7c;
        case 0x2d3b80u: goto label_2d3b80;
        case 0x2d3b84u: goto label_2d3b84;
        case 0x2d3b88u: goto label_2d3b88;
        case 0x2d3b8cu: goto label_2d3b8c;
        case 0x2d3b90u: goto label_2d3b90;
        case 0x2d3b94u: goto label_2d3b94;
        case 0x2d3b98u: goto label_2d3b98;
        case 0x2d3b9cu: goto label_2d3b9c;
        case 0x2d3ba0u: goto label_2d3ba0;
        case 0x2d3ba4u: goto label_2d3ba4;
        case 0x2d3ba8u: goto label_2d3ba8;
        case 0x2d3bacu: goto label_2d3bac;
        case 0x2d3bb0u: goto label_2d3bb0;
        case 0x2d3bb4u: goto label_2d3bb4;
        case 0x2d3bb8u: goto label_2d3bb8;
        case 0x2d3bbcu: goto label_2d3bbc;
        case 0x2d3bc0u: goto label_2d3bc0;
        case 0x2d3bc4u: goto label_2d3bc4;
        case 0x2d3bc8u: goto label_2d3bc8;
        case 0x2d3bccu: goto label_2d3bcc;
        case 0x2d3bd0u: goto label_2d3bd0;
        case 0x2d3bd4u: goto label_2d3bd4;
        case 0x2d3bd8u: goto label_2d3bd8;
        case 0x2d3bdcu: goto label_2d3bdc;
        case 0x2d3be0u: goto label_2d3be0;
        case 0x2d3be4u: goto label_2d3be4;
        case 0x2d3be8u: goto label_2d3be8;
        case 0x2d3becu: goto label_2d3bec;
        case 0x2d3bf0u: goto label_2d3bf0;
        case 0x2d3bf4u: goto label_2d3bf4;
        case 0x2d3bf8u: goto label_2d3bf8;
        case 0x2d3bfcu: goto label_2d3bfc;
        case 0x2d3c00u: goto label_2d3c00;
        case 0x2d3c04u: goto label_2d3c04;
        case 0x2d3c08u: goto label_2d3c08;
        case 0x2d3c0cu: goto label_2d3c0c;
        case 0x2d3c10u: goto label_2d3c10;
        case 0x2d3c14u: goto label_2d3c14;
        case 0x2d3c18u: goto label_2d3c18;
        case 0x2d3c1cu: goto label_2d3c1c;
        case 0x2d3c20u: goto label_2d3c20;
        case 0x2d3c24u: goto label_2d3c24;
        case 0x2d3c28u: goto label_2d3c28;
        case 0x2d3c2cu: goto label_2d3c2c;
        case 0x2d3c30u: goto label_2d3c30;
        case 0x2d3c34u: goto label_2d3c34;
        case 0x2d3c38u: goto label_2d3c38;
        case 0x2d3c3cu: goto label_2d3c3c;
        case 0x2d3c40u: goto label_2d3c40;
        case 0x2d3c44u: goto label_2d3c44;
        case 0x2d3c48u: goto label_2d3c48;
        case 0x2d3c4cu: goto label_2d3c4c;
        case 0x2d3c50u: goto label_2d3c50;
        case 0x2d3c54u: goto label_2d3c54;
        case 0x2d3c58u: goto label_2d3c58;
        case 0x2d3c5cu: goto label_2d3c5c;
        case 0x2d3c60u: goto label_2d3c60;
        case 0x2d3c64u: goto label_2d3c64;
        case 0x2d3c68u: goto label_2d3c68;
        case 0x2d3c6cu: goto label_2d3c6c;
        case 0x2d3c70u: goto label_2d3c70;
        case 0x2d3c74u: goto label_2d3c74;
        case 0x2d3c78u: goto label_2d3c78;
        case 0x2d3c7cu: goto label_2d3c7c;
        case 0x2d3c80u: goto label_2d3c80;
        case 0x2d3c84u: goto label_2d3c84;
        case 0x2d3c88u: goto label_2d3c88;
        case 0x2d3c8cu: goto label_2d3c8c;
        case 0x2d3c90u: goto label_2d3c90;
        case 0x2d3c94u: goto label_2d3c94;
        case 0x2d3c98u: goto label_2d3c98;
        case 0x2d3c9cu: goto label_2d3c9c;
        case 0x2d3ca0u: goto label_2d3ca0;
        case 0x2d3ca4u: goto label_2d3ca4;
        case 0x2d3ca8u: goto label_2d3ca8;
        case 0x2d3cacu: goto label_2d3cac;
        case 0x2d3cb0u: goto label_2d3cb0;
        case 0x2d3cb4u: goto label_2d3cb4;
        case 0x2d3cb8u: goto label_2d3cb8;
        case 0x2d3cbcu: goto label_2d3cbc;
        case 0x2d3cc0u: goto label_2d3cc0;
        case 0x2d3cc4u: goto label_2d3cc4;
        case 0x2d3cc8u: goto label_2d3cc8;
        case 0x2d3cccu: goto label_2d3ccc;
        case 0x2d3cd0u: goto label_2d3cd0;
        case 0x2d3cd4u: goto label_2d3cd4;
        case 0x2d3cd8u: goto label_2d3cd8;
        case 0x2d3cdcu: goto label_2d3cdc;
        case 0x2d3ce0u: goto label_2d3ce0;
        case 0x2d3ce4u: goto label_2d3ce4;
        case 0x2d3ce8u: goto label_2d3ce8;
        case 0x2d3cecu: goto label_2d3cec;
        case 0x2d3cf0u: goto label_2d3cf0;
        case 0x2d3cf4u: goto label_2d3cf4;
        case 0x2d3cf8u: goto label_2d3cf8;
        case 0x2d3cfcu: goto label_2d3cfc;
        case 0x2d3d00u: goto label_2d3d00;
        case 0x2d3d04u: goto label_2d3d04;
        case 0x2d3d08u: goto label_2d3d08;
        case 0x2d3d0cu: goto label_2d3d0c;
        case 0x2d3d10u: goto label_2d3d10;
        case 0x2d3d14u: goto label_2d3d14;
        case 0x2d3d18u: goto label_2d3d18;
        case 0x2d3d1cu: goto label_2d3d1c;
        case 0x2d3d20u: goto label_2d3d20;
        case 0x2d3d24u: goto label_2d3d24;
        case 0x2d3d28u: goto label_2d3d28;
        case 0x2d3d2cu: goto label_2d3d2c;
        case 0x2d3d30u: goto label_2d3d30;
        case 0x2d3d34u: goto label_2d3d34;
        case 0x2d3d38u: goto label_2d3d38;
        case 0x2d3d3cu: goto label_2d3d3c;
        case 0x2d3d40u: goto label_2d3d40;
        case 0x2d3d44u: goto label_2d3d44;
        case 0x2d3d48u: goto label_2d3d48;
        case 0x2d3d4cu: goto label_2d3d4c;
        case 0x2d3d50u: goto label_2d3d50;
        case 0x2d3d54u: goto label_2d3d54;
        case 0x2d3d58u: goto label_2d3d58;
        case 0x2d3d5cu: goto label_2d3d5c;
        case 0x2d3d60u: goto label_2d3d60;
        case 0x2d3d64u: goto label_2d3d64;
        case 0x2d3d68u: goto label_2d3d68;
        case 0x2d3d6cu: goto label_2d3d6c;
        case 0x2d3d70u: goto label_2d3d70;
        case 0x2d3d74u: goto label_2d3d74;
        case 0x2d3d78u: goto label_2d3d78;
        case 0x2d3d7cu: goto label_2d3d7c;
        case 0x2d3d80u: goto label_2d3d80;
        case 0x2d3d84u: goto label_2d3d84;
        case 0x2d3d88u: goto label_2d3d88;
        case 0x2d3d8cu: goto label_2d3d8c;
        case 0x2d3d90u: goto label_2d3d90;
        case 0x2d3d94u: goto label_2d3d94;
        case 0x2d3d98u: goto label_2d3d98;
        case 0x2d3d9cu: goto label_2d3d9c;
        case 0x2d3da0u: goto label_2d3da0;
        case 0x2d3da4u: goto label_2d3da4;
        case 0x2d3da8u: goto label_2d3da8;
        case 0x2d3dacu: goto label_2d3dac;
        case 0x2d3db0u: goto label_2d3db0;
        case 0x2d3db4u: goto label_2d3db4;
        case 0x2d3db8u: goto label_2d3db8;
        case 0x2d3dbcu: goto label_2d3dbc;
        case 0x2d3dc0u: goto label_2d3dc0;
        case 0x2d3dc4u: goto label_2d3dc4;
        case 0x2d3dc8u: goto label_2d3dc8;
        case 0x2d3dccu: goto label_2d3dcc;
        case 0x2d3dd0u: goto label_2d3dd0;
        case 0x2d3dd4u: goto label_2d3dd4;
        case 0x2d3dd8u: goto label_2d3dd8;
        case 0x2d3ddcu: goto label_2d3ddc;
        case 0x2d3de0u: goto label_2d3de0;
        case 0x2d3de4u: goto label_2d3de4;
        case 0x2d3de8u: goto label_2d3de8;
        case 0x2d3decu: goto label_2d3dec;
        case 0x2d3df0u: goto label_2d3df0;
        case 0x2d3df4u: goto label_2d3df4;
        case 0x2d3df8u: goto label_2d3df8;
        case 0x2d3dfcu: goto label_2d3dfc;
        case 0x2d3e00u: goto label_2d3e00;
        case 0x2d3e04u: goto label_2d3e04;
        case 0x2d3e08u: goto label_2d3e08;
        case 0x2d3e0cu: goto label_2d3e0c;
        case 0x2d3e10u: goto label_2d3e10;
        case 0x2d3e14u: goto label_2d3e14;
        case 0x2d3e18u: goto label_2d3e18;
        case 0x2d3e1cu: goto label_2d3e1c;
        case 0x2d3e20u: goto label_2d3e20;
        case 0x2d3e24u: goto label_2d3e24;
        case 0x2d3e28u: goto label_2d3e28;
        case 0x2d3e2cu: goto label_2d3e2c;
        case 0x2d3e30u: goto label_2d3e30;
        case 0x2d3e34u: goto label_2d3e34;
        case 0x2d3e38u: goto label_2d3e38;
        case 0x2d3e3cu: goto label_2d3e3c;
        case 0x2d3e40u: goto label_2d3e40;
        case 0x2d3e44u: goto label_2d3e44;
        case 0x2d3e48u: goto label_2d3e48;
        case 0x2d3e4cu: goto label_2d3e4c;
        case 0x2d3e50u: goto label_2d3e50;
        case 0x2d3e54u: goto label_2d3e54;
        case 0x2d3e58u: goto label_2d3e58;
        case 0x2d3e5cu: goto label_2d3e5c;
        case 0x2d3e60u: goto label_2d3e60;
        case 0x2d3e64u: goto label_2d3e64;
        case 0x2d3e68u: goto label_2d3e68;
        case 0x2d3e6cu: goto label_2d3e6c;
        case 0x2d3e70u: goto label_2d3e70;
        case 0x2d3e74u: goto label_2d3e74;
        case 0x2d3e78u: goto label_2d3e78;
        case 0x2d3e7cu: goto label_2d3e7c;
        case 0x2d3e80u: goto label_2d3e80;
        case 0x2d3e84u: goto label_2d3e84;
        case 0x2d3e88u: goto label_2d3e88;
        case 0x2d3e8cu: goto label_2d3e8c;
        case 0x2d3e90u: goto label_2d3e90;
        case 0x2d3e94u: goto label_2d3e94;
        case 0x2d3e98u: goto label_2d3e98;
        case 0x2d3e9cu: goto label_2d3e9c;
        case 0x2d3ea0u: goto label_2d3ea0;
        case 0x2d3ea4u: goto label_2d3ea4;
        case 0x2d3ea8u: goto label_2d3ea8;
        case 0x2d3eacu: goto label_2d3eac;
        case 0x2d3eb0u: goto label_2d3eb0;
        case 0x2d3eb4u: goto label_2d3eb4;
        case 0x2d3eb8u: goto label_2d3eb8;
        case 0x2d3ebcu: goto label_2d3ebc;
        case 0x2d3ec0u: goto label_2d3ec0;
        case 0x2d3ec4u: goto label_2d3ec4;
        case 0x2d3ec8u: goto label_2d3ec8;
        case 0x2d3eccu: goto label_2d3ecc;
        case 0x2d3ed0u: goto label_2d3ed0;
        case 0x2d3ed4u: goto label_2d3ed4;
        case 0x2d3ed8u: goto label_2d3ed8;
        case 0x2d3edcu: goto label_2d3edc;
        case 0x2d3ee0u: goto label_2d3ee0;
        case 0x2d3ee4u: goto label_2d3ee4;
        case 0x2d3ee8u: goto label_2d3ee8;
        case 0x2d3eecu: goto label_2d3eec;
        case 0x2d3ef0u: goto label_2d3ef0;
        case 0x2d3ef4u: goto label_2d3ef4;
        case 0x2d3ef8u: goto label_2d3ef8;
        case 0x2d3efcu: goto label_2d3efc;
        case 0x2d3f00u: goto label_2d3f00;
        case 0x2d3f04u: goto label_2d3f04;
        case 0x2d3f08u: goto label_2d3f08;
        case 0x2d3f0cu: goto label_2d3f0c;
        case 0x2d3f10u: goto label_2d3f10;
        case 0x2d3f14u: goto label_2d3f14;
        case 0x2d3f18u: goto label_2d3f18;
        case 0x2d3f1cu: goto label_2d3f1c;
        case 0x2d3f20u: goto label_2d3f20;
        case 0x2d3f24u: goto label_2d3f24;
        case 0x2d3f28u: goto label_2d3f28;
        case 0x2d3f2cu: goto label_2d3f2c;
        case 0x2d3f30u: goto label_2d3f30;
        case 0x2d3f34u: goto label_2d3f34;
        case 0x2d3f38u: goto label_2d3f38;
        case 0x2d3f3cu: goto label_2d3f3c;
        case 0x2d3f40u: goto label_2d3f40;
        case 0x2d3f44u: goto label_2d3f44;
        case 0x2d3f48u: goto label_2d3f48;
        case 0x2d3f4cu: goto label_2d3f4c;
        case 0x2d3f50u: goto label_2d3f50;
        case 0x2d3f54u: goto label_2d3f54;
        case 0x2d3f58u: goto label_2d3f58;
        case 0x2d3f5cu: goto label_2d3f5c;
        case 0x2d3f60u: goto label_2d3f60;
        case 0x2d3f64u: goto label_2d3f64;
        case 0x2d3f68u: goto label_2d3f68;
        case 0x2d3f6cu: goto label_2d3f6c;
        case 0x2d3f70u: goto label_2d3f70;
        case 0x2d3f74u: goto label_2d3f74;
        case 0x2d3f78u: goto label_2d3f78;
        case 0x2d3f7cu: goto label_2d3f7c;
        case 0x2d3f80u: goto label_2d3f80;
        case 0x2d3f84u: goto label_2d3f84;
        case 0x2d3f88u: goto label_2d3f88;
        case 0x2d3f8cu: goto label_2d3f8c;
        case 0x2d3f90u: goto label_2d3f90;
        case 0x2d3f94u: goto label_2d3f94;
        case 0x2d3f98u: goto label_2d3f98;
        case 0x2d3f9cu: goto label_2d3f9c;
        case 0x2d3fa0u: goto label_2d3fa0;
        case 0x2d3fa4u: goto label_2d3fa4;
        case 0x2d3fa8u: goto label_2d3fa8;
        case 0x2d3facu: goto label_2d3fac;
        case 0x2d3fb0u: goto label_2d3fb0;
        case 0x2d3fb4u: goto label_2d3fb4;
        case 0x2d3fb8u: goto label_2d3fb8;
        case 0x2d3fbcu: goto label_2d3fbc;
        case 0x2d3fc0u: goto label_2d3fc0;
        case 0x2d3fc4u: goto label_2d3fc4;
        case 0x2d3fc8u: goto label_2d3fc8;
        case 0x2d3fccu: goto label_2d3fcc;
        case 0x2d3fd0u: goto label_2d3fd0;
        case 0x2d3fd4u: goto label_2d3fd4;
        case 0x2d3fd8u: goto label_2d3fd8;
        case 0x2d3fdcu: goto label_2d3fdc;
        case 0x2d3fe0u: goto label_2d3fe0;
        case 0x2d3fe4u: goto label_2d3fe4;
        case 0x2d3fe8u: goto label_2d3fe8;
        case 0x2d3fecu: goto label_2d3fec;
        case 0x2d3ff0u: goto label_2d3ff0;
        case 0x2d3ff4u: goto label_2d3ff4;
        case 0x2d3ff8u: goto label_2d3ff8;
        case 0x2d3ffcu: goto label_2d3ffc;
        case 0x2d4000u: goto label_2d4000;
        case 0x2d4004u: goto label_2d4004;
        case 0x2d4008u: goto label_2d4008;
        case 0x2d400cu: goto label_2d400c;
        case 0x2d4010u: goto label_2d4010;
        case 0x2d4014u: goto label_2d4014;
        case 0x2d4018u: goto label_2d4018;
        case 0x2d401cu: goto label_2d401c;
        case 0x2d4020u: goto label_2d4020;
        case 0x2d4024u: goto label_2d4024;
        case 0x2d4028u: goto label_2d4028;
        case 0x2d402cu: goto label_2d402c;
        case 0x2d4030u: goto label_2d4030;
        case 0x2d4034u: goto label_2d4034;
        case 0x2d4038u: goto label_2d4038;
        case 0x2d403cu: goto label_2d403c;
        case 0x2d4040u: goto label_2d4040;
        case 0x2d4044u: goto label_2d4044;
        case 0x2d4048u: goto label_2d4048;
        case 0x2d404cu: goto label_2d404c;
        case 0x2d4050u: goto label_2d4050;
        case 0x2d4054u: goto label_2d4054;
        case 0x2d4058u: goto label_2d4058;
        case 0x2d405cu: goto label_2d405c;
        case 0x2d4060u: goto label_2d4060;
        case 0x2d4064u: goto label_2d4064;
        case 0x2d4068u: goto label_2d4068;
        case 0x2d406cu: goto label_2d406c;
        case 0x2d4070u: goto label_2d4070;
        case 0x2d4074u: goto label_2d4074;
        case 0x2d4078u: goto label_2d4078;
        case 0x2d407cu: goto label_2d407c;
        case 0x2d4080u: goto label_2d4080;
        case 0x2d4084u: goto label_2d4084;
        case 0x2d4088u: goto label_2d4088;
        case 0x2d408cu: goto label_2d408c;
        case 0x2d4090u: goto label_2d4090;
        case 0x2d4094u: goto label_2d4094;
        case 0x2d4098u: goto label_2d4098;
        case 0x2d409cu: goto label_2d409c;
        case 0x2d40a0u: goto label_2d40a0;
        case 0x2d40a4u: goto label_2d40a4;
        case 0x2d40a8u: goto label_2d40a8;
        case 0x2d40acu: goto label_2d40ac;
        case 0x2d40b0u: goto label_2d40b0;
        case 0x2d40b4u: goto label_2d40b4;
        case 0x2d40b8u: goto label_2d40b8;
        case 0x2d40bcu: goto label_2d40bc;
        default: break;
    }

    ctx->pc = 0x2d2988u;

label_2d2988:
    // 0x2d2988: 0x27bdff70  addiu       $sp, $sp, -0x90
    ctx->pc = 0x2d2988u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967152));
label_2d298c:
    // 0x2d298c: 0x3402ffff  ori         $v0, $zero, 0xFFFF
    ctx->pc = 0x2d298cu;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 0) | (uint64_t)(uint16_t)65535);
label_2d2990:
    // 0x2d2990: 0x7fb00080  sq          $s0, 0x80($sp)
    ctx->pc = 0x2d2990u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 128), GPR_VEC(ctx, 16));
label_2d2994:
    // 0x2d2994: 0x7fb10070  sq          $s1, 0x70($sp)
    ctx->pc = 0x2d2994u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 112), GPR_VEC(ctx, 17));
label_2d2998:
    // 0x2d2998: 0x7fb20060  sq          $s2, 0x60($sp)
    ctx->pc = 0x2d2998u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 96), GPR_VEC(ctx, 18));
label_2d299c:
    // 0x2d299c: 0x7fb30050  sq          $s3, 0x50($sp)
    ctx->pc = 0x2d299cu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 80), GPR_VEC(ctx, 19));
label_2d29a0:
    // 0x2d29a0: 0x7fb40040  sq          $s4, 0x40($sp)
    ctx->pc = 0x2d29a0u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 64), GPR_VEC(ctx, 20));
label_2d29a4:
    // 0x2d29a4: 0x7fb50030  sq          $s5, 0x30($sp)
    ctx->pc = 0x2d29a4u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 48), GPR_VEC(ctx, 21));
label_2d29a8:
    // 0x2d29a8: 0x7fb60020  sq          $s6, 0x20($sp)
    ctx->pc = 0x2d29a8u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 22));
label_2d29ac:
    // 0x2d29ac: 0x7fb70010  sq          $s7, 0x10($sp)
    ctx->pc = 0x2d29acu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 23));
label_2d29b0:
    // 0x2d29b0: 0x14a20369  bne         $a1, $v0, . + 4 + (0x369 << 2)
label_2d29b4:
    if (ctx->pc == 0x2D29B4u) {
        ctx->pc = 0x2D29B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D29B0u;
        // 0x2d29b4: 0x7fbe0000  sq          $fp, 0x0($sp) (Delay Slot)
        WRITE128(ADD32(GPR_U32(ctx, 29), 0), GPR_VEC(ctx, 30));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D29B8u;
        goto label_2d29b8;
    }
    ctx->pc = 0x2D29B0u;
    {
        const bool branch_taken_0x2d29b0 = (GPR_U64(ctx, 5) != GPR_U64(ctx, 2));
        ctx->pc = 0x2D29B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D29B0u;
        // 0x2d29b4: 0x7fbe0000  sq          $fp, 0x0($sp) (Delay Slot)
        WRITE128(ADD32(GPR_U32(ctx, 29), 0), GPR_VEC(ctx, 30));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2d29b0) {
            ctx->pc = 0x2D3758u;
            goto label_2d3758;
        }
    }
    ctx->pc = 0x2D29B8u;
label_2d29b8:
    // 0x2d29b8: 0x10800367  beqz        $a0, . + 4 + (0x367 << 2)
label_2d29bc:
    if (ctx->pc == 0x2D29BCu) {
        ctx->pc = 0x2D29BCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D29B8u;
        // 0x2d29bc: 0x3c02004d  lui         $v0, 0x4D (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)77 << 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D29C0u;
        goto label_2d29c0;
    }
    ctx->pc = 0x2D29B8u;
    {
        const bool branch_taken_0x2d29b8 = (GPR_U64(ctx, 4) == GPR_U64(ctx, 0));
        ctx->pc = 0x2D29BCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D29B8u;
        // 0x2d29bc: 0x3c02004d  lui         $v0, 0x4D (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)77 << 16));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2d29b8) {
            ctx->pc = 0x2D3758u;
            goto label_2d3758;
        }
    }
    ctx->pc = 0x2D29C0u;
label_2d29c0:
    // 0x2d29c0: 0xc788c06c  lwc1        $f8, -0x3F94($gp)
    ctx->pc = 0x2d29c0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951020)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[8] = f; }
label_2d29c4:
    // 0x2d29c4: 0xc789c070  lwc1        $f9, -0x3F90($gp)
    ctx->pc = 0x2d29c4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951024)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[9] = f; }
label_2d29c8:
    // 0x2d29c8: 0x24454da0  addiu       $a1, $v0, 0x4DA0
    ctx->pc = 0x2d29c8u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 2), 19872));
label_2d29cc:
    // 0x2d29cc: 0xc78ac074  lwc1        $f10, -0x3F8C($gp)
    ctx->pc = 0x2d29ccu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951028)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[10] = f; }
label_2d29d0:
    // 0x2d29d0: 0x3c0d004d  lui         $t5, 0x4D
    ctx->pc = 0x2d29d0u;
    SET_GPR_S32(ctx, 13, (int32_t)((uint32_t)77 << 16));
label_2d29d4:
    // 0x2d29d4: 0x3c0e004d  lui         $t6, 0x4D
    ctx->pc = 0x2d29d4u;
    SET_GPR_S32(ctx, 14, (int32_t)((uint32_t)77 << 16));
label_2d29d8:
    // 0x2d29d8: 0x3c0f004d  lui         $t7, 0x4D
    ctx->pc = 0x2d29d8u;
    SET_GPR_S32(ctx, 15, (int32_t)((uint32_t)77 << 16));
label_2d29dc:
    // 0x2d29dc: 0xc786c078  lwc1        $f6, -0x3F88($gp)
    ctx->pc = 0x2d29dcu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951032)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[6] = f; }
label_2d29e0:
    // 0x2d29e0: 0x25e24dd0  addiu       $v0, $t7, 0x4DD0
    ctx->pc = 0x2d29e0u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 15), 19920));
label_2d29e4:
    // 0x2d29e4: 0xe5a84db0  swc1        $f8, 0x4DB0($t5)
    ctx->pc = 0x2d29e4u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 19888), bits); }
label_2d29e8:
    // 0x2d29e8: 0x3c12004d  lui         $s2, 0x4D
    ctx->pc = 0x2d29e8u;
    SET_GPR_S32(ctx, 18, (int32_t)((uint32_t)77 << 16));
label_2d29ec:
    // 0x2d29ec: 0xe5c94dc0  swc1        $f9, 0x4DC0($t6)
    ctx->pc = 0x2d29ecu;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 19904), bits); }
label_2d29f0:
    // 0x2d29f0: 0x26484df0  addiu       $t0, $s2, 0x4DF0
    ctx->pc = 0x2d29f0u;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 18), 19952));
label_2d29f4:
    // 0x2d29f4: 0xe5ea4dd0  swc1        $f10, 0x4DD0($t7)
    ctx->pc = 0x2d29f4u;
    { float f = ctx->f[10]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 19920), bits); }
label_2d29f8:
    // 0x2d29f8: 0x3c11004d  lui         $s1, 0x4D
    ctx->pc = 0x2d29f8u;
    SET_GPR_S32(ctx, 17, (int32_t)((uint32_t)77 << 16));
label_2d29fc:
    // 0x2d29fc: 0xc784c07c  lwc1        $f4, -0x3F84($gp)
    ctx->pc = 0x2d29fcu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951036)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[4] = f; }
label_2d2a00:
    // 0x2d2a00: 0x3c13004d  lui         $s3, 0x4D
    ctx->pc = 0x2d2a00u;
    SET_GPR_S32(ctx, 19, (int32_t)((uint32_t)77 << 16));
label_2d2a04:
    // 0x2d2a04: 0xe446000c  swc1        $f6, 0xC($v0)
    ctx->pc = 0x2d2a04u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 12), bits); }
label_2d2a08:
    // 0x2d2a08: 0x26234de0  addiu       $v1, $s1, 0x4DE0
    ctx->pc = 0x2d2a08u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 17), 19936));
label_2d2a0c:
    // 0x2d2a0c: 0xc787c080  lwc1        $f7, -0x3F80($gp)
    ctx->pc = 0x2d2a0cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951040)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[7] = f; }
label_2d2a10:
    // 0x2d2a10: 0x26644e00  addiu       $a0, $s3, 0x4E00
    ctx->pc = 0x2d2a10u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 19), 19968));
label_2d2a14:
    // 0x2d2a14: 0xc785c084  lwc1        $f5, -0x3F7C($gp)
    ctx->pc = 0x2d2a14u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951044)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[5] = f; }
label_2d2a18:
    // 0x2d2a18: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2a18u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2a1c:
    // 0x2d2a1c: 0xe6444df0  swc1        $f4, 0x4DF0($s2)
    ctx->pc = 0x2d2a1cu;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 18), 19952), bits); }
label_2d2a20:
    // 0x2d2a20: 0x26cf4e60  addiu       $t7, $s6, 0x4E60
    ctx->pc = 0x2d2a20u;
    SET_GPR_S32(ctx, 15, (int32_t)ADD32(GPR_U32(ctx, 22), 20064));
label_2d2a24:
    // 0x2d2a24: 0xe6274de0  swc1        $f7, 0x4DE0($s1)
    ctx->pc = 0x2d2a24u;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 19936), bits); }
label_2d2a28:
    // 0x2d2a28: 0x3c12004d  lui         $s2, 0x4D
    ctx->pc = 0x2d2a28u;
    SET_GPR_S32(ctx, 18, (int32_t)((uint32_t)77 << 16));
label_2d2a2c:
    // 0x2d2a2c: 0xe6654e00  swc1        $f5, 0x4E00($s3)
    ctx->pc = 0x2d2a2cu;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 19968), bits); }
label_2d2a30:
    // 0x2d2a30: 0x26514e80  addiu       $s1, $s2, 0x4E80
    ctx->pc = 0x2d2a30u;
    SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 18), 20096));
label_2d2a34:
    // 0x2d2a34: 0xc782c088  lwc1        $f2, -0x3F78($gp)
    ctx->pc = 0x2d2a34u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951048)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[2] = f; }
label_2d2a38:
    // 0x2d2a38: 0x3c13004d  lui         $s3, 0x4D
    ctx->pc = 0x2d2a38u;
    SET_GPR_S32(ctx, 19, (int32_t)((uint32_t)77 << 16));
label_2d2a3c:
    // 0x2d2a3c: 0xc781c08c  lwc1        $f1, -0x3F74($gp)
    ctx->pc = 0x2d2a3cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951052)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_2d2a40:
    // 0x2d2a40: 0x26724e90  addiu       $s2, $s3, 0x4E90
    ctx->pc = 0x2d2a40u;
    SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 19), 20112));
label_2d2a44:
    // 0x2d2a44: 0xe482000c  swc1        $f2, 0xC($a0)
    ctx->pc = 0x2d2a44u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 12), bits); }
label_2d2a48:
    // 0x2d2a48: 0x3c0b004d  lui         $t3, 0x4D
    ctx->pc = 0x2d2a48u;
    SET_GPR_S32(ctx, 11, (int32_t)((uint32_t)77 << 16));
label_2d2a4c:
    // 0x2d2a4c: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2a4cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2a50:
    // 0x2d2a50: 0x3c013f80  lui         $at, 0x3F80
    ctx->pc = 0x2d2a50u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16256 << 16));
label_2d2a54:
    // 0x2d2a54: 0x44810000  mtc1        $at, $f0
    ctx->pc = 0x2d2a54u;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[0], &bits, sizeof(bits)); }
label_2d2a58:
    // 0x2d2a58: 0xe5614e20  swc1        $f1, 0x4E20($t3)
    ctx->pc = 0x2d2a58u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 20000), bits); }
label_2d2a5c:
    // 0x2d2a5c: 0x256c4e20  addiu       $t4, $t3, 0x4E20
    ctx->pc = 0x2d2a5cu;
    SET_GPR_S32(ctx, 12, (int32_t)ADD32(GPR_U32(ctx, 11), 20000));
label_2d2a60:
    // 0x2d2a60: 0x26d34ea0  addiu       $s3, $s6, 0x4EA0
    ctx->pc = 0x2d2a60u;
    SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 22), 20128));
label_2d2a64:
    // 0x2d2a64: 0xc783c090  lwc1        $f3, -0x3F70($gp)
    ctx->pc = 0x2d2a64u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951056)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[3] = f; }
label_2d2a68:
    // 0x2d2a68: 0x3c013f00  lui         $at, 0x3F00
    ctx->pc = 0x2d2a68u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16128 << 16));
label_2d2a6c:
    // 0x2d2a6c: 0x44818000  mtc1        $at, $f16
    ctx->pc = 0x2d2a6cu;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[16], &bits, sizeof(bits)); }
label_2d2a70:
    // 0x2d2a70: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2a70u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2a74:
    // 0x2d2a74: 0x3c0b004d  lui         $t3, 0x4D
    ctx->pc = 0x2d2a74u;
    SET_GPR_S32(ctx, 11, (int32_t)((uint32_t)77 << 16));
label_2d2a78:
    // 0x2d2a78: 0xe6c34e10  swc1        $f3, 0x4E10($s6)
    ctx->pc = 0x2d2a78u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 19984), bits); }
label_2d2a7c:
    // 0x2d2a7c: 0xe5604da0  swc1        $f0, 0x4DA0($t3)
    ctx->pc = 0x2d2a7cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 19872), bits); }
label_2d2a80:
    // 0x2d2a80: 0x25a74db0  addiu       $a3, $t5, 0x4DB0
    ctx->pc = 0x2d2a80u;
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 13), 19888));
label_2d2a84:
    // 0x2d2a84: 0xe4b0000c  swc1        $f16, 0xC($a1)
    ctx->pc = 0x2d2a84u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 12), bits); }
label_2d2a88:
    // 0x2d2a88: 0x25c94dc0  addiu       $t1, $t6, 0x4DC0
    ctx->pc = 0x2d2a88u;
    SET_GPR_S32(ctx, 9, (int32_t)ADD32(GPR_U32(ctx, 14), 19904));
label_2d2a8c:
    // 0x2d2a8c: 0xace0000c  sw          $zero, 0xC($a3)
    ctx->pc = 0x2d2a8cu;
    WRITE32(ADD32(GPR_U32(ctx, 7), 12), GPR_U32(ctx, 0));
label_2d2a90:
    // 0x2d2a90: 0x3c0a004d  lui         $t2, 0x4D
    ctx->pc = 0x2d2a90u;
    SET_GPR_S32(ctx, 10, (int32_t)((uint32_t)77 << 16));
label_2d2a94:
    // 0x2d2a94: 0xc791c094  lwc1        $f17, -0x3F6C($gp)
    ctx->pc = 0x2d2a94u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951060)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[17] = f; }
label_2d2a98:
    // 0x2d2a98: 0x25464e10  addiu       $a2, $t2, 0x4E10
    ctx->pc = 0x2d2a98u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 10), 19984));
label_2d2a9c:
    // 0x2d2a9c: 0xc792c098  lwc1        $f18, -0x3F68($gp)
    ctx->pc = 0x2d2a9cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951064)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[18] = f; }
label_2d2aa0:
    // 0x2d2aa0: 0x3c15004d  lui         $s5, 0x4D
    ctx->pc = 0x2d2aa0u;
    SET_GPR_S32(ctx, 21, (int32_t)((uint32_t)77 << 16));
label_2d2aa4:
    // 0x2d2aa4: 0xad20000c  sw          $zero, 0xC($t1)
    ctx->pc = 0x2d2aa4u;
    WRITE32(ADD32(GPR_U32(ctx, 9), 12), GPR_U32(ctx, 0));
label_2d2aa8:
    // 0x2d2aa8: 0x26aa4e30  addiu       $t2, $s5, 0x4E30
    ctx->pc = 0x2d2aa8u;
    SET_GPR_S32(ctx, 10, (int32_t)ADD32(GPR_U32(ctx, 21), 20016));
label_2d2aac:
    // 0x2d2aac: 0xc78cc09c  lwc1        $f12, -0x3F64($gp)
    ctx->pc = 0x2d2aacu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951068)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[12] = f; }
label_2d2ab0:
    // 0x2d2ab0: 0x3c14004d  lui         $s4, 0x4D
    ctx->pc = 0x2d2ab0u;
    SET_GPR_S32(ctx, 20, (int32_t)((uint32_t)77 << 16));
label_2d2ab4:
    // 0x2d2ab4: 0xc78dc0a0  lwc1        $f13, -0x3F60($gp)
    ctx->pc = 0x2d2ab4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951072)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[13] = f; }
label_2d2ab8:
    // 0x2d2ab8: 0x268d4e40  addiu       $t5, $s4, 0x4E40
    ctx->pc = 0x2d2ab8u;
    SET_GPR_S32(ctx, 13, (int32_t)ADD32(GPR_U32(ctx, 20), 20032));
label_2d2abc:
    // 0x2d2abc: 0xe4510004  swc1        $f17, 0x4($v0)
    ctx->pc = 0x2d2abcu;
    { float f = ctx->f[17]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 4), bits); }
label_2d2ac0:
    // 0x2d2ac0: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2ac0u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2ac4:
    // 0x2d2ac4: 0xe4520008  swc1        $f18, 0x8($v0)
    ctx->pc = 0x2d2ac4u;
    { float f = ctx->f[18]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 8), bits); }
label_2d2ac8:
    // 0x2d2ac8: 0x260e4e50  addiu       $t6, $s0, 0x4E50
    ctx->pc = 0x2d2ac8u;
    SET_GPR_S32(ctx, 14, (int32_t)ADD32(GPR_U32(ctx, 16), 20048));
label_2d2acc:
    // 0x2d2acc: 0xe46c0004  swc1        $f12, 0x4($v1)
    ctx->pc = 0x2d2accu;
    { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 4), bits); }
label_2d2ad0:
    // 0x2d2ad0: 0x3c02004d  lui         $v0, 0x4D
    ctx->pc = 0x2d2ad0u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)77 << 16));
label_2d2ad4:
    // 0x2d2ad4: 0xe46d0008  swc1        $f13, 0x8($v1)
    ctx->pc = 0x2d2ad4u;
    { float f = ctx->f[13]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 8), bits); }
label_2d2ad8:
    // 0x2d2ad8: 0x244b4ef0  addiu       $t3, $v0, 0x4EF0
    ctx->pc = 0x2d2ad8u;
    SET_GPR_S32(ctx, 11, (int32_t)ADD32(GPR_U32(ctx, 2), 20208));
label_2d2adc:
    // 0x2d2adc: 0xac60000c  sw          $zero, 0xC($v1)
    ctx->pc = 0x2d2adcu;
    WRITE32(ADD32(GPR_U32(ctx, 3), 12), GPR_U32(ctx, 0));
label_2d2ae0:
    // 0x2d2ae0: 0x3c02004d  lui         $v0, 0x4D
    ctx->pc = 0x2d2ae0u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)77 << 16));
label_2d2ae4:
    // 0x2d2ae4: 0xc78ec0a4  lwc1        $f14, -0x3F5C($gp)
    ctx->pc = 0x2d2ae4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951076)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[14] = f; }
label_2d2ae8:
    // 0x2d2ae8: 0x3c03004d  lui         $v1, 0x4D
    ctx->pc = 0x2d2ae8u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)77 << 16));
label_2d2aec:
    // 0x2d2aec: 0xc78fc0a8  lwc1        $f15, -0x3F58($gp)
    ctx->pc = 0x2d2aecu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951080)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[15] = f; }
label_2d2af0:
    // 0x2d2af0: 0x24774f30  addiu       $s7, $v1, 0x4F30
    ctx->pc = 0x2d2af0u;
    SET_GPR_S32(ctx, 23, (int32_t)ADD32(GPR_U32(ctx, 3), 20272));
label_2d2af4:
    // 0x2d2af4: 0xad00000c  sw          $zero, 0xC($t0)
    ctx->pc = 0x2d2af4u;
    WRITE32(ADD32(GPR_U32(ctx, 8), 12), GPR_U32(ctx, 0));
label_2d2af8:
    // 0x2d2af8: 0x3c03004d  lui         $v1, 0x4D
    ctx->pc = 0x2d2af8u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)77 << 16));
label_2d2afc:
    // 0x2d2afc: 0xc78bc0ac  lwc1        $f11, -0x3F54($gp)
    ctx->pc = 0x2d2afcu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951084)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[11] = f; }
label_2d2b00:
    // 0x2d2b00: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2b00u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2b04:
    // 0x2d2b04: 0xe48e0004  swc1        $f14, 0x4($a0)
    ctx->pc = 0x2d2b04u;
    { float f = ctx->f[14]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 4), bits); }
label_2d2b08:
    // 0x2d2b08: 0x26de4ee0  addiu       $fp, $s6, 0x4EE0
    ctx->pc = 0x2d2b08u;
    SET_GPR_S32(ctx, 30, (int32_t)ADD32(GPR_U32(ctx, 22), 20192));
label_2d2b0c:
    // 0x2d2b0c: 0xe48f0008  swc1        $f15, 0x8($a0)
    ctx->pc = 0x2d2b0cu;
    { float f = ctx->f[15]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 8), bits); }
label_2d2b10:
    // 0x2d2b10: 0xe4cb0004  swc1        $f11, 0x4($a2)
    ctx->pc = 0x2d2b10u;
    { float f = ctx->f[11]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 4), bits); }
label_2d2b14:
    // 0x2d2b14: 0x3c04004d  lui         $a0, 0x4D
    ctx->pc = 0x2d2b14u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)77 << 16));
label_2d2b18:
    // 0x2d2b18: 0xe4c0000c  swc1        $f0, 0xC($a2)
    ctx->pc = 0x2d2b18u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 12), bits); }
label_2d2b1c:
    // 0x2d2b1c: 0x24994f40  addiu       $t9, $a0, 0x4F40
    ctx->pc = 0x2d2b1cu;
    SET_GPR_S32(ctx, 25, (int32_t)ADD32(GPR_U32(ctx, 4), 20288));
label_2d2b20:
    // 0x2d2b20: 0xe4a00004  swc1        $f0, 0x4($a1)
    ctx->pc = 0x2d2b20u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 4), bits); }
label_2d2b24:
    // 0x2d2b24: 0x3c04004d  lui         $a0, 0x4D
    ctx->pc = 0x2d2b24u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)77 << 16));
label_2d2b28:
    // 0x2d2b28: 0xe4a00008  swc1        $f0, 0x8($a1)
    ctx->pc = 0x2d2b28u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 8), bits); }
label_2d2b2c:
    // 0x2d2b2c: 0xe4e00004  swc1        $f0, 0x4($a3)
    ctx->pc = 0x2d2b2cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 4), bits); }
label_2d2b30:
    // 0x2d2b30: 0x3c05004d  lui         $a1, 0x4D
    ctx->pc = 0x2d2b30u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)77 << 16));
label_2d2b34:
    // 0x2d2b34: 0xe4e00008  swc1        $f0, 0x8($a3)
    ctx->pc = 0x2d2b34u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 8), bits); }
label_2d2b38:
    // 0x2d2b38: 0x24b84f50  addiu       $t8, $a1, 0x4F50
    ctx->pc = 0x2d2b38u;
    SET_GPR_S32(ctx, 24, (int32_t)ADD32(GPR_U32(ctx, 5), 20304));
label_2d2b3c:
    // 0x2d2b3c: 0xe5200004  swc1        $f0, 0x4($t1)
    ctx->pc = 0x2d2b3cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 4), bits); }
label_2d2b40:
    // 0x2d2b40: 0x3c05004d  lui         $a1, 0x4D
    ctx->pc = 0x2d2b40u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)77 << 16));
label_2d2b44:
    // 0x2d2b44: 0xe5200008  swc1        $f0, 0x8($t1)
    ctx->pc = 0x2d2b44u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 8), bits); }
label_2d2b48:
    // 0x2d2b48: 0xe5000004  swc1        $f0, 0x4($t0)
    ctx->pc = 0x2d2b48u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 4), bits); }
label_2d2b4c:
    // 0x2d2b4c: 0x3c09004d  lui         $t1, 0x4D
    ctx->pc = 0x2d2b4cu;
    SET_GPR_S32(ctx, 9, (int32_t)((uint32_t)77 << 16));
label_2d2b50:
    // 0x2d2b50: 0xe5000008  swc1        $f0, 0x8($t0)
    ctx->pc = 0x2d2b50u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 8), bits); }
label_2d2b54:
    // 0x2d2b54: 0xc793c0b0  lwc1        $f19, -0x3F50($gp)
    ctx->pc = 0x2d2b54u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951088)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[19] = f; }
label_2d2b58:
    // 0x2d2b58: 0x3c08004d  lui         $t0, 0x4D
    ctx->pc = 0x2d2b58u;
    SET_GPR_S32(ctx, 8, (int32_t)((uint32_t)77 << 16));
label_2d2b5c:
    // 0x2d2b5c: 0xe4c00008  swc1        $f0, 0x8($a2)
    ctx->pc = 0x2d2b5cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 8), bits); }
label_2d2b60:
    // 0x2d2b60: 0xc782c0b4  lwc1        $f2, -0x3F4C($gp)
    ctx->pc = 0x2d2b60u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951092)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[2] = f; }
label_2d2b64:
    // 0x2d2b64: 0x3c06004d  lui         $a2, 0x4D
    ctx->pc = 0x2d2b64u;
    SET_GPR_S32(ctx, 6, (int32_t)((uint32_t)77 << 16));
label_2d2b68:
    // 0x2d2b68: 0xe5930004  swc1        $f19, 0x4($t4)
    ctx->pc = 0x2d2b68u;
    { float f = ctx->f[19]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 4), bits); }
label_2d2b6c:
    // 0x2d2b6c: 0x24d64fa0  addiu       $s6, $a2, 0x4FA0
    ctx->pc = 0x2d2b6cu;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 6), 20384));
label_2d2b70:
    // 0x2d2b70: 0xc781c0b8  lwc1        $f1, -0x3F48($gp)
    ctx->pc = 0x2d2b70u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951096)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_2d2b74:
    // 0x2d2b74: 0x3c06004d  lui         $a2, 0x4D
    ctx->pc = 0x2d2b74u;
    SET_GPR_S32(ctx, 6, (int32_t)((uint32_t)77 << 16));
label_2d2b78:
    // 0x2d2b78: 0xe6a24e30  swc1        $f2, 0x4E30($s5)
    ctx->pc = 0x2d2b78u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 21), 20016), bits); }
label_2d2b7c:
    // 0x2d2b7c: 0x24c75140  addiu       $a3, $a2, 0x5140
    ctx->pc = 0x2d2b7cu;
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 6), 20800));
label_2d2b80:
    // 0x2d2b80: 0xc787c0bc  lwc1        $f7, -0x3F44($gp)
    ctx->pc = 0x2d2b80u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951100)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[7] = f; }
label_2d2b84:
    // 0x2d2b84: 0xe541000c  swc1        $f1, 0xC($t2)
    ctx->pc = 0x2d2b84u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 12), bits); }
label_2d2b88:
    // 0x2d2b88: 0xc783c0c0  lwc1        $f3, -0x3F40($gp)
    ctx->pc = 0x2d2b88u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951104)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[3] = f; }
label_2d2b8c:
    // 0x2d2b8c: 0xe5e7000c  swc1        $f7, 0xC($t7)
    ctx->pc = 0x2d2b8cu;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 12), bits); }
label_2d2b90:
    // 0x2d2b90: 0xc784c0c4  lwc1        $f4, -0x3F3C($gp)
    ctx->pc = 0x2d2b90u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951108)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[4] = f; }
label_2d2b94:
    // 0x2d2b94: 0xc785c0c8  lwc1        $f5, -0x3F38($gp)
    ctx->pc = 0x2d2b94u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951112)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[5] = f; }
label_2d2b98:
    // 0x2d2b98: 0xe5830008  swc1        $f3, 0x8($t4)
    ctx->pc = 0x2d2b98u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 8), bits); }
label_2d2b9c:
    // 0x2d2b9c: 0xad80000c  sw          $zero, 0xC($t4)
    ctx->pc = 0x2d2b9cu;
    WRITE32(ADD32(GPR_U32(ctx, 12), 12), GPR_U32(ctx, 0));
label_2d2ba0:
    // 0x2d2ba0: 0xe5440004  swc1        $f4, 0x4($t2)
    ctx->pc = 0x2d2ba0u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 4), bits); }
label_2d2ba4:
    // 0x2d2ba4: 0x3c0c004d  lui         $t4, 0x4D
    ctx->pc = 0x2d2ba4u;
    SET_GPR_S32(ctx, 12, (int32_t)((uint32_t)77 << 16));
label_2d2ba8:
    // 0x2d2ba8: 0xe5450008  swc1        $f5, 0x8($t2)
    ctx->pc = 0x2d2ba8u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 8), bits); }
label_2d2bac:
    // 0x2d2bac: 0xe6804e40  swc1        $f0, 0x4E40($s4)
    ctx->pc = 0x2d2bacu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 20), 20032), bits); }
label_2d2bb0:
    // 0x2d2bb0: 0x120502d  daddu       $t2, $t1, $zero
    ctx->pc = 0x2d2bb0u;
    SET_GPR_U64(ctx, 10, (uint64_t)GPR_U64(ctx, 9) + (uint64_t)GPR_U64(ctx, 0));
label_2d2bb4:
    // 0x2d2bb4: 0xe5a0000c  swc1        $f0, 0xC($t5)
    ctx->pc = 0x2d2bb4u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 12), bits); }
label_2d2bb8:
    // 0x2d2bb8: 0x254a4e70  addiu       $t2, $t2, 0x4E70
    ctx->pc = 0x2d2bb8u;
    SET_GPR_S32(ctx, 10, (int32_t)ADD32(GPR_U32(ctx, 10), 20080));
label_2d2bbc:
    // 0x2d2bbc: 0xe6004e50  swc1        $f0, 0x4E50($s0)
    ctx->pc = 0x2d2bbcu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20048), bits); }
label_2d2bc0:
    // 0x2d2bc0: 0xadc0000c  sw          $zero, 0xC($t6)
    ctx->pc = 0x2d2bc0u;
    WRITE32(ADD32(GPR_U32(ctx, 14), 12), GPR_U32(ctx, 0));
label_2d2bc4:
    // 0x2d2bc4: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2bc4u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2bc8:
    // 0x2d2bc8: 0xc786c0cc  lwc1        $f6, -0x3F34($gp)
    ctx->pc = 0x2d2bc8u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951116)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[6] = f; }
label_2d2bcc:
    // 0x2d2bcc: 0xe5004e60  swc1        $f0, 0x4E60($t0)
    ctx->pc = 0x2d2bccu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 20064), bits); }
label_2d2bd0:
    // 0x2d2bd0: 0xe5e60008  swc1        $f6, 0x8($t7)
    ctx->pc = 0x2d2bd0u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 8), bits); }
label_2d2bd4:
    // 0x2d2bd4: 0xa0402d  daddu       $t0, $a1, $zero
    ctx->pc = 0x2d2bd4u;
    SET_GPR_U64(ctx, 8, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_2d2bd8:
    // 0x2d2bd8: 0xe5204e70  swc1        $f0, 0x4E70($t1)
    ctx->pc = 0x2d2bd8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 20080), bits); }
label_2d2bdc:
    // 0x2d2bdc: 0x25084eb0  addiu       $t0, $t0, 0x4EB0
    ctx->pc = 0x2d2bdcu;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 8), 20144));
label_2d2be0:
    // 0x2d2be0: 0xe540000c  swc1        $f0, 0xC($t2)
    ctx->pc = 0x2d2be0u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 12), bits); }
label_2d2be4:
    // 0x2d2be4: 0x3c09004d  lui         $t1, 0x4D
    ctx->pc = 0x2d2be4u;
    SET_GPR_S32(ctx, 9, (int32_t)((uint32_t)77 << 16));
label_2d2be8:
    // 0x2d2be8: 0xe5804e80  swc1        $f0, 0x4E80($t4)
    ctx->pc = 0x2d2be8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 20096), bits); }
label_2d2bec:
    // 0x2d2bec: 0xe620000c  swc1        $f0, 0xC($s1)
    ctx->pc = 0x2d2becu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 12), bits); }
label_2d2bf0:
    // 0x2d2bf0: 0x3c0c004d  lui         $t4, 0x4D
    ctx->pc = 0x2d2bf0u;
    SET_GPR_S32(ctx, 12, (int32_t)((uint32_t)77 << 16));
label_2d2bf4:
    // 0x2d2bf4: 0xe6004e90  swc1        $f0, 0x4E90($s0)
    ctx->pc = 0x2d2bf4u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20112), bits); }
label_2d2bf8:
    // 0x2d2bf8: 0xae40000c  sw          $zero, 0xC($s2)
    ctx->pc = 0x2d2bf8u;
    WRITE32(ADD32(GPR_U32(ctx, 18), 12), GPR_U32(ctx, 0));
label_2d2bfc:
    // 0x2d2bfc: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2bfcu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2c00:
    // 0x2d2c00: 0xe4404ea0  swc1        $f0, 0x4EA0($v0)
    ctx->pc = 0x2d2c00u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 20128), bits); }
label_2d2c04:
    // 0x2d2c04: 0xe5a00004  swc1        $f0, 0x4($t5)
    ctx->pc = 0x2d2c04u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 4), bits); }
label_2d2c08:
    // 0x2d2c08: 0xe5a00008  swc1        $f0, 0x8($t5)
    ctx->pc = 0x2d2c08u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 8), bits); }
label_2d2c0c:
    // 0x2d2c0c: 0xadc00004  sw          $zero, 0x4($t6)
    ctx->pc = 0x2d2c0cu;
    WRITE32(ADD32(GPR_U32(ctx, 14), 4), GPR_U32(ctx, 0));
label_2d2c10:
    // 0x2d2c10: 0xadc00008  sw          $zero, 0x8($t6)
    ctx->pc = 0x2d2c10u;
    WRITE32(ADD32(GPR_U32(ctx, 14), 8), GPR_U32(ctx, 0));
label_2d2c14:
    // 0x2d2c14: 0xe5e70004  swc1        $f7, 0x4($t7)
    ctx->pc = 0x2d2c14u;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 4), bits); }
label_2d2c18:
    // 0x2d2c18: 0x180702d  daddu       $t6, $t4, $zero
    ctx->pc = 0x2d2c18u;
    SET_GPR_U64(ctx, 14, (uint64_t)GPR_U64(ctx, 12) + (uint64_t)GPR_U64(ctx, 0));
label_2d2c1c:
    // 0x2d2c1c: 0xe5400004  swc1        $f0, 0x4($t2)
    ctx->pc = 0x2d2c1cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 4), bits); }
label_2d2c20:
    // 0x2d2c20: 0x25ce4ed0  addiu       $t6, $t6, 0x4ED0
    ctx->pc = 0x2d2c20u;
    SET_GPR_S32(ctx, 14, (int32_t)ADD32(GPR_U32(ctx, 14), 20176));
label_2d2c24:
    // 0x2d2c24: 0xe5400008  swc1        $f0, 0x8($t2)
    ctx->pc = 0x2d2c24u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 8), bits); }
label_2d2c28:
    // 0x2d2c28: 0x3c0f004d  lui         $t7, 0x4D
    ctx->pc = 0x2d2c28u;
    SET_GPR_S32(ctx, 15, (int32_t)((uint32_t)77 << 16));
label_2d2c2c:
    // 0x2d2c2c: 0xe6200004  swc1        $f0, 0x4($s1)
    ctx->pc = 0x2d2c2cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 4), bits); }
label_2d2c30:
    // 0x2d2c30: 0x120502d  daddu       $t2, $t1, $zero
    ctx->pc = 0x2d2c30u;
    SET_GPR_U64(ctx, 10, (uint64_t)GPR_U64(ctx, 9) + (uint64_t)GPR_U64(ctx, 0));
label_2d2c34:
    // 0x2d2c34: 0xe6200008  swc1        $f0, 0x8($s1)
    ctx->pc = 0x2d2c34u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 8), bits); }
label_2d2c38:
    // 0x2d2c38: 0x254a4ec0  addiu       $t2, $t2, 0x4EC0
    ctx->pc = 0x2d2c38u;
    SET_GPR_S32(ctx, 10, (int32_t)ADD32(GPR_U32(ctx, 10), 20160));
label_2d2c3c:
    // 0x2d2c3c: 0xae400004  sw          $zero, 0x4($s2)
    ctx->pc = 0x2d2c3cu;
    WRITE32(ADD32(GPR_U32(ctx, 18), 4), GPR_U32(ctx, 0));
label_2d2c40:
    // 0x2d2c40: 0xae400008  sw          $zero, 0x8($s2)
    ctx->pc = 0x2d2c40u;
    WRITE32(ADD32(GPR_U32(ctx, 18), 8), GPR_U32(ctx, 0));
label_2d2c44:
    // 0x2d2c44: 0xae600004  sw          $zero, 0x4($s3)
    ctx->pc = 0x2d2c44u;
    WRITE32(ADD32(GPR_U32(ctx, 19), 4), GPR_U32(ctx, 0));
label_2d2c48:
    // 0x2d2c48: 0x3c12004d  lui         $s2, 0x4D
    ctx->pc = 0x2d2c48u;
    SET_GPR_S32(ctx, 18, (int32_t)((uint32_t)77 << 16));
label_2d2c4c:
    // 0x2d2c4c: 0xae600008  sw          $zero, 0x8($s3)
    ctx->pc = 0x2d2c4cu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 8), GPR_U32(ctx, 0));
label_2d2c50:
    // 0x2d2c50: 0x26425160  addiu       $v0, $s2, 0x5160
    ctx->pc = 0x2d2c50u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 18), 20832));
label_2d2c54:
    // 0x2d2c54: 0xc782c0d0  lwc1        $f2, -0x3F30($gp)
    ctx->pc = 0x2d2c54u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951120)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[2] = f; }
label_2d2c58:
    // 0x2d2c58: 0x3c12004d  lui         $s2, 0x4D
    ctx->pc = 0x2d2c58u;
    SET_GPR_S32(ctx, 18, (int32_t)((uint32_t)77 << 16));
label_2d2c5c:
    // 0x2d2c5c: 0xae60000c  sw          $zero, 0xC($s3)
    ctx->pc = 0x2d2c5cu;
    WRITE32(ADD32(GPR_U32(ctx, 19), 12), GPR_U32(ctx, 0));
label_2d2c60:
    // 0x2d2c60: 0xc781c0d4  lwc1        $f1, -0x3F2C($gp)
    ctx->pc = 0x2d2c60u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951124)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_2d2c64:
    // 0x2d2c64: 0x3c13004d  lui         $s3, 0x4D
    ctx->pc = 0x2d2c64u;
    SET_GPR_S32(ctx, 19, (int32_t)((uint32_t)77 << 16));
label_2d2c68:
    // 0x2d2c68: 0xe562000c  swc1        $f2, 0xC($t3)
    ctx->pc = 0x2d2c68u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 12), bits); }
label_2d2c6c:
    // 0x2d2c6c: 0x260302d  daddu       $a2, $s3, $zero
    ctx->pc = 0x2d2c6cu;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
label_2d2c70:
    // 0x2d2c70: 0xe4614f10  swc1        $f1, 0x4F10($v1)
    ctx->pc = 0x2d2c70u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 20240), bits); }
label_2d2c74:
    // 0x2d2c74: 0x24c64f00  addiu       $a2, $a2, 0x4F00
    ctx->pc = 0x2d2c74u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), 20224));
label_2d2c78:
    // 0x2d2c78: 0xe4a04eb0  swc1        $f0, 0x4EB0($a1)
    ctx->pc = 0x2d2c78u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 20144), bits); }
label_2d2c7c:
    // 0x2d2c7c: 0x24835120  addiu       $v1, $a0, 0x5120
    ctx->pc = 0x2d2c7cu;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 4), 20768));
label_2d2c80:
    // 0x2d2c80: 0xe500000c  swc1        $f0, 0xC($t0)
    ctx->pc = 0x2d2c80u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 12), bits); }
label_2d2c84:
    // 0x2d2c84: 0x3c05004d  lui         $a1, 0x4D
    ctx->pc = 0x2d2c84u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)77 << 16));
label_2d2c88:
    // 0x2d2c88: 0xe5204ec0  swc1        $f0, 0x4EC0($t1)
    ctx->pc = 0x2d2c88u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 20160), bits); }
label_2d2c8c:
    // 0x2d2c8c: 0x24a45180  addiu       $a0, $a1, 0x5180
    ctx->pc = 0x2d2c8cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 5), 20864));
label_2d2c90:
    // 0x2d2c90: 0xe550000c  swc1        $f16, 0xC($t2)
    ctx->pc = 0x2d2c90u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 12), bits); }
label_2d2c94:
    // 0x2d2c94: 0x3c08004d  lui         $t0, 0x4D
    ctx->pc = 0x2d2c94u;
    SET_GPR_S32(ctx, 8, (int32_t)((uint32_t)77 << 16));
label_2d2c98:
    // 0x2d2c98: 0xe5804ed0  swc1        $f0, 0x4ED0($t4)
    ctx->pc = 0x2d2c98u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 20176), bits); }
label_2d2c9c:
    // 0x2d2c9c: 0x3c0a004d  lui         $t2, 0x4D
    ctx->pc = 0x2d2c9cu;
    SET_GPR_S32(ctx, 10, (int32_t)((uint32_t)77 << 16));
label_2d2ca0:
    // 0x2d2ca0: 0xe5d0000c  swc1        $f16, 0xC($t6)
    ctx->pc = 0x2d2ca0u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 12), bits); }
label_2d2ca4:
    // 0x2d2ca4: 0x254a4f10  addiu       $t2, $t2, 0x4F10
    ctx->pc = 0x2d2ca4u;
    SET_GPR_S32(ctx, 10, (int32_t)ADD32(GPR_U32(ctx, 10), 20240));
label_2d2ca8:
    // 0x2d2ca8: 0xe5e04ee0  swc1        $f0, 0x4EE0($t7)
    ctx->pc = 0x2d2ca8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 20192), bits); }
label_2d2cac:
    // 0x2d2cac: 0x250551a0  addiu       $a1, $t0, 0x51A0
    ctx->pc = 0x2d2cacu;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 8), 20896));
label_2d2cb0:
    // 0x2d2cb0: 0xe7d0000c  swc1        $f16, 0xC($fp)
    ctx->pc = 0x2d2cb0u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 30), 12), bits); }
label_2d2cb4:
    // 0x2d2cb4: 0x3c09004d  lui         $t1, 0x4D
    ctx->pc = 0x2d2cb4u;
    SET_GPR_S32(ctx, 9, (int32_t)((uint32_t)77 << 16));
label_2d2cb8:
    // 0x2d2cb8: 0xc783c0d8  lwc1        $f3, -0x3F28($gp)
    ctx->pc = 0x2d2cb8u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951128)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[3] = f; }
label_2d2cbc:
    // 0x2d2cbc: 0x3c0e004d  lui         $t6, 0x4D
    ctx->pc = 0x2d2cbcu;
    SET_GPR_S32(ctx, 14, (int32_t)((uint32_t)77 << 16));
label_2d2cc0:
    // 0x2d2cc0: 0xc784c0dc  lwc1        $f4, -0x3F24($gp)
    ctx->pc = 0x2d2cc0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951132)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[4] = f; }
label_2d2cc4:
    // 0x2d2cc4: 0x25c851e0  addiu       $t0, $t6, 0x51E0
    ctx->pc = 0x2d2cc4u;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 14), 20960));
label_2d2cc8:
    // 0x2d2cc8: 0xe6004ef0  swc1        $f0, 0x4EF0($s0)
    ctx->pc = 0x2d2cc8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20208), bits); }
label_2d2ccc:
    // 0x2d2ccc: 0x3c0f004d  lui         $t7, 0x4D
    ctx->pc = 0x2d2cccu;
    SET_GPR_S32(ctx, 15, (int32_t)((uint32_t)77 << 16));
label_2d2cd0:
    // 0x2d2cd0: 0xe5630004  swc1        $f3, 0x4($t3)
    ctx->pc = 0x2d2cd0u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 4), bits); }
label_2d2cd4:
    // 0x2d2cd4: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2cd4u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2cd8:
    // 0x2d2cd8: 0xe5640008  swc1        $f4, 0x8($t3)
    ctx->pc = 0x2d2cd8u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 8), bits); }
label_2d2cdc:
    // 0x2d2cdc: 0x3c0e004d  lui         $t6, 0x4D
    ctx->pc = 0x2d2cdcu;
    SET_GPR_S32(ctx, 14, (int32_t)((uint32_t)77 << 16));
label_2d2ce0:
    // 0x2d2ce0: 0xc785c0e0  lwc1        $f5, -0x3F20($gp)
    ctx->pc = 0x2d2ce0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951136)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[5] = f; }
label_2d2ce4:
    // 0x2d2ce4: 0x3c0b004d  lui         $t3, 0x4D
    ctx->pc = 0x2d2ce4u;
    SET_GPR_S32(ctx, 11, (int32_t)((uint32_t)77 << 16));
label_2d2ce8:
    // 0x2d2ce8: 0xe6604f00  swc1        $f0, 0x4F00($s3)
    ctx->pc = 0x2d2ce8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 20224), bits); }
label_2d2cec:
    // 0x2d2cec: 0x160602d  daddu       $t4, $t3, $zero
    ctx->pc = 0x2d2cecu;
    SET_GPR_U64(ctx, 12, (uint64_t)GPR_U64(ctx, 11) + (uint64_t)GPR_U64(ctx, 0));
label_2d2cf0:
    // 0x2d2cf0: 0xc786c0e4  lwc1        $f6, -0x3F1C($gp)
    ctx->pc = 0x2d2cf0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951140)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[6] = f; }
label_2d2cf4:
    // 0x2d2cf4: 0x258c4f20  addiu       $t4, $t4, 0x4F20
    ctx->pc = 0x2d2cf4u;
    SET_GPR_S32(ctx, 12, (int32_t)ADD32(GPR_U32(ctx, 12), 20256));
label_2d2cf8:
    // 0x2d2cf8: 0xc787c0e8  lwc1        $f7, -0x3F18($gp)
    ctx->pc = 0x2d2cf8u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951144)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[7] = f; }
label_2d2cfc:
    // 0x2d2cfc: 0x3c13004d  lui         $s3, 0x4D
    ctx->pc = 0x2d2cfcu;
    SET_GPR_S32(ctx, 19, (int32_t)((uint32_t)77 << 16));
label_2d2d00:
    // 0x2d2d00: 0xe4c50008  swc1        $f5, 0x8($a2)
    ctx->pc = 0x2d2d00u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 8), bits); }
label_2d2d04:
    // 0x2d2d04: 0x26734eb0  addiu       $s3, $s3, 0x4EB0
    ctx->pc = 0x2d2d04u;
    SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 19), 20144));
label_2d2d08:
    // 0x2d2d08: 0xacc0000c  sw          $zero, 0xC($a2)
    ctx->pc = 0x2d2d08u;
    WRITE32(ADD32(GPR_U32(ctx, 6), 12), GPR_U32(ctx, 0));
label_2d2d0c:
    // 0x2d2d0c: 0x25ce4ec0  addiu       $t6, $t6, 0x4EC0
    ctx->pc = 0x2d2d0cu;
    SET_GPR_S32(ctx, 14, (int32_t)ADD32(GPR_U32(ctx, 14), 20160));
label_2d2d10:
    // 0x2d2d10: 0xe5460004  swc1        $f6, 0x4($t2)
    ctx->pc = 0x2d2d10u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 4), bits); }
label_2d2d14:
    // 0x2d2d14: 0x252651c0  addiu       $a2, $t1, 0x51C0
    ctx->pc = 0x2d2d14u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 9), 20928));
label_2d2d18:
    // 0x2d2d18: 0xe5470008  swc1        $f7, 0x8($t2)
    ctx->pc = 0x2d2d18u;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 8), bits); }
label_2d2d1c:
    // 0x2d2d1c: 0x26095200  addiu       $t1, $s0, 0x5200
    ctx->pc = 0x2d2d1cu;
    SET_GPR_S32(ctx, 9, (int32_t)ADD32(GPR_U32(ctx, 16), 20992));
label_2d2d20:
    // 0x2d2d20: 0xad40000c  sw          $zero, 0xC($t2)
    ctx->pc = 0x2d2d20u;
    WRITE32(ADD32(GPR_U32(ctx, 10), 12), GPR_U32(ctx, 0));
label_2d2d24:
    // 0x2d2d24: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2d24u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2d28:
    // 0x2d2d28: 0xe5604f20  swc1        $f0, 0x4F20($t3)
    ctx->pc = 0x2d2d28u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 20256), bits); }
label_2d2d2c:
    // 0x2d2d2c: 0x26104ed0  addiu       $s0, $s0, 0x4ED0
    ctx->pc = 0x2d2d2cu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20176));
label_2d2d30:
    // 0x2d2d30: 0xe580000c  swc1        $f0, 0xC($t4)
    ctx->pc = 0x2d2d30u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 12), bits); }
label_2d2d34:
    // 0x2d2d34: 0x264a5220  addiu       $t2, $s2, 0x5220
    ctx->pc = 0x2d2d34u;
    SET_GPR_S32(ctx, 10, (int32_t)ADD32(GPR_U32(ctx, 18), 21024));
label_2d2d38:
    // 0x2d2d38: 0xe5e04f30  swc1        $f0, 0x4F30($t7)
    ctx->pc = 0x2d2d38u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 20272), bits); }
label_2d2d3c:
    // 0x2d2d3c: 0x3c0c004d  lui         $t4, 0x4D
    ctx->pc = 0x2d2d3cu;
    SET_GPR_S32(ctx, 12, (int32_t)((uint32_t)77 << 16));
label_2d2d40:
    // 0x2d2d40: 0xe6600004  swc1        $f0, 0x4($s3)
    ctx->pc = 0x2d2d40u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 4), bits); }
label_2d2d44:
    // 0x2d2d44: 0x3c0f004d  lui         $t7, 0x4D
    ctx->pc = 0x2d2d44u;
    SET_GPR_S32(ctx, 15, (int32_t)((uint32_t)77 << 16));
label_2d2d48:
    // 0x2d2d48: 0xe6600008  swc1        $f0, 0x8($s3)
    ctx->pc = 0x2d2d48u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 8), bits); }
label_2d2d4c:
    // 0x2d2d4c: 0x258b5240  addiu       $t3, $t4, 0x5240
    ctx->pc = 0x2d2d4cu;
    SET_GPR_S32(ctx, 11, (int32_t)ADD32(GPR_U32(ctx, 12), 21056));
label_2d2d50:
    // 0x2d2d50: 0xe5d00004  swc1        $f16, 0x4($t6)
    ctx->pc = 0x2d2d50u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 4), bits); }
label_2d2d54:
    // 0x2d2d54: 0x3c13004d  lui         $s3, 0x4D
    ctx->pc = 0x2d2d54u;
    SET_GPR_S32(ctx, 19, (int32_t)((uint32_t)77 << 16));
label_2d2d58:
    // 0x2d2d58: 0xe5c00008  swc1        $f0, 0x8($t6)
    ctx->pc = 0x2d2d58u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 8), bits); }
label_2d2d5c:
    // 0x2d2d5c: 0x25ed5260  addiu       $t5, $t7, 0x5260
    ctx->pc = 0x2d2d5cu;
    SET_GPR_S32(ctx, 13, (int32_t)ADD32(GPR_U32(ctx, 15), 21088));
label_2d2d60:
    // 0x2d2d60: 0xe6100004  swc1        $f16, 0x4($s0)
    ctx->pc = 0x2d2d60u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d2d64:
    // 0x2d2d64: 0x3c12004d  lui         $s2, 0x4D
    ctx->pc = 0x2d2d64u;
    SET_GPR_S32(ctx, 18, (int32_t)((uint32_t)77 << 16));
label_2d2d68:
    // 0x2d2d68: 0xe6000008  swc1        $f0, 0x8($s0)
    ctx->pc = 0x2d2d68u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d2d6c:
    // 0x2d2d6c: 0x26734f00  addiu       $s3, $s3, 0x4F00
    ctx->pc = 0x2d2d6cu;
    SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 19), 20224));
label_2d2d70:
    // 0x2d2d70: 0xe7d00004  swc1        $f16, 0x4($fp)
    ctx->pc = 0x2d2d70u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 30), 4), bits); }
label_2d2d74:
    // 0x2d2d74: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2d74u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2d78:
    // 0x2d2d78: 0xe7c00008  swc1        $f0, 0x8($fp)
    ctx->pc = 0x2d2d78u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 30), 8), bits); }
label_2d2d7c:
    // 0x2d2d7c: 0x264c5280  addiu       $t4, $s2, 0x5280
    ctx->pc = 0x2d2d7cu;
    SET_GPR_S32(ctx, 12, (int32_t)ADD32(GPR_U32(ctx, 18), 21120));
label_2d2d80:
    // 0x2d2d80: 0xe6600004  swc1        $f0, 0x4($s3)
    ctx->pc = 0x2d2d80u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 4), bits); }
label_2d2d84:
    // 0x2d2d84: 0x26104f20  addiu       $s0, $s0, 0x4F20
    ctx->pc = 0x2d2d84u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20256));
label_2d2d88:
    // 0x2d2d88: 0x3c0f004d  lui         $t7, 0x4D
    ctx->pc = 0x2d2d88u;
    SET_GPR_S32(ctx, 15, (int32_t)((uint32_t)77 << 16));
label_2d2d8c:
    // 0x2d2d8c: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d2d8cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d2d90:
    // 0x2d2d90: 0x25ee52a0  addiu       $t6, $t7, 0x52A0
    ctx->pc = 0x2d2d90u;
    SET_GPR_S32(ctx, 14, (int32_t)ADD32(GPR_U32(ctx, 15), 21152));
label_2d2d94:
    // 0x2d2d94: 0x3c12004d  lui         $s2, 0x4D
    ctx->pc = 0x2d2d94u;
    SET_GPR_S32(ctx, 18, (int32_t)((uint32_t)77 << 16));
label_2d2d98:
    // 0x2d2d98: 0xe6000008  swc1        $f0, 0x8($s0)
    ctx->pc = 0x2d2d98u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d2d9c:
    // 0x2d2d9c: 0x264f52c0  addiu       $t7, $s2, 0x52C0
    ctx->pc = 0x2d2d9cu;
    SET_GPR_S32(ctx, 15, (int32_t)ADD32(GPR_U32(ctx, 18), 21184));
label_2d2da0:
    // 0x2d2da0: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2da0u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2da4:
    // 0x2d2da4: 0x3c13004d  lui         $s3, 0x4D
    ctx->pc = 0x2d2da4u;
    SET_GPR_S32(ctx, 19, (int32_t)((uint32_t)77 << 16));
label_2d2da8:
    // 0x2d2da8: 0x26125320  addiu       $s2, $s0, 0x5320
    ctx->pc = 0x2d2da8u;
    SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 16), 21280));
label_2d2dac:
    // 0x2d2dac: 0x267152e0  addiu       $s1, $s3, 0x52E0
    ctx->pc = 0x2d2dacu;
    SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 19), 21216));
label_2d2db0:
    // 0x2d2db0: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2db0u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2db4:
    // 0x2d2db4: 0xc782c0ec  lwc1        $f2, -0x3F14($gp)
    ctx->pc = 0x2d2db4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951148)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[2] = f; }
label_2d2db8:
    // 0x2d2db8: 0x26135340  addiu       $s3, $s0, 0x5340
    ctx->pc = 0x2d2db8u;
    SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 16), 21312));
label_2d2dbc:
    // 0x2d2dbc: 0xe6e00004  swc1        $f0, 0x4($s7)
    ctx->pc = 0x2d2dbcu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 23), 4), bits); }
label_2d2dc0:
    // 0x2d2dc0: 0xc781c0f0  lwc1        $f1, -0x3F10($gp)
    ctx->pc = 0x2d2dc0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951152)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_2d2dc4:
    // 0x2d2dc4: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2dc4u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2dc8:
    // 0x2d2dc8: 0xe702000c  swc1        $f2, 0xC($t8)
    ctx->pc = 0x2d2dc8u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 24), 12), bits); }
label_2d2dcc:
    // 0x2d2dcc: 0x26104f70  addiu       $s0, $s0, 0x4F70
    ctx->pc = 0x2d2dccu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20336));
label_2d2dd0:
    // 0x2d2dd0: 0xc783c0f4  lwc1        $f3, -0x3F0C($gp)
    ctx->pc = 0x2d2dd0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951156)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[3] = f; }
label_2d2dd4:
    // 0x2d2dd4: 0xe601000c  swc1        $f1, 0xC($s0)
    ctx->pc = 0x2d2dd4u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d2dd8:
    // 0x2d2dd8: 0xe6e30008  swc1        $f3, 0x8($s7)
    ctx->pc = 0x2d2dd8u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 23), 8), bits); }
label_2d2ddc:
    // 0x2d2ddc: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2ddcu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2de0:
    // 0x2d2de0: 0xaee0000c  sw          $zero, 0xC($s7)
    ctx->pc = 0x2d2de0u;
    WRITE32(ADD32(GPR_U32(ctx, 23), 12), GPR_U32(ctx, 0));
label_2d2de4:
    // 0x2d2de4: 0xe6004f40  swc1        $f0, 0x4F40($s0)
    ctx->pc = 0x2d2de4u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20288), bits); }
label_2d2de8:
    // 0x2d2de8: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2de8u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2dec:
    // 0x2d2dec: 0xc784c0f8  lwc1        $f4, -0x3F08($gp)
    ctx->pc = 0x2d2decu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951160)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[4] = f; }
label_2d2df0:
    // 0x2d2df0: 0x261e53c0  addiu       $fp, $s0, 0x53C0
    ctx->pc = 0x2d2df0u;
    SET_GPR_S32(ctx, 30, (int32_t)ADD32(GPR_U32(ctx, 16), 21440));
label_2d2df4:
    // 0x2d2df4: 0xc785c0fc  lwc1        $f5, -0x3F04($gp)
    ctx->pc = 0x2d2df4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951164)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[5] = f; }
label_2d2df8:
    // 0x2d2df8: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2df8u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2dfc:
    // 0x2d2dfc: 0xc786c100  lwc1        $f6, -0x3F00($gp)
    ctx->pc = 0x2d2dfcu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951168)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[6] = f; }
label_2d2e00:
    // 0x2d2e00: 0xe6004f50  swc1        $f0, 0x4F50($s0)
    ctx->pc = 0x2d2e00u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20304), bits); }
label_2d2e04:
    // 0x2d2e04: 0xc787c104  lwc1        $f7, -0x3EFC($gp)
    ctx->pc = 0x2d2e04u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951172)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[7] = f; }
label_2d2e08:
    // 0x2d2e08: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2e08u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2e0c:
    // 0x2d2e0c: 0xe6004f60  swc1        $f0, 0x4F60($s0)
    ctx->pc = 0x2d2e0cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20320), bits); }
label_2d2e10:
    // 0x2d2e10: 0xc788c108  lwc1        $f8, -0x3EF8($gp)
    ctx->pc = 0x2d2e10u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951176)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[8] = f; }
label_2d2e14:
    // 0x2d2e14: 0x26104f60  addiu       $s0, $s0, 0x4F60
    ctx->pc = 0x2d2e14u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20320));
label_2d2e18:
    // 0x2d2e18: 0xe7240004  swc1        $f4, 0x4($t9)
    ctx->pc = 0x2d2e18u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 25), 4), bits); }
label_2d2e1c:
    // 0x2d2e1c: 0xe7250008  swc1        $f5, 0x8($t9)
    ctx->pc = 0x2d2e1cu;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 25), 8), bits); }
label_2d2e20:
    // 0x2d2e20: 0xe7060004  swc1        $f6, 0x4($t8)
    ctx->pc = 0x2d2e20u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 24), 4), bits); }
label_2d2e24:
    // 0x2d2e24: 0xe7070008  swc1        $f7, 0x8($t8)
    ctx->pc = 0x2d2e24u;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 24), 8), bits); }
label_2d2e28:
    // 0x2d2e28: 0xaf20000c  sw          $zero, 0xC($t9)
    ctx->pc = 0x2d2e28u;
    WRITE32(ADD32(GPR_U32(ctx, 25), 12), GPR_U32(ctx, 0));
label_2d2e2c:
    // 0x2d2e2c: 0xe6080008  swc1        $f8, 0x8($s0)
    ctx->pc = 0x2d2e2cu;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d2e30:
    // 0x2d2e30: 0xe600000c  swc1        $f0, 0xC($s0)
    ctx->pc = 0x2d2e30u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d2e34:
    // 0x2d2e34: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2e34u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2e38:
    // 0x2d2e38: 0xc789c10c  lwc1        $f9, -0x3EF4($gp)
    ctx->pc = 0x2d2e38u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951180)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[9] = f; }
label_2d2e3c:
    // 0x2d2e3c: 0xe6004f70  swc1        $f0, 0x4F70($s0)
    ctx->pc = 0x2d2e3cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20336), bits); }
label_2d2e40:
    // 0x2d2e40: 0x26104f70  addiu       $s0, $s0, 0x4F70
    ctx->pc = 0x2d2e40u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20336));
label_2d2e44:
    // 0x2d2e44: 0xc78ac110  lwc1        $f10, -0x3EF0($gp)
    ctx->pc = 0x2d2e44u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951184)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[10] = f; }
label_2d2e48:
    // 0x2d2e48: 0xe6090004  swc1        $f9, 0x4($s0)
    ctx->pc = 0x2d2e48u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d2e4c:
    // 0x2d2e4c: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2e4cu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2e50:
    // 0x2d2e50: 0xc78cc114  lwc1        $f12, -0x3EEC($gp)
    ctx->pc = 0x2d2e50u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951188)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[12] = f; }
label_2d2e54:
    // 0x2d2e54: 0xe6004f80  swc1        $f0, 0x4F80($s0)
    ctx->pc = 0x2d2e54u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20352), bits); }
label_2d2e58:
    // 0x2d2e58: 0x26104f80  addiu       $s0, $s0, 0x4F80
    ctx->pc = 0x2d2e58u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20352));
label_2d2e5c:
    // 0x2d2e5c: 0xc78bc118  lwc1        $f11, -0x3EE8($gp)
    ctx->pc = 0x2d2e5cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951192)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[11] = f; }
label_2d2e60:
    // 0x2d2e60: 0xe600000c  swc1        $f0, 0xC($s0)
    ctx->pc = 0x2d2e60u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d2e64:
    // 0x2d2e64: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2e64u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2e68:
    // 0x2d2e68: 0xc784c11c  lwc1        $f4, -0x3EE4($gp)
    ctx->pc = 0x2d2e68u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951196)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[4] = f; }
label_2d2e6c:
    // 0x2d2e6c: 0xe6004f90  swc1        $f0, 0x4F90($s0)
    ctx->pc = 0x2d2e6cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20368), bits); }
label_2d2e70:
    // 0x2d2e70: 0x26104f90  addiu       $s0, $s0, 0x4F90
    ctx->pc = 0x2d2e70u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20368));
label_2d2e74:
    // 0x2d2e74: 0xc783c120  lwc1        $f3, -0x3EE0($gp)
    ctx->pc = 0x2d2e74u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951200)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[3] = f; }
label_2d2e78:
    // 0x2d2e78: 0xe600000c  swc1        $f0, 0xC($s0)
    ctx->pc = 0x2d2e78u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d2e7c:
    // 0x2d2e7c: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2e7cu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2e80:
    // 0x2d2e80: 0xc782c124  lwc1        $f2, -0x3EDC($gp)
    ctx->pc = 0x2d2e80u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951204)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[2] = f; }
label_2d2e84:
    // 0x2d2e84: 0xe6004fa0  swc1        $f0, 0x4FA0($s0)
    ctx->pc = 0x2d2e84u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20384), bits); }
label_2d2e88:
    // 0x2d2e88: 0xe6cc0008  swc1        $f12, 0x8($s6)
    ctx->pc = 0x2d2e88u;
    { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d2e8c:
    // 0x2d2e8c: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2e8cu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2e90:
    // 0x2d2e90: 0xe6ca0004  swc1        $f10, 0x4($s6)
    ctx->pc = 0x2d2e90u;
    { float f = ctx->f[10]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d2e94:
    // 0x2d2e94: 0x26104f60  addiu       $s0, $s0, 0x4F60
    ctx->pc = 0x2d2e94u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20320));
label_2d2e98:
    // 0x2d2e98: 0xaec0000c  sw          $zero, 0xC($s6)
    ctx->pc = 0x2d2e98u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 12), GPR_U32(ctx, 0));
label_2d2e9c:
    // 0x2d2e9c: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2e9cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2ea0:
    // 0x2d2ea0: 0xc781c128  lwc1        $f1, -0x3ED8($gp)
    ctx->pc = 0x2d2ea0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951208)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_2d2ea4:
    // 0x2d2ea4: 0xe6c04fb0  swc1        $f0, 0x4FB0($s6)
    ctx->pc = 0x2d2ea4u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20400), bits); }
label_2d2ea8:
    // 0x2d2ea8: 0xe60b0004  swc1        $f11, 0x4($s0)
    ctx->pc = 0x2d2ea8u;
    { float f = ctx->f[11]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d2eac:
    // 0x2d2eac: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2eacu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2eb0:
    // 0x2d2eb0: 0x26d64f70  addiu       $s6, $s6, 0x4F70
    ctx->pc = 0x2d2eb0u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20336));
label_2d2eb4:
    // 0x2d2eb4: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2eb4u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2eb8:
    // 0x2d2eb8: 0xe6c00008  swc1        $f0, 0x8($s6)
    ctx->pc = 0x2d2eb8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d2ebc:
    // 0x2d2ebc: 0x26104f80  addiu       $s0, $s0, 0x4F80
    ctx->pc = 0x2d2ebcu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20352));
label_2d2ec0:
    // 0x2d2ec0: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d2ec0u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d2ec4:
    // 0x2d2ec4: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2ec4u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2ec8:
    // 0x2d2ec8: 0xe6000008  swc1        $f0, 0x8($s0)
    ctx->pc = 0x2d2ec8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d2ecc:
    // 0x2d2ecc: 0x26d64f90  addiu       $s6, $s6, 0x4F90
    ctx->pc = 0x2d2eccu;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20368));
label_2d2ed0:
    // 0x2d2ed0: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2ed0u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2ed4:
    // 0x2d2ed4: 0xe6c00004  swc1        $f0, 0x4($s6)
    ctx->pc = 0x2d2ed4u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d2ed8:
    // 0x2d2ed8: 0xe6c00008  swc1        $f0, 0x8($s6)
    ctx->pc = 0x2d2ed8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d2edc:
    // 0x2d2edc: 0x26104fb0  addiu       $s0, $s0, 0x4FB0
    ctx->pc = 0x2d2edcu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20400));
label_2d2ee0:
    // 0x2d2ee0: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d2ee0u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d2ee4:
    // 0x2d2ee4: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2ee4u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2ee8:
    // 0x2d2ee8: 0xe6000008  swc1        $f0, 0x8($s0)
    ctx->pc = 0x2d2ee8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d2eec:
    // 0x2d2eec: 0xe600000c  swc1        $f0, 0xC($s0)
    ctx->pc = 0x2d2eecu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d2ef0:
    // 0x2d2ef0: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2ef0u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2ef4:
    // 0x2d2ef4: 0xe6c44ff0  swc1        $f4, 0x4FF0($s6)
    ctx->pc = 0x2d2ef4u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20464), bits); }
label_2d2ef8:
    // 0x2d2ef8: 0x26105000  addiu       $s0, $s0, 0x5000
    ctx->pc = 0x2d2ef8u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20480));
label_2d2efc:
    // 0x2d2efc: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2efcu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2f00:
    // 0x2d2f00: 0xe603000c  swc1        $f3, 0xC($s0)
    ctx->pc = 0x2d2f00u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d2f04:
    // 0x2d2f04: 0x26d65010  addiu       $s6, $s6, 0x5010
    ctx->pc = 0x2d2f04u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20496));
label_2d2f08:
    // 0x2d2f08: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2f08u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2f0c:
    // 0x2d2f0c: 0xe6c2000c  swc1        $f2, 0xC($s6)
    ctx->pc = 0x2d2f0cu;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 12), bits); }
label_2d2f10:
    // 0x2d2f10: 0x26105030  addiu       $s0, $s0, 0x5030
    ctx->pc = 0x2d2f10u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20528));
label_2d2f14:
    // 0x2d2f14: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2f14u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2f18:
    // 0x2d2f18: 0xe601000c  swc1        $f1, 0xC($s0)
    ctx->pc = 0x2d2f18u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d2f1c:
    // 0x2d2f1c: 0xc785c12c  lwc1        $f5, -0x3ED4($gp)
    ctx->pc = 0x2d2f1cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951212)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[5] = f; }
label_2d2f20:
    // 0x2d2f20: 0x2c0802d  daddu       $s0, $s6, $zero
    ctx->pc = 0x2d2f20u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d2f24:
    // 0x2d2f24: 0xe6c04fc0  swc1        $f0, 0x4FC0($s6)
    ctx->pc = 0x2d2f24u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20416), bits); }
label_2d2f28:
    // 0x2d2f28: 0x26104fc0  addiu       $s0, $s0, 0x4FC0
    ctx->pc = 0x2d2f28u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20416));
label_2d2f2c:
    // 0x2d2f2c: 0xe6050004  swc1        $f5, 0x4($s0)
    ctx->pc = 0x2d2f2cu;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d2f30:
    // 0x2d2f30: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2f30u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2f34:
    // 0x2d2f34: 0xae00000c  sw          $zero, 0xC($s0)
    ctx->pc = 0x2d2f34u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 12), GPR_U32(ctx, 0));
label_2d2f38:
    // 0x2d2f38: 0x2c0802d  daddu       $s0, $s6, $zero
    ctx->pc = 0x2d2f38u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d2f3c:
    // 0x2d2f3c: 0xe6c04fd0  swc1        $f0, 0x4FD0($s6)
    ctx->pc = 0x2d2f3cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20432), bits); }
label_2d2f40:
    // 0x2d2f40: 0x26104fd0  addiu       $s0, $s0, 0x4FD0
    ctx->pc = 0x2d2f40u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20432));
label_2d2f44:
    // 0x2d2f44: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2f44u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2f48:
    // 0x2d2f48: 0xe600000c  swc1        $f0, 0xC($s0)
    ctx->pc = 0x2d2f48u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d2f4c:
    // 0x2d2f4c: 0xe6c04fe0  swc1        $f0, 0x4FE0($s6)
    ctx->pc = 0x2d2f4cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20448), bits); }
label_2d2f50:
    // 0x2d2f50: 0x2c0802d  daddu       $s0, $s6, $zero
    ctx->pc = 0x2d2f50u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d2f54:
    // 0x2d2f54: 0x26104fe0  addiu       $s0, $s0, 0x4FE0
    ctx->pc = 0x2d2f54u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20448));
label_2d2f58:
    // 0x2d2f58: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2f58u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2f5c:
    // 0x2d2f5c: 0xae00000c  sw          $zero, 0xC($s0)
    ctx->pc = 0x2d2f5cu;
    WRITE32(ADD32(GPR_U32(ctx, 16), 12), GPR_U32(ctx, 0));
label_2d2f60:
    // 0x2d2f60: 0x26d64ff0  addiu       $s6, $s6, 0x4FF0
    ctx->pc = 0x2d2f60u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20464));
label_2d2f64:
    // 0x2d2f64: 0xaec0000c  sw          $zero, 0xC($s6)
    ctx->pc = 0x2d2f64u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 12), GPR_U32(ctx, 0));
label_2d2f68:
    // 0x2d2f68: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2f68u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2f6c:
    // 0x2d2f6c: 0xc786c130  lwc1        $f6, -0x3ED0($gp)
    ctx->pc = 0x2d2f6cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951216)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[6] = f; }
label_2d2f70:
    // 0x2d2f70: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d2f70u;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d2f74:
    // 0x2d2f74: 0xc787c134  lwc1        $f7, -0x3ECC($gp)
    ctx->pc = 0x2d2f74u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951220)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[7] = f; }
label_2d2f78:
    // 0x2d2f78: 0x26d65000  addiu       $s6, $s6, 0x5000
    ctx->pc = 0x2d2f78u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20480));
label_2d2f7c:
    // 0x2d2f7c: 0xe6005000  swc1        $f0, 0x5000($s0)
    ctx->pc = 0x2d2f7cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20480), bits); }
label_2d2f80:
    // 0x2d2f80: 0xe6c70008  swc1        $f7, 0x8($s6)
    ctx->pc = 0x2d2f80u;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d2f84:
    // 0x2d2f84: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2f84u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2f88:
    // 0x2d2f88: 0xe6c60004  swc1        $f6, 0x4($s6)
    ctx->pc = 0x2d2f88u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d2f8c:
    // 0x2d2f8c: 0xc788c138  lwc1        $f8, -0x3EC8($gp)
    ctx->pc = 0x2d2f8cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951224)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[8] = f; }
label_2d2f90:
    // 0x2d2f90: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d2f90u;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d2f94:
    // 0x2d2f94: 0xe6005010  swc1        $f0, 0x5010($s0)
    ctx->pc = 0x2d2f94u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20496), bits); }
label_2d2f98:
    // 0x2d2f98: 0x26d65010  addiu       $s6, $s6, 0x5010
    ctx->pc = 0x2d2f98u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20496));
label_2d2f9c:
    // 0x2d2f9c: 0xe6c80004  swc1        $f8, 0x4($s6)
    ctx->pc = 0x2d2f9cu;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d2fa0:
    // 0x2d2fa0: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2fa0u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2fa4:
    // 0x2d2fa4: 0xc789c13c  lwc1        $f9, -0x3EC4($gp)
    ctx->pc = 0x2d2fa4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951228)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[9] = f; }
label_2d2fa8:
    // 0x2d2fa8: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d2fa8u;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d2fac:
    // 0x2d2fac: 0xe6005020  swc1        $f0, 0x5020($s0)
    ctx->pc = 0x2d2facu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20512), bits); }
label_2d2fb0:
    // 0x2d2fb0: 0x26d65020  addiu       $s6, $s6, 0x5020
    ctx->pc = 0x2d2fb0u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20512));
label_2d2fb4:
    // 0x2d2fb4: 0xe6c90008  swc1        $f9, 0x8($s6)
    ctx->pc = 0x2d2fb4u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d2fb8:
    // 0x2d2fb8: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2fb8u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2fbc:
    // 0x2d2fbc: 0xaec0000c  sw          $zero, 0xC($s6)
    ctx->pc = 0x2d2fbcu;
    WRITE32(ADD32(GPR_U32(ctx, 22), 12), GPR_U32(ctx, 0));
label_2d2fc0:
    // 0x2d2fc0: 0xc78ac140  lwc1        $f10, -0x3EC0($gp)
    ctx->pc = 0x2d2fc0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951232)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[10] = f; }
label_2d2fc4:
    // 0x2d2fc4: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d2fc4u;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d2fc8:
    // 0x2d2fc8: 0xe6005030  swc1        $f0, 0x5030($s0)
    ctx->pc = 0x2d2fc8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20528), bits); }
label_2d2fcc:
    // 0x2d2fcc: 0x26d65030  addiu       $s6, $s6, 0x5030
    ctx->pc = 0x2d2fccu;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20528));
label_2d2fd0:
    // 0x2d2fd0: 0xe6ca0004  swc1        $f10, 0x4($s6)
    ctx->pc = 0x2d2fd0u;
    { float f = ctx->f[10]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d2fd4:
    // 0x2d2fd4: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2fd4u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2fd8:
    // 0x2d2fd8: 0xe6005040  swc1        $f0, 0x5040($s0)
    ctx->pc = 0x2d2fd8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20544), bits); }
label_2d2fdc:
    // 0x2d2fdc: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2fdcu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2fe0:
    // 0x2d2fe0: 0x26d64fc0  addiu       $s6, $s6, 0x4FC0
    ctx->pc = 0x2d2fe0u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20416));
label_2d2fe4:
    // 0x2d2fe4: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d2fe4u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d2fe8:
    // 0x2d2fe8: 0xe6c00008  swc1        $f0, 0x8($s6)
    ctx->pc = 0x2d2fe8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d2fec:
    // 0x2d2fec: 0x26104fd0  addiu       $s0, $s0, 0x4FD0
    ctx->pc = 0x2d2fecu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20432));
label_2d2ff0:
    // 0x2d2ff0: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d2ff0u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d2ff4:
    // 0x2d2ff4: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d2ff4u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d2ff8:
    // 0x2d2ff8: 0xe6000008  swc1        $f0, 0x8($s0)
    ctx->pc = 0x2d2ff8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d2ffc:
    // 0x2d2ffc: 0x26d64fe0  addiu       $s6, $s6, 0x4FE0
    ctx->pc = 0x2d2ffcu;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20448));
label_2d3000:
    // 0x2d3000: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3000u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3004:
    // 0x2d3004: 0xaec00008  sw          $zero, 0x8($s6)
    ctx->pc = 0x2d3004u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 8), GPR_U32(ctx, 0));
label_2d3008:
    // 0x2d3008: 0xe6c00004  swc1        $f0, 0x4($s6)
    ctx->pc = 0x2d3008u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d300c:
    // 0x2d300c: 0x26104ff0  addiu       $s0, $s0, 0x4FF0
    ctx->pc = 0x2d300cu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20464));
label_2d3010:
    // 0x2d3010: 0xae000004  sw          $zero, 0x4($s0)
    ctx->pc = 0x2d3010u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 4), GPR_U32(ctx, 0));
label_2d3014:
    // 0x2d3014: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d3014u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3018:
    // 0x2d3018: 0xae000008  sw          $zero, 0x8($s0)
    ctx->pc = 0x2d3018u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 8), GPR_U32(ctx, 0));
label_2d301c:
    // 0x2d301c: 0x26d65010  addiu       $s6, $s6, 0x5010
    ctx->pc = 0x2d301cu;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20496));
label_2d3020:
    // 0x2d3020: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3020u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3024:
    // 0x2d3024: 0xe6c00008  swc1        $f0, 0x8($s6)
    ctx->pc = 0x2d3024u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d3028:
    // 0x2d3028: 0x26105020  addiu       $s0, $s0, 0x5020
    ctx->pc = 0x2d3028u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20512));
label_2d302c:
    // 0x2d302c: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d302cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3030:
    // 0x2d3030: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d3030u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d3034:
    // 0x2d3034: 0x26d65030  addiu       $s6, $s6, 0x5030
    ctx->pc = 0x2d3034u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20528));
label_2d3038:
    // 0x2d3038: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3038u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d303c:
    // 0x2d303c: 0xe6c00008  swc1        $f0, 0x8($s6)
    ctx->pc = 0x2d303cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d3040:
    // 0x2d3040: 0x26105040  addiu       $s0, $s0, 0x5040
    ctx->pc = 0x2d3040u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20544));
label_2d3044:
    // 0x2d3044: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d3044u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3048:
    // 0x2d3048: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d3048u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d304c:
    // 0x2d304c: 0x26d65050  addiu       $s6, $s6, 0x5050
    ctx->pc = 0x2d304cu;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20560));
label_2d3050:
    // 0x2d3050: 0xc782c144  lwc1        $f2, -0x3EBC($gp)
    ctx->pc = 0x2d3050u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951236)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[2] = f; }
label_2d3054:
    // 0x2d3054: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3054u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3058:
    // 0x2d3058: 0xe6cb000c  swc1        $f11, 0xC($s6)
    ctx->pc = 0x2d3058u;
    { float f = ctx->f[11]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 12), bits); }
label_2d305c:
    // 0x2d305c: 0x26105090  addiu       $s0, $s0, 0x5090
    ctx->pc = 0x2d305cu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20624));
label_2d3060:
    // 0x2d3060: 0xe602000c  swc1        $f2, 0xC($s0)
    ctx->pc = 0x2d3060u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d3064:
    // 0x2d3064: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d3064u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3068:
    // 0x2d3068: 0xc781c148  lwc1        $f1, -0x3EB8($gp)
    ctx->pc = 0x2d3068u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951240)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_2d306c:
    // 0x2d306c: 0x26d650a0  addiu       $s6, $s6, 0x50A0
    ctx->pc = 0x2d306cu;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20640));
label_2d3070:
    // 0x2d3070: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3070u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3074:
    // 0x2d3074: 0xc783c14c  lwc1        $f3, -0x3EB4($gp)
    ctx->pc = 0x2d3074u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951244)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[3] = f; }
label_2d3078:
    // 0x2d3078: 0xe6c1000c  swc1        $f1, 0xC($s6)
    ctx->pc = 0x2d3078u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 12), bits); }
label_2d307c:
    // 0x2d307c: 0x26105040  addiu       $s0, $s0, 0x5040
    ctx->pc = 0x2d307cu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20544));
label_2d3080:
    // 0x2d3080: 0xe600000c  swc1        $f0, 0xC($s0)
    ctx->pc = 0x2d3080u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d3084:
    // 0x2d3084: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d3084u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3088:
    // 0x2d3088: 0xe6c05050  swc1        $f0, 0x5050($s6)
    ctx->pc = 0x2d3088u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20560), bits); }
label_2d308c:
    // 0x2d308c: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d308cu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3090:
    // 0x2d3090: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d3090u;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d3094:
    // 0x2d3094: 0xe6005060  swc1        $f0, 0x5060($s0)
    ctx->pc = 0x2d3094u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20576), bits); }
label_2d3098:
    // 0x2d3098: 0x26d65060  addiu       $s6, $s6, 0x5060
    ctx->pc = 0x2d3098u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20576));
label_2d309c:
    // 0x2d309c: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d309cu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d30a0:
    // 0x2d30a0: 0xaec0000c  sw          $zero, 0xC($s6)
    ctx->pc = 0x2d30a0u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 12), GPR_U32(ctx, 0));
label_2d30a4:
    // 0x2d30a4: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d30a4u;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d30a8:
    // 0x2d30a8: 0xe6005070  swc1        $f0, 0x5070($s0)
    ctx->pc = 0x2d30a8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20592), bits); }
label_2d30ac:
    // 0x2d30ac: 0x26d65070  addiu       $s6, $s6, 0x5070
    ctx->pc = 0x2d30acu;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20592));
label_2d30b0:
    // 0x2d30b0: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d30b0u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d30b4:
    // 0x2d30b4: 0xaec0000c  sw          $zero, 0xC($s6)
    ctx->pc = 0x2d30b4u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 12), GPR_U32(ctx, 0));
label_2d30b8:
    // 0x2d30b8: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d30b8u;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d30bc:
    // 0x2d30bc: 0xe6005080  swc1        $f0, 0x5080($s0)
    ctx->pc = 0x2d30bcu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20608), bits); }
label_2d30c0:
    // 0x2d30c0: 0x26d65080  addiu       $s6, $s6, 0x5080
    ctx->pc = 0x2d30c0u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20608));
label_2d30c4:
    // 0x2d30c4: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d30c4u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d30c8:
    // 0x2d30c8: 0xaec0000c  sw          $zero, 0xC($s6)
    ctx->pc = 0x2d30c8u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 12), GPR_U32(ctx, 0));
label_2d30cc:
    // 0x2d30cc: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d30ccu;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d30d0:
    // 0x2d30d0: 0xe6005090  swc1        $f0, 0x5090($s0)
    ctx->pc = 0x2d30d0u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20624), bits); }
label_2d30d4:
    // 0x2d30d4: 0x26d65090  addiu       $s6, $s6, 0x5090
    ctx->pc = 0x2d30d4u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20624));
label_2d30d8:
    // 0x2d30d8: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d30d8u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d30dc:
    // 0x2d30dc: 0xe6c30004  swc1        $f3, 0x4($s6)
    ctx->pc = 0x2d30dcu;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d30e0:
    // 0x2d30e0: 0xc784c150  lwc1        $f4, -0x3EB0($gp)
    ctx->pc = 0x2d30e0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951248)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[4] = f; }
label_2d30e4:
    // 0x2d30e4: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d30e4u;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d30e8:
    // 0x2d30e8: 0xe60050a0  swc1        $f0, 0x50A0($s0)
    ctx->pc = 0x2d30e8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20640), bits); }
label_2d30ec:
    // 0x2d30ec: 0x26d650a0  addiu       $s6, $s6, 0x50A0
    ctx->pc = 0x2d30ecu;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20640));
label_2d30f0:
    // 0x2d30f0: 0xe6c40008  swc1        $f4, 0x8($s6)
    ctx->pc = 0x2d30f0u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d30f4:
    // 0x2d30f4: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d30f4u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d30f8:
    // 0x2d30f8: 0xc785c154  lwc1        $f5, -0x3EAC($gp)
    ctx->pc = 0x2d30f8u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951252)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[5] = f; }
label_2d30fc:
    // 0x2d30fc: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d30fcu;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d3100:
    // 0x2d3100: 0xe60050b0  swc1        $f0, 0x50B0($s0)
    ctx->pc = 0x2d3100u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20656), bits); }
label_2d3104:
    // 0x2d3104: 0x26d650b0  addiu       $s6, $s6, 0x50B0
    ctx->pc = 0x2d3104u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20656));
label_2d3108:
    // 0x2d3108: 0xe6c50008  swc1        $f5, 0x8($s6)
    ctx->pc = 0x2d3108u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d310c:
    // 0x2d310c: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d310cu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3110:
    // 0x2d3110: 0xaec0000c  sw          $zero, 0xC($s6)
    ctx->pc = 0x2d3110u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 12), GPR_U32(ctx, 0));
label_2d3114:
    // 0x2d3114: 0xe60050c0  swc1        $f0, 0x50C0($s0)
    ctx->pc = 0x2d3114u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 20672), bits); }
label_2d3118:
    // 0x2d3118: 0x200b02d  daddu       $s6, $s0, $zero
    ctx->pc = 0x2d3118u;
    SET_GPR_U64(ctx, 22, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d311c:
    // 0x2d311c: 0xc786c158  lwc1        $f6, -0x3EA8($gp)
    ctx->pc = 0x2d311cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951256)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[6] = f; }
label_2d3120:
    // 0x2d3120: 0x26d650c0  addiu       $s6, $s6, 0x50C0
    ctx->pc = 0x2d3120u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20672));
label_2d3124:
    // 0x2d3124: 0xc787c15c  lwc1        $f7, -0x3EA4($gp)
    ctx->pc = 0x2d3124u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951260)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[7] = f; }
label_2d3128:
    // 0x2d3128: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3128u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d312c:
    // 0x2d312c: 0xe6c60004  swc1        $f6, 0x4($s6)
    ctx->pc = 0x2d312cu;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d3130:
    // 0x2d3130: 0x26105040  addiu       $s0, $s0, 0x5040
    ctx->pc = 0x2d3130u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20544));
label_2d3134:
    // 0x2d3134: 0xe6c70008  swc1        $f7, 0x8($s6)
    ctx->pc = 0x2d3134u;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d3138:
    // 0x2d3138: 0xe6000008  swc1        $f0, 0x8($s0)
    ctx->pc = 0x2d3138u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d313c:
    // 0x2d313c: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d313cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3140:
    // 0x2d3140: 0x26d65050  addiu       $s6, $s6, 0x5050
    ctx->pc = 0x2d3140u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20560));
label_2d3144:
    // 0x2d3144: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3144u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3148:
    // 0x2d3148: 0xe6cb0004  swc1        $f11, 0x4($s6)
    ctx->pc = 0x2d3148u;
    { float f = ctx->f[11]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d314c:
    // 0x2d314c: 0x26105060  addiu       $s0, $s0, 0x5060
    ctx->pc = 0x2d314cu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20576));
label_2d3150:
    // 0x2d3150: 0xe6c00008  swc1        $f0, 0x8($s6)
    ctx->pc = 0x2d3150u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d3154:
    // 0x2d3154: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d3154u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d3158:
    // 0x2d3158: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d3158u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d315c:
    // 0x2d315c: 0xae000008  sw          $zero, 0x8($s0)
    ctx->pc = 0x2d315cu;
    WRITE32(ADD32(GPR_U32(ctx, 16), 8), GPR_U32(ctx, 0));
label_2d3160:
    // 0x2d3160: 0x26d65070  addiu       $s6, $s6, 0x5070
    ctx->pc = 0x2d3160u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20592));
label_2d3164:
    // 0x2d3164: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3164u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3168:
    // 0x2d3168: 0xe6c00004  swc1        $f0, 0x4($s6)
    ctx->pc = 0x2d3168u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d316c:
    // 0x2d316c: 0xaec00008  sw          $zero, 0x8($s6)
    ctx->pc = 0x2d316cu;
    WRITE32(ADD32(GPR_U32(ctx, 22), 8), GPR_U32(ctx, 0));
label_2d3170:
    // 0x2d3170: 0x26105080  addiu       $s0, $s0, 0x5080
    ctx->pc = 0x2d3170u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20608));
label_2d3174:
    // 0x2d3174: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d3174u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d3178:
    // 0x2d3178: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d3178u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d317c:
    // 0x2d317c: 0xae000008  sw          $zero, 0x8($s0)
    ctx->pc = 0x2d317cu;
    WRITE32(ADD32(GPR_U32(ctx, 16), 8), GPR_U32(ctx, 0));
label_2d3180:
    // 0x2d3180: 0x26d65090  addiu       $s6, $s6, 0x5090
    ctx->pc = 0x2d3180u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20624));
label_2d3184:
    // 0x2d3184: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3184u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3188:
    // 0x2d3188: 0xe6c00008  swc1        $f0, 0x8($s6)
    ctx->pc = 0x2d3188u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d318c:
    // 0x2d318c: 0x261050a0  addiu       $s0, $s0, 0x50A0
    ctx->pc = 0x2d318cu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20640));
label_2d3190:
    // 0x2d3190: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d3190u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3194:
    // 0x2d3194: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d3194u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d3198:
    // 0x2d3198: 0x26d650b0  addiu       $s6, $s6, 0x50B0
    ctx->pc = 0x2d3198u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20656));
label_2d319c:
    // 0x2d319c: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d319cu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d31a0:
    // 0x2d31a0: 0xe6c00004  swc1        $f0, 0x4($s6)
    ctx->pc = 0x2d31a0u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 4), bits); }
label_2d31a4:
    // 0x2d31a4: 0x261050c0  addiu       $s0, $s0, 0x50C0
    ctx->pc = 0x2d31a4u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20672));
label_2d31a8:
    // 0x2d31a8: 0xc787c160  lwc1        $f7, -0x3EA0($gp)
    ctx->pc = 0x2d31a8u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951264)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[7] = f; }
label_2d31ac:
    // 0x2d31ac: 0xae00000c  sw          $zero, 0xC($s0)
    ctx->pc = 0x2d31acu;
    WRITE32(ADD32(GPR_U32(ctx, 16), 12), GPR_U32(ctx, 0));
label_2d31b0:
    // 0x2d31b0: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d31b0u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d31b4:
    // 0x2d31b4: 0xc781c164  lwc1        $f1, -0x3E9C($gp)
    ctx->pc = 0x2d31b4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951268)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_2d31b8:
    // 0x2d31b8: 0x26d650e0  addiu       $s6, $s6, 0x50E0
    ctx->pc = 0x2d31b8u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20704));
label_2d31bc:
    // 0x2d31bc: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d31bcu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d31c0:
    // 0x2d31c0: 0xe6c7000c  swc1        $f7, 0xC($s6)
    ctx->pc = 0x2d31c0u;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 12), bits); }
label_2d31c4:
    // 0x2d31c4: 0x261050f0  addiu       $s0, $s0, 0x50F0
    ctx->pc = 0x2d31c4u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20720));
label_2d31c8:
    // 0x2d31c8: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d31c8u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d31cc:
    // 0x2d31cc: 0xe601000c  swc1        $f1, 0xC($s0)
    ctx->pc = 0x2d31ccu;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 12), bits); }
label_2d31d0:
    // 0x2d31d0: 0xc78ac168  lwc1        $f10, -0x3E98($gp)
    ctx->pc = 0x2d31d0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951272)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[10] = f; }
label_2d31d4:
    // 0x2d31d4: 0x2c0802d  daddu       $s0, $s6, $zero
    ctx->pc = 0x2d31d4u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d31d8:
    // 0x2d31d8: 0xc78bc16c  lwc1        $f11, -0x3E94($gp)
    ctx->pc = 0x2d31d8u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951276)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[11] = f; }
label_2d31dc:
    // 0x2d31dc: 0x261050d0  addiu       $s0, $s0, 0x50D0
    ctx->pc = 0x2d31dcu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20688));
label_2d31e0:
    // 0x2d31e0: 0xe6c050d0  swc1        $f0, 0x50D0($s6)
    ctx->pc = 0x2d31e0u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20688), bits); }
label_2d31e4:
    // 0x2d31e4: 0xe60a0004  swc1        $f10, 0x4($s0)
    ctx->pc = 0x2d31e4u;
    { float f = ctx->f[10]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d31e8:
    // 0x2d31e8: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d31e8u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d31ec:
    // 0x2d31ec: 0xe60b0008  swc1        $f11, 0x8($s0)
    ctx->pc = 0x2d31ecu;
    { float f = ctx->f[11]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d31f0:
    // 0x2d31f0: 0xae00000c  sw          $zero, 0xC($s0)
    ctx->pc = 0x2d31f0u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 12), GPR_U32(ctx, 0));
label_2d31f4:
    // 0x2d31f4: 0xc78cc170  lwc1        $f12, -0x3E90($gp)
    ctx->pc = 0x2d31f4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951280)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[12] = f; }
label_2d31f8:
    // 0x2d31f8: 0x2c0802d  daddu       $s0, $s6, $zero
    ctx->pc = 0x2d31f8u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d31fc:
    // 0x2d31fc: 0xc78dc174  lwc1        $f13, -0x3E8C($gp)
    ctx->pc = 0x2d31fcu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951284)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[13] = f; }
label_2d3200:
    // 0x2d3200: 0x261050e0  addiu       $s0, $s0, 0x50E0
    ctx->pc = 0x2d3200u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20704));
label_2d3204:
    // 0x2d3204: 0xe6c050e0  swc1        $f0, 0x50E0($s6)
    ctx->pc = 0x2d3204u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20704), bits); }
label_2d3208:
    // 0x2d3208: 0xe60c0004  swc1        $f12, 0x4($s0)
    ctx->pc = 0x2d3208u;
    { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d320c:
    // 0x2d320c: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d320cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3210:
    // 0x2d3210: 0xe60d0008  swc1        $f13, 0x8($s0)
    ctx->pc = 0x2d3210u;
    { float f = ctx->f[13]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d3214:
    // 0x2d3214: 0x2c0802d  daddu       $s0, $s6, $zero
    ctx->pc = 0x2d3214u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d3218:
    // 0x2d3218: 0xc78ec178  lwc1        $f14, -0x3E88($gp)
    ctx->pc = 0x2d3218u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951288)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[14] = f; }
label_2d321c:
    // 0x2d321c: 0xc78fc17c  lwc1        $f15, -0x3E84($gp)
    ctx->pc = 0x2d321cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951292)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[15] = f; }
label_2d3220:
    // 0x2d3220: 0x261050f0  addiu       $s0, $s0, 0x50F0
    ctx->pc = 0x2d3220u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20720));
label_2d3224:
    // 0x2d3224: 0xe6c050f0  swc1        $f0, 0x50F0($s6)
    ctx->pc = 0x2d3224u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20720), bits); }
label_2d3228:
    // 0x2d3228: 0xe60e0004  swc1        $f14, 0x4($s0)
    ctx->pc = 0x2d3228u;
    { float f = ctx->f[14]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d322c:
    // 0x2d322c: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d322cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3230:
    // 0x2d3230: 0xe60f0008  swc1        $f15, 0x8($s0)
    ctx->pc = 0x2d3230u;
    { float f = ctx->f[15]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d3234:
    // 0x2d3234: 0x2c0802d  daddu       $s0, $s6, $zero
    ctx->pc = 0x2d3234u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d3238:
    // 0x2d3238: 0xe6c05100  swc1        $f0, 0x5100($s6)
    ctx->pc = 0x2d3238u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20736), bits); }
label_2d323c:
    // 0x2d323c: 0x26105100  addiu       $s0, $s0, 0x5100
    ctx->pc = 0x2d323cu;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20736));
label_2d3240:
    // 0x2d3240: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d3240u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3244:
    // 0x2d3244: 0xae00000c  sw          $zero, 0xC($s0)
    ctx->pc = 0x2d3244u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 12), GPR_U32(ctx, 0));
label_2d3248:
    // 0x2d3248: 0x2c0802d  daddu       $s0, $s6, $zero
    ctx->pc = 0x2d3248u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d324c:
    // 0x2d324c: 0xe6c05110  swc1        $f0, 0x5110($s6)
    ctx->pc = 0x2d324cu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 20752), bits); }
label_2d3250:
    // 0x2d3250: 0x26105110  addiu       $s0, $s0, 0x5110
    ctx->pc = 0x2d3250u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20752));
label_2d3254:
    // 0x2d3254: 0xc788c180  lwc1        $f8, -0x3E80($gp)
    ctx->pc = 0x2d3254u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951296)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[8] = f; }
label_2d3258:
    // 0x2d3258: 0xae00000c  sw          $zero, 0xC($s0)
    ctx->pc = 0x2d3258u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 12), GPR_U32(ctx, 0));
label_2d325c:
    // 0x2d325c: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d325cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3260:
    // 0x2d3260: 0xaec05120  sw          $zero, 0x5120($s6)
    ctx->pc = 0x2d3260u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 20768), GPR_U32(ctx, 0));
label_2d3264:
    // 0x2d3264: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3264u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3268:
    // 0x2d3268: 0xe468001c  swc1        $f8, 0x1C($v1)
    ctx->pc = 0x2d3268u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 28), bits); }
label_2d326c:
    // 0x2d326c: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d326cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3270:
    // 0x2d3270: 0xae005140  sw          $zero, 0x5140($s0)
    ctx->pc = 0x2d3270u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 20800), GPR_U32(ctx, 0));
label_2d3274:
    // 0x2d3274: 0x26d65100  addiu       $s6, $s6, 0x5100
    ctx->pc = 0x2d3274u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 22), 20736));
label_2d3278:
    // 0x2d3278: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3278u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d327c:
    // 0x2d327c: 0xc782c184  lwc1        $f2, -0x3E7C($gp)
    ctx->pc = 0x2d327cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951300)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[2] = f; }
label_2d3280:
    // 0x2d3280: 0x3c014220  lui         $at, 0x4220
    ctx->pc = 0x2d3280u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)16928 << 16));
label_2d3284:
    // 0x2d3284: 0x44811800  mtc1        $at, $f3
    ctx->pc = 0x2d3284u;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[3], &bits, sizeof(bits)); }
label_2d3288:
    // 0x2d3288: 0x26105110  addiu       $s0, $s0, 0x5110
    ctx->pc = 0x2d3288u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 20752));
label_2d328c:
    // 0x2d328c: 0xc784c188  lwc1        $f4, -0x3E78($gp)
    ctx->pc = 0x2d328cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951304)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[4] = f; }
label_2d3290:
    // 0x2d3290: 0x3c0142a0  lui         $at, 0x42A0
    ctx->pc = 0x2d3290u;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)17056 << 16));
label_2d3294:
    // 0x2d3294: 0x44812800  mtc1        $at, $f5
    ctx->pc = 0x2d3294u;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[5], &bits, sizeof(bits)); }
label_2d3298:
    // 0x2d3298: 0xc786c18c  lwc1        $f6, -0x3E74($gp)
    ctx->pc = 0x2d3298u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951308)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[6] = f; }
label_2d329c:
    // 0x2d329c: 0x3c0142f0  lui         $at, 0x42F0
    ctx->pc = 0x2d329cu;
    SET_GPR_S32(ctx, 1, (int32_t)((uint32_t)17136 << 16));
label_2d32a0:
    // 0x2d32a0: 0x44814800  mtc1        $at, $f9
    ctx->pc = 0x2d32a0u;
    { uint32_t bits = GPR_U32(ctx, 1); std::memcpy(&ctx->f[9], &bits, sizeof(bits)); }
label_2d32a4:
    // 0x2d32a4: 0xaec00004  sw          $zero, 0x4($s6)
    ctx->pc = 0x2d32a4u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 4), GPR_U32(ctx, 0));
label_2d32a8:
    // 0x2d32a8: 0xe6c00008  swc1        $f0, 0x8($s6)
    ctx->pc = 0x2d32a8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 22), 8), bits); }
label_2d32ac:
    // 0x2d32ac: 0xe6000004  swc1        $f0, 0x4($s0)
    ctx->pc = 0x2d32acu;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d32b0:
    // 0x2d32b0: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d32b0u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d32b4:
    // 0x2d32b4: 0xae000008  sw          $zero, 0x8($s0)
    ctx->pc = 0x2d32b4u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 8), GPR_U32(ctx, 0));
label_2d32b8:
    // 0x2d32b8: 0xe4620004  swc1        $f2, 0x4($v1)
    ctx->pc = 0x2d32b8u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 4), bits); }
label_2d32bc:
    // 0x2d32bc: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d32bcu;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d32c0:
    // 0x2d32c0: 0xe4630008  swc1        $f3, 0x8($v1)
    ctx->pc = 0x2d32c0u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 8), bits); }
label_2d32c4:
    // 0x2d32c4: 0xe464000c  swc1        $f4, 0xC($v1)
    ctx->pc = 0x2d32c4u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 12), bits); }
label_2d32c8:
    // 0x2d32c8: 0xe4650010  swc1        $f5, 0x10($v1)
    ctx->pc = 0x2d32c8u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 16), bits); }
label_2d32cc:
    // 0x2d32cc: 0xe4660014  swc1        $f6, 0x14($v1)
    ctx->pc = 0x2d32ccu;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 20), bits); }
label_2d32d0:
    // 0x2d32d0: 0xe4690018  swc1        $f9, 0x18($v1)
    ctx->pc = 0x2d32d0u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 24), bits); }
label_2d32d4:
    // 0x2d32d4: 0xe4e20004  swc1        $f2, 0x4($a3)
    ctx->pc = 0x2d32d4u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 4), bits); }
label_2d32d8:
    // 0x2d32d8: 0x3c03004d  lui         $v1, 0x4D
    ctx->pc = 0x2d32d8u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)77 << 16));
label_2d32dc:
    // 0x2d32dc: 0xe4e30008  swc1        $f3, 0x8($a3)
    ctx->pc = 0x2d32dcu;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 8), bits); }
label_2d32e0:
    // 0x2d32e0: 0xe4e4000c  swc1        $f4, 0xC($a3)
    ctx->pc = 0x2d32e0u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 12), bits); }
label_2d32e4:
    // 0x2d32e4: 0xe4e50010  swc1        $f5, 0x10($a3)
    ctx->pc = 0x2d32e4u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 16), bits); }
label_2d32e8:
    // 0x2d32e8: 0xe4e60014  swc1        $f6, 0x14($a3)
    ctx->pc = 0x2d32e8u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 20), bits); }
label_2d32ec:
    // 0x2d32ec: 0xe4e8001c  swc1        $f8, 0x1C($a3)
    ctx->pc = 0x2d32ecu;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 28), bits); }
label_2d32f0:
    // 0x2d32f0: 0xaec05160  sw          $zero, 0x5160($s6)
    ctx->pc = 0x2d32f0u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 20832), GPR_U32(ctx, 0));
label_2d32f4:
    // 0x2d32f4: 0xe448001c  swc1        $f8, 0x1C($v0)
    ctx->pc = 0x2d32f4u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 28), bits); }
label_2d32f8:
    // 0x2d32f8: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d32f8u;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d32fc:
    // 0x2d32fc: 0xac605180  sw          $zero, 0x5180($v1)
    ctx->pc = 0x2d32fcu;
    WRITE32(ADD32(GPR_U32(ctx, 3), 20864), GPR_U32(ctx, 0));
label_2d3300:
    // 0x2d3300: 0xe488001c  swc1        $f8, 0x1C($a0)
    ctx->pc = 0x2d3300u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 28), bits); }
label_2d3304:
    // 0x2d3304: 0x3c03004d  lui         $v1, 0x4D
    ctx->pc = 0x2d3304u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)77 << 16));
label_2d3308:
    // 0x2d3308: 0xae0051a0  sw          $zero, 0x51A0($s0)
    ctx->pc = 0x2d3308u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 20896), GPR_U32(ctx, 0));
label_2d330c:
    // 0x2d330c: 0xe4a8001c  swc1        $f8, 0x1C($a1)
    ctx->pc = 0x2d330cu;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 28), bits); }
label_2d3310:
    // 0x2d3310: 0x3c10004d  lui         $s0, 0x4D
    ctx->pc = 0x2d3310u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)77 << 16));
label_2d3314:
    // 0x2d3314: 0xaec051c0  sw          $zero, 0x51C0($s6)
    ctx->pc = 0x2d3314u;
    WRITE32(ADD32(GPR_U32(ctx, 22), 20928), GPR_U32(ctx, 0));
label_2d3318:
    // 0x2d3318: 0xe4e90018  swc1        $f9, 0x18($a3)
    ctx->pc = 0x2d3318u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 7), 24), bits); }
label_2d331c:
    // 0x2d331c: 0x3c16004d  lui         $s6, 0x4D
    ctx->pc = 0x2d331cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)77 << 16));
label_2d3320:
    // 0x2d3320: 0xe4420004  swc1        $f2, 0x4($v0)
    ctx->pc = 0x2d3320u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 4), bits); }
label_2d3324:
    // 0x2d3324: 0xe4430008  swc1        $f3, 0x8($v0)
    ctx->pc = 0x2d3324u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 8), bits); }
label_2d3328:
    // 0x2d3328: 0xe444000c  swc1        $f4, 0xC($v0)
    ctx->pc = 0x2d3328u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 12), bits); }
label_2d332c:
    // 0x2d332c: 0xe4450010  swc1        $f5, 0x10($v0)
    ctx->pc = 0x2d332cu;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 16), bits); }
label_2d3330:
    // 0x2d3330: 0xe4460014  swc1        $f6, 0x14($v0)
    ctx->pc = 0x2d3330u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 20), bits); }
label_2d3334:
    // 0x2d3334: 0xe4490018  swc1        $f9, 0x18($v0)
    ctx->pc = 0x2d3334u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 24), bits); }
label_2d3338:
    // 0x2d3338: 0xe4820004  swc1        $f2, 0x4($a0)
    ctx->pc = 0x2d3338u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 4), bits); }
label_2d333c:
    // 0x2d333c: 0x3c02004d  lui         $v0, 0x4D
    ctx->pc = 0x2d333cu;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)77 << 16));
label_2d3340:
    // 0x2d3340: 0xe4830008  swc1        $f3, 0x8($a0)
    ctx->pc = 0x2d3340u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 8), bits); }
label_2d3344:
    // 0x2d3344: 0xe484000c  swc1        $f4, 0xC($a0)
    ctx->pc = 0x2d3344u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 12), bits); }
label_2d3348:
    // 0x2d3348: 0xe4850010  swc1        $f5, 0x10($a0)
    ctx->pc = 0x2d3348u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 16), bits); }
label_2d334c:
    // 0x2d334c: 0xe4860014  swc1        $f6, 0x14($a0)
    ctx->pc = 0x2d334cu;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 20), bits); }
label_2d3350:
    // 0x2d3350: 0xe4890018  swc1        $f9, 0x18($a0)
    ctx->pc = 0x2d3350u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 24), bits); }
label_2d3354:
    // 0x2d3354: 0xe4a20004  swc1        $f2, 0x4($a1)
    ctx->pc = 0x2d3354u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 4), bits); }
label_2d3358:
    // 0x2d3358: 0x3c04004d  lui         $a0, 0x4D
    ctx->pc = 0x2d3358u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)77 << 16));
label_2d335c:
    // 0x2d335c: 0xe4a30008  swc1        $f3, 0x8($a1)
    ctx->pc = 0x2d335cu;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 8), bits); }
label_2d3360:
    // 0x2d3360: 0xe4a4000c  swc1        $f4, 0xC($a1)
    ctx->pc = 0x2d3360u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 12), bits); }
label_2d3364:
    // 0x2d3364: 0xe4a50010  swc1        $f5, 0x10($a1)
    ctx->pc = 0x2d3364u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 16), bits); }
label_2d3368:
    // 0x2d3368: 0xe4a60014  swc1        $f6, 0x14($a1)
    ctx->pc = 0x2d3368u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 20), bits); }
label_2d336c:
    // 0x2d336c: 0xe4a90018  swc1        $f9, 0x18($a1)
    ctx->pc = 0x2d336cu;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 24), bits); }
label_2d3370:
    // 0x2d3370: 0xe4c20004  swc1        $f2, 0x4($a2)
    ctx->pc = 0x2d3370u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 4), bits); }
label_2d3374:
    // 0x2d3374: 0x3c05004d  lui         $a1, 0x4D
    ctx->pc = 0x2d3374u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)77 << 16));
label_2d3378:
    // 0x2d3378: 0xe4c30008  swc1        $f3, 0x8($a2)
    ctx->pc = 0x2d3378u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 8), bits); }
label_2d337c:
    // 0x2d337c: 0xe4c4000c  swc1        $f4, 0xC($a2)
    ctx->pc = 0x2d337cu;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 12), bits); }
label_2d3380:
    // 0x2d3380: 0xe4c50010  swc1        $f5, 0x10($a2)
    ctx->pc = 0x2d3380u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 16), bits); }
label_2d3384:
    // 0x2d3384: 0xe4c60014  swc1        $f6, 0x14($a2)
    ctx->pc = 0x2d3384u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 20), bits); }
label_2d3388:
    // 0x2d3388: 0xe4c90018  swc1        $f9, 0x18($a2)
    ctx->pc = 0x2d3388u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 24), bits); }
label_2d338c:
    // 0x2d338c: 0xe4c8001c  swc1        $f8, 0x1C($a2)
    ctx->pc = 0x2d338cu;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 28), bits); }
label_2d3390:
    // 0x2d3390: 0xac4051e0  sw          $zero, 0x51E0($v0)
    ctx->pc = 0x2d3390u;
    WRITE32(ADD32(GPR_U32(ctx, 2), 20960), GPR_U32(ctx, 0));
label_2d3394:
    // 0x2d3394: 0x3c06004d  lui         $a2, 0x4D
    ctx->pc = 0x2d3394u;
    SET_GPR_S32(ctx, 6, (int32_t)((uint32_t)77 << 16));
label_2d3398:
    // 0x2d3398: 0xe508001c  swc1        $f8, 0x1C($t0)
    ctx->pc = 0x2d3398u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 28), bits); }
label_2d339c:
    // 0x2d339c: 0x2c0102d  daddu       $v0, $s6, $zero
    ctx->pc = 0x2d339cu;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d33a0:
    // 0x2d33a0: 0xe528001c  swc1        $f8, 0x1C($t1)
    ctx->pc = 0x2d33a0u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 28), bits); }
label_2d33a4:
    // 0x2d33a4: 0x24425360  addiu       $v0, $v0, 0x5360
    ctx->pc = 0x2d33a4u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 21344));
label_2d33a8:
    // 0x2d33a8: 0xac605220  sw          $zero, 0x5220($v1)
    ctx->pc = 0x2d33a8u;
    WRITE32(ADD32(GPR_U32(ctx, 3), 21024), GPR_U32(ctx, 0));
label_2d33ac:
    // 0x2d33ac: 0xe548001c  swc1        $f8, 0x1C($t2)
    ctx->pc = 0x2d33acu;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 28), bits); }
label_2d33b0:
    // 0x2d33b0: 0x2c0182d  daddu       $v1, $s6, $zero
    ctx->pc = 0x2d33b0u;
    SET_GPR_U64(ctx, 3, (uint64_t)GPR_U64(ctx, 22) + (uint64_t)GPR_U64(ctx, 0));
label_2d33b4:
    // 0x2d33b4: 0xac805240  sw          $zero, 0x5240($a0)
    ctx->pc = 0x2d33b4u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 21056), GPR_U32(ctx, 0));
label_2d33b8:
    // 0x2d33b8: 0x24635360  addiu       $v1, $v1, 0x5360
    ctx->pc = 0x2d33b8u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 3), 21344));
label_2d33bc:
    // 0x2d33bc: 0xe568001c  swc1        $f8, 0x1C($t3)
    ctx->pc = 0x2d33bcu;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 28), bits); }
label_2d33c0:
    // 0x2d33c0: 0x3c04004d  lui         $a0, 0x4D
    ctx->pc = 0x2d33c0u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)77 << 16));
label_2d33c4:
    // 0x2d33c4: 0xaca05260  sw          $zero, 0x5260($a1)
    ctx->pc = 0x2d33c4u;
    WRITE32(ADD32(GPR_U32(ctx, 5), 21088), GPR_U32(ctx, 0));
label_2d33c8:
    // 0x2d33c8: 0xe5020004  swc1        $f2, 0x4($t0)
    ctx->pc = 0x2d33c8u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 4), bits); }
label_2d33cc:
    // 0x2d33cc: 0x80282d  daddu       $a1, $a0, $zero
    ctx->pc = 0x2d33ccu;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2d33d0:
    // 0x2d33d0: 0xe5030008  swc1        $f3, 0x8($t0)
    ctx->pc = 0x2d33d0u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 8), bits); }
label_2d33d4:
    // 0x2d33d4: 0x24a55380  addiu       $a1, $a1, 0x5380
    ctx->pc = 0x2d33d4u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 21376));
label_2d33d8:
    // 0x2d33d8: 0xe504000c  swc1        $f4, 0xC($t0)
    ctx->pc = 0x2d33d8u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 12), bits); }
label_2d33dc:
    // 0x2d33dc: 0xe5050010  swc1        $f5, 0x10($t0)
    ctx->pc = 0x2d33dcu;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 16), bits); }
label_2d33e0:
    // 0x2d33e0: 0xe5060014  swc1        $f6, 0x14($t0)
    ctx->pc = 0x2d33e0u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 20), bits); }
label_2d33e4:
    // 0x2d33e4: 0xe5090018  swc1        $f9, 0x18($t0)
    ctx->pc = 0x2d33e4u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 24), bits); }
label_2d33e8:
    // 0x2d33e8: 0xacc05200  sw          $zero, 0x5200($a2)
    ctx->pc = 0x2d33e8u;
    WRITE32(ADD32(GPR_U32(ctx, 6), 20992), GPR_U32(ctx, 0));
label_2d33ec:
    // 0x2d33ec: 0x3c08004d  lui         $t0, 0x4D
    ctx->pc = 0x2d33ecu;
    SET_GPR_S32(ctx, 8, (int32_t)((uint32_t)77 << 16));
label_2d33f0:
    // 0x2d33f0: 0xe5220004  swc1        $f2, 0x4($t1)
    ctx->pc = 0x2d33f0u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 4), bits); }
label_2d33f4:
    // 0x2d33f4: 0xe5230008  swc1        $f3, 0x8($t1)
    ctx->pc = 0x2d33f4u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 8), bits); }
label_2d33f8:
    // 0x2d33f8: 0xe524000c  swc1        $f4, 0xC($t1)
    ctx->pc = 0x2d33f8u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 12), bits); }
label_2d33fc:
    // 0x2d33fc: 0xe5250010  swc1        $f5, 0x10($t1)
    ctx->pc = 0x2d33fcu;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 16), bits); }
label_2d3400:
    // 0x2d3400: 0xe5260014  swc1        $f6, 0x14($t1)
    ctx->pc = 0x2d3400u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 20), bits); }
label_2d3404:
    // 0x2d3404: 0xe5290018  swc1        $f9, 0x18($t1)
    ctx->pc = 0x2d3404u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 24), bits); }
label_2d3408:
    // 0x2d3408: 0xe5420004  swc1        $f2, 0x4($t2)
    ctx->pc = 0x2d3408u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 4), bits); }
label_2d340c:
    // 0x2d340c: 0x3c09004d  lui         $t1, 0x4D
    ctx->pc = 0x2d340cu;
    SET_GPR_S32(ctx, 9, (int32_t)((uint32_t)77 << 16));
label_2d3410:
    // 0x2d3410: 0xe5430008  swc1        $f3, 0x8($t2)
    ctx->pc = 0x2d3410u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 8), bits); }
label_2d3414:
    // 0x2d3414: 0xe544000c  swc1        $f4, 0xC($t2)
    ctx->pc = 0x2d3414u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 12), bits); }
label_2d3418:
    // 0x2d3418: 0xe5450010  swc1        $f5, 0x10($t2)
    ctx->pc = 0x2d3418u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 16), bits); }
label_2d341c:
    // 0x2d341c: 0xe5460014  swc1        $f6, 0x14($t2)
    ctx->pc = 0x2d341cu;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 20), bits); }
label_2d3420:
    // 0x2d3420: 0xe5490018  swc1        $f9, 0x18($t2)
    ctx->pc = 0x2d3420u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 24), bits); }
label_2d3424:
    // 0x2d3424: 0xe5620004  swc1        $f2, 0x4($t3)
    ctx->pc = 0x2d3424u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 4), bits); }
label_2d3428:
    // 0x2d3428: 0x3c0a004d  lui         $t2, 0x4D
    ctx->pc = 0x2d3428u;
    SET_GPR_S32(ctx, 10, (int32_t)((uint32_t)77 << 16));
label_2d342c:
    // 0x2d342c: 0xe5630008  swc1        $f3, 0x8($t3)
    ctx->pc = 0x2d342cu;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 8), bits); }
label_2d3430:
    // 0x2d3430: 0xe564000c  swc1        $f4, 0xC($t3)
    ctx->pc = 0x2d3430u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 12), bits); }
label_2d3434:
    // 0x2d3434: 0xe5650010  swc1        $f5, 0x10($t3)
    ctx->pc = 0x2d3434u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 16), bits); }
label_2d3438:
    // 0x2d3438: 0xe5660014  swc1        $f6, 0x14($t3)
    ctx->pc = 0x2d3438u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 20), bits); }
label_2d343c:
    // 0x2d343c: 0xe5690018  swc1        $f9, 0x18($t3)
    ctx->pc = 0x2d343cu;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 24), bits); }
label_2d3440:
    // 0x2d3440: 0xe5a20004  swc1        $f2, 0x4($t5)
    ctx->pc = 0x2d3440u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 4), bits); }
label_2d3444:
    // 0x2d3444: 0x3c0b004d  lui         $t3, 0x4D
    ctx->pc = 0x2d3444u;
    SET_GPR_S32(ctx, 11, (int32_t)((uint32_t)77 << 16));
label_2d3448:
    // 0x2d3448: 0xe5a8001c  swc1        $f8, 0x1C($t5)
    ctx->pc = 0x2d3448u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 28), bits); }
label_2d344c:
    // 0x2d344c: 0xad005280  sw          $zero, 0x5280($t0)
    ctx->pc = 0x2d344cu;
    WRITE32(ADD32(GPR_U32(ctx, 8), 21120), GPR_U32(ctx, 0));
label_2d3450:
    // 0x2d3450: 0xe588001c  swc1        $f8, 0x1C($t4)
    ctx->pc = 0x2d3450u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 28), bits); }
label_2d3454:
    // 0x2d3454: 0xad2052a0  sw          $zero, 0x52A0($t1)
    ctx->pc = 0x2d3454u;
    WRITE32(ADD32(GPR_U32(ctx, 9), 21152), GPR_U32(ctx, 0));
label_2d3458:
    // 0x2d3458: 0xe5c8001c  swc1        $f8, 0x1C($t6)
    ctx->pc = 0x2d3458u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 28), bits); }
label_2d345c:
    // 0x2d345c: 0x3c09004d  lui         $t1, 0x4D
    ctx->pc = 0x2d345cu;
    SET_GPR_S32(ctx, 9, (int32_t)((uint32_t)77 << 16));
label_2d3460:
    // 0x2d3460: 0xad4052c0  sw          $zero, 0x52C0($t2)
    ctx->pc = 0x2d3460u;
    WRITE32(ADD32(GPR_U32(ctx, 10), 21184), GPR_U32(ctx, 0));
label_2d3464:
    // 0x2d3464: 0x252953d0  addiu       $t1, $t1, 0x53D0
    ctx->pc = 0x2d3464u;
    SET_GPR_S32(ctx, 9, (int32_t)ADD32(GPR_U32(ctx, 9), 21456));
label_2d3468:
    // 0x2d3468: 0xe5e8001c  swc1        $f8, 0x1C($t7)
    ctx->pc = 0x2d3468u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 28), bits); }
label_2d346c:
    // 0x2d346c: 0x3c0a004d  lui         $t2, 0x4D
    ctx->pc = 0x2d346cu;
    SET_GPR_S32(ctx, 10, (int32_t)((uint32_t)77 << 16));
label_2d3470:
    // 0x2d3470: 0xad6052e0  sw          $zero, 0x52E0($t3)
    ctx->pc = 0x2d3470u;
    WRITE32(ADD32(GPR_U32(ctx, 11), 21216), GPR_U32(ctx, 0));
label_2d3474:
    // 0x2d3474: 0xe5a30008  swc1        $f3, 0x8($t5)
    ctx->pc = 0x2d3474u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 8), bits); }
label_2d3478:
    // 0x2d3478: 0x140582d  daddu       $t3, $t2, $zero
    ctx->pc = 0x2d3478u;
    SET_GPR_U64(ctx, 11, (uint64_t)GPR_U64(ctx, 10) + (uint64_t)GPR_U64(ctx, 0));
label_2d347c:
    // 0x2d347c: 0xe5a4000c  swc1        $f4, 0xC($t5)
    ctx->pc = 0x2d347cu;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 12), bits); }
label_2d3480:
    // 0x2d3480: 0x256b53e0  addiu       $t3, $t3, 0x53E0
    ctx->pc = 0x2d3480u;
    SET_GPR_S32(ctx, 11, (int32_t)ADD32(GPR_U32(ctx, 11), 21472));
label_2d3484:
    // 0x2d3484: 0xe5a50010  swc1        $f5, 0x10($t5)
    ctx->pc = 0x2d3484u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 16), bits); }
label_2d3488:
    // 0x2d3488: 0xe5a60014  swc1        $f6, 0x14($t5)
    ctx->pc = 0x2d3488u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 20), bits); }
label_2d348c:
    // 0x2d348c: 0xe5a90018  swc1        $f9, 0x18($t5)
    ctx->pc = 0x2d348cu;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 13), 24), bits); }
label_2d3490:
    // 0x2d3490: 0xe5820004  swc1        $f2, 0x4($t4)
    ctx->pc = 0x2d3490u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 4), bits); }
label_2d3494:
    // 0x2d3494: 0xe5830008  swc1        $f3, 0x8($t4)
    ctx->pc = 0x2d3494u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 8), bits); }
label_2d3498:
    // 0x2d3498: 0xe584000c  swc1        $f4, 0xC($t4)
    ctx->pc = 0x2d3498u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 12), bits); }
label_2d349c:
    // 0x2d349c: 0xe5850010  swc1        $f5, 0x10($t4)
    ctx->pc = 0x2d349cu;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 16), bits); }
label_2d34a0:
    // 0x2d34a0: 0xe5860014  swc1        $f6, 0x14($t4)
    ctx->pc = 0x2d34a0u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 20), bits); }
label_2d34a4:
    // 0x2d34a4: 0xe5890018  swc1        $f9, 0x18($t4)
    ctx->pc = 0x2d34a4u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 24), bits); }
label_2d34a8:
    // 0x2d34a8: 0xe5c20004  swc1        $f2, 0x4($t6)
    ctx->pc = 0x2d34a8u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 4), bits); }
label_2d34ac:
    // 0x2d34ac: 0x3c0c004d  lui         $t4, 0x4D
    ctx->pc = 0x2d34acu;
    SET_GPR_S32(ctx, 12, (int32_t)((uint32_t)77 << 16));
label_2d34b0:
    // 0x2d34b0: 0xe5c30008  swc1        $f3, 0x8($t6)
    ctx->pc = 0x2d34b0u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 8), bits); }
label_2d34b4:
    // 0x2d34b4: 0xe5c4000c  swc1        $f4, 0xC($t6)
    ctx->pc = 0x2d34b4u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 12), bits); }
label_2d34b8:
    // 0x2d34b8: 0xe5c50010  swc1        $f5, 0x10($t6)
    ctx->pc = 0x2d34b8u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 16), bits); }
label_2d34bc:
    // 0x2d34bc: 0xe5c60014  swc1        $f6, 0x14($t6)
    ctx->pc = 0x2d34bcu;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 20), bits); }
label_2d34c0:
    // 0x2d34c0: 0xe5c90018  swc1        $f9, 0x18($t6)
    ctx->pc = 0x2d34c0u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 24), bits); }
label_2d34c4:
    // 0x2d34c4: 0xe5e20004  swc1        $f2, 0x4($t7)
    ctx->pc = 0x2d34c4u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 4), bits); }
label_2d34c8:
    // 0x2d34c8: 0x180702d  daddu       $t6, $t4, $zero
    ctx->pc = 0x2d34c8u;
    SET_GPR_U64(ctx, 14, (uint64_t)GPR_U64(ctx, 12) + (uint64_t)GPR_U64(ctx, 0));
label_2d34cc:
    // 0x2d34cc: 0xe5e30008  swc1        $f3, 0x8($t7)
    ctx->pc = 0x2d34ccu;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 8), bits); }
label_2d34d0:
    // 0x2d34d0: 0x25ce5300  addiu       $t6, $t6, 0x5300
    ctx->pc = 0x2d34d0u;
    SET_GPR_S32(ctx, 14, (int32_t)ADD32(GPR_U32(ctx, 14), 21248));
label_2d34d4:
    // 0x2d34d4: 0xe5e4000c  swc1        $f4, 0xC($t7)
    ctx->pc = 0x2d34d4u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 12), bits); }
label_2d34d8:
    // 0x2d34d8: 0xe5e50010  swc1        $f5, 0x10($t7)
    ctx->pc = 0x2d34d8u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 16), bits); }
label_2d34dc:
    // 0x2d34dc: 0xe5e60014  swc1        $f6, 0x14($t7)
    ctx->pc = 0x2d34dcu;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 20), bits); }
label_2d34e0:
    // 0x2d34e0: 0xe5e90018  swc1        $f9, 0x18($t7)
    ctx->pc = 0x2d34e0u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 24), bits); }
label_2d34e4:
    // 0x2d34e4: 0xe6220004  swc1        $f2, 0x4($s1)
    ctx->pc = 0x2d34e4u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 4), bits); }
label_2d34e8:
    // 0x2d34e8: 0x3c0f004d  lui         $t7, 0x4D
    ctx->pc = 0x2d34e8u;
    SET_GPR_S32(ctx, 15, (int32_t)((uint32_t)77 << 16));
label_2d34ec:
    // 0x2d34ec: 0xe6230008  swc1        $f3, 0x8($s1)
    ctx->pc = 0x2d34ecu;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 8), bits); }
label_2d34f0:
    // 0x2d34f0: 0xe624000c  swc1        $f4, 0xC($s1)
    ctx->pc = 0x2d34f0u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 12), bits); }
label_2d34f4:
    // 0x2d34f4: 0xe628001c  swc1        $f8, 0x1C($s1)
    ctx->pc = 0x2d34f4u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 28), bits); }
label_2d34f8:
    // 0x2d34f8: 0xad805300  sw          $zero, 0x5300($t4)
    ctx->pc = 0x2d34f8u;
    WRITE32(ADD32(GPR_U32(ctx, 12), 21248), GPR_U32(ctx, 0));
label_2d34fc:
    // 0x2d34fc: 0xe5c8001c  swc1        $f8, 0x1C($t6)
    ctx->pc = 0x2d34fcu;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 28), bits); }
label_2d3500:
    // 0x2d3500: 0x3c0c004d  lui         $t4, 0x4D
    ctx->pc = 0x2d3500u;
    SET_GPR_S32(ctx, 12, (int32_t)((uint32_t)77 << 16));
label_2d3504:
    // 0x2d3504: 0xade05320  sw          $zero, 0x5320($t7)
    ctx->pc = 0x2d3504u;
    WRITE32(ADD32(GPR_U32(ctx, 15), 21280), GPR_U32(ctx, 0));
label_2d3508:
    // 0x2d3508: 0xe648001c  swc1        $f8, 0x1C($s2)
    ctx->pc = 0x2d3508u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 18), 28), bits); }
label_2d350c:
    // 0x2d350c: 0x3c0f004d  lui         $t7, 0x4D
    ctx->pc = 0x2d350cu;
    SET_GPR_S32(ctx, 15, (int32_t)((uint32_t)77 << 16));
label_2d3510:
    // 0x2d3510: 0xae005340  sw          $zero, 0x5340($s0)
    ctx->pc = 0x2d3510u;
    WRITE32(ADD32(GPR_U32(ctx, 16), 21312), GPR_U32(ctx, 0));
label_2d3514:
    // 0x2d3514: 0xe668001c  swc1        $f8, 0x1C($s3)
    ctx->pc = 0x2d3514u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 28), bits); }
label_2d3518:
    // 0x2d3518: 0x1e0802d  daddu       $s0, $t7, $zero
    ctx->pc = 0x2d3518u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 15) + (uint64_t)GPR_U64(ctx, 0));
label_2d351c:
    // 0x2d351c: 0xaec05360  sw          $zero, 0x5360($s6)
    ctx->pc = 0x2d351cu;
    WRITE32(ADD32(GPR_U32(ctx, 22), 21344), GPR_U32(ctx, 0));
label_2d3520:
    // 0x2d3520: 0x261053b0  addiu       $s0, $s0, 0x53B0
    ctx->pc = 0x2d3520u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 21424));
label_2d3524:
    // 0x2d3524: 0xe4420004  swc1        $f2, 0x4($v0)
    ctx->pc = 0x2d3524u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 4), bits); }
label_2d3528:
    // 0x2d3528: 0x24160001  addiu       $s6, $zero, 0x1
    ctx->pc = 0x2d3528u;
    SET_GPR_S32(ctx, 22, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_2d352c:
    // 0x2d352c: 0xe4430008  swc1        $f3, 0x8($v0)
    ctx->pc = 0x2d352cu;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 8), bits); }
label_2d3530:
    // 0x2d3530: 0xe444000c  swc1        $f4, 0xC($v0)
    ctx->pc = 0x2d3530u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 12), bits); }
label_2d3534:
    // 0x2d3534: 0xe4450010  swc1        $f5, 0x10($v0)
    ctx->pc = 0x2d3534u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 16), bits); }
label_2d3538:
    // 0x2d3538: 0xe6250010  swc1        $f5, 0x10($s1)
    ctx->pc = 0x2d3538u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 16), bits); }
label_2d353c:
    // 0x2d353c: 0xe6260014  swc1        $f6, 0x14($s1)
    ctx->pc = 0x2d353cu;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 20), bits); }
label_2d3540:
    // 0x2d3540: 0xe6290018  swc1        $f9, 0x18($s1)
    ctx->pc = 0x2d3540u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 17), 24), bits); }
label_2d3544:
    // 0x2d3544: 0xe5c20004  swc1        $f2, 0x4($t6)
    ctx->pc = 0x2d3544u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 4), bits); }
label_2d3548:
    // 0x2d3548: 0xe5c30008  swc1        $f3, 0x8($t6)
    ctx->pc = 0x2d3548u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 8), bits); }
label_2d354c:
    // 0x2d354c: 0xe5c4000c  swc1        $f4, 0xC($t6)
    ctx->pc = 0x2d354cu;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 12), bits); }
label_2d3550:
    // 0x2d3550: 0xe5c50010  swc1        $f5, 0x10($t6)
    ctx->pc = 0x2d3550u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 16), bits); }
label_2d3554:
    // 0x2d3554: 0xe5c60014  swc1        $f6, 0x14($t6)
    ctx->pc = 0x2d3554u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 20), bits); }
label_2d3558:
    // 0x2d3558: 0xe5c90018  swc1        $f9, 0x18($t6)
    ctx->pc = 0x2d3558u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 24), bits); }
label_2d355c:
    // 0x2d355c: 0xe6420004  swc1        $f2, 0x4($s2)
    ctx->pc = 0x2d355cu;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 18), 4), bits); }
label_2d3560:
    // 0x2d3560: 0x180702d  daddu       $t6, $t4, $zero
    ctx->pc = 0x2d3560u;
    SET_GPR_U64(ctx, 14, (uint64_t)GPR_U64(ctx, 12) + (uint64_t)GPR_U64(ctx, 0));
label_2d3564:
    // 0x2d3564: 0xe6430008  swc1        $f3, 0x8($s2)
    ctx->pc = 0x2d3564u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 18), 8), bits); }
label_2d3568:
    // 0x2d3568: 0x25ce5390  addiu       $t6, $t6, 0x5390
    ctx->pc = 0x2d3568u;
    SET_GPR_S32(ctx, 14, (int32_t)ADD32(GPR_U32(ctx, 14), 21392));
label_2d356c:
    // 0x2d356c: 0xe644000c  swc1        $f4, 0xC($s2)
    ctx->pc = 0x2d356cu;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 18), 12), bits); }
label_2d3570:
    // 0x2d3570: 0xe6450010  swc1        $f5, 0x10($s2)
    ctx->pc = 0x2d3570u;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 18), 16), bits); }
label_2d3574:
    // 0x2d3574: 0xe6460014  swc1        $f6, 0x14($s2)
    ctx->pc = 0x2d3574u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 18), 20), bits); }
label_2d3578:
    // 0x2d3578: 0xe6490018  swc1        $f9, 0x18($s2)
    ctx->pc = 0x2d3578u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 18), 24), bits); }
label_2d357c:
    // 0x2d357c: 0xe6620004  swc1        $f2, 0x4($s3)
    ctx->pc = 0x2d357cu;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 4), bits); }
label_2d3580:
    // 0x2d3580: 0x3c12004d  lui         $s2, 0x4D
    ctx->pc = 0x2d3580u;
    SET_GPR_S32(ctx, 18, (int32_t)((uint32_t)77 << 16));
label_2d3584:
    // 0x2d3584: 0xe6630008  swc1        $f3, 0x8($s3)
    ctx->pc = 0x2d3584u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 8), bits); }
label_2d3588:
    // 0x2d3588: 0xe664000c  swc1        $f4, 0xC($s3)
    ctx->pc = 0x2d3588u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 12), bits); }
label_2d358c:
    // 0x2d358c: 0xe6650010  swc1        $f5, 0x10($s3)
    ctx->pc = 0x2d358cu;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 16), bits); }
label_2d3590:
    // 0x2d3590: 0xe6660014  swc1        $f6, 0x14($s3)
    ctx->pc = 0x2d3590u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 20), bits); }
label_2d3594:
    // 0x2d3594: 0xe6690018  swc1        $f9, 0x18($s3)
    ctx->pc = 0x2d3594u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 24), bits); }
label_2d3598:
    // 0x2d3598: 0xe4460014  swc1        $f6, 0x14($v0)
    ctx->pc = 0x2d3598u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 20), bits); }
label_2d359c:
    // 0x2d359c: 0x3c13004d  lui         $s3, 0x4D
    ctx->pc = 0x2d359cu;
    SET_GPR_S32(ctx, 19, (int32_t)((uint32_t)77 << 16));
label_2d35a0:
    // 0x2d35a0: 0xa3802360  sb          $zero, 0x2360($gp)
    ctx->pc = 0x2d35a0u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9056), (uint8_t)GPR_U32(ctx, 0));
label_2d35a4:
    // 0x2d35a4: 0xc4c65200  lwc1        $f6, 0x5200($a2)
    ctx->pc = 0x2d35a4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 6), 20992)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[6] = f; }
label_2d35a8:
    // 0x2d35a8: 0x93822360  lbu         $v0, 0x2360($gp)
    ctx->pc = 0x2d35a8u;
    SET_GPR_U32(ctx, 2, (uint8_t)READ8(ADD32(GPR_U32(ctx, 28), 9056)));
label_2d35ac:
    // 0x2d35ac: 0x3c06004d  lui         $a2, 0x4D
    ctx->pc = 0x2d35acu;
    SET_GPR_S32(ctx, 6, (int32_t)((uint32_t)77 << 16));
label_2d35b0:
    // 0x2d35b0: 0xc781c190  lwc1        $f1, -0x3E70($gp)
    ctx->pc = 0x2d35b0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951312)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_2d35b4:
    // 0x2d35b4: 0xc0402d  daddu       $t0, $a2, $zero
    ctx->pc = 0x2d35b4u;
    SET_GPR_U64(ctx, 8, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
label_2d35b8:
    // 0x2d35b8: 0xe468001c  swc1        $f8, 0x1C($v1)
    ctx->pc = 0x2d35b8u;
    { float f = ctx->f[8]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 28), bits); }
label_2d35bc:
    // 0x2d35bc: 0x250853a0  addiu       $t0, $t0, 0x53A0
    ctx->pc = 0x2d35bcu;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 8), 21408));
label_2d35c0:
    // 0x2d35c0: 0xc782c194  lwc1        $f2, -0x3E6C($gp)
    ctx->pc = 0x2d35c0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951316)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[2] = f; }
label_2d35c4:
    // 0x2d35c4: 0xe4815380  swc1        $f1, 0x5380($a0)
    ctx->pc = 0x2d35c4u;
    { float f = ctx->f[1]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 21376), bits); }
label_2d35c8:
    // 0x2d35c8: 0xe4a2000c  swc1        $f2, 0xC($a1)
    ctx->pc = 0x2d35c8u;
    { float f = ctx->f[2]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 12), bits); }
label_2d35cc:
    // 0x2d35cc: 0x24040004  addiu       $a0, $zero, 0x4
    ctx->pc = 0x2d35ccu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 0), 4));
label_2d35d0:
    // 0x2d35d0: 0xc787c198  lwc1        $f7, -0x3E68($gp)
    ctx->pc = 0x2d35d0u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951320)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[7] = f; }
label_2d35d4:
    // 0x2d35d4: 0xe4d053a0  swc1        $f16, 0x53A0($a2)
    ctx->pc = 0x2d35d4u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 6), 21408), bits); }
label_2d35d8:
    // 0x2d35d8: 0xe5070008  swc1        $f7, 0x8($t0)
    ctx->pc = 0x2d35d8u;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 8), bits); }
label_2d35dc:
    // 0x2d35dc: 0x24060006  addiu       $a2, $zero, 0x6
    ctx->pc = 0x2d35dcu;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 0), 6));
label_2d35e0:
    // 0x2d35e0: 0xe526000c  swc1        $f6, 0xC($t1)
    ctx->pc = 0x2d35e0u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 12), bits); }
label_2d35e4:
    // 0x2d35e4: 0xc785c19c  lwc1        $f5, -0x3E64($gp)
    ctx->pc = 0x2d35e4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951324)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[5] = f; }
label_2d35e8:
    // 0x2d35e8: 0xe54053e0  swc1        $f0, 0x53E0($t2)
    ctx->pc = 0x2d35e8u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 10), 21472), bits); }
label_2d35ec:
    // 0x2d35ec: 0xe565000c  swc1        $f5, 0xC($t3)
    ctx->pc = 0x2d35ecu;
    { float f = ctx->f[5]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 12), bits); }
label_2d35f0:
    // 0x2d35f0: 0x240a0009  addiu       $t2, $zero, 0x9
    ctx->pc = 0x2d35f0u;
    SET_GPR_S32(ctx, 10, (int32_t)ADD32(GPR_U32(ctx, 0), 9));
label_2d35f4:
    // 0x2d35f4: 0xc78cc1a0  lwc1        $f12, -0x3E60($gp)
    ctx->pc = 0x2d35f4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951328)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[12] = f; }
label_2d35f8:
    // 0x2d35f8: 0xe4690018  swc1        $f9, 0x18($v1)
    ctx->pc = 0x2d35f8u;
    { float f = ctx->f[9]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 3), 24), bits); }
label_2d35fc:
    // 0x2d35fc: 0xe4ac0008  swc1        $f12, 0x8($a1)
    ctx->pc = 0x2d35fcu;
    { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 8), bits); }
label_2d3600:
    // 0x2d3600: 0x24030003  addiu       $v1, $zero, 0x3
    ctx->pc = 0x2d3600u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 3));
label_2d3604:
    // 0x2d3604: 0xe5875390  swc1        $f7, 0x5390($t4)
    ctx->pc = 0x2d3604u;
    { float f = ctx->f[7]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 12), 21392), bits); }
label_2d3608:
    // 0x2d3608: 0xc78bc1a4  lwc1        $f11, -0x3E5C($gp)
    ctx->pc = 0x2d3608u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951332)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[11] = f; }
label_2d360c:
    // 0x2d360c: 0x240c000b  addiu       $t4, $zero, 0xB
    ctx->pc = 0x2d360cu;
    SET_GPR_S32(ctx, 12, (int32_t)ADD32(GPR_U32(ctx, 0), 11));
label_2d3610:
    // 0x2d3610: 0xe5c0000c  swc1        $f0, 0xC($t6)
    ctx->pc = 0x2d3610u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 12), bits); }
label_2d3614:
    // 0x2d3614: 0xc78ac1a8  lwc1        $f10, -0x3E58($gp)
    ctx->pc = 0x2d3614u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951336)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[10] = f; }
label_2d3618:
    // 0x2d3618: 0xe50b0004  swc1        $f11, 0x4($t0)
    ctx->pc = 0x2d3618u;
    { float f = ctx->f[11]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 8), 4), bits); }
label_2d361c:
    // 0x2d361c: 0xc783c1ac  lwc1        $f3, -0x3E54($gp)
    ctx->pc = 0x2d361cu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951340)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[3] = f; }
label_2d3620:
    // 0x2d3620: 0x24080007  addiu       $t0, $zero, 0x7
    ctx->pc = 0x2d3620u;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 0), 7));
label_2d3624:
    // 0x2d3624: 0xe5ea53b0  swc1        $f10, 0x53B0($t7)
    ctx->pc = 0x2d3624u;
    { float f = ctx->f[10]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 15), 21424), bits); }
label_2d3628:
    // 0x2d3628: 0xe60a0004  swc1        $f10, 0x4($s0)
    ctx->pc = 0x2d3628u;
    { float f = ctx->f[10]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 4), bits); }
label_2d362c:
    // 0x2d362c: 0x240f000d  addiu       $t7, $zero, 0xD
    ctx->pc = 0x2d362cu;
    SET_GPR_S32(ctx, 15, (int32_t)ADD32(GPR_U32(ctx, 0), 13));
label_2d3630:
    // 0x2d3630: 0xe6030008  swc1        $f3, 0x8($s0)
    ctx->pc = 0x2d3630u;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 16), 8), bits); }
label_2d3634:
    // 0x2d3634: 0xc784c1b0  lwc1        $f4, -0x3E50($gp)
    ctx->pc = 0x2d3634u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 28), 4294951344)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[4] = f; }
label_2d3638:
    // 0x2d3638: 0xe64053c0  swc1        $f0, 0x53C0($s2)
    ctx->pc = 0x2d3638u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 18), 21440), bits); }
label_2d363c:
    // 0x2d363c: 0xe7c30008  swc1        $f3, 0x8($fp)
    ctx->pc = 0x2d363cu;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 30), 8), bits); }
label_2d3640:
    // 0x2d3640: 0xe7c4000c  swc1        $f4, 0xC($fp)
    ctx->pc = 0x2d3640u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 30), 12), bits); }
label_2d3644:
    // 0x2d3644: 0xe66053d0  swc1        $f0, 0x53D0($s3)
    ctx->pc = 0x2d3644u;
    { float f = ctx->f[0]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 19), 21456), bits); }
label_2d3648:
    // 0x2d3648: 0xe5640008  swc1        $f4, 0x8($t3)
    ctx->pc = 0x2d3648u;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 8), bits); }
label_2d364c:
    // 0x2d364c: 0xe4ac0004  swc1        $f12, 0x4($a1)
    ctx->pc = 0x2d364cu;
    { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 5), 4), bits); }
label_2d3650:
    // 0x2d3650: 0xe5d00004  swc1        $f16, 0x4($t6)
    ctx->pc = 0x2d3650u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 4), bits); }
label_2d3654:
    // 0x2d3654: 0x24050005  addiu       $a1, $zero, 0x5
    ctx->pc = 0x2d3654u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 5));
label_2d3658:
    // 0x2d3658: 0xe5d00008  swc1        $f16, 0x8($t6)
    ctx->pc = 0x2d3658u;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 14), 8), bits); }
label_2d365c:
    // 0x2d365c: 0xe7c30004  swc1        $f3, 0x4($fp)
    ctx->pc = 0x2d365cu;
    { float f = ctx->f[3]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 30), 4), bits); }
label_2d3660:
    // 0x2d3660: 0x240e000c  addiu       $t6, $zero, 0xC
    ctx->pc = 0x2d3660u;
    SET_GPR_S32(ctx, 14, (int32_t)ADD32(GPR_U32(ctx, 0), 12));
label_2d3664:
    // 0x2d3664: 0xe5260004  swc1        $f6, 0x4($t1)
    ctx->pc = 0x2d3664u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 4), bits); }
label_2d3668:
    // 0x2d3668: 0xe5260008  swc1        $f6, 0x8($t1)
    ctx->pc = 0x2d3668u;
    { float f = ctx->f[6]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 9), 8), bits); }
label_2d366c:
    // 0x2d366c: 0xe5640004  swc1        $f4, 0x4($t3)
    ctx->pc = 0x2d366cu;
    { float f = ctx->f[4]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 11), 4), bits); }
label_2d3670:
    // 0x2d3670: 0x24090008  addiu       $t1, $zero, 0x8
    ctx->pc = 0x2d3670u;
    SET_GPR_S32(ctx, 9, (int32_t)ADD32(GPR_U32(ctx, 0), 8));
label_2d3674:
    // 0x2d3674: 0xaf80235c  sw          $zero, 0x235C($gp)
    ctx->pc = 0x2d3674u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9052), GPR_U32(ctx, 0));
label_2d3678:
    // 0x2d3678: 0x240b000a  addiu       $t3, $zero, 0xA
    ctx->pc = 0x2d3678u;
    SET_GPR_S32(ctx, 11, (int32_t)ADD32(GPR_U32(ctx, 0), 10));
label_2d367c:
    // 0x2d367c: 0xaf802358  sw          $zero, 0x2358($gp)
    ctx->pc = 0x2d367cu;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9048), GPR_U32(ctx, 0));
label_2d3680:
    // 0x2d3680: 0xaf822360  sw          $v0, 0x2360($gp)
    ctx->pc = 0x2d3680u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9056), GPR_U32(ctx, 2));
label_2d3684:
    // 0x2d3684: 0x24020002  addiu       $v0, $zero, 0x2
    ctx->pc = 0x2d3684u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
label_2d3688:
    // 0x2d3688: 0xa3832378  sb          $v1, 0x2378($gp)
    ctx->pc = 0x2d3688u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9080), (uint8_t)GPR_U32(ctx, 3));
label_2d368c:
    // 0x2d368c: 0xa3822370  sb          $v0, 0x2370($gp)
    ctx->pc = 0x2d368cu;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9072), (uint8_t)GPR_U32(ctx, 2));
label_2d3690:
    // 0x2d3690: 0xa3842380  sb          $a0, 0x2380($gp)
    ctx->pc = 0x2d3690u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9088), (uint8_t)GPR_U32(ctx, 4));
label_2d3694:
    // 0x2d3694: 0xa3852388  sb          $a1, 0x2388($gp)
    ctx->pc = 0x2d3694u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9096), (uint8_t)GPR_U32(ctx, 5));
label_2d3698:
    // 0x2d3698: 0xa3862390  sb          $a2, 0x2390($gp)
    ctx->pc = 0x2d3698u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9104), (uint8_t)GPR_U32(ctx, 6));
label_2d369c:
    // 0x2d369c: 0xa3882398  sb          $t0, 0x2398($gp)
    ctx->pc = 0x2d369cu;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9112), (uint8_t)GPR_U32(ctx, 8));
label_2d36a0:
    // 0x2d36a0: 0xa38923a0  sb          $t1, 0x23A0($gp)
    ctx->pc = 0x2d36a0u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9120), (uint8_t)GPR_U32(ctx, 9));
label_2d36a4:
    // 0x2d36a4: 0x30a800ff  andi        $t0, $a1, 0xFF
    ctx->pc = 0x2d36a4u;
    SET_GPR_U64(ctx, 8, GPR_U64(ctx, 5) & (uint64_t)(uint16_t)255);
label_2d36a8:
    // 0x2d36a8: 0xa38a23a8  sb          $t2, 0x23A8($gp)
    ctx->pc = 0x2d36a8u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9128), (uint8_t)GPR_U32(ctx, 10));
label_2d36ac:
    // 0x2d36ac: 0x30c700ff  andi        $a3, $a2, 0xFF
    ctx->pc = 0x2d36acu;
    SET_GPR_U64(ctx, 7, GPR_U64(ctx, 6) & (uint64_t)(uint16_t)255);
label_2d36b0:
    // 0x2d36b0: 0xa38b23b0  sb          $t3, 0x23B0($gp)
    ctx->pc = 0x2d36b0u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9136), (uint8_t)GPR_U32(ctx, 11));
label_2d36b4:
    // 0x2d36b4: 0x308a00ff  andi        $t2, $a0, 0xFF
    ctx->pc = 0x2d36b4u;
    SET_GPR_U64(ctx, 10, GPR_U64(ctx, 4) & (uint64_t)(uint16_t)255);
label_2d36b8:
    // 0x2d36b8: 0xa38c23b8  sb          $t4, 0x23B8($gp)
    ctx->pc = 0x2d36b8u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9144), (uint8_t)GPR_U32(ctx, 12));
label_2d36bc:
    // 0x2d36bc: 0x304b00ff  andi        $t3, $v0, 0xFF
    ctx->pc = 0x2d36bcu;
    SET_GPR_U64(ctx, 11, GPR_U64(ctx, 2) & (uint64_t)(uint16_t)255);
label_2d36c0:
    // 0x2d36c0: 0x306c00ff  andi        $t4, $v1, 0xFF
    ctx->pc = 0x2d36c0u;
    SET_GPR_U64(ctx, 12, GPR_U64(ctx, 3) & (uint64_t)(uint16_t)255);
label_2d36c4:
    // 0x2d36c4: 0xa3962368  sb          $s6, 0x2368($gp)
    ctx->pc = 0x2d36c4u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9064), (uint8_t)GPR_U32(ctx, 22));
label_2d36c8:
    // 0x2d36c8: 0x93862398  lbu         $a2, 0x2398($gp)
    ctx->pc = 0x2d36c8u;
    SET_GPR_U32(ctx, 6, (uint8_t)READ8(ADD32(GPR_U32(ctx, 28), 9112)));
label_2d36cc:
    // 0x2d36cc: 0x356b0200  ori         $t3, $t3, 0x200
    ctx->pc = 0x2d36ccu;
    SET_GPR_U64(ctx, 11, GPR_U64(ctx, 11) | (uint64_t)(uint16_t)512);
label_2d36d0:
    // 0x2d36d0: 0x938523a0  lbu         $a1, 0x23A0($gp)
    ctx->pc = 0x2d36d0u;
    SET_GPR_U32(ctx, 5, (uint8_t)READ8(ADD32(GPR_U32(ctx, 28), 9120)));
label_2d36d4:
    // 0x2d36d4: 0x32c900ff  andi        $t1, $s6, 0xFF
    ctx->pc = 0x2d36d4u;
    SET_GPR_U64(ctx, 9, GPR_U64(ctx, 22) & (uint64_t)(uint16_t)255);
label_2d36d8:
    // 0x2d36d8: 0x938423a8  lbu         $a0, 0x23A8($gp)
    ctx->pc = 0x2d36d8u;
    SET_GPR_U32(ctx, 4, (uint8_t)READ8(ADD32(GPR_U32(ctx, 28), 9128)));
label_2d36dc:
    // 0x2d36dc: 0x35290100  ori         $t1, $t1, 0x100
    ctx->pc = 0x2d36dcu;
    SET_GPR_U64(ctx, 9, GPR_U64(ctx, 9) | (uint64_t)(uint16_t)256);
label_2d36e0:
    // 0x2d36e0: 0x938323b0  lbu         $v1, 0x23B0($gp)
    ctx->pc = 0x2d36e0u;
    SET_GPR_U32(ctx, 3, (uint8_t)READ8(ADD32(GPR_U32(ctx, 28), 9136)));
label_2d36e4:
    // 0x2d36e4: 0x358c0300  ori         $t4, $t4, 0x300
    ctx->pc = 0x2d36e4u;
    SET_GPR_U64(ctx, 12, GPR_U64(ctx, 12) | (uint64_t)(uint16_t)768);
label_2d36e8:
    // 0x2d36e8: 0x938223b8  lbu         $v0, 0x23B8($gp)
    ctx->pc = 0x2d36e8u;
    SET_GPR_U32(ctx, 2, (uint8_t)READ8(ADD32(GPR_U32(ctx, 28), 9144)));
label_2d36ec:
    // 0x2d36ec: 0x354a0400  ori         $t2, $t2, 0x400
    ctx->pc = 0x2d36ecu;
    SET_GPR_U64(ctx, 10, GPR_U64(ctx, 10) | (uint64_t)(uint16_t)1024);
label_2d36f0:
    // 0x2d36f0: 0x34630a00  ori         $v1, $v1, 0xA00
    ctx->pc = 0x2d36f0u;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 3) | (uint64_t)(uint16_t)2560);
label_2d36f4:
    // 0x2d36f4: 0x35080500  ori         $t0, $t0, 0x500
    ctx->pc = 0x2d36f4u;
    SET_GPR_U64(ctx, 8, GPR_U64(ctx, 8) | (uint64_t)(uint16_t)1280);
label_2d36f8:
    // 0x2d36f8: 0x34420b00  ori         $v0, $v0, 0xB00
    ctx->pc = 0x2d36f8u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) | (uint64_t)(uint16_t)2816);
label_2d36fc:
    // 0x2d36fc: 0x34e70600  ori         $a3, $a3, 0x600
    ctx->pc = 0x2d36fcu;
    SET_GPR_U64(ctx, 7, GPR_U64(ctx, 7) | (uint64_t)(uint16_t)1536);
label_2d3700:
    // 0x2d3700: 0x34c60700  ori         $a2, $a2, 0x700
    ctx->pc = 0x2d3700u;
    SET_GPR_U64(ctx, 6, GPR_U64(ctx, 6) | (uint64_t)(uint16_t)1792);
label_2d3704:
    // 0x2d3704: 0x34a50800  ori         $a1, $a1, 0x800
    ctx->pc = 0x2d3704u;
    SET_GPR_U64(ctx, 5, GPR_U64(ctx, 5) | (uint64_t)(uint16_t)2048);
label_2d3708:
    // 0x2d3708: 0x34840900  ori         $a0, $a0, 0x900
    ctx->pc = 0x2d3708u;
    SET_GPR_U64(ctx, 4, GPR_U64(ctx, 4) | (uint64_t)(uint16_t)2304);
label_2d370c:
    // 0x2d370c: 0xaf8323b0  sw          $v1, 0x23B0($gp)
    ctx->pc = 0x2d370cu;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9136), GPR_U32(ctx, 3));
label_2d3710:
    // 0x2d3710: 0xaf8223b8  sw          $v0, 0x23B8($gp)
    ctx->pc = 0x2d3710u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9144), GPR_U32(ctx, 2));
label_2d3714:
    // 0x2d3714: 0xaf892368  sw          $t1, 0x2368($gp)
    ctx->pc = 0x2d3714u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9064), GPR_U32(ctx, 9));
label_2d3718:
    // 0x2d3718: 0xaf8b2370  sw          $t3, 0x2370($gp)
    ctx->pc = 0x2d3718u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9072), GPR_U32(ctx, 11));
label_2d371c:
    // 0x2d371c: 0xaf8c2378  sw          $t4, 0x2378($gp)
    ctx->pc = 0x2d371cu;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9080), GPR_U32(ctx, 12));
label_2d3720:
    // 0x2d3720: 0xaf8a2380  sw          $t2, 0x2380($gp)
    ctx->pc = 0x2d3720u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9088), GPR_U32(ctx, 10));
label_2d3724:
    // 0x2d3724: 0xaf882388  sw          $t0, 0x2388($gp)
    ctx->pc = 0x2d3724u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9096), GPR_U32(ctx, 8));
label_2d3728:
    // 0x2d3728: 0xaf872390  sw          $a3, 0x2390($gp)
    ctx->pc = 0x2d3728u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9104), GPR_U32(ctx, 7));
label_2d372c:
    // 0x2d372c: 0xaf862398  sw          $a2, 0x2398($gp)
    ctx->pc = 0x2d372cu;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9112), GPR_U32(ctx, 6));
label_2d3730:
    // 0x2d3730: 0xaf8523a0  sw          $a1, 0x23A0($gp)
    ctx->pc = 0x2d3730u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9120), GPR_U32(ctx, 5));
label_2d3734:
    // 0x2d3734: 0xaf8423a8  sw          $a0, 0x23A8($gp)
    ctx->pc = 0x2d3734u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9128), GPR_U32(ctx, 4));
label_2d3738:
    // 0x2d3738: 0xa38e23c0  sb          $t6, 0x23C0($gp)
    ctx->pc = 0x2d3738u;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9152), (uint8_t)GPR_U32(ctx, 14));
label_2d373c:
    // 0x2d373c: 0xa38f23c8  sb          $t7, 0x23C8($gp)
    ctx->pc = 0x2d373cu;
    WRITE8(ADD32(GPR_U32(ctx, 28), 9160), (uint8_t)GPR_U32(ctx, 15));
label_2d3740:
    // 0x2d3740: 0x31c200ff  andi        $v0, $t6, 0xFF
    ctx->pc = 0x2d3740u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 14) & (uint64_t)(uint16_t)255);
label_2d3744:
    // 0x2d3744: 0x34420c00  ori         $v0, $v0, 0xC00
    ctx->pc = 0x2d3744u;
    SET_GPR_U64(ctx, 2, GPR_U64(ctx, 2) | (uint64_t)(uint16_t)3072);
label_2d3748:
    // 0x2d3748: 0x31e300ff  andi        $v1, $t7, 0xFF
    ctx->pc = 0x2d3748u;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 15) & (uint64_t)(uint16_t)255);
label_2d374c:
    // 0x2d374c: 0xaf8223c0  sw          $v0, 0x23C0($gp)
    ctx->pc = 0x2d374cu;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9152), GPR_U32(ctx, 2));
label_2d3750:
    // 0x2d3750: 0x34630d00  ori         $v1, $v1, 0xD00
    ctx->pc = 0x2d3750u;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 3) | (uint64_t)(uint16_t)3328);
label_2d3754:
    // 0x2d3754: 0xaf8323c8  sw          $v1, 0x23C8($gp)
    ctx->pc = 0x2d3754u;
    WRITE32(ADD32(GPR_U32(ctx, 28), 9160), GPR_U32(ctx, 3));
label_2d3758:
    // 0x2d3758: 0x7bb00080  lq          $s0, 0x80($sp)
    ctx->pc = 0x2d3758u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 128)));
label_2d375c:
    // 0x2d375c: 0x7bb10070  lq          $s1, 0x70($sp)
    ctx->pc = 0x2d375cu;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 112)));
label_2d3760:
    // 0x2d3760: 0x7bb20060  lq          $s2, 0x60($sp)
    ctx->pc = 0x2d3760u;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 96)));
label_2d3764:
    // 0x2d3764: 0x7bb30050  lq          $s3, 0x50($sp)
    ctx->pc = 0x2d3764u;
    SET_GPR_VEC(ctx, 19, READ128(ADD32(GPR_U32(ctx, 29), 80)));
label_2d3768:
    // 0x2d3768: 0x7bb40040  lq          $s4, 0x40($sp)
    ctx->pc = 0x2d3768u;
    SET_GPR_VEC(ctx, 20, READ128(ADD32(GPR_U32(ctx, 29), 64)));
label_2d376c:
    // 0x2d376c: 0x7bb50030  lq          $s5, 0x30($sp)
    ctx->pc = 0x2d376cu;
    SET_GPR_VEC(ctx, 21, READ128(ADD32(GPR_U32(ctx, 29), 48)));
label_2d3770:
    // 0x2d3770: 0x7bb60020  lq          $s6, 0x20($sp)
    ctx->pc = 0x2d3770u;
    SET_GPR_VEC(ctx, 22, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_2d3774:
    // 0x2d3774: 0x7bb70010  lq          $s7, 0x10($sp)
    ctx->pc = 0x2d3774u;
    SET_GPR_VEC(ctx, 23, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_2d3778:
    // 0x2d3778: 0x7bbe0000  lq          $fp, 0x0($sp)
    ctx->pc = 0x2d3778u;
    SET_GPR_VEC(ctx, 30, READ128(ADD32(GPR_U32(ctx, 29), 0)));
label_2d377c:
    // 0x2d377c: 0x3e00008  jr          $ra
label_2d3780:
    if (ctx->pc == 0x2D3780u) {
        ctx->pc = 0x2D3780u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D377Cu;
        // 0x2d3780: 0x27bd0090  addiu       $sp, $sp, 0x90 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 144));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3784u;
        goto label_2d3784;
    }
    ctx->pc = 0x2D377Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3780u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D377Cu;
        // 0x2d3780: 0x27bd0090  addiu       $sp, $sp, 0x90 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 144));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D377Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3784u;
label_2d3784:
    // 0x2d3784: 0x0  nop
    ctx->pc = 0x2d3784u;
    // NOP
label_2d3788:
    // 0x2d3788: 0x3c020048  lui         $v0, 0x48
    ctx->pc = 0x2d3788u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)72 << 16));
label_2d378c:
    // 0x2d378c: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d378cu;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3790:
    // 0x2d3790: 0x244271e8  addiu       $v0, $v0, 0x71E8
    ctx->pc = 0x2d3790u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 29160));
label_2d3794:
    // 0x2d3794: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3794u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3798:
    // 0x2d3798: 0x30a50001  andi        $a1, $a1, 0x1
    ctx->pc = 0x2d3798u;
    SET_GPR_U64(ctx, 5, GPR_U64(ctx, 5) & (uint64_t)(uint16_t)1);
label_2d379c:
    // 0x2d379c: 0x10a00003  beqz        $a1, . + 4 + (0x3 << 2)
label_2d37a0:
    if (ctx->pc == 0x2D37A0u) {
        ctx->pc = 0x2D37A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D379Cu;
        // 0x2d37a0: 0xac820000  sw          $v0, 0x0($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 0), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D37A4u;
        goto label_2d37a4;
    }
    ctx->pc = 0x2D379Cu;
    {
        const bool branch_taken_0x2d379c = (GPR_U64(ctx, 5) == GPR_U64(ctx, 0));
        ctx->pc = 0x2D37A0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D379Cu;
        // 0x2d37a0: 0xac820000  sw          $v0, 0x0($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 0), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2d379c) {
            ctx->pc = 0x2D37ACu;
            goto label_2d37ac;
        }
    }
    ctx->pc = 0x2D37A4u;
label_2d37a4:
    // 0x2d37a4: 0xc0c5f94  jal         func_317E50
label_2d37a8:
    if (ctx->pc == 0x2D37A8u) {
        ctx->pc = 0x2D37ACu;
        goto label_2d37ac;
    }
    ctx->pc = 0x2D37A4u;
    SET_GPR_U32(ctx, 31, 0x2D37ACu);
    ctx->pc = 0x317E50u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x317E50u, 0x2D37A4u, 0x2D37ACu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D37ACu;
label_2d37ac:
    // 0x2d37ac: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d37acu;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d37b0:
    // 0x2d37b0: 0x3e00008  jr          $ra
label_2d37b4:
    if (ctx->pc == 0x2D37B4u) {
        ctx->pc = 0x2D37B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37B0u;
        // 0x2d37b4: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D37B8u;
        goto label_2d37b8;
    }
    ctx->pc = 0x2D37B0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D37B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37B0u;
        // 0x2d37b4: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D37B0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D37B8u;
label_2d37b8:
    // 0x2d37b8: 0x3e00008  jr          $ra
label_2d37bc:
    if (ctx->pc == 0x2D37BCu) {
        ctx->pc = 0x2D37BCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37B8u;
        // 0x2d37bc: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D37C0u;
        goto label_2d37c0;
    }
    ctx->pc = 0x2D37B8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D37BCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37B8u;
        // 0x2d37bc: 0x24020001  addiu       $v0, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D37B8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D37C0u;
label_2d37c0:
    // 0x2d37c0: 0x3e00008  jr          $ra
label_2d37c4:
    if (ctx->pc == 0x2D37C4u) {
        ctx->pc = 0x2D37C8u;
        goto label_2d37c8;
    }
    ctx->pc = 0x2D37C0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D37C0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D37C8u;
label_2d37c8:
    // 0x2d37c8: 0x3e00008  jr          $ra
label_2d37cc:
    if (ctx->pc == 0x2D37CCu) {
        ctx->pc = 0x2D37D0u;
        goto label_2d37d0;
    }
    ctx->pc = 0x2D37C8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D37C8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D37D0u;
label_2d37d0:
    // 0x2d37d0: 0x3e00008  jr          $ra
label_2d37d4:
    if (ctx->pc == 0x2D37D4u) {
        ctx->pc = 0x2D37D4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37D0u;
        // 0x2d37d4: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D37D8u;
        goto label_2d37d8;
    }
    ctx->pc = 0x2D37D0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D37D4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37D0u;
        // 0x2d37d4: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D37D0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D37D8u;
label_2d37d8:
    // 0x2d37d8: 0x3e00008  jr          $ra
label_2d37dc:
    if (ctx->pc == 0x2D37DCu) {
        ctx->pc = 0x2D37DCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37D8u;
        // 0x2d37dc: 0x8c82000c  lw          $v0, 0xC($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D37E0u;
        goto label_2d37e0;
    }
    ctx->pc = 0x2D37D8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D37DCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37D8u;
        // 0x2d37dc: 0x8c82000c  lw          $v0, 0xC($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D37D8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D37E0u;
label_2d37e0:
    // 0x2d37e0: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d37e0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d37e4:
    // 0x2d37e4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d37e4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d37e8:
    // 0x2d37e8: 0x8c830000  lw          $v1, 0x0($a0)
    ctx->pc = 0x2d37e8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_2d37ec:
    // 0x2d37ec: 0x8c85000c  lw          $a1, 0xC($a0)
    ctx->pc = 0x2d37ecu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
label_2d37f0:
    // 0x2d37f0: 0x84660180  lh          $a2, 0x180($v1)
    ctx->pc = 0x2d37f0u;
    SET_GPR_S32(ctx, 6, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 384)));
label_2d37f4:
    // 0x2d37f4: 0x8c620184  lw          $v0, 0x184($v1)
    ctx->pc = 0x2d37f4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 388)));
label_2d37f8:
    // 0x2d37f8: 0x40f809  jalr        $v0
label_2d37fc:
    if (ctx->pc == 0x2D37FCu) {
        ctx->pc = 0x2D37FCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37F8u;
        // 0x2d37fc: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3800u;
        goto label_2d3800;
    }
    ctx->pc = 0x2D37F8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2D3800u);
        ctx->pc = 0x2D37FCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D37F8u;
        // 0x2d37fc: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D37F8u, 0x2D3800u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2D3800u;
label_2d3800:
    // 0x2d3800: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3800u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3804:
    // 0x2d3804: 0x3e00008  jr          $ra
label_2d3808:
    if (ctx->pc == 0x2D3808u) {
        ctx->pc = 0x2D3808u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3804u;
        // 0x2d3808: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D380Cu;
        goto label_2d380c;
    }
    ctx->pc = 0x2D3804u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3808u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3804u;
        // 0x2d3808: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3804u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D380Cu;
label_2d380c:
    // 0x2d380c: 0x0  nop
    ctx->pc = 0x2d380cu;
    // NOP
label_2d3810:
    // 0x2d3810: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3810u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3814:
    // 0x2d3814: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3814u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3818:
    // 0x2d3818: 0x8c830000  lw          $v1, 0x0($a0)
    ctx->pc = 0x2d3818u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_2d381c:
    // 0x2d381c: 0x8c85000c  lw          $a1, 0xC($a0)
    ctx->pc = 0x2d381cu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
label_2d3820:
    // 0x2d3820: 0x846601a0  lh          $a2, 0x1A0($v1)
    ctx->pc = 0x2d3820u;
    SET_GPR_S32(ctx, 6, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 416)));
label_2d3824:
    // 0x2d3824: 0x8c6201a4  lw          $v0, 0x1A4($v1)
    ctx->pc = 0x2d3824u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 420)));
label_2d3828:
    // 0x2d3828: 0x40f809  jalr        $v0
label_2d382c:
    if (ctx->pc == 0x2D382Cu) {
        ctx->pc = 0x2D382Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3828u;
        // 0x2d382c: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3830u;
        goto label_2d3830;
    }
    ctx->pc = 0x2D3828u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2D3830u);
        ctx->pc = 0x2D382Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3828u;
        // 0x2d382c: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3828u, 0x2D3830u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2D3830u;
label_2d3830:
    // 0x2d3830: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3830u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3834:
    // 0x2d3834: 0x3e00008  jr          $ra
label_2d3838:
    if (ctx->pc == 0x2D3838u) {
        ctx->pc = 0x2D3838u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3834u;
        // 0x2d3838: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D383Cu;
        goto label_2d383c;
    }
    ctx->pc = 0x2D3834u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3838u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3834u;
        // 0x2d3838: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3834u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D383Cu;
label_2d383c:
    // 0x2d383c: 0x0  nop
    ctx->pc = 0x2d383cu;
    // NOP
label_2d3840:
    // 0x2d3840: 0x27bdffc0  addiu       $sp, $sp, -0x40
    ctx->pc = 0x2d3840u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967232));
label_2d3844:
    // 0x2d3844: 0x7fb00030  sq          $s0, 0x30($sp)
    ctx->pc = 0x2d3844u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 48), GPR_VEC(ctx, 16));
label_2d3848:
    // 0x2d3848: 0x7fb10020  sq          $s1, 0x20($sp)
    ctx->pc = 0x2d3848u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 17));
label_2d384c:
    // 0x2d384c: 0x80802d  daddu       $s0, $a0, $zero
    ctx->pc = 0x2d384cu;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2d3850:
    // 0x2d3850: 0x7fb20010  sq          $s2, 0x10($sp)
    ctx->pc = 0x2d3850u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 18));
label_2d3854:
    // 0x2d3854: 0xa0882d  daddu       $s1, $a1, $zero
    ctx->pc = 0x2d3854u;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_2d3858:
    // 0x2d3858: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3858u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d385c:
    // 0x2d385c: 0x902d  daddu       $s2, $zero, $zero
    ctx->pc = 0x2d385cu;
    SET_GPR_U64(ctx, 18, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_2d3860:
    // 0x2d3860: 0x8e030000  lw          $v1, 0x0($s0)
    ctx->pc = 0x2d3860u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 0)));
label_2d3864:
    // 0x2d3864: 0x84640180  lh          $a0, 0x180($v1)
    ctx->pc = 0x2d3864u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 384)));
label_2d3868:
    // 0x2d3868: 0x8c620184  lw          $v0, 0x184($v1)
    ctx->pc = 0x2d3868u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 388)));
label_2d386c:
    // 0x2d386c: 0x40f809  jalr        $v0
label_2d3870:
    if (ctx->pc == 0x2D3870u) {
        ctx->pc = 0x2D3870u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D386Cu;
        // 0x2d3870: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3874u;
        goto label_2d3874;
    }
    ctx->pc = 0x2D386Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2D3874u);
        ctx->pc = 0x2D3870u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D386Cu;
        // 0x2d3870: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D386Cu, 0x2D3874u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2D3874u;
label_2d3874:
    // 0x2d3874: 0x14400018  bnez        $v0, . + 4 + (0x18 << 2)
label_2d3878:
    if (ctx->pc == 0x2D3878u) {
        ctx->pc = 0x2D3878u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3874u;
        // 0x2d3878: 0x240102d  daddu       $v0, $s2, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D387Cu;
        goto label_2d387c;
    }
    ctx->pc = 0x2D3874u;
    {
        const bool branch_taken_0x2d3874 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x2D3878u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3874u;
        // 0x2d3878: 0x240102d  daddu       $v0, $s2, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2d3874) {
            ctx->pc = 0x2D38D8u;
            goto label_2d38d8;
        }
    }
    ctx->pc = 0x2D387Cu;
label_2d387c:
    // 0x2d387c: 0x8e030000  lw          $v1, 0x0($s0)
    ctx->pc = 0x2d387cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 0)));
label_2d3880:
    // 0x2d3880: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x2d3880u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_2d3884:
    // 0x2d3884: 0x84640190  lh          $a0, 0x190($v1)
    ctx->pc = 0x2d3884u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 400)));
label_2d3888:
    // 0x2d3888: 0x8c620194  lw          $v0, 0x194($v1)
    ctx->pc = 0x2d3888u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 404)));
label_2d388c:
    // 0x2d388c: 0x40f809  jalr        $v0
label_2d3890:
    if (ctx->pc == 0x2D3890u) {
        ctx->pc = 0x2D3890u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D388Cu;
        // 0x2d3890: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3894u;
        goto label_2d3894;
    }
    ctx->pc = 0x2D388Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2D3894u);
        ctx->pc = 0x2D3890u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D388Cu;
        // 0x2d3890: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D388Cu, 0x2D3894u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2D3894u;
label_2d3894:
    // 0x2d3894: 0x14400010  bnez        $v0, . + 4 + (0x10 << 2)
label_2d3898:
    if (ctx->pc == 0x2D3898u) {
        ctx->pc = 0x2D3898u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3894u;
        // 0x2d3898: 0x240102d  daddu       $v0, $s2, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D389Cu;
        goto label_2d389c;
    }
    ctx->pc = 0x2D3894u;
    {
        const bool branch_taken_0x2d3894 = (GPR_U64(ctx, 2) != GPR_U64(ctx, 0));
        ctx->pc = 0x2D3898u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3894u;
        // 0x2d3898: 0x240102d  daddu       $v0, $s2, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2d3894) {
            ctx->pc = 0x2D38D8u;
            goto label_2d38d8;
        }
    }
    ctx->pc = 0x2D389Cu;
label_2d389c:
    // 0x2d389c: 0x8e030000  lw          $v1, 0x0($s0)
    ctx->pc = 0x2d389cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 0)));
label_2d38a0:
    // 0x2d38a0: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x2d38a0u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_2d38a4:
    // 0x2d38a4: 0x846401c0  lh          $a0, 0x1C0($v1)
    ctx->pc = 0x2d38a4u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 448)));
label_2d38a8:
    // 0x2d38a8: 0x8c6201c4  lw          $v0, 0x1C4($v1)
    ctx->pc = 0x2d38a8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 452)));
label_2d38ac:
    // 0x2d38ac: 0x40f809  jalr        $v0
label_2d38b0:
    if (ctx->pc == 0x2D38B0u) {
        ctx->pc = 0x2D38B0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D38ACu;
        // 0x2d38b0: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D38B4u;
        goto label_2d38b4;
    }
    ctx->pc = 0x2D38ACu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2D38B4u);
        ctx->pc = 0x2D38B0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D38ACu;
        // 0x2d38b0: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D38ACu, 0x2D38B4u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2D38B4u;
label_2d38b4:
    // 0x2d38b4: 0x10400007  beqz        $v0, . + 4 + (0x7 << 2)
label_2d38b8:
    if (ctx->pc == 0x2D38B8u) {
        ctx->pc = 0x2D38B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D38B4u;
        // 0x2d38b8: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D38BCu;
        goto label_2d38bc;
    }
    ctx->pc = 0x2D38B4u;
    {
        const bool branch_taken_0x2d38b4 = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        ctx->pc = 0x2D38B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D38B4u;
        // 0x2d38b8: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2d38b4) {
            ctx->pc = 0x2D38D4u;
            goto label_2d38d4;
        }
    }
    ctx->pc = 0x2D38BCu;
label_2d38bc:
    // 0x2d38bc: 0x8e030000  lw          $v1, 0x0($s0)
    ctx->pc = 0x2d38bcu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 0)));
label_2d38c0:
    // 0x2d38c0: 0x846401a0  lh          $a0, 0x1A0($v1)
    ctx->pc = 0x2d38c0u;
    SET_GPR_S32(ctx, 4, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 416)));
label_2d38c4:
    // 0x2d38c4: 0x8c6201a4  lw          $v0, 0x1A4($v1)
    ctx->pc = 0x2d38c4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 420)));
label_2d38c8:
    // 0x2d38c8: 0x40f809  jalr        $v0
label_2d38cc:
    if (ctx->pc == 0x2D38CCu) {
        ctx->pc = 0x2D38CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D38C8u;
        // 0x2d38cc: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D38D0u;
        goto label_2d38d0;
    }
    ctx->pc = 0x2D38C8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2D38D0u);
        ctx->pc = 0x2D38CCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D38C8u;
        // 0x2d38cc: 0x2042021  addu        $a0, $s0, $a0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), GPR_U32(ctx, 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D38C8u, 0x2D38D0u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2D38D0u;
label_2d38d0:
    // 0x2d38d0: 0x2902b  sltu        $s2, $zero, $v0
    ctx->pc = 0x2d38d0u;
    SET_GPR_U64(ctx, 18, ((uint64_t)GPR_U64(ctx, 0) < (uint64_t)GPR_U64(ctx, 2)) ? 1 : 0);
label_2d38d4:
    // 0x2d38d4: 0x240102d  daddu       $v0, $s2, $zero
    ctx->pc = 0x2d38d4u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_2d38d8:
    // 0x2d38d8: 0x7bb00030  lq          $s0, 0x30($sp)
    ctx->pc = 0x2d38d8u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 48)));
label_2d38dc:
    // 0x2d38dc: 0x7bb10020  lq          $s1, 0x20($sp)
    ctx->pc = 0x2d38dcu;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_2d38e0:
    // 0x2d38e0: 0x7bb20010  lq          $s2, 0x10($sp)
    ctx->pc = 0x2d38e0u;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_2d38e4:
    // 0x2d38e4: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d38e4u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d38e8:
    // 0x2d38e8: 0x3e00008  jr          $ra
label_2d38ec:
    if (ctx->pc == 0x2D38ECu) {
        ctx->pc = 0x2D38ECu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D38E8u;
        // 0x2d38ec: 0x27bd0040  addiu       $sp, $sp, 0x40 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 64));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D38F0u;
        goto label_2d38f0;
    }
    ctx->pc = 0x2D38E8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D38ECu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D38E8u;
        // 0x2d38ec: 0x27bd0040  addiu       $sp, $sp, 0x40 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 64));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D38E8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D38F0u;
label_2d38f0:
    // 0x2d38f0: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d38f0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d38f4:
    // 0x2d38f4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d38f4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d38f8:
    // 0x2d38f8: 0x8c830000  lw          $v1, 0x0($a0)
    ctx->pc = 0x2d38f8u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_2d38fc:
    // 0x2d38fc: 0x8c85000c  lw          $a1, 0xC($a0)
    ctx->pc = 0x2d38fcu;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
label_2d3900:
    // 0x2d3900: 0x846601c0  lh          $a2, 0x1C0($v1)
    ctx->pc = 0x2d3900u;
    SET_GPR_S32(ctx, 6, (int16_t)READ16(ADD32(GPR_U32(ctx, 3), 448)));
label_2d3904:
    // 0x2d3904: 0x8c6201c4  lw          $v0, 0x1C4($v1)
    ctx->pc = 0x2d3904u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 452)));
label_2d3908:
    // 0x2d3908: 0x40f809  jalr        $v0
label_2d390c:
    if (ctx->pc == 0x2D390Cu) {
        ctx->pc = 0x2D390Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3908u;
        // 0x2d390c: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3910u;
        goto label_2d3910;
    }
    ctx->pc = 0x2D3908u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2D3910u);
        ctx->pc = 0x2D390Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3908u;
        // 0x2d390c: 0x862021  addu        $a0, $a0, $a2 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 6)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3908u, 0x2D3910u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2D3910u;
label_2d3910:
    // 0x2d3910: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3910u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3914:
    // 0x2d3914: 0x3e00008  jr          $ra
label_2d3918:
    if (ctx->pc == 0x2D3918u) {
        ctx->pc = 0x2D3918u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3914u;
        // 0x2d3918: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D391Cu;
        goto label_2d391c;
    }
    ctx->pc = 0x2D3914u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3918u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3914u;
        // 0x2d3918: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3914u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D391Cu;
label_2d391c:
    // 0x2d391c: 0x0  nop
    ctx->pc = 0x2d391cu;
    // NOP
label_2d3920:
    // 0x2d3920: 0x3e00008  jr          $ra
label_2d3924:
    if (ctx->pc == 0x2D3924u) {
        ctx->pc = 0x2D3924u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3920u;
        // 0x2d3924: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3928u;
        goto label_2d3928;
    }
    ctx->pc = 0x2D3920u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3924u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3920u;
        // 0x2d3924: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3920u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3928u;
label_2d3928:
    // 0x2d3928: 0x3e00008  jr          $ra
label_2d392c:
    if (ctx->pc == 0x2D392Cu) {
        ctx->pc = 0x2D392Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3928u;
        // 0x2d392c: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3930u;
        goto label_2d3930;
    }
    ctx->pc = 0x2D3928u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D392Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3928u;
        // 0x2d392c: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3928u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3930u;
label_2d3930:
    // 0x2d3930: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3930u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3934:
    // 0x2d3934: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3934u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3938:
    // 0x2d3938: 0xc0b14f2  jal         func_2C53C8
label_2d393c:
    if (ctx->pc == 0x2D393Cu) {
        ctx->pc = 0x2D393Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3938u;
        // 0x2d393c: 0x8c85000c  lw          $a1, 0xC($a0) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3940u;
        goto label_2d3940;
    }
    ctx->pc = 0x2D3938u;
    SET_GPR_U32(ctx, 31, 0x2D3940u);
    ctx->pc = 0x2D393Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3938u;
    // 0x2d393c: 0x8c85000c  lw          $a1, 0xC($a0) (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C53C8u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C53C8u, 0x2D3938u, 0x2D3940u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3940u;
label_2d3940:
    // 0x2d3940: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3940u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3944:
    // 0x2d3944: 0x3e00008  jr          $ra
label_2d3948:
    if (ctx->pc == 0x2D3948u) {
        ctx->pc = 0x2D3948u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3944u;
        // 0x2d3948: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D394Cu;
        goto label_2d394c;
    }
    ctx->pc = 0x2D3944u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3948u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3944u;
        // 0x2d3948: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3944u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D394Cu;
label_2d394c:
    // 0x2d394c: 0x0  nop
    ctx->pc = 0x2d394cu;
    // NOP
label_2d3950:
    // 0x2d3950: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3950u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3954:
    // 0x2d3954: 0xa0302d  daddu       $a2, $a1, $zero
    ctx->pc = 0x2d3954u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_2d3958:
    // 0x2d3958: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3958u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d395c:
    // 0x2d395c: 0xc0b14f8  jal         func_2C53E0
label_2d3960:
    if (ctx->pc == 0x2D3960u) {
        ctx->pc = 0x2D3960u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D395Cu;
        // 0x2d3960: 0x8c85000c  lw          $a1, 0xC($a0) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3964u;
        goto label_2d3964;
    }
    ctx->pc = 0x2D395Cu;
    SET_GPR_U32(ctx, 31, 0x2D3964u);
    ctx->pc = 0x2D3960u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D395Cu;
    // 0x2d3960: 0x8c85000c  lw          $a1, 0xC($a0) (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C53E0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C53E0u, 0x2D395Cu, 0x2D3964u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3964u;
label_2d3964:
    // 0x2d3964: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3964u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3968:
    // 0x2d3968: 0x3e00008  jr          $ra
label_2d396c:
    if (ctx->pc == 0x2D396Cu) {
        ctx->pc = 0x2D396Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3968u;
        // 0x2d396c: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3970u;
        goto label_2d3970;
    }
    ctx->pc = 0x2D3968u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D396Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3968u;
        // 0x2d396c: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3968u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3970u;
label_2d3970:
    // 0x2d3970: 0x3e00008  jr          $ra
label_2d3974:
    if (ctx->pc == 0x2D3974u) {
        ctx->pc = 0x2D3974u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3970u;
        // 0x2d3974: 0x8c820014  lw          $v0, 0x14($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 20)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3978u;
        goto label_2d3978;
    }
    ctx->pc = 0x2D3970u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3974u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3970u;
        // 0x2d3974: 0x8c820014  lw          $v0, 0x14($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 20)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3970u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3978u;
label_2d3978:
    // 0x2d3978: 0x3e00008  jr          $ra
label_2d397c:
    if (ctx->pc == 0x2D397Cu) {
        ctx->pc = 0x2D397Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3978u;
        // 0x2d397c: 0x24020002  addiu       $v0, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3980u;
        goto label_2d3980;
    }
    ctx->pc = 0x2D3978u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D397Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3978u;
        // 0x2d397c: 0x24020002  addiu       $v0, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3978u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3980u;
label_2d3980:
    // 0x2d3980: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3980u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3984:
    // 0x2d3984: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3984u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3988:
    // 0x2d3988: 0x8c880000  lw          $t0, 0x0($a0)
    ctx->pc = 0x2d3988u;
    SET_GPR_S32(ctx, 8, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_2d398c:
    // 0x2d398c: 0x85020230  lh          $v0, 0x230($t0)
    ctx->pc = 0x2d398cu;
    SET_GPR_S32(ctx, 2, (int16_t)READ16(ADD32(GPR_U32(ctx, 8), 560)));
label_2d3990:
    // 0x2d3990: 0x8d030234  lw          $v1, 0x234($t0)
    ctx->pc = 0x2d3990u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 8), 564)));
label_2d3994:
    // 0x2d3994: 0x60f809  jalr        $v1
label_2d3998:
    if (ctx->pc == 0x2D3998u) {
        ctx->pc = 0x2D3998u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3994u;
        // 0x2d3998: 0x822021  addu        $a0, $a0, $v0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 2)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D399Cu;
        goto label_2d399c;
    }
    ctx->pc = 0x2D3994u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 3);
        SET_GPR_U32(ctx, 31, 0x2D399Cu);
        ctx->pc = 0x2D3998u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3994u;
        // 0x2d3998: 0x822021  addu        $a0, $a0, $v0 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 2)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3994u, 0x2D399Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2D399Cu;
label_2d399c:
    // 0x2d399c: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d399cu;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d39a0:
    // 0x2d39a0: 0x3e00008  jr          $ra
label_2d39a4:
    if (ctx->pc == 0x2D39A4u) {
        ctx->pc = 0x2D39A4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39A0u;
        // 0x2d39a4: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D39A8u;
        goto label_2d39a8;
    }
    ctx->pc = 0x2D39A0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D39A4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39A0u;
        // 0x2d39a4: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D39A0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D39A8u;
label_2d39a8:
    // 0x2d39a8: 0x3e00008  jr          $ra
label_2d39ac:
    if (ctx->pc == 0x2D39ACu) {
        ctx->pc = 0x2D39ACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39A8u;
        // 0x2d39ac: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D39B0u;
        goto label_2d39b0;
    }
    ctx->pc = 0x2D39A8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D39ACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39A8u;
        // 0x2d39ac: 0x102d  daddu       $v0, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D39A8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D39B0u;
label_2d39b0:
    // 0x2d39b0: 0x3e00008  jr          $ra
label_2d39b4:
    if (ctx->pc == 0x2D39B4u) {
        ctx->pc = 0x2D39B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39B0u;
        // 0x2d39b4: 0x8c82003c  lw          $v0, 0x3C($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 60)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D39B8u;
        goto label_2d39b8;
    }
    ctx->pc = 0x2D39B0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D39B4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39B0u;
        // 0x2d39b4: 0x8c82003c  lw          $v0, 0x3C($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 60)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D39B0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D39B8u;
label_2d39b8:
    // 0x2d39b8: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d39b8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d39bc:
    // 0x2d39bc: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d39bcu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d39c0:
    // 0x2d39c0: 0xc0b1474  jal         func_2C51D0
label_2d39c4:
    if (ctx->pc == 0x2D39C4u) {
        ctx->pc = 0x2D39C4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39C0u;
        // 0x2d39c4: 0x8c85000c  lw          $a1, 0xC($a0) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D39C8u;
        goto label_2d39c8;
    }
    ctx->pc = 0x2D39C0u;
    SET_GPR_U32(ctx, 31, 0x2D39C8u);
    ctx->pc = 0x2D39C4u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D39C0u;
    // 0x2d39c4: 0x8c85000c  lw          $a1, 0xC($a0) (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2C51D0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2C51D0u, 0x2D39C0u, 0x2D39C8u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D39C8u;
label_2d39c8:
    // 0x2d39c8: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d39c8u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d39cc:
    // 0x2d39cc: 0x3e00008  jr          $ra
label_2d39d0:
    if (ctx->pc == 0x2D39D0u) {
        ctx->pc = 0x2D39D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39CCu;
        // 0x2d39d0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D39D4u;
        goto label_2d39d4;
    }
    ctx->pc = 0x2D39CCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D39D0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39CCu;
        // 0x2d39d0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D39CCu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D39D4u;
label_2d39d4:
    // 0x2d39d4: 0x0  nop
    ctx->pc = 0x2d39d4u;
    // NOP
label_2d39d8:
    // 0x2d39d8: 0x3e00008  jr          $ra
label_2d39dc:
    if (ctx->pc == 0x2D39DCu) {
        ctx->pc = 0x2D39DCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39D8u;
        // 0x2d39dc: 0x8c820004  lw          $v0, 0x4($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D39E0u;
        goto label_2d39e0;
    }
    ctx->pc = 0x2D39D8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D39DCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39D8u;
        // 0x2d39dc: 0x8c820004  lw          $v0, 0x4($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 4)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D39D8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D39E0u;
label_2d39e0:
    // 0x2d39e0: 0x3e00008  jr          $ra
label_2d39e4:
    if (ctx->pc == 0x2D39E4u) {
        ctx->pc = 0x2D39E8u;
        goto label_2d39e8;
    }
    ctx->pc = 0x2D39E0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D39E0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D39E8u;
label_2d39e8:
    // 0x2d39e8: 0x3e00008  jr          $ra
label_2d39ec:
    if (ctx->pc == 0x2D39ECu) {
        ctx->pc = 0x2D39ECu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39E8u;
        // 0x2d39ec: 0x8c820054  lw          $v0, 0x54($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 84)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D39F0u;
        goto label_2d39f0;
    }
    ctx->pc = 0x2D39E8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D39ECu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39E8u;
        // 0x2d39ec: 0x8c820054  lw          $v0, 0x54($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 84)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D39E8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D39F0u;
label_2d39f0:
    // 0x2d39f0: 0x3e00008  jr          $ra
label_2d39f4:
    if (ctx->pc == 0x2D39F4u) {
        ctx->pc = 0x2D39F4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39F0u;
        // 0x2d39f4: 0x8f820850  lw          $v0, 0x850($gp) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 2128)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D39F8u;
        goto label_2d39f8;
    }
    ctx->pc = 0x2D39F0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D39F4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D39F0u;
        // 0x2d39f4: 0x8f820850  lw          $v0, 0x850($gp) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 2128)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D39F0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D39F8u;
label_2d39f8:
    // 0x2d39f8: 0x3e00008  jr          $ra
label_2d39fc:
    if (ctx->pc == 0x2D39FCu) {
        ctx->pc = 0x2D3A00u;
        goto label_2d3a00;
    }
    ctx->pc = 0x2D39F8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D39F8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A00u;
label_2d3a00:
    // 0x2d3a00: 0x3e00008  jr          $ra
label_2d3a04:
    if (ctx->pc == 0x2D3A04u) {
        ctx->pc = 0x2D3A04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A00u;
        // 0x2d3a04: 0xac850008  sw          $a1, 0x8($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A08u;
        goto label_2d3a08;
    }
    ctx->pc = 0x2D3A00u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A00u;
        // 0x2d3a04: 0xac850008  sw          $a1, 0x8($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 8), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A00u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A08u;
label_2d3a08:
    // 0x2d3a08: 0x3e00008  jr          $ra
label_2d3a0c:
    if (ctx->pc == 0x2D3A0Cu) {
        ctx->pc = 0x2D3A0Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A08u;
        // 0x2d3a0c: 0x8c820008  lw          $v0, 0x8($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 8)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A10u;
        goto label_2d3a10;
    }
    ctx->pc = 0x2D3A08u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A0Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A08u;
        // 0x2d3a0c: 0x8c820008  lw          $v0, 0x8($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 8)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A08u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A10u;
label_2d3a10:
    // 0x2d3a10: 0x3e00008  jr          $ra
label_2d3a14:
    if (ctx->pc == 0x2D3A14u) {
        ctx->pc = 0x2D3A14u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A10u;
        // 0x2d3a14: 0xac85000c  sw          $a1, 0xC($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 12), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A18u;
        goto label_2d3a18;
    }
    ctx->pc = 0x2D3A10u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A14u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A10u;
        // 0x2d3a14: 0xac85000c  sw          $a1, 0xC($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 12), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A10u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A18u;
label_2d3a18:
    // 0x2d3a18: 0x3e00008  jr          $ra
label_2d3a1c:
    if (ctx->pc == 0x2D3A1Cu) {
        ctx->pc = 0x2D3A1Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A18u;
        // 0x2d3a1c: 0x8c82000c  lw          $v0, 0xC($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A20u;
        goto label_2d3a20;
    }
    ctx->pc = 0x2D3A18u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A1Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A18u;
        // 0x2d3a1c: 0x8c82000c  lw          $v0, 0xC($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A18u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A20u;
label_2d3a20:
    // 0x2d3a20: 0x3e00008  jr          $ra
label_2d3a24:
    if (ctx->pc == 0x2D3A24u) {
        ctx->pc = 0x2D3A24u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A20u;
        // 0x2d3a24: 0x8c820000  lw          $v0, 0x0($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A28u;
        goto label_2d3a28;
    }
    ctx->pc = 0x2D3A20u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A24u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A20u;
        // 0x2d3a24: 0x8c820000  lw          $v0, 0x0($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A20u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A28u;
label_2d3a28:
    // 0x2d3a28: 0x52880  sll         $a1, $a1, 2
    ctx->pc = 0x2d3a28u;
    SET_GPR_S32(ctx, 5, (int32_t)SLL32(GPR_U32(ctx, 5), 2));
label_2d3a2c:
    // 0x2d3a2c: 0x852021  addu        $a0, $a0, $a1
    ctx->pc = 0x2d3a2cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), GPR_U32(ctx, 5)));
label_2d3a30:
    // 0x2d3a30: 0x3e00008  jr          $ra
label_2d3a34:
    if (ctx->pc == 0x2D3A34u) {
        ctx->pc = 0x2D3A34u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A30u;
        // 0x2d3a34: 0x8c82000c  lw          $v0, 0xC($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A38u;
        goto label_2d3a38;
    }
    ctx->pc = 0x2D3A30u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A34u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A30u;
        // 0x2d3a34: 0x8c82000c  lw          $v0, 0xC($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 12)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A30u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A38u;
label_2d3a38:
    // 0x2d3a38: 0x3e00008  jr          $ra
label_2d3a3c:
    if (ctx->pc == 0x2D3A3Cu) {
        ctx->pc = 0x2D3A3Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A38u;
        // 0x2d3a3c: 0x8c820000  lw          $v0, 0x0($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A40u;
        goto label_2d3a40;
    }
    ctx->pc = 0x2D3A38u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A3Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A38u;
        // 0x2d3a3c: 0x8c820000  lw          $v0, 0x0($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A38u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A40u;
label_2d3a40:
    // 0x2d3a40: 0x3e00008  jr          $ra
label_2d3a44:
    if (ctx->pc == 0x2D3A44u) {
        ctx->pc = 0x2D3A44u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A40u;
        // 0x2d3a44: 0x8c820124  lw          $v0, 0x124($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 292)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A48u;
        goto label_2d3a48;
    }
    ctx->pc = 0x2D3A40u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A44u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A40u;
        // 0x2d3a44: 0x8c820124  lw          $v0, 0x124($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 292)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A40u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A48u;
label_2d3a48:
    // 0x2d3a48: 0x8c830124  lw          $v1, 0x124($a0)
    ctx->pc = 0x2d3a48u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 292)));
label_2d3a4c:
    // 0x2d3a4c: 0x3e00008  jr          $ra
label_2d3a50:
    if (ctx->pc == 0x2D3A50u) {
        ctx->pc = 0x2D3A50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A4Cu;
        // 0x2d3a50: 0x8c620058  lw          $v0, 0x58($v1) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 88)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A54u;
        goto label_2d3a54;
    }
    ctx->pc = 0x2D3A4Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A4Cu;
        // 0x2d3a50: 0x8c620058  lw          $v0, 0x58($v1) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 88)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A4Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A54u;
label_2d3a54:
    // 0x2d3a54: 0x0  nop
    ctx->pc = 0x2d3a54u;
    // NOP
label_2d3a58:
    // 0x2d3a58: 0x8c820000  lw          $v0, 0x0($a0)
    ctx->pc = 0x2d3a58u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_2d3a5c:
    // 0x2d3a5c: 0x8c430124  lw          $v1, 0x124($v0)
    ctx->pc = 0x2d3a5cu;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 292)));
label_2d3a60:
    // 0x2d3a60: 0x3e00008  jr          $ra
label_2d3a64:
    if (ctx->pc == 0x2D3A64u) {
        ctx->pc = 0x2D3A64u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A60u;
        // 0x2d3a64: 0x8c620058  lw          $v0, 0x58($v1) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 88)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A68u;
        goto label_2d3a68;
    }
    ctx->pc = 0x2D3A60u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A64u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A60u;
        // 0x2d3a64: 0x8c620058  lw          $v0, 0x58($v1) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 88)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A60u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A68u;
label_2d3a68:
    // 0x2d3a68: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3a68u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3a6c:
    // 0x2d3a6c: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3a6cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3a70:
    // 0x2d3a70: 0xc0b28a0  jal         func_2CA280
label_2d3a74:
    if (ctx->pc == 0x2D3A74u) {
        ctx->pc = 0x2D3A78u;
        goto label_2d3a78;
    }
    ctx->pc = 0x2D3A70u;
    SET_GPR_U32(ctx, 31, 0x2D3A78u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3A70u, 0x2D3A78u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3A78u;
label_2d3a78:
    // 0x2d3a78: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3a78u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3a7c:
    // 0x2d3a7c: 0x3e00008  jr          $ra
label_2d3a80:
    if (ctx->pc == 0x2D3A80u) {
        ctx->pc = 0x2D3A80u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A7Cu;
        // 0x2d3a80: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A84u;
        goto label_2d3a84;
    }
    ctx->pc = 0x2D3A7Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A80u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A7Cu;
        // 0x2d3a80: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A7Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A84u;
label_2d3a84:
    // 0x2d3a84: 0x0  nop
    ctx->pc = 0x2d3a84u;
    // NOP
label_2d3a88:
    // 0x2d3a88: 0x3e00008  jr          $ra
label_2d3a8c:
    if (ctx->pc == 0x2D3A8Cu) {
        ctx->pc = 0x2D3A8Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A88u;
        // 0x2d3a8c: 0xac850020  sw          $a1, 0x20($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 32), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A90u;
        goto label_2d3a90;
    }
    ctx->pc = 0x2D3A88u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A8Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A88u;
        // 0x2d3a8c: 0xac850020  sw          $a1, 0x20($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 32), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A88u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A90u;
label_2d3a90:
    // 0x2d3a90: 0x3e00008  jr          $ra
label_2d3a94:
    if (ctx->pc == 0x2D3A94u) {
        ctx->pc = 0x2D3A94u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A90u;
        // 0x2d3a94: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3A98u;
        goto label_2d3a98;
    }
    ctx->pc = 0x2D3A90u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3A94u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3A90u;
        // 0x2d3a94: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3A90u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3A98u;
label_2d3a98:
    // 0x2d3a98: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3a98u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3a9c:
    // 0x2d3a9c: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3a9cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3aa0:
    // 0x2d3aa0: 0xc0b28a0  jal         func_2CA280
label_2d3aa4:
    if (ctx->pc == 0x2D3AA4u) {
        ctx->pc = 0x2D3AA8u;
        goto label_2d3aa8;
    }
    ctx->pc = 0x2D3AA0u;
    SET_GPR_U32(ctx, 31, 0x2D3AA8u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3AA0u, 0x2D3AA8u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3AA8u;
label_2d3aa8:
    // 0x2d3aa8: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3aa8u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3aac:
    // 0x2d3aac: 0x3e00008  jr          $ra
label_2d3ab0:
    if (ctx->pc == 0x2D3AB0u) {
        ctx->pc = 0x2D3AB0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AACu;
        // 0x2d3ab0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3AB4u;
        goto label_2d3ab4;
    }
    ctx->pc = 0x2D3AACu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3AB0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AACu;
        // 0x2d3ab0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3AACu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3AB4u;
label_2d3ab4:
    // 0x2d3ab4: 0x0  nop
    ctx->pc = 0x2d3ab4u;
    // NOP
label_2d3ab8:
    // 0x2d3ab8: 0xac86001c  sw          $a2, 0x1C($a0)
    ctx->pc = 0x2d3ab8u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 28), GPR_U32(ctx, 6));
label_2d3abc:
    // 0x2d3abc: 0x3e00008  jr          $ra
label_2d3ac0:
    if (ctx->pc == 0x2D3AC0u) {
        ctx->pc = 0x2D3AC0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3ABCu;
        // 0x2d3ac0: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3AC4u;
        goto label_2d3ac4;
    }
    ctx->pc = 0x2D3ABCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3AC0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3ABCu;
        // 0x2d3ac0: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3ABCu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3AC4u;
label_2d3ac4:
    // 0x2d3ac4: 0x0  nop
    ctx->pc = 0x2d3ac4u;
    // NOP
label_2d3ac8:
    // 0x2d3ac8: 0x3e00008  jr          $ra
label_2d3acc:
    if (ctx->pc == 0x2D3ACCu) {
        ctx->pc = 0x2D3ACCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AC8u;
        // 0x2d3acc: 0xac850020  sw          $a1, 0x20($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 32), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3AD0u;
        goto label_2d3ad0;
    }
    ctx->pc = 0x2D3AC8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3ACCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AC8u;
        // 0x2d3acc: 0xac850020  sw          $a1, 0x20($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 32), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3AC8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3AD0u;
label_2d3ad0:
    // 0x2d3ad0: 0x3e00008  jr          $ra
label_2d3ad4:
    if (ctx->pc == 0x2D3AD4u) {
        ctx->pc = 0x2D3AD4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AD0u;
        // 0x2d3ad4: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3AD8u;
        goto label_2d3ad8;
    }
    ctx->pc = 0x2D3AD0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3AD4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AD0u;
        // 0x2d3ad4: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3AD0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3AD8u;
label_2d3ad8:
    // 0x2d3ad8: 0x3e00008  jr          $ra
label_2d3adc:
    if (ctx->pc == 0x2D3ADCu) {
        ctx->pc = 0x2D3ADCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AD8u;
        // 0x2d3adc: 0x8c820014  lw          $v0, 0x14($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 20)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3AE0u;
        goto label_2d3ae0;
    }
    ctx->pc = 0x2D3AD8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3ADCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AD8u;
        // 0x2d3adc: 0x8c820014  lw          $v0, 0x14($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 20)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3AD8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3AE0u;
label_2d3ae0:
    // 0x2d3ae0: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3ae0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3ae4:
    // 0x2d3ae4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3ae4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3ae8:
    // 0x2d3ae8: 0xc0b28a0  jal         func_2CA280
label_2d3aec:
    if (ctx->pc == 0x2D3AECu) {
        ctx->pc = 0x2D3AF0u;
        goto label_2d3af0;
    }
    ctx->pc = 0x2D3AE8u;
    SET_GPR_U32(ctx, 31, 0x2D3AF0u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3AE8u, 0x2D3AF0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3AF0u;
label_2d3af0:
    // 0x2d3af0: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3af0u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3af4:
    // 0x2d3af4: 0x3e00008  jr          $ra
label_2d3af8:
    if (ctx->pc == 0x2D3AF8u) {
        ctx->pc = 0x2D3AF8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AF4u;
        // 0x2d3af8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3AFCu;
        goto label_2d3afc;
    }
    ctx->pc = 0x2D3AF4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3AF8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3AF4u;
        // 0x2d3af8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3AF4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3AFCu;
label_2d3afc:
    // 0x2d3afc: 0x0  nop
    ctx->pc = 0x2d3afcu;
    // NOP
label_2d3b00:
    // 0x2d3b00: 0x3e00008  jr          $ra
label_2d3b04:
    if (ctx->pc == 0x2D3B04u) {
        ctx->pc = 0x2D3B04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B00u;
        // 0x2d3b04: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B08u;
        goto label_2d3b08;
    }
    ctx->pc = 0x2D3B00u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B00u;
        // 0x2d3b04: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B00u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B08u;
label_2d3b08:
    // 0x2d3b08: 0x3e00008  jr          $ra
label_2d3b0c:
    if (ctx->pc == 0x2D3B0Cu) {
        ctx->pc = 0x2D3B0Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B08u;
        // 0x2d3b0c: 0x8c820018  lw          $v0, 0x18($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 24)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B10u;
        goto label_2d3b10;
    }
    ctx->pc = 0x2D3B08u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B0Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B08u;
        // 0x2d3b0c: 0x8c820018  lw          $v0, 0x18($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 24)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B08u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B10u;
label_2d3b10:
    // 0x2d3b10: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3b10u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3b14:
    // 0x2d3b14: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3b14u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3b18:
    // 0x2d3b18: 0xc0b28a0  jal         func_2CA280
label_2d3b1c:
    if (ctx->pc == 0x2D3B1Cu) {
        ctx->pc = 0x2D3B20u;
        goto label_2d3b20;
    }
    ctx->pc = 0x2D3B18u;
    SET_GPR_U32(ctx, 31, 0x2D3B20u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3B18u, 0x2D3B20u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3B20u;
label_2d3b20:
    // 0x2d3b20: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3b20u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3b24:
    // 0x2d3b24: 0x3e00008  jr          $ra
label_2d3b28:
    if (ctx->pc == 0x2D3B28u) {
        ctx->pc = 0x2D3B28u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B24u;
        // 0x2d3b28: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B2Cu;
        goto label_2d3b2c;
    }
    ctx->pc = 0x2D3B24u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B28u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B24u;
        // 0x2d3b28: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B24u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B2Cu;
label_2d3b2c:
    // 0x2d3b2c: 0x0  nop
    ctx->pc = 0x2d3b2cu;
    // NOP
label_2d3b30:
    // 0x2d3b30: 0x3e00008  jr          $ra
label_2d3b34:
    if (ctx->pc == 0x2D3B34u) {
        ctx->pc = 0x2D3B34u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B30u;
        // 0x2d3b34: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B38u;
        goto label_2d3b38;
    }
    ctx->pc = 0x2D3B30u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B34u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B30u;
        // 0x2d3b34: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B30u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B38u;
label_2d3b38:
    // 0x2d3b38: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3b38u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3b3c:
    // 0x2d3b3c: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3b3cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3b40:
    // 0x2d3b40: 0xc0b28a0  jal         func_2CA280
label_2d3b44:
    if (ctx->pc == 0x2D3B44u) {
        ctx->pc = 0x2D3B48u;
        goto label_2d3b48;
    }
    ctx->pc = 0x2D3B40u;
    SET_GPR_U32(ctx, 31, 0x2D3B48u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3B40u, 0x2D3B48u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3B48u;
label_2d3b48:
    // 0x2d3b48: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3b48u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3b4c:
    // 0x2d3b4c: 0x3e00008  jr          $ra
label_2d3b50:
    if (ctx->pc == 0x2D3B50u) {
        ctx->pc = 0x2D3B50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B4Cu;
        // 0x2d3b50: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B54u;
        goto label_2d3b54;
    }
    ctx->pc = 0x2D3B4Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B4Cu;
        // 0x2d3b50: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B4Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B54u;
label_2d3b54:
    // 0x2d3b54: 0x0  nop
    ctx->pc = 0x2d3b54u;
    // NOP
label_2d3b58:
    // 0x2d3b58: 0x3e00008  jr          $ra
label_2d3b5c:
    if (ctx->pc == 0x2D3B5Cu) {
        ctx->pc = 0x2D3B5Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B58u;
        // 0x2d3b5c: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B60u;
        goto label_2d3b60;
    }
    ctx->pc = 0x2D3B58u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B5Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B58u;
        // 0x2d3b5c: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B58u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B60u;
label_2d3b60:
    // 0x2d3b60: 0x3e00008  jr          $ra
label_2d3b64:
    if (ctx->pc == 0x2D3B64u) {
        ctx->pc = 0x2D3B64u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B60u;
        // 0x2d3b64: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B68u;
        goto label_2d3b68;
    }
    ctx->pc = 0x2D3B60u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B64u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B60u;
        // 0x2d3b64: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B60u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B68u;
label_2d3b68:
    // 0x2d3b68: 0x3e00008  jr          $ra
label_2d3b6c:
    if (ctx->pc == 0x2D3B6Cu) {
        ctx->pc = 0x2D3B6Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B68u;
        // 0x2d3b6c: 0x8c820014  lw          $v0, 0x14($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 20)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B70u;
        goto label_2d3b70;
    }
    ctx->pc = 0x2D3B68u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B6Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B68u;
        // 0x2d3b6c: 0x8c820014  lw          $v0, 0x14($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 20)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B68u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B70u;
label_2d3b70:
    // 0x2d3b70: 0x3e00008  jr          $ra
label_2d3b74:
    if (ctx->pc == 0x2D3B74u) {
        ctx->pc = 0x2D3B74u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B70u;
        // 0x2d3b74: 0xac850020  sw          $a1, 0x20($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 32), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B78u;
        goto label_2d3b78;
    }
    ctx->pc = 0x2D3B70u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B74u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B70u;
        // 0x2d3b74: 0xac850020  sw          $a1, 0x20($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 32), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B70u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B78u;
label_2d3b78:
    // 0x2d3b78: 0x3e00008  jr          $ra
label_2d3b7c:
    if (ctx->pc == 0x2D3B7Cu) {
        ctx->pc = 0x2D3B7Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B78u;
        // 0x2d3b7c: 0x8c820020  lw          $v0, 0x20($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 32)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B80u;
        goto label_2d3b80;
    }
    ctx->pc = 0x2D3B78u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B7Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B78u;
        // 0x2d3b7c: 0x8c820020  lw          $v0, 0x20($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 32)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B78u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B80u;
label_2d3b80:
    // 0x2d3b80: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3b80u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3b84:
    // 0x2d3b84: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3b84u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3b88:
    // 0x2d3b88: 0xc0b28a0  jal         func_2CA280
label_2d3b8c:
    if (ctx->pc == 0x2D3B8Cu) {
        ctx->pc = 0x2D3B90u;
        goto label_2d3b90;
    }
    ctx->pc = 0x2D3B88u;
    SET_GPR_U32(ctx, 31, 0x2D3B90u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3B88u, 0x2D3B90u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3B90u;
label_2d3b90:
    // 0x2d3b90: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3b90u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3b94:
    // 0x2d3b94: 0x3e00008  jr          $ra
label_2d3b98:
    if (ctx->pc == 0x2D3B98u) {
        ctx->pc = 0x2D3B98u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B94u;
        // 0x2d3b98: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3B9Cu;
        goto label_2d3b9c;
    }
    ctx->pc = 0x2D3B94u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3B98u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3B94u;
        // 0x2d3b98: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3B94u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3B9Cu;
label_2d3b9c:
    // 0x2d3b9c: 0x0  nop
    ctx->pc = 0x2d3b9cu;
    // NOP
label_2d3ba0:
    // 0x2d3ba0: 0x3e00008  jr          $ra
label_2d3ba4:
    if (ctx->pc == 0x2D3BA4u) {
        ctx->pc = 0x2D3BA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BA0u;
        // 0x2d3ba4: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3BA8u;
        goto label_2d3ba8;
    }
    ctx->pc = 0x2D3BA0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3BA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BA0u;
        // 0x2d3ba4: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3BA0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3BA8u;
label_2d3ba8:
    // 0x2d3ba8: 0x3e00008  jr          $ra
label_2d3bac:
    if (ctx->pc == 0x2D3BACu) {
        ctx->pc = 0x2D3BACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BA8u;
        // 0x2d3bac: 0x8c820014  lw          $v0, 0x14($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 20)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3BB0u;
        goto label_2d3bb0;
    }
    ctx->pc = 0x2D3BA8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3BACu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BA8u;
        // 0x2d3bac: 0x8c820014  lw          $v0, 0x14($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 20)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3BA8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3BB0u;
label_2d3bb0:
    // 0x2d3bb0: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3bb0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3bb4:
    // 0x2d3bb4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3bb4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3bb8:
    // 0x2d3bb8: 0xc0b28a0  jal         func_2CA280
label_2d3bbc:
    if (ctx->pc == 0x2D3BBCu) {
        ctx->pc = 0x2D3BC0u;
        goto label_2d3bc0;
    }
    ctx->pc = 0x2D3BB8u;
    SET_GPR_U32(ctx, 31, 0x2D3BC0u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3BB8u, 0x2D3BC0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3BC0u;
label_2d3bc0:
    // 0x2d3bc0: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3bc0u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3bc4:
    // 0x2d3bc4: 0x3e00008  jr          $ra
label_2d3bc8:
    if (ctx->pc == 0x2D3BC8u) {
        ctx->pc = 0x2D3BC8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BC4u;
        // 0x2d3bc8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3BCCu;
        goto label_2d3bcc;
    }
    ctx->pc = 0x2D3BC4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3BC8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BC4u;
        // 0x2d3bc8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3BC4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3BCCu;
label_2d3bcc:
    // 0x2d3bcc: 0x0  nop
    ctx->pc = 0x2d3bccu;
    // NOP
label_2d3bd0:
    // 0x2d3bd0: 0x3e00008  jr          $ra
label_2d3bd4:
    if (ctx->pc == 0x2D3BD4u) {
        ctx->pc = 0x2D3BD4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BD0u;
        // 0x2d3bd4: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3BD8u;
        goto label_2d3bd8;
    }
    ctx->pc = 0x2D3BD0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3BD4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BD0u;
        // 0x2d3bd4: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3BD0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3BD8u;
label_2d3bd8:
    // 0x2d3bd8: 0x3e00008  jr          $ra
label_2d3bdc:
    if (ctx->pc == 0x2D3BDCu) {
        ctx->pc = 0x2D3BDCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BD8u;
        // 0x2d3bdc: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3BE0u;
        goto label_2d3be0;
    }
    ctx->pc = 0x2D3BD8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3BDCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BD8u;
        // 0x2d3bdc: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3BD8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3BE0u;
label_2d3be0:
    // 0x2d3be0: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3be0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3be4:
    // 0x2d3be4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3be4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3be8:
    // 0x2d3be8: 0xc0b28a0  jal         func_2CA280
label_2d3bec:
    if (ctx->pc == 0x2D3BECu) {
        ctx->pc = 0x2D3BF0u;
        goto label_2d3bf0;
    }
    ctx->pc = 0x2D3BE8u;
    SET_GPR_U32(ctx, 31, 0x2D3BF0u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3BE8u, 0x2D3BF0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3BF0u;
label_2d3bf0:
    // 0x2d3bf0: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3bf0u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3bf4:
    // 0x2d3bf4: 0x3e00008  jr          $ra
label_2d3bf8:
    if (ctx->pc == 0x2D3BF8u) {
        ctx->pc = 0x2D3BF8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BF4u;
        // 0x2d3bf8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3BFCu;
        goto label_2d3bfc;
    }
    ctx->pc = 0x2D3BF4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3BF8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3BF4u;
        // 0x2d3bf8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3BF4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3BFCu;
label_2d3bfc:
    // 0x2d3bfc: 0x0  nop
    ctx->pc = 0x2d3bfcu;
    // NOP
label_2d3c00:
    // 0x2d3c00: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3c00u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3c04:
    // 0x2d3c04: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3c04u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3c08:
    // 0x2d3c08: 0xc0b28a0  jal         func_2CA280
label_2d3c0c:
    if (ctx->pc == 0x2D3C0Cu) {
        ctx->pc = 0x2D3C10u;
        goto label_2d3c10;
    }
    ctx->pc = 0x2D3C08u;
    SET_GPR_U32(ctx, 31, 0x2D3C10u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3C08u, 0x2D3C10u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3C10u;
label_2d3c10:
    // 0x2d3c10: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3c10u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3c14:
    // 0x2d3c14: 0x3e00008  jr          $ra
label_2d3c18:
    if (ctx->pc == 0x2D3C18u) {
        ctx->pc = 0x2D3C18u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C14u;
        // 0x2d3c18: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3C1Cu;
        goto label_2d3c1c;
    }
    ctx->pc = 0x2D3C14u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C18u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C14u;
        // 0x2d3c18: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C14u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3C1Cu;
label_2d3c1c:
    // 0x2d3c1c: 0x0  nop
    ctx->pc = 0x2d3c1cu;
    // NOP
label_2d3c20:
    // 0x2d3c20: 0x3e00008  jr          $ra
label_2d3c24:
    if (ctx->pc == 0x2D3C24u) {
        ctx->pc = 0x2D3C24u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C20u;
        // 0x2d3c24: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3C28u;
        goto label_2d3c28;
    }
    ctx->pc = 0x2D3C20u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C24u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C20u;
        // 0x2d3c24: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C20u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3C28u;
label_2d3c28:
    // 0x2d3c28: 0x3e00008  jr          $ra
label_2d3c2c:
    if (ctx->pc == 0x2D3C2Cu) {
        ctx->pc = 0x2D3C2Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C28u;
        // 0x2d3c2c: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3C30u;
        goto label_2d3c30;
    }
    ctx->pc = 0x2D3C28u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C2Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C28u;
        // 0x2d3c2c: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C28u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3C30u;
label_2d3c30:
    // 0x2d3c30: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3c30u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3c34:
    // 0x2d3c34: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3c34u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3c38:
    // 0x2d3c38: 0xc0b28a0  jal         func_2CA280
label_2d3c3c:
    if (ctx->pc == 0x2D3C3Cu) {
        ctx->pc = 0x2D3C40u;
        goto label_2d3c40;
    }
    ctx->pc = 0x2D3C38u;
    SET_GPR_U32(ctx, 31, 0x2D3C40u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3C38u, 0x2D3C40u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3C40u;
label_2d3c40:
    // 0x2d3c40: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3c40u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3c44:
    // 0x2d3c44: 0x3e00008  jr          $ra
label_2d3c48:
    if (ctx->pc == 0x2D3C48u) {
        ctx->pc = 0x2D3C48u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C44u;
        // 0x2d3c48: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3C4Cu;
        goto label_2d3c4c;
    }
    ctx->pc = 0x2D3C44u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C48u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C44u;
        // 0x2d3c48: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C44u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3C4Cu;
label_2d3c4c:
    // 0x2d3c4c: 0x0  nop
    ctx->pc = 0x2d3c4cu;
    // NOP
label_2d3c50:
    // 0x2d3c50: 0x3e00008  jr          $ra
label_2d3c54:
    if (ctx->pc == 0x2D3C54u) {
        ctx->pc = 0x2D3C54u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C50u;
        // 0x2d3c54: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3C58u;
        goto label_2d3c58;
    }
    ctx->pc = 0x2D3C50u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C54u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C50u;
        // 0x2d3c54: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C50u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3C58u;
label_2d3c58:
    // 0x2d3c58: 0x3e00008  jr          $ra
label_2d3c5c:
    if (ctx->pc == 0x2D3C5Cu) {
        ctx->pc = 0x2D3C5Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C58u;
        // 0x2d3c5c: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3C60u;
        goto label_2d3c60;
    }
    ctx->pc = 0x2D3C58u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C5Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C58u;
        // 0x2d3c5c: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C58u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3C60u;
label_2d3c60:
    // 0x2d3c60: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3c60u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3c64:
    // 0x2d3c64: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3c64u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3c68:
    // 0x2d3c68: 0xc0b28a0  jal         func_2CA280
label_2d3c6c:
    if (ctx->pc == 0x2D3C6Cu) {
        ctx->pc = 0x2D3C70u;
        goto label_2d3c70;
    }
    ctx->pc = 0x2D3C68u;
    SET_GPR_U32(ctx, 31, 0x2D3C70u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3C68u, 0x2D3C70u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3C70u;
label_2d3c70:
    // 0x2d3c70: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3c70u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3c74:
    // 0x2d3c74: 0x3e00008  jr          $ra
label_2d3c78:
    if (ctx->pc == 0x2D3C78u) {
        ctx->pc = 0x2D3C78u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C74u;
        // 0x2d3c78: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3C7Cu;
        goto label_2d3c7c;
    }
    ctx->pc = 0x2D3C74u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C78u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C74u;
        // 0x2d3c78: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C74u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3C7Cu;
label_2d3c7c:
    // 0x2d3c7c: 0x0  nop
    ctx->pc = 0x2d3c7cu;
    // NOP
label_2d3c80:
    // 0x2d3c80: 0x3e00008  jr          $ra
label_2d3c84:
    if (ctx->pc == 0x2D3C84u) {
        ctx->pc = 0x2D3C84u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C80u;
        // 0x2d3c84: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3C88u;
        goto label_2d3c88;
    }
    ctx->pc = 0x2D3C80u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C84u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C80u;
        // 0x2d3c84: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C80u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3C88u;
label_2d3c88:
    // 0x2d3c88: 0xe48d0020  swc1        $f13, 0x20($a0)
    ctx->pc = 0x2d3c88u;
    { float f = ctx->f[13]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 32), bits); }
label_2d3c8c:
    // 0x2d3c8c: 0x3e00008  jr          $ra
label_2d3c90:
    if (ctx->pc == 0x2D3C90u) {
        ctx->pc = 0x2D3C90u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C8Cu;
        // 0x2d3c90: 0xe48c001c  swc1        $f12, 0x1C($a0) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 28), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3C94u;
        goto label_2d3c94;
    }
    ctx->pc = 0x2D3C8Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C90u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C8Cu;
        // 0x2d3c90: 0xe48c001c  swc1        $f12, 0x1C($a0) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 28), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C8Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3C94u;
label_2d3c94:
    // 0x2d3c94: 0x0  nop
    ctx->pc = 0x2d3c94u;
    // NOP
label_2d3c98:
    // 0x2d3c98: 0x3e00008  jr          $ra
label_2d3c9c:
    if (ctx->pc == 0x2D3C9Cu) {
        ctx->pc = 0x2D3C9Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C98u;
        // 0x2d3c9c: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3CA0u;
        goto label_2d3ca0;
    }
    ctx->pc = 0x2D3C98u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3C9Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3C98u;
        // 0x2d3c9c: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3C98u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3CA0u;
label_2d3ca0:
    // 0x2d3ca0: 0xe48d0028  swc1        $f13, 0x28($a0)
    ctx->pc = 0x2d3ca0u;
    { float f = ctx->f[13]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 40), bits); }
label_2d3ca4:
    // 0x2d3ca4: 0x3e00008  jr          $ra
label_2d3ca8:
    if (ctx->pc == 0x2D3CA8u) {
        ctx->pc = 0x2D3CA8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3CA4u;
        // 0x2d3ca8: 0xe48c0024  swc1        $f12, 0x24($a0) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 36), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3CACu;
        goto label_2d3cac;
    }
    ctx->pc = 0x2D3CA4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3CA8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3CA4u;
        // 0x2d3ca8: 0xe48c0024  swc1        $f12, 0x24($a0) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 36), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3CA4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3CACu;
label_2d3cac:
    // 0x2d3cac: 0x0  nop
    ctx->pc = 0x2d3cacu;
    // NOP
label_2d3cb0:
    // 0x2d3cb0: 0x8c820018  lw          $v0, 0x18($a0)
    ctx->pc = 0x2d3cb0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 24)));
label_2d3cb4:
    // 0x2d3cb4: 0x3e00008  jr          $ra
label_2d3cb8:
    if (ctx->pc == 0x2D3CB8u) {
        ctx->pc = 0x2D3CB8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3CB4u;
        // 0x2d3cb8: 0xe44c0000  swc1        $f12, 0x0($v0) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 0), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3CBCu;
        goto label_2d3cbc;
    }
    ctx->pc = 0x2D3CB4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3CB8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3CB4u;
        // 0x2d3cb8: 0xe44c0000  swc1        $f12, 0x0($v0) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 2), 0), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3CB4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3CBCu;
label_2d3cbc:
    // 0x2d3cbc: 0x0  nop
    ctx->pc = 0x2d3cbcu;
    // NOP
label_2d3cc0:
    // 0x2d3cc0: 0x8c820018  lw          $v0, 0x18($a0)
    ctx->pc = 0x2d3cc0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 24)));
label_2d3cc4:
    // 0x2d3cc4: 0xc4800024  lwc1        $f0, 0x24($a0)
    ctx->pc = 0x2d3cc4u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 4), 36)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
label_2d3cc8:
    // 0x2d3cc8: 0xc4410000  lwc1        $f1, 0x0($v0)
    ctx->pc = 0x2d3cc8u;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 2), 0)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[1] = f; }
label_2d3ccc:
    // 0x2d3ccc: 0xc4820028  lwc1        $f2, 0x28($a0)
    ctx->pc = 0x2d3cccu;
    { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 4), 40)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[2] = f; }
label_2d3cd0:
    // 0x2d3cd0: 0x46010002  mul.s       $f0, $f0, $f1
    ctx->pc = 0x2d3cd0u;
    ctx->f[0] = FPU_MUL_S(ctx->f[0], ctx->f[1]);
label_2d3cd4:
    // 0x2d3cd4: 0x3e00008  jr          $ra
label_2d3cd8:
    if (ctx->pc == 0x2D3CD8u) {
        ctx->pc = 0x2D3CD8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3CD4u;
        // 0x2d3cd8: 0x46020000  add.s       $f0, $f0, $f2 (Delay Slot)
        ctx->f[0] = FPU_ADD_S(ctx->f[0], ctx->f[2]);
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3CDCu;
        goto label_2d3cdc;
    }
    ctx->pc = 0x2D3CD4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3CD8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3CD4u;
        // 0x2d3cd8: 0x46020000  add.s       $f0, $f0, $f2 (Delay Slot)
        ctx->f[0] = FPU_ADD_S(ctx->f[0], ctx->f[2]);
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3CD4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3CDCu;
label_2d3cdc:
    // 0x2d3cdc: 0x0  nop
    ctx->pc = 0x2d3cdcu;
    // NOP
label_2d3ce0:
    // 0x2d3ce0: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3ce0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3ce4:
    // 0x2d3ce4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3ce4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3ce8:
    // 0x2d3ce8: 0xc0b28a0  jal         func_2CA280
label_2d3cec:
    if (ctx->pc == 0x2D3CECu) {
        ctx->pc = 0x2D3CF0u;
        goto label_2d3cf0;
    }
    ctx->pc = 0x2D3CE8u;
    SET_GPR_U32(ctx, 31, 0x2D3CF0u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3CE8u, 0x2D3CF0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3CF0u;
label_2d3cf0:
    // 0x2d3cf0: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3cf0u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3cf4:
    // 0x2d3cf4: 0x3e00008  jr          $ra
label_2d3cf8:
    if (ctx->pc == 0x2D3CF8u) {
        ctx->pc = 0x2D3CF8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3CF4u;
        // 0x2d3cf8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3CFCu;
        goto label_2d3cfc;
    }
    ctx->pc = 0x2D3CF4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3CF8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3CF4u;
        // 0x2d3cf8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3CF4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3CFCu;
label_2d3cfc:
    // 0x2d3cfc: 0x0  nop
    ctx->pc = 0x2d3cfcu;
    // NOP
label_2d3d00:
    // 0x2d3d00: 0x3e00008  jr          $ra
label_2d3d04:
    if (ctx->pc == 0x2D3D04u) {
        ctx->pc = 0x2D3D04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D00u;
        // 0x2d3d04: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3D08u;
        goto label_2d3d08;
    }
    ctx->pc = 0x2D3D00u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3D04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D00u;
        // 0x2d3d04: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3D00u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3D08u;
label_2d3d08:
    // 0x2d3d08: 0xe48d0020  swc1        $f13, 0x20($a0)
    ctx->pc = 0x2d3d08u;
    { float f = ctx->f[13]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 32), bits); }
label_2d3d0c:
    // 0x2d3d0c: 0x3e00008  jr          $ra
label_2d3d10:
    if (ctx->pc == 0x2D3D10u) {
        ctx->pc = 0x2D3D10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D0Cu;
        // 0x2d3d10: 0xe48c001c  swc1        $f12, 0x1C($a0) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 28), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3D14u;
        goto label_2d3d14;
    }
    ctx->pc = 0x2D3D0Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3D10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D0Cu;
        // 0x2d3d10: 0xe48c001c  swc1        $f12, 0x1C($a0) (Delay Slot)
        { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 4), 28), bits); }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3D0Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3D14u;
label_2d3d14:
    // 0x2d3d14: 0x0  nop
    ctx->pc = 0x2d3d14u;
    // NOP
label_2d3d18:
    // 0x2d3d18: 0x3e00008  jr          $ra
label_2d3d1c:
    if (ctx->pc == 0x2D3D1Cu) {
        ctx->pc = 0x2D3D1Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D18u;
        // 0x2d3d1c: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3D20u;
        goto label_2d3d20;
    }
    ctx->pc = 0x2D3D18u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3D1Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D18u;
        // 0x2d3d1c: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3D18u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3D20u;
label_2d3d20:
    // 0x2d3d20: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3d20u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3d24:
    // 0x2d3d24: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3d24u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3d28:
    // 0x2d3d28: 0xc0b28a0  jal         func_2CA280
label_2d3d2c:
    if (ctx->pc == 0x2D3D2Cu) {
        ctx->pc = 0x2D3D30u;
        goto label_2d3d30;
    }
    ctx->pc = 0x2D3D28u;
    SET_GPR_U32(ctx, 31, 0x2D3D30u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3D28u, 0x2D3D30u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3D30u;
label_2d3d30:
    // 0x2d3d30: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3d30u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3d34:
    // 0x2d3d34: 0x3e00008  jr          $ra
label_2d3d38:
    if (ctx->pc == 0x2D3D38u) {
        ctx->pc = 0x2D3D38u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D34u;
        // 0x2d3d38: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3D3Cu;
        goto label_2d3d3c;
    }
    ctx->pc = 0x2D3D34u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3D38u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D34u;
        // 0x2d3d38: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3D34u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3D3Cu;
label_2d3d3c:
    // 0x2d3d3c: 0x0  nop
    ctx->pc = 0x2d3d3cu;
    // NOP
label_2d3d40:
    // 0x2d3d40: 0x3e00008  jr          $ra
label_2d3d44:
    if (ctx->pc == 0x2D3D44u) {
        ctx->pc = 0x2D3D44u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D40u;
        // 0x2d3d44: 0x24820018  addiu       $v0, $a0, 0x18 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 4), 24));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3D48u;
        goto label_2d3d48;
    }
    ctx->pc = 0x2D3D40u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3D44u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D40u;
        // 0x2d3d44: 0x24820018  addiu       $v0, $a0, 0x18 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 4), 24));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3D40u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3D48u;
label_2d3d48:
    // 0x2d3d48: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3d48u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3d4c:
    // 0x2d3d4c: 0x80102d  daddu       $v0, $a0, $zero
    ctx->pc = 0x2d3d4cu;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2d3d50:
    // 0x2d3d50: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3d50u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3d54:
    // 0x2d3d54: 0x24440018  addiu       $a0, $v0, 0x18
    ctx->pc = 0x2d3d54u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 2), 24));
label_2d3d58:
    // 0x2d3d58: 0x2406000f  addiu       $a2, $zero, 0xF
    ctx->pc = 0x2d3d58u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 0), 15));
label_2d3d5c:
    // 0x2d3d5c: 0xc105a56  jal         func_416958
label_2d3d60:
    if (ctx->pc == 0x2D3D60u) {
        ctx->pc = 0x2D3D60u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D5Cu;
        // 0x2d3d60: 0xa0400018  sb          $zero, 0x18($v0) (Delay Slot)
        WRITE8(ADD32(GPR_U32(ctx, 2), 24), (uint8_t)GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3D64u;
        goto label_2d3d64;
    }
    ctx->pc = 0x2D3D5Cu;
    SET_GPR_U32(ctx, 31, 0x2D3D64u);
    ctx->pc = 0x2D3D60u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3D5Cu;
    // 0x2d3d60: 0xa0400018  sb          $zero, 0x18($v0) (Delay Slot)
    WRITE8(ADD32(GPR_U32(ctx, 2), 24), (uint8_t)GPR_U32(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x416958u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x416958u, 0x2D3D5Cu, 0x2D3D64u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3D64u;
label_2d3d64:
    // 0x2d3d64: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3d64u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3d68:
    // 0x2d3d68: 0x3e00008  jr          $ra
label_2d3d6c:
    if (ctx->pc == 0x2D3D6Cu) {
        ctx->pc = 0x2D3D6Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D68u;
        // 0x2d3d6c: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3D70u;
        goto label_2d3d70;
    }
    ctx->pc = 0x2D3D68u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3D6Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D68u;
        // 0x2d3d6c: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3D68u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3D70u;
label_2d3d70:
    // 0x2d3d70: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3d70u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3d74:
    // 0x2d3d74: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3d74u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3d78:
    // 0x2d3d78: 0xc0b28a0  jal         func_2CA280
label_2d3d7c:
    if (ctx->pc == 0x2D3D7Cu) {
        ctx->pc = 0x2D3D80u;
        goto label_2d3d80;
    }
    ctx->pc = 0x2D3D78u;
    SET_GPR_U32(ctx, 31, 0x2D3D80u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3D78u, 0x2D3D80u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3D80u;
label_2d3d80:
    // 0x2d3d80: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3d80u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3d84:
    // 0x2d3d84: 0x3e00008  jr          $ra
label_2d3d88:
    if (ctx->pc == 0x2D3D88u) {
        ctx->pc = 0x2D3D88u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D84u;
        // 0x2d3d88: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3D8Cu;
        goto label_2d3d8c;
    }
    ctx->pc = 0x2D3D84u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3D88u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3D84u;
        // 0x2d3d88: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3D84u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3D8Cu;
label_2d3d8c:
    // 0x2d3d8c: 0x0  nop
    ctx->pc = 0x2d3d8cu;
    // NOP
label_2d3d90:
    // 0x2d3d90: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3d90u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3d94:
    // 0x2d3d94: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3d94u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3d98:
    // 0x2d3d98: 0xc0b2aa0  jal         func_2CAA80
label_2d3d9c:
    if (ctx->pc == 0x2D3D9Cu) {
        ctx->pc = 0x2D3DA0u;
        goto label_2d3da0;
    }
    ctx->pc = 0x2D3D98u;
    SET_GPR_U32(ctx, 31, 0x2D3DA0u);
    ctx->pc = 0x2CAA80u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CAA80u, 0x2D3D98u, 0x2D3DA0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3DA0u;
label_2d3da0:
    // 0x2d3da0: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3da0u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3da4:
    // 0x2d3da4: 0x3e00008  jr          $ra
label_2d3da8:
    if (ctx->pc == 0x2D3DA8u) {
        ctx->pc = 0x2D3DA8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3DA4u;
        // 0x2d3da8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3DACu;
        goto label_2d3dac;
    }
    ctx->pc = 0x2D3DA4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3DA8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3DA4u;
        // 0x2d3da8: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3DA4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3DACu;
label_2d3dac:
    // 0x2d3dac: 0x0  nop
    ctx->pc = 0x2d3dacu;
    // NOP
label_2d3db0:
    // 0x2d3db0: 0x27bdffd0  addiu       $sp, $sp, -0x30
    ctx->pc = 0x2d3db0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967248));
label_2d3db4:
    // 0x2d3db4: 0x7fb00020  sq          $s0, 0x20($sp)
    ctx->pc = 0x2d3db4u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 16));
label_2d3db8:
    // 0x2d3db8: 0x7fb10010  sq          $s1, 0x10($sp)
    ctx->pc = 0x2d3db8u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 17));
label_2d3dbc:
    // 0x2d3dbc: 0x80802d  daddu       $s0, $a0, $zero
    ctx->pc = 0x2d3dbcu;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2d3dc0:
    // 0x2d3dc0: 0xa0882d  daddu       $s1, $a1, $zero
    ctx->pc = 0x2d3dc0u;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_2d3dc4:
    // 0x2d3dc4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3dc4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3dc8:
    // 0x2d3dc8: 0x26040018  addiu       $a0, $s0, 0x18
    ctx->pc = 0x2d3dc8u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 24));
label_2d3dcc:
    // 0x2d3dcc: 0xc0b2aa0  jal         func_2CAA80
label_2d3dd0:
    if (ctx->pc == 0x2D3DD0u) {
        ctx->pc = 0x2D3DD0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3DCCu;
        // 0x2d3dd0: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3DD4u;
        goto label_2d3dd4;
    }
    ctx->pc = 0x2D3DCCu;
    SET_GPR_U32(ctx, 31, 0x2D3DD4u);
    ctx->pc = 0x2D3DD0u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3DCCu;
    // 0x2d3dd0: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CAA80u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CAA80u, 0x2D3DCCu, 0x2D3DD4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3DD4u;
label_2d3dd4:
    // 0x2d3dd4: 0x200202d  daddu       $a0, $s0, $zero
    ctx->pc = 0x2d3dd4u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d3dd8:
    // 0x2d3dd8: 0xc0b28a0  jal         func_2CA280
label_2d3ddc:
    if (ctx->pc == 0x2D3DDCu) {
        ctx->pc = 0x2D3DDCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3DD8u;
        // 0x2d3ddc: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3DE0u;
        goto label_2d3de0;
    }
    ctx->pc = 0x2D3DD8u;
    SET_GPR_U32(ctx, 31, 0x2D3DE0u);
    ctx->pc = 0x2D3DDCu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3DD8u;
    // 0x2d3ddc: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3DD8u, 0x2D3DE0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3DE0u;
label_2d3de0:
    // 0x2d3de0: 0x7bb00020  lq          $s0, 0x20($sp)
    ctx->pc = 0x2d3de0u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_2d3de4:
    // 0x2d3de4: 0x7bb10010  lq          $s1, 0x10($sp)
    ctx->pc = 0x2d3de4u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_2d3de8:
    // 0x2d3de8: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3de8u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3dec:
    // 0x2d3dec: 0x3e00008  jr          $ra
label_2d3df0:
    if (ctx->pc == 0x2D3DF0u) {
        ctx->pc = 0x2D3DF0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3DECu;
        // 0x2d3df0: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3DF4u;
        goto label_2d3df4;
    }
    ctx->pc = 0x2D3DECu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3DF0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3DECu;
        // 0x2d3df0: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3DECu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3DF4u;
label_2d3df4:
    // 0x2d3df4: 0x0  nop
    ctx->pc = 0x2d3df4u;
    // NOP
label_2d3df8:
    // 0x2d3df8: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3df8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3dfc:
    // 0x2d3dfc: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3dfcu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3e00:
    // 0x2d3e00: 0xc0b28a0  jal         func_2CA280
label_2d3e04:
    if (ctx->pc == 0x2D3E04u) {
        ctx->pc = 0x2D3E08u;
        goto label_2d3e08;
    }
    ctx->pc = 0x2D3E00u;
    SET_GPR_U32(ctx, 31, 0x2D3E08u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3E00u, 0x2D3E08u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3E08u;
label_2d3e08:
    // 0x2d3e08: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3e08u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3e0c:
    // 0x2d3e0c: 0x3e00008  jr          $ra
label_2d3e10:
    if (ctx->pc == 0x2D3E10u) {
        ctx->pc = 0x2D3E10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E0Cu;
        // 0x2d3e10: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3E14u;
        goto label_2d3e14;
    }
    ctx->pc = 0x2D3E0Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3E10u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E0Cu;
        // 0x2d3e10: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3E0Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3E14u;
label_2d3e14:
    // 0x2d3e14: 0x0  nop
    ctx->pc = 0x2d3e14u;
    // NOP
label_2d3e18:
    // 0x2d3e18: 0x3e00008  jr          $ra
label_2d3e1c:
    if (ctx->pc == 0x2D3E1Cu) {
        ctx->pc = 0x2D3E1Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E18u;
        // 0x2d3e1c: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3E20u;
        goto label_2d3e20;
    }
    ctx->pc = 0x2D3E18u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3E1Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E18u;
        // 0x2d3e1c: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3E18u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3E20u;
label_2d3e20:
    // 0x2d3e20: 0x27bdffd0  addiu       $sp, $sp, -0x30
    ctx->pc = 0x2d3e20u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967248));
label_2d3e24:
    // 0x2d3e24: 0x7fb00020  sq          $s0, 0x20($sp)
    ctx->pc = 0x2d3e24u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 16));
label_2d3e28:
    // 0x2d3e28: 0x7fb10010  sq          $s1, 0x10($sp)
    ctx->pc = 0x2d3e28u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 17));
label_2d3e2c:
    // 0x2d3e2c: 0x80802d  daddu       $s0, $a0, $zero
    ctx->pc = 0x2d3e2cu;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2d3e30:
    // 0x2d3e30: 0xa0882d  daddu       $s1, $a1, $zero
    ctx->pc = 0x2d3e30u;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_2d3e34:
    // 0x2d3e34: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3e34u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3e38:
    // 0x2d3e38: 0x26040640  addiu       $a0, $s0, 0x640
    ctx->pc = 0x2d3e38u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 1600));
label_2d3e3c:
    // 0x2d3e3c: 0xc0b28a0  jal         func_2CA280
label_2d3e40:
    if (ctx->pc == 0x2D3E40u) {
        ctx->pc = 0x2D3E40u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E3Cu;
        // 0x2d3e40: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3E44u;
        goto label_2d3e44;
    }
    ctx->pc = 0x2D3E3Cu;
    SET_GPR_U32(ctx, 31, 0x2D3E44u);
    ctx->pc = 0x2D3E40u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3E3Cu;
    // 0x2d3e40: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3E3Cu, 0x2D3E44u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3E44u;
label_2d3e44:
    // 0x2d3e44: 0x2604061c  addiu       $a0, $s0, 0x61C
    ctx->pc = 0x2d3e44u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 1564));
label_2d3e48:
    // 0x2d3e48: 0xc0b28a0  jal         func_2CA280
label_2d3e4c:
    if (ctx->pc == 0x2D3E4Cu) {
        ctx->pc = 0x2D3E4Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E48u;
        // 0x2d3e4c: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3E50u;
        goto label_2d3e50;
    }
    ctx->pc = 0x2D3E48u;
    SET_GPR_U32(ctx, 31, 0x2D3E50u);
    ctx->pc = 0x2D3E4Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3E48u;
    // 0x2d3e4c: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3E48u, 0x2D3E50u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3E50u;
label_2d3e50:
    // 0x2d3e50: 0x260405f8  addiu       $a0, $s0, 0x5F8
    ctx->pc = 0x2d3e50u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 1528));
label_2d3e54:
    // 0x2d3e54: 0xc0b28a0  jal         func_2CA280
label_2d3e58:
    if (ctx->pc == 0x2D3E58u) {
        ctx->pc = 0x2D3E58u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E54u;
        // 0x2d3e58: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3E5Cu;
        goto label_2d3e5c;
    }
    ctx->pc = 0x2D3E54u;
    SET_GPR_U32(ctx, 31, 0x2D3E5Cu);
    ctx->pc = 0x2D3E58u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3E54u;
    // 0x2d3e58: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3E54u, 0x2D3E5Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3E5Cu;
label_2d3e5c:
    // 0x2d3e5c: 0x260405d4  addiu       $a0, $s0, 0x5D4
    ctx->pc = 0x2d3e5cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 1492));
label_2d3e60:
    // 0x2d3e60: 0xc0b28a0  jal         func_2CA280
label_2d3e64:
    if (ctx->pc == 0x2D3E64u) {
        ctx->pc = 0x2D3E64u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E60u;
        // 0x2d3e64: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3E68u;
        goto label_2d3e68;
    }
    ctx->pc = 0x2D3E60u;
    SET_GPR_U32(ctx, 31, 0x2D3E68u);
    ctx->pc = 0x2D3E64u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3E60u;
    // 0x2d3e64: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3E60u, 0x2D3E68u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3E68u;
label_2d3e68:
    // 0x2d3e68: 0x260405b0  addiu       $a0, $s0, 0x5B0
    ctx->pc = 0x2d3e68u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 1456));
label_2d3e6c:
    // 0x2d3e6c: 0xc0b28a0  jal         func_2CA280
label_2d3e70:
    if (ctx->pc == 0x2D3E70u) {
        ctx->pc = 0x2D3E70u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E6Cu;
        // 0x2d3e70: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3E74u;
        goto label_2d3e74;
    }
    ctx->pc = 0x2D3E6Cu;
    SET_GPR_U32(ctx, 31, 0x2D3E74u);
    ctx->pc = 0x2D3E70u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3E6Cu;
    // 0x2d3e70: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3E6Cu, 0x2D3E74u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3E74u;
label_2d3e74:
    // 0x2d3e74: 0x26040018  addiu       $a0, $s0, 0x18
    ctx->pc = 0x2d3e74u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 24));
label_2d3e78:
    // 0x2d3e78: 0xc0b2aa0  jal         func_2CAA80
label_2d3e7c:
    if (ctx->pc == 0x2D3E7Cu) {
        ctx->pc = 0x2D3E7Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E78u;
        // 0x2d3e7c: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3E80u;
        goto label_2d3e80;
    }
    ctx->pc = 0x2D3E78u;
    SET_GPR_U32(ctx, 31, 0x2D3E80u);
    ctx->pc = 0x2D3E7Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3E78u;
    // 0x2d3e7c: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CAA80u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CAA80u, 0x2D3E78u, 0x2D3E80u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3E80u;
label_2d3e80:
    // 0x2d3e80: 0x200202d  daddu       $a0, $s0, $zero
    ctx->pc = 0x2d3e80u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d3e84:
    // 0x2d3e84: 0xc0b28a0  jal         func_2CA280
label_2d3e88:
    if (ctx->pc == 0x2D3E88u) {
        ctx->pc = 0x2D3E88u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E84u;
        // 0x2d3e88: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3E8Cu;
        goto label_2d3e8c;
    }
    ctx->pc = 0x2D3E84u;
    SET_GPR_U32(ctx, 31, 0x2D3E8Cu);
    ctx->pc = 0x2D3E88u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3E84u;
    // 0x2d3e88: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3E84u, 0x2D3E8Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3E8Cu;
label_2d3e8c:
    // 0x2d3e8c: 0x7bb00020  lq          $s0, 0x20($sp)
    ctx->pc = 0x2d3e8cu;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_2d3e90:
    // 0x2d3e90: 0x7bb10010  lq          $s1, 0x10($sp)
    ctx->pc = 0x2d3e90u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_2d3e94:
    // 0x2d3e94: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3e94u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3e98:
    // 0x2d3e98: 0x3e00008  jr          $ra
label_2d3e9c:
    if (ctx->pc == 0x2D3E9Cu) {
        ctx->pc = 0x2D3E9Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E98u;
        // 0x2d3e9c: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3EA0u;
        goto label_2d3ea0;
    }
    ctx->pc = 0x2D3E98u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3E9Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3E98u;
        // 0x2d3e9c: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3E98u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3EA0u;
label_2d3ea0:
    // 0x2d3ea0: 0x3e00008  jr          $ra
label_2d3ea4:
    if (ctx->pc == 0x2D3EA4u) {
        ctx->pc = 0x2D3EA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3EA0u;
        // 0x2d3ea4: 0xac850658  sw          $a1, 0x658($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 1624), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3EA8u;
        goto label_2d3ea8;
    }
    ctx->pc = 0x2D3EA0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3EA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3EA0u;
        // 0x2d3ea4: 0xac850658  sw          $a1, 0x658($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 1624), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3EA0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3EA8u;
label_2d3ea8:
    // 0x2d3ea8: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3ea8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3eac:
    // 0x2d3eac: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3eacu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3eb0:
    // 0x2d3eb0: 0xc0b28a0  jal         func_2CA280
label_2d3eb4:
    if (ctx->pc == 0x2D3EB4u) {
        ctx->pc = 0x2D3EB8u;
        goto label_2d3eb8;
    }
    ctx->pc = 0x2D3EB0u;
    SET_GPR_U32(ctx, 31, 0x2D3EB8u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3EB0u, 0x2D3EB8u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3EB8u;
label_2d3eb8:
    // 0x2d3eb8: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3eb8u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3ebc:
    // 0x2d3ebc: 0x3e00008  jr          $ra
label_2d3ec0:
    if (ctx->pc == 0x2D3EC0u) {
        ctx->pc = 0x2D3EC0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3EBCu;
        // 0x2d3ec0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3EC4u;
        goto label_2d3ec4;
    }
    ctx->pc = 0x2D3EBCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3EC0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3EBCu;
        // 0x2d3ec0: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3EBCu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3EC4u;
label_2d3ec4:
    // 0x2d3ec4: 0x0  nop
    ctx->pc = 0x2d3ec4u;
    // NOP
label_2d3ec8:
    // 0x2d3ec8: 0x3e00008  jr          $ra
label_2d3ecc:
    if (ctx->pc == 0x2D3ECCu) {
        ctx->pc = 0x2D3ECCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3EC8u;
        // 0x2d3ecc: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3ED0u;
        goto label_2d3ed0;
    }
    ctx->pc = 0x2D3EC8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3ECCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3EC8u;
        // 0x2d3ecc: 0xac850018  sw          $a1, 0x18($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 24), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3EC8u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3ED0u;
label_2d3ed0:
    // 0x2d3ed0: 0x27bdffd0  addiu       $sp, $sp, -0x30
    ctx->pc = 0x2d3ed0u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967248));
label_2d3ed4:
    // 0x2d3ed4: 0x7fb00020  sq          $s0, 0x20($sp)
    ctx->pc = 0x2d3ed4u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 16));
label_2d3ed8:
    // 0x2d3ed8: 0x7fb10010  sq          $s1, 0x10($sp)
    ctx->pc = 0x2d3ed8u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 17));
label_2d3edc:
    // 0x2d3edc: 0x80802d  daddu       $s0, $a0, $zero
    ctx->pc = 0x2d3edcu;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2d3ee0:
    // 0x2d3ee0: 0xa0882d  daddu       $s1, $a1, $zero
    ctx->pc = 0x2d3ee0u;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_2d3ee4:
    // 0x2d3ee4: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3ee4u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3ee8:
    // 0x2d3ee8: 0x26040654  addiu       $a0, $s0, 0x654
    ctx->pc = 0x2d3ee8u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 1620));
label_2d3eec:
    // 0x2d3eec: 0xc0b28a0  jal         func_2CA280
label_2d3ef0:
    if (ctx->pc == 0x2D3EF0u) {
        ctx->pc = 0x2D3EF0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3EECu;
        // 0x2d3ef0: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3EF4u;
        goto label_2d3ef4;
    }
    ctx->pc = 0x2D3EECu;
    SET_GPR_U32(ctx, 31, 0x2D3EF4u);
    ctx->pc = 0x2D3EF0u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3EECu;
    // 0x2d3ef0: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3EECu, 0x2D3EF4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3EF4u;
label_2d3ef4:
    // 0x2d3ef4: 0x26040620  addiu       $a0, $s0, 0x620
    ctx->pc = 0x2d3ef4u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 1568));
label_2d3ef8:
    // 0x2d3ef8: 0xc0b28a0  jal         func_2CA280
label_2d3efc:
    if (ctx->pc == 0x2D3EFCu) {
        ctx->pc = 0x2D3EFCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3EF8u;
        // 0x2d3efc: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F00u;
        goto label_2d3f00;
    }
    ctx->pc = 0x2D3EF8u;
    SET_GPR_U32(ctx, 31, 0x2D3F00u);
    ctx->pc = 0x2D3EFCu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3EF8u;
    // 0x2d3efc: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3EF8u, 0x2D3F00u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3F00u;
label_2d3f00:
    // 0x2d3f00: 0x260405ec  addiu       $a0, $s0, 0x5EC
    ctx->pc = 0x2d3f00u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 1516));
label_2d3f04:
    // 0x2d3f04: 0xc0b28a0  jal         func_2CA280
label_2d3f08:
    if (ctx->pc == 0x2D3F08u) {
        ctx->pc = 0x2D3F08u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F04u;
        // 0x2d3f08: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F0Cu;
        goto label_2d3f0c;
    }
    ctx->pc = 0x2D3F04u;
    SET_GPR_U32(ctx, 31, 0x2D3F0Cu);
    ctx->pc = 0x2D3F08u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3F04u;
    // 0x2d3f08: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3F04u, 0x2D3F0Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3F0Cu;
label_2d3f0c:
    // 0x2d3f0c: 0x260405b8  addiu       $a0, $s0, 0x5B8
    ctx->pc = 0x2d3f0cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 1464));
label_2d3f10:
    // 0x2d3f10: 0xc0b28a0  jal         func_2CA280
label_2d3f14:
    if (ctx->pc == 0x2D3F14u) {
        ctx->pc = 0x2D3F14u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F10u;
        // 0x2d3f14: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F18u;
        goto label_2d3f18;
    }
    ctx->pc = 0x2D3F10u;
    SET_GPR_U32(ctx, 31, 0x2D3F18u);
    ctx->pc = 0x2D3F14u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3F10u;
    // 0x2d3f14: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3F10u, 0x2D3F18u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3F18u;
label_2d3f18:
    // 0x2d3f18: 0x26040018  addiu       $a0, $s0, 0x18
    ctx->pc = 0x2d3f18u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 24));
label_2d3f1c:
    // 0x2d3f1c: 0xc0b2aa0  jal         func_2CAA80
label_2d3f20:
    if (ctx->pc == 0x2D3F20u) {
        ctx->pc = 0x2D3F20u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F1Cu;
        // 0x2d3f20: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F24u;
        goto label_2d3f24;
    }
    ctx->pc = 0x2D3F1Cu;
    SET_GPR_U32(ctx, 31, 0x2D3F24u);
    ctx->pc = 0x2D3F20u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3F1Cu;
    // 0x2d3f20: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CAA80u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CAA80u, 0x2D3F1Cu, 0x2D3F24u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3F24u;
label_2d3f24:
    // 0x2d3f24: 0x200202d  daddu       $a0, $s0, $zero
    ctx->pc = 0x2d3f24u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d3f28:
    // 0x2d3f28: 0xc0b28a0  jal         func_2CA280
label_2d3f2c:
    if (ctx->pc == 0x2D3F2Cu) {
        ctx->pc = 0x2D3F2Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F28u;
        // 0x2d3f2c: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F30u;
        goto label_2d3f30;
    }
    ctx->pc = 0x2D3F28u;
    SET_GPR_U32(ctx, 31, 0x2D3F30u);
    ctx->pc = 0x2D3F2Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3F28u;
    // 0x2d3f2c: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3F28u, 0x2D3F30u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3F30u;
label_2d3f30:
    // 0x2d3f30: 0x7bb00020  lq          $s0, 0x20($sp)
    ctx->pc = 0x2d3f30u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_2d3f34:
    // 0x2d3f34: 0x7bb10010  lq          $s1, 0x10($sp)
    ctx->pc = 0x2d3f34u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_2d3f38:
    // 0x2d3f38: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3f38u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3f3c:
    // 0x2d3f3c: 0x3e00008  jr          $ra
label_2d3f40:
    if (ctx->pc == 0x2D3F40u) {
        ctx->pc = 0x2D3F40u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F3Cu;
        // 0x2d3f40: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F44u;
        goto label_2d3f44;
    }
    ctx->pc = 0x2D3F3Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3F40u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F3Cu;
        // 0x2d3f40: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3F3Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3F44u;
label_2d3f44:
    // 0x2d3f44: 0x0  nop
    ctx->pc = 0x2d3f44u;
    // NOP
label_2d3f48:
    // 0x2d3f48: 0x3e00008  jr          $ra
label_2d3f4c:
    if (ctx->pc == 0x2D3F4Cu) {
        ctx->pc = 0x2D3F4Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F48u;
        // 0x2d3f4c: 0xac85066c  sw          $a1, 0x66C($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 1644), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F50u;
        goto label_2d3f50;
    }
    ctx->pc = 0x2D3F48u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3F4Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F48u;
        // 0x2d3f4c: 0xac85066c  sw          $a1, 0x66C($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 1644), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3F48u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3F50u;
label_2d3f50:
    // 0x2d3f50: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3f50u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3f54:
    // 0x2d3f54: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3f54u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3f58:
    // 0x2d3f58: 0xc0b28a0  jal         func_2CA280
label_2d3f5c:
    if (ctx->pc == 0x2D3F5Cu) {
        ctx->pc = 0x2D3F60u;
        goto label_2d3f60;
    }
    ctx->pc = 0x2D3F58u;
    SET_GPR_U32(ctx, 31, 0x2D3F60u);
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3F58u, 0x2D3F60u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3F60u;
label_2d3f60:
    // 0x2d3f60: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3f60u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3f64:
    // 0x2d3f64: 0x3e00008  jr          $ra
label_2d3f68:
    if (ctx->pc == 0x2D3F68u) {
        ctx->pc = 0x2D3F68u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F64u;
        // 0x2d3f68: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F6Cu;
        goto label_2d3f6c;
    }
    ctx->pc = 0x2D3F64u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3F68u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F64u;
        // 0x2d3f68: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3F64u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3F6Cu;
label_2d3f6c:
    // 0x2d3f6c: 0x0  nop
    ctx->pc = 0x2d3f6cu;
    // NOP
label_2d3f70:
    // 0x2d3f70: 0x3e00008  jr          $ra
label_2d3f74:
    if (ctx->pc == 0x2D3F74u) {
        ctx->pc = 0x2D3F74u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F70u;
        // 0x2d3f74: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F78u;
        goto label_2d3f78;
    }
    ctx->pc = 0x2D3F70u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3F74u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F70u;
        // 0x2d3f74: 0xac850014  sw          $a1, 0x14($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 20), GPR_U32(ctx, 5));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3F70u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3F78u;
label_2d3f78:
    // 0x2d3f78: 0x27bdffd0  addiu       $sp, $sp, -0x30
    ctx->pc = 0x2d3f78u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967248));
label_2d3f7c:
    // 0x2d3f7c: 0x7fb00020  sq          $s0, 0x20($sp)
    ctx->pc = 0x2d3f7cu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 16));
label_2d3f80:
    // 0x2d3f80: 0x7fb10010  sq          $s1, 0x10($sp)
    ctx->pc = 0x2d3f80u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 17));
label_2d3f84:
    // 0x2d3f84: 0x80802d  daddu       $s0, $a0, $zero
    ctx->pc = 0x2d3f84u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2d3f88:
    // 0x2d3f88: 0xa0882d  daddu       $s1, $a1, $zero
    ctx->pc = 0x2d3f88u;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_2d3f8c:
    // 0x2d3f8c: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3f8cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3f90:
    // 0x2d3f90: 0x26040164  addiu       $a0, $s0, 0x164
    ctx->pc = 0x2d3f90u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 356));
label_2d3f94:
    // 0x2d3f94: 0xc0b28a0  jal         func_2CA280
label_2d3f98:
    if (ctx->pc == 0x2D3F98u) {
        ctx->pc = 0x2D3F98u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3F94u;
        // 0x2d3f98: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3F9Cu;
        goto label_2d3f9c;
    }
    ctx->pc = 0x2D3F94u;
    SET_GPR_U32(ctx, 31, 0x2D3F9Cu);
    ctx->pc = 0x2D3F98u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3F94u;
    // 0x2d3f98: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3F94u, 0x2D3F9Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3F9Cu;
label_2d3f9c:
    // 0x2d3f9c: 0x2604014c  addiu       $a0, $s0, 0x14C
    ctx->pc = 0x2d3f9cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 332));
label_2d3fa0:
    // 0x2d3fa0: 0xc0b28a0  jal         func_2CA280
label_2d3fa4:
    if (ctx->pc == 0x2D3FA4u) {
        ctx->pc = 0x2D3FA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3FA0u;
        // 0x2d3fa4: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3FA8u;
        goto label_2d3fa8;
    }
    ctx->pc = 0x2D3FA0u;
    SET_GPR_U32(ctx, 31, 0x2D3FA8u);
    ctx->pc = 0x2D3FA4u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3FA0u;
    // 0x2d3fa4: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3FA0u, 0x2D3FA8u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3FA8u;
label_2d3fa8:
    // 0x2d3fa8: 0x26040130  addiu       $a0, $s0, 0x130
    ctx->pc = 0x2d3fa8u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 16), 304));
label_2d3fac:
    // 0x2d3fac: 0xc0b28a0  jal         func_2CA280
label_2d3fb0:
    if (ctx->pc == 0x2D3FB0u) {
        ctx->pc = 0x2D3FB0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3FACu;
        // 0x2d3fb0: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3FB4u;
        goto label_2d3fb4;
    }
    ctx->pc = 0x2D3FACu;
    SET_GPR_U32(ctx, 31, 0x2D3FB4u);
    ctx->pc = 0x2D3FB0u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3FACu;
    // 0x2d3fb0: 0x24050002  addiu       $a1, $zero, 0x2 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CA280u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CA280u, 0x2D3FACu, 0x2D3FB4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3FB4u;
label_2d3fb4:
    // 0x2d3fb4: 0x200202d  daddu       $a0, $s0, $zero
    ctx->pc = 0x2d3fb4u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
label_2d3fb8:
    // 0x2d3fb8: 0xc0b2aa0  jal         func_2CAA80
label_2d3fbc:
    if (ctx->pc == 0x2D3FBCu) {
        ctx->pc = 0x2D3FBCu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3FB8u;
        // 0x2d3fbc: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3FC0u;
        goto label_2d3fc0;
    }
    ctx->pc = 0x2D3FB8u;
    SET_GPR_U32(ctx, 31, 0x2D3FC0u);
    ctx->pc = 0x2D3FBCu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D3FB8u;
    // 0x2d3fbc: 0x220282d  daddu       $a1, $s1, $zero (Delay Slot)
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x2CAA80u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x2CAA80u, 0x2D3FB8u, 0x2D3FC0u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3FC0u;
label_2d3fc0:
    // 0x2d3fc0: 0x7bb00020  lq          $s0, 0x20($sp)
    ctx->pc = 0x2d3fc0u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_2d3fc4:
    // 0x2d3fc4: 0x7bb10010  lq          $s1, 0x10($sp)
    ctx->pc = 0x2d3fc4u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_2d3fc8:
    // 0x2d3fc8: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3fc8u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d3fcc:
    // 0x2d3fcc: 0x3e00008  jr          $ra
label_2d3fd0:
    if (ctx->pc == 0x2D3FD0u) {
        ctx->pc = 0x2D3FD0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3FCCu;
        // 0x2d3fd0: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3FD4u;
        goto label_2d3fd4;
    }
    ctx->pc = 0x2D3FCCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D3FD0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3FCCu;
        // 0x2d3fd0: 0x27bd0030  addiu       $sp, $sp, 0x30 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 48));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D3FCCu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D3FD4u;
label_2d3fd4:
    // 0x2d3fd4: 0x0  nop
    ctx->pc = 0x2d3fd4u;
    // NOP
label_2d3fd8:
    // 0x2d3fd8: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d3fd8u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d3fdc:
    // 0x2d3fdc: 0x3c020048  lui         $v0, 0x48
    ctx->pc = 0x2d3fdcu;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)72 << 16));
label_2d3fe0:
    // 0x2d3fe0: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d3fe0u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d3fe4:
    // 0x2d3fe4: 0x24427480  addiu       $v0, $v0, 0x7480
    ctx->pc = 0x2d3fe4u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 29824));
label_2d3fe8:
    // 0x2d3fe8: 0x30a50001  andi        $a1, $a1, 0x1
    ctx->pc = 0x2d3fe8u;
    SET_GPR_U64(ctx, 5, GPR_U64(ctx, 5) & (uint64_t)(uint16_t)1);
label_2d3fec:
    // 0x2d3fec: 0x10a00003  beqz        $a1, . + 4 + (0x3 << 2)
label_2d3ff0:
    if (ctx->pc == 0x2D3FF0u) {
        ctx->pc = 0x2D3FF0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3FECu;
        // 0x2d3ff0: 0xac820034  sw          $v0, 0x34($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 52), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D3FF4u;
        goto label_2d3ff4;
    }
    ctx->pc = 0x2D3FECu;
    {
        const bool branch_taken_0x2d3fec = (GPR_U64(ctx, 5) == GPR_U64(ctx, 0));
        ctx->pc = 0x2D3FF0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D3FECu;
        // 0x2d3ff0: 0xac820034  sw          $v0, 0x34($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 52), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2d3fec) {
            ctx->pc = 0x2D3FFCu;
            goto label_2d3ffc;
        }
    }
    ctx->pc = 0x2D3FF4u;
label_2d3ff4:
    // 0x2d3ff4: 0xc0c5f94  jal         func_317E50
label_2d3ff8:
    if (ctx->pc == 0x2D3FF8u) {
        ctx->pc = 0x2D3FFCu;
        goto label_2d3ffc;
    }
    ctx->pc = 0x2D3FF4u;
    SET_GPR_U32(ctx, 31, 0x2D3FFCu);
    ctx->pc = 0x317E50u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x317E50u, 0x2D3FF4u, 0x2D3FFCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D3FFCu;
label_2d3ffc:
    // 0x2d3ffc: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d3ffcu;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d4000:
    // 0x2d4000: 0x3e00008  jr          $ra
label_2d4004:
    if (ctx->pc == 0x2D4004u) {
        ctx->pc = 0x2D4004u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4000u;
        // 0x2d4004: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D4008u;
        goto label_2d4008;
    }
    ctx->pc = 0x2D4000u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D4004u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4000u;
        // 0x2d4004: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D4000u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D4008u;
label_2d4008:
    // 0x2d4008: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d4008u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d400c:
    // 0x2d400c: 0x8f8223cc  lw          $v0, 0x23CC($gp)
    ctx->pc = 0x2d400cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 28), 9164)));
label_2d4010:
    // 0x2d4010: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d4010u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d4014:
    // 0x2d4014: 0x8c840000  lw          $a0, 0x0($a0)
    ctx->pc = 0x2d4014u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 0)));
label_2d4018:
    // 0x2d4018: 0x40f809  jalr        $v0
label_2d401c:
    if (ctx->pc == 0x2D401Cu) {
        ctx->pc = 0x2D401Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4018u;
        // 0x2d401c: 0x8ca50000  lw          $a1, 0x0($a1) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D4020u;
        goto label_2d4020;
    }
    ctx->pc = 0x2D4018u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x2D4020u);
        ctx->pc = 0x2D401Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4018u;
        // 0x2d401c: 0x8ca50000  lw          $a1, 0x0($a1) (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 5), 0)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D4018u, 0x2D4020u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x2D4020u;
label_2d4020:
    // 0x2d4020: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d4020u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d4024:
    // 0x2d4024: 0x3e00008  jr          $ra
label_2d4028:
    if (ctx->pc == 0x2D4028u) {
        ctx->pc = 0x2D4028u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4024u;
        // 0x2d4028: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D402Cu;
        goto label_2d402c;
    }
    ctx->pc = 0x2D4024u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D4028u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4024u;
        // 0x2d4028: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D4024u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D402Cu;
label_2d402c:
    // 0x2d402c: 0x0  nop
    ctx->pc = 0x2d402cu;
    // NOP
label_2d4030:
    // 0x2d4030: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d4030u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d4034:
    // 0x2d4034: 0x3c020048  lui         $v0, 0x48
    ctx->pc = 0x2d4034u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)72 << 16));
label_2d4038:
    // 0x2d4038: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d4038u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d403c:
    // 0x2d403c: 0x24427480  addiu       $v0, $v0, 0x7480
    ctx->pc = 0x2d403cu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 29824));
label_2d4040:
    // 0x2d4040: 0x30a50001  andi        $a1, $a1, 0x1
    ctx->pc = 0x2d4040u;
    SET_GPR_U64(ctx, 5, GPR_U64(ctx, 5) & (uint64_t)(uint16_t)1);
label_2d4044:
    // 0x2d4044: 0x10a00003  beqz        $a1, . + 4 + (0x3 << 2)
label_2d4048:
    if (ctx->pc == 0x2D4048u) {
        ctx->pc = 0x2D4048u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4044u;
        // 0x2d4048: 0xac820034  sw          $v0, 0x34($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 52), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D404Cu;
        goto label_2d404c;
    }
    ctx->pc = 0x2D4044u;
    {
        const bool branch_taken_0x2d4044 = (GPR_U64(ctx, 5) == GPR_U64(ctx, 0));
        ctx->pc = 0x2D4048u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4044u;
        // 0x2d4048: 0xac820034  sw          $v0, 0x34($a0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 4), 52), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x2d4044) {
            ctx->pc = 0x2D4054u;
            goto label_2d4054;
        }
    }
    ctx->pc = 0x2D404Cu;
label_2d404c:
    // 0x2d404c: 0xc0c5f94  jal         func_317E50
label_2d4050:
    if (ctx->pc == 0x2D4050u) {
        ctx->pc = 0x2D4054u;
        goto label_2d4054;
    }
    ctx->pc = 0x2D404Cu;
    SET_GPR_U32(ctx, 31, 0x2D4054u);
    ctx->pc = 0x317E50u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x317E50u, 0x2D404Cu, 0x2D4054u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x2D4054u;
label_2d4054:
    // 0x2d4054: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d4054u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d4058:
    // 0x2d4058: 0x3e00008  jr          $ra
label_2d405c:
    if (ctx->pc == 0x2D405Cu) {
        ctx->pc = 0x2D405Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4058u;
        // 0x2d405c: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D4060u;
        goto label_2d4060;
    }
    ctx->pc = 0x2D4058u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D405Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4058u;
        // 0x2d405c: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D4058u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D4060u;
label_2d4060:
    // 0x2d4060: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x2d4060u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
label_2d4064:
    // 0x2d4064: 0x24040001  addiu       $a0, $zero, 0x1
    ctx->pc = 0x2d4064u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_2d4068:
    // 0x2d4068: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x2d4068u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_2d406c:
    // 0x2d406c: 0xc0b4a62  jal         func_2D2988
label_2d4070:
    if (ctx->pc == 0x2D4070u) {
        ctx->pc = 0x2D4070u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D406Cu;
        // 0x2d4070: 0x3405ffff  ori         $a1, $zero, 0xFFFF (Delay Slot)
        SET_GPR_U64(ctx, 5, GPR_U64(ctx, 0) | (uint64_t)(uint16_t)65535);
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D4074u;
        goto label_2d4074;
    }
    ctx->pc = 0x2D406Cu;
    SET_GPR_U32(ctx, 31, 0x2D4074u);
    ctx->pc = 0x2D4070u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x2D406Cu;
    // 0x2d4070: 0x3405ffff  ori         $a1, $zero, 0xFFFF (Delay Slot)
    SET_GPR_U64(ctx, 5, GPR_U64(ctx, 0) | (uint64_t)(uint16_t)65535);
    ctx->in_delay_slot = false;
    ctx->pc = 0x2D2988u;
    goto label_2d2988;
    ctx->pc = 0x2D4074u;
label_2d4074:
    // 0x2d4074: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x2d4074u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_2d4078:
    // 0x2d4078: 0x3e00008  jr          $ra
label_2d407c:
    if (ctx->pc == 0x2D407Cu) {
        ctx->pc = 0x2D407Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4078u;
        // 0x2d407c: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D4080u;
        goto label_2d4080;
    }
    ctx->pc = 0x2D4078u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D407Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D4078u;
        // 0x2d407c: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D4078u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D4080u;
label_2d4080:
    // 0x2d4080: 0x27bdff80  addiu       $sp, $sp, -0x80
    ctx->pc = 0x2d4080u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967168));
label_2d4084:
    // 0x2d4084: 0x80102d  daddu       $v0, $a0, $zero
    ctx->pc = 0x2d4084u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_2d4088:
    // 0x2d4088: 0xffa50048  sd          $a1, 0x48($sp)
    ctx->pc = 0x2d4088u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 72), GPR_U64(ctx, 5));
label_2d408c:
    // 0x2d408c: 0xffa60050  sd          $a2, 0x50($sp)
    ctx->pc = 0x2d408cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 80), GPR_U64(ctx, 6));
label_2d4090:
    // 0x2d4090: 0xffa70058  sd          $a3, 0x58($sp)
    ctx->pc = 0x2d4090u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 88), GPR_U64(ctx, 7));
label_2d4094:
    // 0x2d4094: 0xffa80060  sd          $t0, 0x60($sp)
    ctx->pc = 0x2d4094u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 96), GPR_U64(ctx, 8));
label_2d4098:
    // 0x2d4098: 0xffa90068  sd          $t1, 0x68($sp)
    ctx->pc = 0x2d4098u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 104), GPR_U64(ctx, 9));
label_2d409c:
    // 0x2d409c: 0xffaa0070  sd          $t2, 0x70($sp)
    ctx->pc = 0x2d409cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 112), GPR_U64(ctx, 10));
label_2d40a0:
    // 0x2d40a0: 0xffab0078  sd          $t3, 0x78($sp)
    ctx->pc = 0x2d40a0u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 120), GPR_U64(ctx, 11));
label_2d40a4:
    // 0x2d40a4: 0xe7ac0038  swc1        $f12, 0x38($sp)
    ctx->pc = 0x2d40a4u;
    { float f = ctx->f[12]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 29), 56), bits); }
label_2d40a8:
    // 0x2d40a8: 0xe7ae003c  swc1        $f14, 0x3C($sp)
    ctx->pc = 0x2d40a8u;
    { float f = ctx->f[14]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 29), 60), bits); }
label_2d40ac:
    // 0x2d40ac: 0xe7b00040  swc1        $f16, 0x40($sp)
    ctx->pc = 0x2d40acu;
    { float f = ctx->f[16]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 29), 64), bits); }
label_2d40b0:
    // 0x2d40b0: 0xe7b20044  swc1        $f18, 0x44($sp)
    ctx->pc = 0x2d40b0u;
    { float f = ctx->f[18]; uint32_t bits; std::memcpy(&bits, &f, sizeof(bits)); WRITE32(ADD32(GPR_U32(ctx, 29), 68), bits); }
label_2d40b4:
    // 0x2d40b4: 0x3e00008  jr          $ra
label_2d40b8:
    if (ctx->pc == 0x2D40B8u) {
        ctx->pc = 0x2D40B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D40B4u;
        // 0x2d40b8: 0x27bd0080  addiu       $sp, $sp, 0x80 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 128));
        ctx->in_delay_slot = false;
        ctx->pc = 0x2D40BCu;
        goto label_2d40bc;
    }
    ctx->pc = 0x2D40B4u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x2D40B8u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x2D40B4u;
        // 0x2d40b8: 0x27bd0080  addiu       $sp, $sp, 0x80 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 128));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x2D40B4u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x2D40BCu;
label_2d40bc:
    // 0x2d40bc: 0x0  nop
    ctx->pc = 0x2d40bcu;
    // NOP
    ctx->pc = 0x2d40c0u;
}
