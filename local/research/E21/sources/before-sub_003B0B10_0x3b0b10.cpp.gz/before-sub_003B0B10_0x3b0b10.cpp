#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_003B0B10
// Address: 0x3b0b10 - 0x3b0b40
void sub_003B0B10_0x3b0b10(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_003B0B10_0x3b0b10");
#endif

    switch (ctx->pc) {
        case 0x3b0b30u: goto label_3b0b30;
        default: break;
    }

    ctx->pc = 0x3b0b10u;

    // 0x3b0b10: 0x80102d  daddu       $v0, $a0, $zero
    ctx->pc = 0x3b0b10u;
    SET_GPR_U64(ctx, 2, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
    // 0x3b0b14: 0x27bdfff0  addiu       $sp, $sp, -0x10
    ctx->pc = 0x3b0b14u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967280));
    // 0x3b0b18: 0xa0182d  daddu       $v1, $a1, $zero
    ctx->pc = 0x3b0b18u;
    SET_GPR_U64(ctx, 3, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
    // 0x3b0b1c: 0xc0202d  daddu       $a0, $a2, $zero
    ctx->pc = 0x3b0b1cu;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
    // 0x3b0b20: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x3b0b20u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
    // 0x3b0b24: 0x40282d  daddu       $a1, $v0, $zero
    ctx->pc = 0x3b0b24u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
    // 0x3b0b28: 0xc0ec2d0  jal         func_3B0B40
    ctx->pc = 0x3B0B28u;
    SET_GPR_U32(ctx, 31, 0x3B0B30u);
    ctx->pc = 0x3B0B2Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0B28u;
    // 0x3b0b2c: 0x60302d  daddu       $a2, $v1, $zero (Delay Slot)
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 3) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3B0B40u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3B0B40u, 0x3B0B28u, 0x3B0B30u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0B30u;
label_3b0b30:
    // 0x3b0b30: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x3b0b30u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
    // 0x3b0b34: 0x24020001  addiu       $v0, $zero, 0x1
    ctx->pc = 0x3b0b34u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
    // 0x3b0b38: 0x3e00008  jr          $ra
    ctx->pc = 0x3B0B38u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3B0B3Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0B38u;
        // 0x3b0b3c: 0x27bd0010  addiu       $sp, $sp, 0x10 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 16));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0B38u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3B0B40u;
}
