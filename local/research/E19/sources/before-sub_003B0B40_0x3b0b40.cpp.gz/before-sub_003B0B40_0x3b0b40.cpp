#include <stdexcept>
#include "ps2_runtime_macros.h"
#include "ps2_runtime.h"
#include "ps2_recompiled_functions.h"
#include "ps2_recompiled_stubs.h"

#include "ps2_syscalls.h"
#include "ps2_stubs.h"

#ifdef PS2_FUNCTION_LOG_TRACKER
#include "ps2_log.h"
#endif

// Function: sub_003B0B40
// Address: 0x3b0b40 - 0x3b0fb8
void sub_003B0B40_0x3b0b40(uint8_t* rdram, R5900Context* ctx, PS2Runtime *runtime) {
#ifdef PS2_FUNCTION_LOG_TRACKER
    PS_LOG_ENTRY("sub_003B0B40_0x3b0b40");
#endif

    switch (ctx->pc) {
        case 0x3b0b40u: goto label_3b0b40;
        case 0x3b0b44u: goto label_3b0b44;
        case 0x3b0b48u: goto label_3b0b48;
        case 0x3b0b4cu: goto label_3b0b4c;
        case 0x3b0b50u: goto label_3b0b50;
        case 0x3b0b54u: goto label_3b0b54;
        case 0x3b0b58u: goto label_3b0b58;
        case 0x3b0b5cu: goto label_3b0b5c;
        case 0x3b0b60u: goto label_3b0b60;
        case 0x3b0b64u: goto label_3b0b64;
        case 0x3b0b68u: goto label_3b0b68;
        case 0x3b0b6cu: goto label_3b0b6c;
        case 0x3b0b70u: goto label_3b0b70;
        case 0x3b0b74u: goto label_3b0b74;
        case 0x3b0b78u: goto label_3b0b78;
        case 0x3b0b7cu: goto label_3b0b7c;
        case 0x3b0b80u: goto label_3b0b80;
        case 0x3b0b84u: goto label_3b0b84;
        case 0x3b0b88u: goto label_3b0b88;
        case 0x3b0b8cu: goto label_3b0b8c;
        case 0x3b0b90u: goto label_3b0b90;
        case 0x3b0b94u: goto label_3b0b94;
        case 0x3b0b98u: goto label_3b0b98;
        case 0x3b0b9cu: goto label_3b0b9c;
        case 0x3b0ba0u: goto label_3b0ba0;
        case 0x3b0ba4u: goto label_3b0ba4;
        case 0x3b0ba8u: goto label_3b0ba8;
        case 0x3b0bacu: goto label_3b0bac;
        case 0x3b0bb0u: goto label_3b0bb0;
        case 0x3b0bb4u: goto label_3b0bb4;
        case 0x3b0bb8u: goto label_3b0bb8;
        case 0x3b0bbcu: goto label_3b0bbc;
        case 0x3b0bc0u: goto label_3b0bc0;
        case 0x3b0bc4u: goto label_3b0bc4;
        case 0x3b0bc8u: goto label_3b0bc8;
        case 0x3b0bccu: goto label_3b0bcc;
        case 0x3b0bd0u: goto label_3b0bd0;
        case 0x3b0bd4u: goto label_3b0bd4;
        case 0x3b0bd8u: goto label_3b0bd8;
        case 0x3b0bdcu: goto label_3b0bdc;
        case 0x3b0be0u: goto label_3b0be0;
        case 0x3b0be4u: goto label_3b0be4;
        case 0x3b0be8u: goto label_3b0be8;
        case 0x3b0becu: goto label_3b0bec;
        case 0x3b0bf0u: goto label_3b0bf0;
        case 0x3b0bf4u: goto label_3b0bf4;
        case 0x3b0bf8u: goto label_3b0bf8;
        case 0x3b0bfcu: goto label_3b0bfc;
        case 0x3b0c00u: goto label_3b0c00;
        case 0x3b0c04u: goto label_3b0c04;
        case 0x3b0c08u: goto label_3b0c08;
        case 0x3b0c0cu: goto label_3b0c0c;
        case 0x3b0c10u: goto label_3b0c10;
        case 0x3b0c14u: goto label_3b0c14;
        case 0x3b0c18u: goto label_3b0c18;
        case 0x3b0c1cu: goto label_3b0c1c;
        case 0x3b0c20u: goto label_3b0c20;
        case 0x3b0c24u: goto label_3b0c24;
        case 0x3b0c28u: goto label_3b0c28;
        case 0x3b0c2cu: goto label_3b0c2c;
        case 0x3b0c30u: goto label_3b0c30;
        case 0x3b0c34u: goto label_3b0c34;
        case 0x3b0c38u: goto label_3b0c38;
        case 0x3b0c3cu: goto label_3b0c3c;
        case 0x3b0c40u: goto label_3b0c40;
        case 0x3b0c44u: goto label_3b0c44;
        case 0x3b0c48u: goto label_3b0c48;
        case 0x3b0c4cu: goto label_3b0c4c;
        case 0x3b0c50u: goto label_3b0c50;
        case 0x3b0c54u: goto label_3b0c54;
        case 0x3b0c58u: goto label_3b0c58;
        case 0x3b0c5cu: goto label_3b0c5c;
        case 0x3b0c60u: goto label_3b0c60;
        case 0x3b0c64u: goto label_3b0c64;
        case 0x3b0c68u: goto label_3b0c68;
        case 0x3b0c6cu: goto label_3b0c6c;
        case 0x3b0c70u: goto label_3b0c70;
        case 0x3b0c74u: goto label_3b0c74;
        case 0x3b0c78u: goto label_3b0c78;
        case 0x3b0c7cu: goto label_3b0c7c;
        case 0x3b0c80u: goto label_3b0c80;
        case 0x3b0c84u: goto label_3b0c84;
        case 0x3b0c88u: goto label_3b0c88;
        case 0x3b0c8cu: goto label_3b0c8c;
        case 0x3b0c90u: goto label_3b0c90;
        case 0x3b0c94u: goto label_3b0c94;
        case 0x3b0c98u: goto label_3b0c98;
        case 0x3b0c9cu: goto label_3b0c9c;
        case 0x3b0ca0u: goto label_3b0ca0;
        case 0x3b0ca4u: goto label_3b0ca4;
        case 0x3b0ca8u: goto label_3b0ca8;
        case 0x3b0cacu: goto label_3b0cac;
        case 0x3b0cb0u: goto label_3b0cb0;
        case 0x3b0cb4u: goto label_3b0cb4;
        case 0x3b0cb8u: goto label_3b0cb8;
        case 0x3b0cbcu: goto label_3b0cbc;
        case 0x3b0cc0u: goto label_3b0cc0;
        case 0x3b0cc4u: goto label_3b0cc4;
        case 0x3b0cc8u: goto label_3b0cc8;
        case 0x3b0cccu: goto label_3b0ccc;
        case 0x3b0cd0u: goto label_3b0cd0;
        case 0x3b0cd4u: goto label_3b0cd4;
        case 0x3b0cd8u: goto label_3b0cd8;
        case 0x3b0cdcu: goto label_3b0cdc;
        case 0x3b0ce0u: goto label_3b0ce0;
        case 0x3b0ce4u: goto label_3b0ce4;
        case 0x3b0ce8u: goto label_3b0ce8;
        case 0x3b0cecu: goto label_3b0cec;
        case 0x3b0cf0u: goto label_3b0cf0;
        case 0x3b0cf4u: goto label_3b0cf4;
        case 0x3b0cf8u: goto label_3b0cf8;
        case 0x3b0cfcu: goto label_3b0cfc;
        case 0x3b0d00u: goto label_3b0d00;
        case 0x3b0d04u: goto label_3b0d04;
        case 0x3b0d08u: goto label_3b0d08;
        case 0x3b0d0cu: goto label_3b0d0c;
        case 0x3b0d10u: goto label_3b0d10;
        case 0x3b0d14u: goto label_3b0d14;
        case 0x3b0d18u: goto label_3b0d18;
        case 0x3b0d1cu: goto label_3b0d1c;
        case 0x3b0d20u: goto label_3b0d20;
        case 0x3b0d24u: goto label_3b0d24;
        case 0x3b0d28u: goto label_3b0d28;
        case 0x3b0d2cu: goto label_3b0d2c;
        case 0x3b0d30u: goto label_3b0d30;
        case 0x3b0d34u: goto label_3b0d34;
        case 0x3b0d38u: goto label_3b0d38;
        case 0x3b0d3cu: goto label_3b0d3c;
        case 0x3b0d40u: goto label_3b0d40;
        case 0x3b0d44u: goto label_3b0d44;
        case 0x3b0d48u: goto label_3b0d48;
        case 0x3b0d4cu: goto label_3b0d4c;
        case 0x3b0d50u: goto label_3b0d50;
        case 0x3b0d54u: goto label_3b0d54;
        case 0x3b0d58u: goto label_3b0d58;
        case 0x3b0d5cu: goto label_3b0d5c;
        case 0x3b0d60u: goto label_3b0d60;
        case 0x3b0d64u: goto label_3b0d64;
        case 0x3b0d68u: goto label_3b0d68;
        case 0x3b0d6cu: goto label_3b0d6c;
        case 0x3b0d70u: goto label_3b0d70;
        case 0x3b0d74u: goto label_3b0d74;
        case 0x3b0d78u: goto label_3b0d78;
        case 0x3b0d7cu: goto label_3b0d7c;
        case 0x3b0d80u: goto label_3b0d80;
        case 0x3b0d84u: goto label_3b0d84;
        case 0x3b0d88u: goto label_3b0d88;
        case 0x3b0d8cu: goto label_3b0d8c;
        case 0x3b0d90u: goto label_3b0d90;
        case 0x3b0d94u: goto label_3b0d94;
        case 0x3b0d98u: goto label_3b0d98;
        case 0x3b0d9cu: goto label_3b0d9c;
        case 0x3b0da0u: goto label_3b0da0;
        case 0x3b0da4u: goto label_3b0da4;
        case 0x3b0da8u: goto label_3b0da8;
        case 0x3b0dacu: goto label_3b0dac;
        case 0x3b0db0u: goto label_3b0db0;
        case 0x3b0db4u: goto label_3b0db4;
        case 0x3b0db8u: goto label_3b0db8;
        case 0x3b0dbcu: goto label_3b0dbc;
        case 0x3b0dc0u: goto label_3b0dc0;
        case 0x3b0dc4u: goto label_3b0dc4;
        case 0x3b0dc8u: goto label_3b0dc8;
        case 0x3b0dccu: goto label_3b0dcc;
        case 0x3b0dd0u: goto label_3b0dd0;
        case 0x3b0dd4u: goto label_3b0dd4;
        case 0x3b0dd8u: goto label_3b0dd8;
        case 0x3b0ddcu: goto label_3b0ddc;
        case 0x3b0de0u: goto label_3b0de0;
        case 0x3b0de4u: goto label_3b0de4;
        case 0x3b0de8u: goto label_3b0de8;
        case 0x3b0decu: goto label_3b0dec;
        case 0x3b0df0u: goto label_3b0df0;
        case 0x3b0df4u: goto label_3b0df4;
        case 0x3b0df8u: goto label_3b0df8;
        case 0x3b0dfcu: goto label_3b0dfc;
        case 0x3b0e00u: goto label_3b0e00;
        case 0x3b0e04u: goto label_3b0e04;
        case 0x3b0e08u: goto label_3b0e08;
        case 0x3b0e0cu: goto label_3b0e0c;
        case 0x3b0e10u: goto label_3b0e10;
        case 0x3b0e14u: goto label_3b0e14;
        case 0x3b0e18u: goto label_3b0e18;
        case 0x3b0e1cu: goto label_3b0e1c;
        case 0x3b0e20u: goto label_3b0e20;
        case 0x3b0e24u: goto label_3b0e24;
        case 0x3b0e28u: goto label_3b0e28;
        case 0x3b0e2cu: goto label_3b0e2c;
        case 0x3b0e30u: goto label_3b0e30;
        case 0x3b0e34u: goto label_3b0e34;
        case 0x3b0e38u: goto label_3b0e38;
        case 0x3b0e3cu: goto label_3b0e3c;
        case 0x3b0e40u: goto label_3b0e40;
        case 0x3b0e44u: goto label_3b0e44;
        case 0x3b0e48u: goto label_3b0e48;
        case 0x3b0e4cu: goto label_3b0e4c;
        case 0x3b0e50u: goto label_3b0e50;
        case 0x3b0e54u: goto label_3b0e54;
        case 0x3b0e58u: goto label_3b0e58;
        case 0x3b0e5cu: goto label_3b0e5c;
        case 0x3b0e60u: goto label_3b0e60;
        case 0x3b0e64u: goto label_3b0e64;
        case 0x3b0e68u: goto label_3b0e68;
        case 0x3b0e6cu: goto label_3b0e6c;
        case 0x3b0e70u: goto label_3b0e70;
        case 0x3b0e74u: goto label_3b0e74;
        case 0x3b0e78u: goto label_3b0e78;
        case 0x3b0e7cu: goto label_3b0e7c;
        case 0x3b0e80u: goto label_3b0e80;
        case 0x3b0e84u: goto label_3b0e84;
        case 0x3b0e88u: goto label_3b0e88;
        case 0x3b0e8cu: goto label_3b0e8c;
        case 0x3b0e90u: goto label_3b0e90;
        case 0x3b0e94u: goto label_3b0e94;
        case 0x3b0e98u: goto label_3b0e98;
        case 0x3b0e9cu: goto label_3b0e9c;
        case 0x3b0ea0u: goto label_3b0ea0;
        case 0x3b0ea4u: goto label_3b0ea4;
        case 0x3b0ea8u: goto label_3b0ea8;
        case 0x3b0eacu: goto label_3b0eac;
        case 0x3b0eb0u: goto label_3b0eb0;
        case 0x3b0eb4u: goto label_3b0eb4;
        case 0x3b0eb8u: goto label_3b0eb8;
        case 0x3b0ebcu: goto label_3b0ebc;
        case 0x3b0ec0u: goto label_3b0ec0;
        case 0x3b0ec4u: goto label_3b0ec4;
        case 0x3b0ec8u: goto label_3b0ec8;
        case 0x3b0eccu: goto label_3b0ecc;
        case 0x3b0ed0u: goto label_3b0ed0;
        case 0x3b0ed4u: goto label_3b0ed4;
        case 0x3b0ed8u: goto label_3b0ed8;
        case 0x3b0edcu: goto label_3b0edc;
        case 0x3b0ee0u: goto label_3b0ee0;
        case 0x3b0ee4u: goto label_3b0ee4;
        case 0x3b0ee8u: goto label_3b0ee8;
        case 0x3b0eecu: goto label_3b0eec;
        case 0x3b0ef0u: goto label_3b0ef0;
        case 0x3b0ef4u: goto label_3b0ef4;
        case 0x3b0ef8u: goto label_3b0ef8;
        case 0x3b0efcu: goto label_3b0efc;
        case 0x3b0f00u: goto label_3b0f00;
        case 0x3b0f04u: goto label_3b0f04;
        case 0x3b0f08u: goto label_3b0f08;
        case 0x3b0f0cu: goto label_3b0f0c;
        case 0x3b0f10u: goto label_3b0f10;
        case 0x3b0f14u: goto label_3b0f14;
        case 0x3b0f18u: goto label_3b0f18;
        case 0x3b0f1cu: goto label_3b0f1c;
        case 0x3b0f20u: goto label_3b0f20;
        case 0x3b0f24u: goto label_3b0f24;
        case 0x3b0f28u: goto label_3b0f28;
        case 0x3b0f2cu: goto label_3b0f2c;
        case 0x3b0f30u: goto label_3b0f30;
        case 0x3b0f34u: goto label_3b0f34;
        case 0x3b0f38u: goto label_3b0f38;
        case 0x3b0f3cu: goto label_3b0f3c;
        case 0x3b0f40u: goto label_3b0f40;
        case 0x3b0f44u: goto label_3b0f44;
        case 0x3b0f48u: goto label_3b0f48;
        case 0x3b0f4cu: goto label_3b0f4c;
        case 0x3b0f50u: goto label_3b0f50;
        case 0x3b0f54u: goto label_3b0f54;
        case 0x3b0f58u: goto label_3b0f58;
        case 0x3b0f5cu: goto label_3b0f5c;
        case 0x3b0f60u: goto label_3b0f60;
        case 0x3b0f64u: goto label_3b0f64;
        case 0x3b0f68u: goto label_3b0f68;
        case 0x3b0f6cu: goto label_3b0f6c;
        case 0x3b0f70u: goto label_3b0f70;
        case 0x3b0f74u: goto label_3b0f74;
        case 0x3b0f78u: goto label_3b0f78;
        case 0x3b0f7cu: goto label_3b0f7c;
        case 0x3b0f80u: goto label_3b0f80;
        case 0x3b0f84u: goto label_3b0f84;
        case 0x3b0f88u: goto label_3b0f88;
        case 0x3b0f8cu: goto label_3b0f8c;
        case 0x3b0f90u: goto label_3b0f90;
        case 0x3b0f94u: goto label_3b0f94;
        case 0x3b0f98u: goto label_3b0f98;
        case 0x3b0f9cu: goto label_3b0f9c;
        case 0x3b0fa0u: goto label_3b0fa0;
        case 0x3b0fa4u: goto label_3b0fa4;
        case 0x3b0fa8u: goto label_3b0fa8;
        case 0x3b0facu: goto label_3b0fac;
        case 0x3b0fb0u: goto label_3b0fb0;
        case 0x3b0fb4u: goto label_3b0fb4;
        default: break;
    }

    ctx->pc = 0x3b0b40u;

label_3b0b40:
    // 0x3b0b40: 0x27bdffa0  addiu       $sp, $sp, -0x60
    ctx->pc = 0x3b0b40u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967200));
label_3b0b44:
    // 0x3b0b44: 0x7fb10040  sq          $s1, 0x40($sp)
    ctx->pc = 0x3b0b44u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 64), GPR_VEC(ctx, 17));
label_3b0b48:
    // 0x3b0b48: 0x7fb20030  sq          $s2, 0x30($sp)
    ctx->pc = 0x3b0b48u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 48), GPR_VEC(ctx, 18));
label_3b0b4c:
    // 0x3b0b4c: 0x80882d  daddu       $s1, $a0, $zero
    ctx->pc = 0x3b0b4cu;
    SET_GPR_U64(ctx, 17, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_3b0b50:
    // 0x3b0b50: 0x7fb30020  sq          $s3, 0x20($sp)
    ctx->pc = 0x3b0b50u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 19));
label_3b0b54:
    // 0x3b0b54: 0x902d  daddu       $s2, $zero, $zero
    ctx->pc = 0x3b0b54u;
    SET_GPR_U64(ctx, 18, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_3b0b58:
    // 0x3b0b58: 0x7fb40010  sq          $s4, 0x10($sp)
    ctx->pc = 0x3b0b58u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 16), GPR_VEC(ctx, 20));
label_3b0b5c:
    // 0x3b0b5c: 0x7fb00050  sq          $s0, 0x50($sp)
    ctx->pc = 0x3b0b5cu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 80), GPR_VEC(ctx, 16));
label_3b0b60:
    // 0x3b0b60: 0xa0a02d  daddu       $s4, $a1, $zero
    ctx->pc = 0x3b0b60u;
    SET_GPR_U64(ctx, 20, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_3b0b64:
    // 0x3b0b64: 0xffbf0000  sd          $ra, 0x0($sp)
    ctx->pc = 0x3b0b64u;
    WRITE64(ADD32(GPR_U32(ctx, 29), 0), GPR_U64(ctx, 31));
label_3b0b68:
    // 0x3b0b68: 0xc0ec1ac  jal         func_3B06B0
label_3b0b6c:
    if (ctx->pc == 0x3B0B6Cu) {
        ctx->pc = 0x3B0B6Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0B68u;
        // 0x3b0b6c: 0x8e240028  lw          $a0, 0x28($s1) (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 40)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0B70u;
        goto label_3b0b70;
    }
    ctx->pc = 0x3B0B68u;
    SET_GPR_U32(ctx, 31, 0x3B0B70u);
    ctx->pc = 0x3B0B6Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0B68u;
    // 0x3b0b6c: 0x8e240028  lw          $a0, 0x28($s1) (Delay Slot)
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 40)));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3B06B0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3B06B0u, 0x3B0B68u, 0x3B0B70u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0B70u;
label_3b0b70:
    // 0x3b0b70: 0x40982d  daddu       $s3, $v0, $zero
    ctx->pc = 0x3b0b70u;
    SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_3b0b74:
    // 0x3b0b74: 0x56600001  bnel        $s3, $zero, . + 4 + (0x1 << 2)
label_3b0b78:
    if (ctx->pc == 0x3B0B78u) {
        ctx->pc = 0x3B0B78u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0B74u;
        // 0x3b0b78: 0x8e720004  lw          $s2, 0x4($s3) (Delay Slot)
        SET_GPR_S32(ctx, 18, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 4)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0B7Cu;
        goto label_3b0b7c;
    }
    ctx->pc = 0x3B0B74u;
    {
        const bool branch_taken_0x3b0b74 = (GPR_U64(ctx, 19) != GPR_U64(ctx, 0));
        if (branch_taken_0x3b0b74) {
            ctx->pc = 0x3B0B78u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x3B0B74u;
            // 0x3b0b78: 0x8e720004  lw          $s2, 0x4($s3) (Delay Slot)
            SET_GPR_S32(ctx, 18, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 4)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x3B0B7Cu;
            goto label_3b0b7c;
        }
    }
    ctx->pc = 0x3B0B7Cu;
label_3b0b7c:
    // 0x3b0b7c: 0x12400017  beqz        $s2, . + 4 + (0x17 << 2)
label_3b0b80:
    if (ctx->pc == 0x3B0B80u) {
        ctx->pc = 0x3B0B80u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0B7Cu;
        // 0x3b0b80: 0x2403fff0  addiu       $v1, $zero, -0x10 (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967280));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0B84u;
        goto label_3b0b84;
    }
    ctx->pc = 0x3B0B7Cu;
    {
        const bool branch_taken_0x3b0b7c = (GPR_U64(ctx, 18) == GPR_U64(ctx, 0));
        ctx->pc = 0x3B0B80u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0B7Cu;
        // 0x3b0b80: 0x2403fff0  addiu       $v1, $zero, -0x10 (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967280));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0b7c) {
            ctx->pc = 0x3B0BDCu;
            goto label_3b0bdc;
        }
    }
    ctx->pc = 0x3B0B84u;
label_3b0b84:
    // 0x3b0b84: 0x8e700008  lw          $s0, 0x8($s3)
    ctx->pc = 0x3b0b84u;
    SET_GPR_S32(ctx, 16, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 8)));
label_3b0b88:
    // 0x3b0b88: 0x8e24007c  lw          $a0, 0x7C($s1)
    ctx->pc = 0x3b0b88u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 124)));
label_3b0b8c:
    // 0x3b0b8c: 0x240282d  daddu       $a1, $s2, $zero
    ctx->pc = 0x3b0b8cu;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_3b0b90:
    // 0x3b0b90: 0x26020007  addiu       $v0, $s0, 0x7
    ctx->pc = 0x3b0b90u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 16), 7));
label_3b0b94:
    // 0x3b0b94: 0x2610fff8  addiu       $s0, $s0, -0x8
    ctx->pc = 0x3b0b94u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 4294967288));
label_3b0b98:
    // 0x3b0b98: 0x439024  and         $s2, $v0, $v1
    ctx->pc = 0x3b0b98u;
    SET_GPR_U64(ctx, 18, GPR_U64(ctx, 2) & GPR_U64(ctx, 3));
label_3b0b9c:
    // 0x3b0b9c: 0xc0f995d  jal         func_3E6574
label_3b0ba0:
    if (ctx->pc == 0x3B0BA0u) {
        ctx->pc = 0x3B0BA0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0B9Cu;
        // 0x3b0ba0: 0x200302d  daddu       $a2, $s0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0BA4u;
        goto label_3b0ba4;
    }
    ctx->pc = 0x3B0B9Cu;
    SET_GPR_U32(ctx, 31, 0x3B0BA4u);
    ctx->pc = 0x3B0BA0u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0B9Cu;
    // 0x3b0ba0: 0x200302d  daddu       $a2, $s0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3E6574u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3E6574u, 0x3B0B9Cu, 0x3B0BA4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0BA4u;
label_3b0ba4:
    // 0x3b0ba4: 0x26440010  addiu       $a0, $s2, 0x10
    ctx->pc = 0x3b0ba4u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 18), 16));
label_3b0ba8:
    // 0x3b0ba8: 0x204102a  slt         $v0, $s0, $a0
    ctx->pc = 0x3b0ba8u;
    SET_GPR_U64(ctx, 2, ((int64_t)GPR_S64(ctx, 16) < (int64_t)GPR_S64(ctx, 4)) ? 1 : 0);
label_3b0bac:
    // 0x3b0bac: 0x10400015  beqz        $v0, . + 4 + (0x15 << 2)
label_3b0bb0:
    if (ctx->pc == 0x3B0BB0u) {
        ctx->pc = 0x3B0BB4u;
        goto label_3b0bb4;
    }
    ctx->pc = 0x3B0BACu;
    {
        const bool branch_taken_0x3b0bac = (GPR_U64(ctx, 2) == GPR_U64(ctx, 0));
        if (branch_taken_0x3b0bac) {
            ctx->pc = 0x3B0C04u;
            goto label_3b0c04;
        }
    }
    ctx->pc = 0x3B0BB4u;
label_3b0bb4:
    // 0x3b0bb4: 0x0  nop
    ctx->pc = 0x3b0bb4u;
    // NOP
label_3b0bb8:
    // 0x3b0bb8: 0x8e22007c  lw          $v0, 0x7C($s1)
    ctx->pc = 0x3b0bb8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 124)));
label_3b0bbc:
    // 0x3b0bbc: 0x501021  addu        $v0, $v0, $s0
    ctx->pc = 0x3b0bbcu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), GPR_U32(ctx, 16)));
label_3b0bc0:
    // 0x3b0bc0: 0x26100004  addiu       $s0, $s0, 0x4
    ctx->pc = 0x3b0bc0u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 4));
label_3b0bc4:
    // 0x3b0bc4: 0x204182a  slt         $v1, $s0, $a0
    ctx->pc = 0x3b0bc4u;
    SET_GPR_U64(ctx, 3, ((int64_t)GPR_S64(ctx, 16) < (int64_t)GPR_S64(ctx, 4)) ? 1 : 0);
label_3b0bc8:
    // 0x3b0bc8: 0x0  nop
    ctx->pc = 0x3b0bc8u;
    // NOP
label_3b0bcc:
    // 0x3b0bcc: 0x1460fffa  bnez        $v1, . + 4 + (-0x6 << 2)
label_3b0bd0:
    if (ctx->pc == 0x3B0BD0u) {
        ctx->pc = 0x3B0BD0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0BCCu;
        // 0x3b0bd0: 0xac400000  sw          $zero, 0x0($v0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 2), 0), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0BD4u;
        goto label_3b0bd4;
    }
    ctx->pc = 0x3B0BCCu;
    {
        const bool branch_taken_0x3b0bcc = (GPR_U64(ctx, 3) != GPR_U64(ctx, 0));
        ctx->pc = 0x3B0BD0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0BCCu;
        // 0x3b0bd0: 0xac400000  sw          $zero, 0x0($v0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 2), 0), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0bcc) {
            ctx->pc = 0x3B0BB8u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_3b0bb8;
        }
    }
    ctx->pc = 0x3B0BD4u;
label_3b0bd4:
    // 0x3b0bd4: 0x1000000b  b           . + 4 + (0xB << 2)
label_3b0bd8:
    if (ctx->pc == 0x3B0BD8u) {
        ctx->pc = 0x3B0BDCu;
        goto label_3b0bdc;
    }
    ctx->pc = 0x3B0BD4u;
    {
        const bool branch_taken_0x3b0bd4 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        if (branch_taken_0x3b0bd4) {
            ctx->pc = 0x3B0C04u;
            goto label_3b0c04;
        }
    }
    ctx->pc = 0x3B0BDCu;
label_3b0bdc:
    // 0x3b0bdc: 0x24120010  addiu       $s2, $zero, 0x10
    ctx->pc = 0x3b0bdcu;
    SET_GPR_S32(ctx, 18, (int32_t)ADD32(GPR_U32(ctx, 0), 16));
label_3b0be0:
    // 0x3b0be0: 0x802d  daddu       $s0, $zero, $zero
    ctx->pc = 0x3b0be0u;
    SET_GPR_U64(ctx, 16, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_3b0be4:
    // 0x3b0be4: 0x3c04b701  lui         $a0, 0xB701
    ctx->pc = 0x3b0be4u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)46849 << 16));
label_3b0be8:
    // 0x3b0be8: 0x8e22007c  lw          $v0, 0x7C($s1)
    ctx->pc = 0x3b0be8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 124)));
label_3b0bec:
    // 0x3b0bec: 0x501021  addu        $v0, $v0, $s0
    ctx->pc = 0x3b0becu;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), GPR_U32(ctx, 16)));
label_3b0bf0:
    // 0x3b0bf0: 0x26100004  addiu       $s0, $s0, 0x4
    ctx->pc = 0x3b0bf0u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 4));
label_3b0bf4:
    // 0x3b0bf4: 0x2a030010  slti        $v1, $s0, 0x10
    ctx->pc = 0x3b0bf4u;
    SET_GPR_U64(ctx, 3, ((int64_t)GPR_S64(ctx, 16) < (int64_t)(int32_t)16) ? 1 : 0);
label_3b0bf8:
    // 0x3b0bf8: 0x0  nop
    ctx->pc = 0x3b0bf8u;
    // NOP
label_3b0bfc:
    // 0x3b0bfc: 0x1460fffa  bnez        $v1, . + 4 + (-0x6 << 2)
label_3b0c00:
    if (ctx->pc == 0x3B0C00u) {
        ctx->pc = 0x3B0C00u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0BFCu;
        // 0x3b0c00: 0xac440000  sw          $a0, 0x0($v0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 2), 0), GPR_U32(ctx, 4));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0C04u;
        goto label_3b0c04;
    }
    ctx->pc = 0x3B0BFCu;
    {
        const bool branch_taken_0x3b0bfc = (GPR_U64(ctx, 3) != GPR_U64(ctx, 0));
        ctx->pc = 0x3B0C00u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0BFCu;
        // 0x3b0c00: 0xac440000  sw          $a0, 0x0($v0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 2), 0), GPR_U32(ctx, 4));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0bfc) {
            ctx->pc = 0x3B0BE8u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_3b0be8;
        }
    }
    ctx->pc = 0x3B0C04u;
label_3b0c04:
    // 0x3b0c04: 0x52600005  beql        $s3, $zero, . + 4 + (0x5 << 2)
label_3b0c08:
    if (ctx->pc == 0x3B0C08u) {
        ctx->pc = 0x3B0C08u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0C04u;
        // 0x3b0c08: 0x8e220014  lw          $v0, 0x14($s1) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 20)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0C0Cu;
        goto label_3b0c0c;
    }
    ctx->pc = 0x3B0C04u;
    {
        const bool branch_taken_0x3b0c04 = (GPR_U64(ctx, 19) == GPR_U64(ctx, 0));
        if (branch_taken_0x3b0c04) {
            ctx->pc = 0x3B0C08u;
            ctx->in_delay_slot = true;
            ctx->branch_pc = 0x3B0C04u;
            // 0x3b0c08: 0x8e220014  lw          $v0, 0x14($s1) (Delay Slot)
            SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 20)));
            ctx->in_delay_slot = false;
            ctx->pc = 0x3B0C1Cu;
            goto label_3b0c1c;
        }
    }
    ctx->pc = 0x3B0C0Cu;
label_3b0c0c:
    // 0x3b0c0c: 0x8e240028  lw          $a0, 0x28($s1)
    ctx->pc = 0x3b0c0cu;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 40)));
label_3b0c10:
    // 0x3b0c10: 0xc0ec1be  jal         func_3B06F8
label_3b0c14:
    if (ctx->pc == 0x3B0C14u) {
        ctx->pc = 0x3B0C14u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0C10u;
        // 0x3b0c14: 0x260282d  daddu       $a1, $s3, $zero (Delay Slot)
        SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0C18u;
        goto label_3b0c18;
    }
    ctx->pc = 0x3B0C10u;
    SET_GPR_U32(ctx, 31, 0x3B0C18u);
    ctx->pc = 0x3B0C14u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0C10u;
    // 0x3b0c14: 0x260282d  daddu       $a1, $s3, $zero (Delay Slot)
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 19) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3B06F8u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3B06F8u, 0x3B0C10u, 0x3B0C18u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0C18u;
label_3b0c18:
    // 0x3b0c18: 0x8e220014  lw          $v0, 0x14($s1)
    ctx->pc = 0x3b0c18u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 20)));
label_3b0c1c:
    // 0x3b0c1c: 0x280202d  daddu       $a0, $s4, $zero
    ctx->pc = 0x3b0c1cu;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 20) + (uint64_t)GPR_U64(ctx, 0));
label_3b0c20:
    // 0x3b0c20: 0x8e250078  lw          $a1, 0x78($s1)
    ctx->pc = 0x3b0c20u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 17), 120)));
label_3b0c24:
    // 0x3b0c24: 0x240302d  daddu       $a2, $s2, $zero
    ctx->pc = 0x3b0c24u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_3b0c28:
    // 0x3b0c28: 0x24420001  addiu       $v0, $v0, 0x1
    ctx->pc = 0x3b0c28u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 1));
label_3b0c2c:
    // 0x3b0c2c: 0xc100a74  jal         func_4029D0
label_3b0c30:
    if (ctx->pc == 0x3B0C30u) {
        ctx->pc = 0x3B0C30u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0C2Cu;
        // 0x3b0c30: 0xae220014  sw          $v0, 0x14($s1) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 17), 20), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0C34u;
        goto label_3b0c34;
    }
    ctx->pc = 0x3B0C2Cu;
    SET_GPR_U32(ctx, 31, 0x3B0C34u);
    ctx->pc = 0x3B0C30u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0C2Cu;
    // 0x3b0c30: 0xae220014  sw          $v0, 0x14($s1) (Delay Slot)
    WRITE32(ADD32(GPR_U32(ctx, 17), 20), GPR_U32(ctx, 2));
    ctx->in_delay_slot = false;
    ctx->pc = 0x4029D0u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x4029D0u, 0x3B0C2Cu, 0x3B0C34u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0C34u;
label_3b0c34:
    // 0x3b0c34: 0x7bb00050  lq          $s0, 0x50($sp)
    ctx->pc = 0x3b0c34u;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 80)));
label_3b0c38:
    // 0x3b0c38: 0x7bb10040  lq          $s1, 0x40($sp)
    ctx->pc = 0x3b0c38u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 64)));
label_3b0c3c:
    // 0x3b0c3c: 0x7bb20030  lq          $s2, 0x30($sp)
    ctx->pc = 0x3b0c3cu;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 48)));
label_3b0c40:
    // 0x3b0c40: 0x7bb30020  lq          $s3, 0x20($sp)
    ctx->pc = 0x3b0c40u;
    SET_GPR_VEC(ctx, 19, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_3b0c44:
    // 0x3b0c44: 0x7bb40010  lq          $s4, 0x10($sp)
    ctx->pc = 0x3b0c44u;
    SET_GPR_VEC(ctx, 20, READ128(ADD32(GPR_U32(ctx, 29), 16)));
label_3b0c48:
    // 0x3b0c48: 0xdfbf0000  ld          $ra, 0x0($sp)
    ctx->pc = 0x3b0c48u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 0)));
label_3b0c4c:
    // 0x3b0c4c: 0x3e00008  jr          $ra
label_3b0c50:
    if (ctx->pc == 0x3B0C50u) {
        ctx->pc = 0x3B0C50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0C4Cu;
        // 0x3b0c50: 0x27bd0060  addiu       $sp, $sp, 0x60 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 96));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0C54u;
        goto label_3b0c54;
    }
    ctx->pc = 0x3B0C4Cu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3B0C50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0C4Cu;
        // 0x3b0c50: 0x27bd0060  addiu       $sp, $sp, 0x60 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 96));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0C4Cu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3B0C54u;
label_3b0c54:
    // 0x3b0c54: 0x0  nop
    ctx->pc = 0x3b0c54u;
    // NOP
label_3b0c58:
    // 0x3b0c58: 0x27bdff50  addiu       $sp, $sp, -0xB0
    ctx->pc = 0x3b0c58u;
    SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 4294967120));
label_3b0c5c:
    // 0x3b0c5c: 0x7fb20080  sq          $s2, 0x80($sp)
    ctx->pc = 0x3b0c5cu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 128), GPR_VEC(ctx, 18));
label_3b0c60:
    // 0x3b0c60: 0x7fb30070  sq          $s3, 0x70($sp)
    ctx->pc = 0x3b0c60u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 112), GPR_VEC(ctx, 19));
label_3b0c64:
    // 0x3b0c64: 0x80902d  daddu       $s2, $a0, $zero
    ctx->pc = 0x3b0c64u;
    SET_GPR_U64(ctx, 18, (uint64_t)GPR_U64(ctx, 4) + (uint64_t)GPR_U64(ctx, 0));
label_3b0c68:
    // 0x3b0c68: 0x7fbe0020  sq          $fp, 0x20($sp)
    ctx->pc = 0x3b0c68u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 32), GPR_VEC(ctx, 30));
label_3b0c6c:
    // 0x3b0c6c: 0xc0982d  daddu       $s3, $a2, $zero
    ctx->pc = 0x3b0c6cu;
    SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
label_3b0c70:
    // 0x3b0c70: 0x7fb000a0  sq          $s0, 0xA0($sp)
    ctx->pc = 0x3b0c70u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 160), GPR_VEC(ctx, 16));
label_3b0c74:
    // 0x3b0c74: 0x3c1e0051  lui         $fp, 0x51
    ctx->pc = 0x3b0c74u;
    SET_GPR_S32(ctx, 30, (int32_t)((uint32_t)81 << 16));
label_3b0c78:
    // 0x3b0c78: 0x7fb10090  sq          $s1, 0x90($sp)
    ctx->pc = 0x3b0c78u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 144), GPR_VEC(ctx, 17));
label_3b0c7c:
    // 0x3b0c7c: 0x7fb40060  sq          $s4, 0x60($sp)
    ctx->pc = 0x3b0c7cu;
    WRITE128(ADD32(GPR_U32(ctx, 29), 96), GPR_VEC(ctx, 20));
label_3b0c80:
    // 0x3b0c80: 0x7fb50050  sq          $s5, 0x50($sp)
    ctx->pc = 0x3b0c80u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 80), GPR_VEC(ctx, 21));
label_3b0c84:
    // 0x3b0c84: 0x7fb60040  sq          $s6, 0x40($sp)
    ctx->pc = 0x3b0c84u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 64), GPR_VEC(ctx, 22));
label_3b0c88:
    // 0x3b0c88: 0x7fb70030  sq          $s7, 0x30($sp)
    ctx->pc = 0x3b0c88u;
    WRITE128(ADD32(GPR_U32(ctx, 29), 48), GPR_VEC(ctx, 23));
label_3b0c8c:
    // 0x3b0c8c: 0xffbf0010  sd          $ra, 0x10($sp)
    ctx->pc = 0x3b0c8cu;
    WRITE64(ADD32(GPR_U32(ctx, 29), 16), GPR_U64(ctx, 31));
label_3b0c90:
    // 0x3b0c90: 0xae450028  sw          $a1, 0x28($s2)
    ctx->pc = 0x3b0c90u;
    WRITE32(ADD32(GPR_U32(ctx, 18), 40), GPR_U32(ctx, 5));
label_3b0c94:
    // 0x3b0c94: 0x8e44002c  lw          $a0, 0x2C($s2)
    ctx->pc = 0x3b0c94u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 44)));
label_3b0c98:
    // 0x3b0c98: 0xae400010  sw          $zero, 0x10($s2)
    ctx->pc = 0x3b0c98u;
    WRITE32(ADD32(GPR_U32(ctx, 18), 16), GPR_U32(ctx, 0));
label_3b0c9c:
    // 0x3b0c9c: 0x10800006  beqz        $a0, . + 4 + (0x6 << 2)
label_3b0ca0:
    if (ctx->pc == 0x3B0CA0u) {
        ctx->pc = 0x3B0CA0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0C9Cu;
        // 0x3b0ca0: 0xae400014  sw          $zero, 0x14($s2) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 18), 20), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0CA4u;
        goto label_3b0ca4;
    }
    ctx->pc = 0x3B0C9Cu;
    {
        const bool branch_taken_0x3b0c9c = (GPR_U64(ctx, 4) == GPR_U64(ctx, 0));
        ctx->pc = 0x3B0CA0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0C9Cu;
        // 0x3b0ca0: 0xae400014  sw          $zero, 0x14($s2) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 18), 20), GPR_U32(ctx, 0));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0c9c) {
            ctx->pc = 0x3B0CB8u;
            goto label_3b0cb8;
        }
    }
    ctx->pc = 0x3B0CA4u;
label_3b0ca4:
    // 0x3b0ca4: 0x27c39430  addiu       $v1, $fp, -0x6BD0
    ctx->pc = 0x3b0ca4u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 30), 4294939696));
label_3b0ca8:
    // 0x3b0ca8: 0x8c620004  lw          $v0, 0x4($v1)
    ctx->pc = 0x3b0ca8u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 4)));
label_3b0cac:
    // 0x3b0cac: 0x40f809  jalr        $v0
label_3b0cb0:
    if (ctx->pc == 0x3B0CB0u) {
        ctx->pc = 0x3B0CB4u;
        goto label_3b0cb4;
    }
    ctx->pc = 0x3B0CACu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x3B0CB4u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0CACu, 0x3B0CB4u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x3B0CB4u;
label_3b0cb4:
    // 0x3b0cb4: 0xae40002c  sw          $zero, 0x2C($s2)
    ctx->pc = 0x3b0cb4u;
    WRITE32(ADD32(GPR_U32(ctx, 18), 44), GPR_U32(ctx, 0));
label_3b0cb8:
    // 0x3b0cb8: 0x8e440078  lw          $a0, 0x78($s2)
    ctx->pc = 0x3b0cb8u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 120)));
label_3b0cbc:
    // 0x3b0cbc: 0x10800005  beqz        $a0, . + 4 + (0x5 << 2)
label_3b0cc0:
    if (ctx->pc == 0x3B0CC0u) {
        ctx->pc = 0x3B0CC0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0CBCu;
        // 0x3b0cc0: 0x27c39430  addiu       $v1, $fp, -0x6BD0 (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 30), 4294939696));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0CC4u;
        goto label_3b0cc4;
    }
    ctx->pc = 0x3B0CBCu;
    {
        const bool branch_taken_0x3b0cbc = (GPR_U64(ctx, 4) == GPR_U64(ctx, 0));
        ctx->pc = 0x3B0CC0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0CBCu;
        // 0x3b0cc0: 0x27c39430  addiu       $v1, $fp, -0x6BD0 (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 30), 4294939696));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0cbc) {
            ctx->pc = 0x3B0CD4u;
            goto label_3b0cd4;
        }
    }
    ctx->pc = 0x3B0CC4u;
label_3b0cc4:
    // 0x3b0cc4: 0x8c620004  lw          $v0, 0x4($v1)
    ctx->pc = 0x3b0cc4u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 4)));
label_3b0cc8:
    // 0x3b0cc8: 0x40f809  jalr        $v0
label_3b0ccc:
    if (ctx->pc == 0x3B0CCCu) {
        ctx->pc = 0x3B0CD0u;
        goto label_3b0cd0;
    }
    ctx->pc = 0x3B0CC8u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x3B0CD0u);
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0CC8u, 0x3B0CD0u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x3B0CD0u;
label_3b0cd0:
    // 0x3b0cd0: 0xae400078  sw          $zero, 0x78($s2)
    ctx->pc = 0x3b0cd0u;
    WRITE32(ADD32(GPR_U32(ctx, 18), 120), GPR_U32(ctx, 0));
label_3b0cd4:
    // 0x3b0cd4: 0x24110001  addiu       $s1, $zero, 0x1
    ctx->pc = 0x3b0cd4u;
    SET_GPR_S32(ctx, 17, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
label_3b0cd8:
    // 0x3b0cd8: 0x3c100051  lui         $s0, 0x51
    ctx->pc = 0x3b0cd8u;
    SET_GPR_S32(ctx, 16, (int32_t)((uint32_t)81 << 16));
label_3b0cdc:
    // 0x3b0cdc: 0xae510004  sw          $s1, 0x4($s2)
    ctx->pc = 0x3b0cdcu;
    WRITE32(ADD32(GPR_U32(ctx, 18), 4), GPR_U32(ctx, 17));
label_3b0ce0:
    // 0x3b0ce0: 0x26109648  addiu       $s0, $s0, -0x69B8
    ctx->pc = 0x3b0ce0u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 16), 4294940232));
label_3b0ce4:
    // 0x3b0ce4: 0x3c020051  lui         $v0, 0x51
    ctx->pc = 0x3b0ce4u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)81 << 16));
label_3b0ce8:
    // 0x3b0ce8: 0x8e640004  lw          $a0, 0x4($s3)
    ctx->pc = 0x3b0ce8u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 19), 4)));
label_3b0cec:
    // 0x3b0cec: 0xc0ec48a  jal         func_3B1228
label_3b0cf0:
    if (ctx->pc == 0x3B0CF0u) {
        ctx->pc = 0x3B0CF0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0CECu;
        // 0x3b0cf0: 0xac50a088  sw          $s0, -0x5F78($v0) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 2), 4294942856), GPR_U32(ctx, 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0CF4u;
        goto label_3b0cf4;
    }
    ctx->pc = 0x3B0CECu;
    SET_GPR_U32(ctx, 31, 0x3B0CF4u);
    ctx->pc = 0x3B0CF0u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0CECu;
    // 0x3b0cf0: 0xac50a088  sw          $s0, -0x5F78($v0) (Delay Slot)
    WRITE32(ADD32(GPR_U32(ctx, 2), 4294942856), GPR_U32(ctx, 16));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3B1228u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3B1228u, 0x3B0CECu, 0x3B0CF4u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0CF4u;
label_3b0cf4:
    // 0x3b0cf4: 0xc0ec4f6  jal         func_3B13D8
label_3b0cf8:
    if (ctx->pc == 0x3B0CF8u) {
        ctx->pc = 0x3B0CFCu;
        goto label_3b0cfc;
    }
    ctx->pc = 0x3B0CF4u;
    SET_GPR_U32(ctx, 31, 0x3B0CFCu);
    ctx->pc = 0x3B13D8u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3B13D8u, 0x3B0CF4u, 0x3B0CFCu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0CFCu;
label_3b0cfc:
    // 0x3b0cfc: 0x8e090420  lw          $t1, 0x420($s0)
    ctx->pc = 0x3b0cfcu;
    SET_GPR_S32(ctx, 9, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 1056)));
label_3b0d00:
    // 0x3b0d00: 0x1520000e  bnez        $t1, . + 4 + (0xE << 2)
label_3b0d04:
    if (ctx->pc == 0x3B0D04u) {
        ctx->pc = 0x3B0D04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0D00u;
        // 0x3b0d04: 0x3c030051  lui         $v1, 0x51 (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)81 << 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0D08u;
        goto label_3b0d08;
    }
    ctx->pc = 0x3B0D00u;
    {
        const bool branch_taken_0x3b0d00 = (GPR_U64(ctx, 9) != GPR_U64(ctx, 0));
        ctx->pc = 0x3B0D04u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0D00u;
        // 0x3b0d04: 0x3c030051  lui         $v1, 0x51 (Delay Slot)
        SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)81 << 16));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0d00) {
            ctx->pc = 0x3B0D3Cu;
            goto label_3b0d3c;
        }
    }
    ctx->pc = 0x3B0D08u;
label_3b0d08:
    // 0x3b0d08: 0x3c070051  lui         $a3, 0x51
    ctx->pc = 0x3b0d08u;
    SET_GPR_S32(ctx, 7, (int32_t)((uint32_t)81 << 16));
label_3b0d0c:
    // 0x3b0d0c: 0x3c080051  lui         $t0, 0x51
    ctx->pc = 0x3b0d0cu;
    SET_GPR_S32(ctx, 8, (int32_t)((uint32_t)81 << 16));
label_3b0d10:
    // 0x3b0d10: 0x3c060051  lui         $a2, 0x51
    ctx->pc = 0x3b0d10u;
    SET_GPR_S32(ctx, 6, (int32_t)((uint32_t)81 << 16));
label_3b0d14:
    // 0x3b0d14: 0x24030003  addiu       $v1, $zero, 0x3
    ctx->pc = 0x3b0d14u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 3));
label_3b0d18:
    // 0x3b0d18: 0x3c040051  lui         $a0, 0x51
    ctx->pc = 0x3b0d18u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)81 << 16));
label_3b0d1c:
    // 0x3b0d1c: 0x3c050051  lui         $a1, 0x51
    ctx->pc = 0x3b0d1cu;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)81 << 16));
label_3b0d20:
    // 0x3b0d20: 0x24020005  addiu       $v0, $zero, 0x5
    ctx->pc = 0x3b0d20u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 5));
label_3b0d24:
    // 0x3b0d24: 0xacc39584  sw          $v1, -0x6A7C($a2)
    ctx->pc = 0x3b0d24u;
    WRITE32(ADD32(GPR_U32(ctx, 6), 4294940036), GPR_U32(ctx, 3));
label_3b0d28:
    // 0x3b0d28: 0xac91958c  sw          $s1, -0x6A74($a0)
    ctx->pc = 0x3b0d28u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 4294940044), GPR_U32(ctx, 17));
label_3b0d2c:
    // 0x3b0d2c: 0xaca29548  sw          $v0, -0x6AB8($a1)
    ctx->pc = 0x3b0d2cu;
    WRITE32(ADD32(GPR_U32(ctx, 5), 4294939976), GPR_U32(ctx, 2));
label_3b0d30:
    // 0x3b0d30: 0xacf19524  sw          $s1, -0x6ADC($a3)
    ctx->pc = 0x3b0d30u;
    WRITE32(ADD32(GPR_U32(ctx, 7), 4294939940), GPR_U32(ctx, 17));
label_3b0d34:
    // 0x3b0d34: 0xad1195a0  sw          $s1, -0x6A60($t0)
    ctx->pc = 0x3b0d34u;
    WRITE32(ADD32(GPR_U32(ctx, 8), 4294940064), GPR_U32(ctx, 17));
label_3b0d38:
    // 0x3b0d38: 0x3c030051  lui         $v1, 0x51
    ctx->pc = 0x3b0d38u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)81 << 16));
label_3b0d3c:
    // 0x3b0d3c: 0x2407ffff  addiu       $a3, $zero, -0x1
    ctx->pc = 0x3b0d3cu;
    SET_GPR_S32(ctx, 7, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
label_3b0d40:
    // 0x3b0d40: 0x8c6294f4  lw          $v0, -0x6B0C($v1)
    ctx->pc = 0x3b0d40u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 4294939892)));
label_3b0d44:
    // 0x3b0d44: 0x3c060051  lui         $a2, 0x51
    ctx->pc = 0x3b0d44u;
    SET_GPR_S32(ctx, 6, (int32_t)((uint32_t)81 << 16));
label_3b0d48:
    // 0x3b0d48: 0x3c050051  lui         $a1, 0x51
    ctx->pc = 0x3b0d48u;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)81 << 16));
label_3b0d4c:
    // 0x3b0d4c: 0xc0582d  daddu       $t3, $a2, $zero
    ctx->pc = 0x3b0d4cu;
    SET_GPR_U64(ctx, 11, (uint64_t)GPR_U64(ctx, 6) + (uint64_t)GPR_U64(ctx, 0));
label_3b0d50:
    // 0x3b0d50: 0x2444000f  addiu       $a0, $v0, 0xF
    ctx->pc = 0x3b0d50u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 2), 15));
label_3b0d54:
    // 0x3b0d54: 0xa0502d  daddu       $t2, $a1, $zero
    ctx->pc = 0x3b0d54u;
    SET_GPR_U64(ctx, 10, (uint64_t)GPR_U64(ctx, 5) + (uint64_t)GPR_U64(ctx, 0));
label_3b0d58:
    // 0x3b0d58: 0x2442001e  addiu       $v0, $v0, 0x1E
    ctx->pc = 0x3b0d58u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 30));
label_3b0d5c:
    // 0x3b0d5c: 0xe4182a  slt         $v1, $a3, $a0
    ctx->pc = 0x3b0d5cu;
    SET_GPR_U64(ctx, 3, ((int64_t)GPR_S64(ctx, 7) < (int64_t)GPR_S64(ctx, 4)) ? 1 : 0);
label_3b0d60:
    // 0x3b0d60: 0x83100b  movn        $v0, $a0, $v1
    ctx->pc = 0x3b0d60u;
    if (GPR_U64(ctx, 3) != 0) SET_GPR_VEC(ctx, 2, GPR_VEC(ctx, 4));
label_3b0d64:
    // 0x3b0d64: 0x24a89500  addiu       $t0, $a1, -0x6B00
    ctx->pc = 0x3b0d64u;
    SET_GPR_S32(ctx, 8, (int32_t)ADD32(GPR_U32(ctx, 5), 4294939904));
label_3b0d68:
    // 0x3b0d68: 0x21103  sra         $v0, $v0, 4
    ctx->pc = 0x3b0d68u;
    SET_GPR_S32(ctx, 2, SRA32(GPR_S32(ctx, 2), 4));
label_3b0d6c:
    // 0x3b0d6c: 0x1120000e  beqz        $t1, . + 4 + (0xE << 2)
label_3b0d70:
    if (ctx->pc == 0x3B0D70u) {
        ctx->pc = 0x3B0D70u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0D6Cu;
        // 0x3b0d70: 0xacc294fc  sw          $v0, -0x6B04($a2) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 6), 4294939900), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0D74u;
        goto label_3b0d74;
    }
    ctx->pc = 0x3B0D6Cu;
    {
        const bool branch_taken_0x3b0d6c = (GPR_U64(ctx, 9) == GPR_U64(ctx, 0));
        ctx->pc = 0x3B0D70u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0D6Cu;
        // 0x3b0d70: 0xacc294fc  sw          $v0, -0x6B04($a2) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 6), 4294939900), GPR_U32(ctx, 2));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0d6c) {
            ctx->pc = 0x3B0DA8u;
            goto label_3b0da8;
        }
    }
    ctx->pc = 0x3B0D74u;
label_3b0d74:
    // 0x3b0d74: 0x3c020051  lui         $v0, 0x51
    ctx->pc = 0x3b0d74u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)81 << 16));
label_3b0d78:
    // 0x3b0d78: 0x8c439524  lw          $v1, -0x6ADC($v0)
    ctx->pc = 0x3b0d78u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 2), 4294939940)));
label_3b0d7c:
    // 0x3b0d7c: 0x1460000b  bnez        $v1, . + 4 + (0xB << 2)
label_3b0d80:
    if (ctx->pc == 0x3B0D80u) {
        ctx->pc = 0x3B0D80u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0D7Cu;
        // 0x3b0d80: 0x3c040051  lui         $a0, 0x51 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)81 << 16));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0D84u;
        goto label_3b0d84;
    }
    ctx->pc = 0x3B0D7Cu;
    {
        const bool branch_taken_0x3b0d7c = (GPR_U64(ctx, 3) != GPR_U64(ctx, 0));
        ctx->pc = 0x3B0D80u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0D7Cu;
        // 0x3b0d80: 0x3c040051  lui         $a0, 0x51 (Delay Slot)
        SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)81 << 16));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0d7c) {
            ctx->pc = 0x3B0DACu;
            goto label_3b0dac;
        }
    }
    ctx->pc = 0x3B0D84u;
label_3b0d84:
    // 0x3b0d84: 0x3c030051  lui         $v1, 0x51
    ctx->pc = 0x3b0d84u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)81 << 16));
label_3b0d88:
    // 0x3b0d88: 0x8c6294f8  lw          $v0, -0x6B08($v1)
    ctx->pc = 0x3b0d88u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 3), 4294939896)));
label_3b0d8c:
    // 0x3b0d8c: 0x2444001f  addiu       $a0, $v0, 0x1F
    ctx->pc = 0x3b0d8cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 2), 31));
label_3b0d90:
    // 0x3b0d90: 0x2442003e  addiu       $v0, $v0, 0x3E
    ctx->pc = 0x3b0d90u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 62));
label_3b0d94:
    // 0x3b0d94: 0xe4182a  slt         $v1, $a3, $a0
    ctx->pc = 0x3b0d94u;
    SET_GPR_U64(ctx, 3, ((int64_t)GPR_S64(ctx, 7) < (int64_t)GPR_S64(ctx, 4)) ? 1 : 0);
label_3b0d98:
    // 0x3b0d98: 0x83100b  movn        $v0, $a0, $v1
    ctx->pc = 0x3b0d98u;
    if (GPR_U64(ctx, 3) != 0) SET_GPR_VEC(ctx, 2, GPR_VEC(ctx, 4));
label_3b0d9c:
    // 0x3b0d9c: 0x21143  sra         $v0, $v0, 5
    ctx->pc = 0x3b0d9cu;
    SET_GPR_S32(ctx, 2, SRA32(GPR_S32(ctx, 2), 5));
label_3b0da0:
    // 0x3b0da0: 0x10000009  b           . + 4 + (0x9 << 2)
label_3b0da4:
    if (ctx->pc == 0x3B0DA4u) {
        ctx->pc = 0x3B0DA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0DA0u;
        // 0x3b0da4: 0x21040  sll         $v0, $v0, 1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 2), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0DA8u;
        goto label_3b0da8;
    }
    ctx->pc = 0x3B0DA0u;
    {
        const bool branch_taken_0x3b0da0 = (GPR_U64(ctx, 0) == GPR_U64(ctx, 0));
        ctx->pc = 0x3B0DA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0DA0u;
        // 0x3b0da4: 0x21040  sll         $v0, $v0, 1 (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 2), 1));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0da0) {
            ctx->pc = 0x3B0DC8u;
            goto label_3b0dc8;
        }
    }
    ctx->pc = 0x3B0DA8u;
label_3b0da8:
    // 0x3b0da8: 0x3c040051  lui         $a0, 0x51
    ctx->pc = 0x3b0da8u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)81 << 16));
label_3b0dac:
    // 0x3b0dac: 0x2403ffff  addiu       $v1, $zero, -0x1
    ctx->pc = 0x3b0dacu;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 0), 4294967295));
label_3b0db0:
    // 0x3b0db0: 0x8c8294f8  lw          $v0, -0x6B08($a0)
    ctx->pc = 0x3b0db0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 4294939896)));
label_3b0db4:
    // 0x3b0db4: 0x2445000f  addiu       $a1, $v0, 0xF
    ctx->pc = 0x3b0db4u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 2), 15));
label_3b0db8:
    // 0x3b0db8: 0x2442001e  addiu       $v0, $v0, 0x1E
    ctx->pc = 0x3b0db8u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 2), 30));
label_3b0dbc:
    // 0x3b0dbc: 0x65182a  slt         $v1, $v1, $a1
    ctx->pc = 0x3b0dbcu;
    SET_GPR_U64(ctx, 3, ((int64_t)GPR_S64(ctx, 3) < (int64_t)GPR_S64(ctx, 5)) ? 1 : 0);
label_3b0dc0:
    // 0x3b0dc0: 0xa3100b  movn        $v0, $a1, $v1
    ctx->pc = 0x3b0dc0u;
    if (GPR_U64(ctx, 3) != 0) SET_GPR_VEC(ctx, 2, GPR_VEC(ctx, 5));
label_3b0dc4:
    // 0x3b0dc4: 0x21103  sra         $v0, $v0, 4
    ctx->pc = 0x3b0dc4u;
    SET_GPR_S32(ctx, 2, SRA32(GPR_S32(ctx, 2), 4));
label_3b0dc8:
    // 0x3b0dc8: 0xad020000  sw          $v0, 0x0($t0)
    ctx->pc = 0x3b0dc8u;
    WRITE32(ADD32(GPR_U32(ctx, 8), 0), GPR_U32(ctx, 2));
label_3b0dcc:
    // 0x3b0dcc: 0x3c040051  lui         $a0, 0x51
    ctx->pc = 0x3b0dccu;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)81 << 16));
label_3b0dd0:
    // 0x3b0dd0: 0x8d6294fc  lw          $v0, -0x6B04($t3)
    ctx->pc = 0x3b0dd0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 11), 4294939900)));
label_3b0dd4:
    // 0x3b0dd4: 0x3c060051  lui         $a2, 0x51
    ctx->pc = 0x3b0dd4u;
    SET_GPR_S32(ctx, 6, (int32_t)((uint32_t)81 << 16));
label_3b0dd8:
    // 0x3b0dd8: 0x8e470028  lw          $a3, 0x28($s2)
    ctx->pc = 0x3b0dd8u;
    SET_GPR_S32(ctx, 7, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 40)));
label_3b0ddc:
    // 0x3b0ddc: 0x3c080051  lui         $t0, 0x51
    ctx->pc = 0x3b0ddcu;
    SET_GPR_S32(ctx, 8, (int32_t)((uint32_t)81 << 16));
label_3b0de0:
    // 0x3b0de0: 0x8d439500  lw          $v1, -0x6B00($t2)
    ctx->pc = 0x3b0de0u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 10), 4294939904)));
label_3b0de4:
    // 0x3b0de4: 0x21100  sll         $v0, $v0, 4
    ctx->pc = 0x3b0de4u;
    SET_GPR_S32(ctx, 2, (int32_t)SLL32(GPR_U32(ctx, 2), 4));
label_3b0de8:
    // 0x3b0de8: 0xac8294d4  sw          $v0, -0x6B2C($a0)
    ctx->pc = 0x3b0de8u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 4294939860), GPR_U32(ctx, 2));
label_3b0dec:
    // 0x3b0dec: 0xae420008  sw          $v0, 0x8($s2)
    ctx->pc = 0x3b0decu;
    WRITE32(ADD32(GPR_U32(ctx, 18), 8), GPR_U32(ctx, 2));
label_3b0df0:
    // 0x3b0df0: 0x31900  sll         $v1, $v1, 4
    ctx->pc = 0x3b0df0u;
    SET_GPR_S32(ctx, 3, (int32_t)SLL32(GPR_U32(ctx, 3), 4));
label_3b0df4:
    // 0x3b0df4: 0xacc394d8  sw          $v1, -0x6B28($a2)
    ctx->pc = 0x3b0df4u;
    WRITE32(ADD32(GPR_U32(ctx, 6), 4294939864), GPR_U32(ctx, 3));
label_3b0df8:
    // 0x3b0df8: 0x21043  sra         $v0, $v0, 1
    ctx->pc = 0x3b0df8u;
    SET_GPR_S32(ctx, 2, SRA32(GPR_S32(ctx, 2), 1));
label_3b0dfc:
    // 0x3b0dfc: 0xae43000c  sw          $v1, 0xC($s2)
    ctx->pc = 0x3b0dfcu;
    WRITE32(ADD32(GPR_U32(ctx, 18), 12), GPR_U32(ctx, 3));
label_3b0e00:
    // 0x3b0e00: 0x32843  sra         $a1, $v1, 1
    ctx->pc = 0x3b0e00u;
    SET_GPR_S32(ctx, 5, SRA32(GPR_S32(ctx, 3), 1));
label_3b0e04:
    // 0x3b0e04: 0xad0294dc  sw          $v0, -0x6B24($t0)
    ctx->pc = 0x3b0e04u;
    WRITE32(ADD32(GPR_U32(ctx, 8), 4294939868), GPR_U32(ctx, 2));
label_3b0e08:
    // 0x3b0e08: 0x3c040051  lui         $a0, 0x51
    ctx->pc = 0x3b0e08u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)81 << 16));
label_3b0e0c:
    // 0x3b0e0c: 0x8ce20010  lw          $v0, 0x10($a3)
    ctx->pc = 0x3b0e0cu;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 7), 16)));
label_3b0e10:
    // 0x3b0e10: 0x26430030  addiu       $v1, $s2, 0x30
    ctx->pc = 0x3b0e10u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 18), 48));
label_3b0e14:
    // 0x3b0e14: 0xac8594e0  sw          $a1, -0x6B20($a0)
    ctx->pc = 0x3b0e14u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 4294939872), GPR_U32(ctx, 5));
label_3b0e18:
    // 0x3b0e18: 0x1840001d  blez        $v0, . + 4 + (0x1D << 2)
label_3b0e1c:
    if (ctx->pc == 0x3B0E1Cu) {
        ctx->pc = 0x3B0E1Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0E18u;
        // 0x3b0e1c: 0xafa30000  sw          $v1, 0x0($sp) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 29), 0), GPR_U32(ctx, 3));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0E20u;
        goto label_3b0e20;
    }
    ctx->pc = 0x3B0E18u;
    {
        const bool branch_taken_0x3b0e18 = (GPR_S32(ctx, 2) <= 0);
        ctx->pc = 0x3B0E1Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0E18u;
        // 0x3b0e1c: 0xafa30000  sw          $v1, 0x0($sp) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 29), 0), GPR_U32(ctx, 3));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0e18) {
            ctx->pc = 0x3B0E90u;
            goto label_3b0e90;
        }
    }
    ctx->pc = 0x3B0E20u;
label_3b0e20:
    // 0x3b0e20: 0x3c140051  lui         $s4, 0x51
    ctx->pc = 0x3b0e20u;
    SET_GPR_S32(ctx, 20, (int32_t)((uint32_t)81 << 16));
label_3b0e24:
    // 0x3b0e24: 0x40982d  daddu       $s3, $v0, $zero
    ctx->pc = 0x3b0e24u;
    SET_GPR_U64(ctx, 19, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_3b0e28:
    // 0x3b0e28: 0x26979430  addiu       $s7, $s4, -0x6BD0
    ctx->pc = 0x3b0e28u;
    SET_GPR_S32(ctx, 23, (int32_t)ADD32(GPR_U32(ctx, 20), 4294939696));
label_3b0e2c:
    // 0x3b0e2c: 0x3c160049  lui         $s6, 0x49
    ctx->pc = 0x3b0e2cu;
    SET_GPR_S32(ctx, 22, (int32_t)((uint32_t)73 << 16));
label_3b0e30:
    // 0x3b0e30: 0x26550020  addiu       $s5, $s2, 0x20
    ctx->pc = 0x3b0e30u;
    SET_GPR_S32(ctx, 21, (int32_t)ADD32(GPR_U32(ctx, 18), 32));
label_3b0e34:
    // 0x3b0e34: 0x0  nop
    ctx->pc = 0x3b0e34u;
    // NOP
label_3b0e38:
    // 0x3b0e38: 0x8ee80008  lw          $t0, 0x8($s7)
    ctx->pc = 0x3b0e38u;
    SET_GPR_S32(ctx, 8, (int32_t)READ32(ADD32(GPR_U32(ctx, 23), 8)));
label_3b0e3c:
    // 0x3b0e3c: 0x26c453e8  addiu       $a0, $s6, 0x53E8
    ctx->pc = 0x3b0e3cu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 22), 21480));
label_3b0e40:
    // 0x3b0e40: 0x8e829430  lw          $v0, -0x6BD0($s4)
    ctx->pc = 0x3b0e40u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 20), 4294939696)));
label_3b0e44:
    // 0x3b0e44: 0x24050014  addiu       $a1, $zero, 0x14
    ctx->pc = 0x3b0e44u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 20));
label_3b0e48:
    // 0x3b0e48: 0x8e510008  lw          $s1, 0x8($s2)
    ctx->pc = 0x3b0e48u;
    SET_GPR_S32(ctx, 17, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 8)));
label_3b0e4c:
    // 0x3b0e4c: 0x302d  daddu       $a2, $zero, $zero
    ctx->pc = 0x3b0e4cu;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_3b0e50:
    // 0x3b0e50: 0x8e50000c  lw          $s0, 0xC($s2)
    ctx->pc = 0x3b0e50u;
    SET_GPR_S32(ctx, 16, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 12)));
label_3b0e54:
    // 0x3b0e54: 0x40f809  jalr        $v0
label_3b0e58:
    if (ctx->pc == 0x3B0E58u) {
        ctx->pc = 0x3B0E58u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0E54u;
        // 0x3b0e58: 0x382d  daddu       $a3, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0E5Cu;
        goto label_3b0e5c;
    }
    ctx->pc = 0x3B0E54u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x3B0E5Cu);
        ctx->pc = 0x3B0E58u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0E54u;
        // 0x3b0e58: 0x382d  daddu       $a3, $zero, $zero (Delay Slot)
        SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0E54u, 0x3B0E5Cu, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x3B0E5Cu;
label_3b0e5c:
    // 0x3b0e5c: 0x2673ffff  addiu       $s3, $s3, -0x1
    ctx->pc = 0x3b0e5cu;
    SET_GPR_S32(ctx, 19, (int32_t)ADD32(GPR_U32(ctx, 19), 4294967295));
label_3b0e60:
    // 0x3b0e60: 0x40202d  daddu       $a0, $v0, $zero
    ctx->pc = 0x3b0e60u;
    SET_GPR_U64(ctx, 4, (uint64_t)GPR_U64(ctx, 2) + (uint64_t)GPR_U64(ctx, 0));
label_3b0e64:
    // 0x3b0e64: 0x220282d  daddu       $a1, $s1, $zero
    ctx->pc = 0x3b0e64u;
    SET_GPR_U64(ctx, 5, (uint64_t)GPR_U64(ctx, 17) + (uint64_t)GPR_U64(ctx, 0));
label_3b0e68:
    // 0x3b0e68: 0xc0ec1fe  jal         func_3B07F8
label_3b0e6c:
    if (ctx->pc == 0x3B0E6Cu) {
        ctx->pc = 0x3B0E6Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0E68u;
        // 0x3b0e6c: 0x200302d  daddu       $a2, $s0, $zero (Delay Slot)
        SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0E70u;
        goto label_3b0e70;
    }
    ctx->pc = 0x3B0E68u;
    SET_GPR_U32(ctx, 31, 0x3B0E70u);
    ctx->pc = 0x3B0E6Cu;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0E68u;
    // 0x3b0e6c: 0x200302d  daddu       $a2, $s0, $zero (Delay Slot)
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 16) + (uint64_t)GPR_U64(ctx, 0));
    ctx->in_delay_slot = false;
    ctx->pc = 0x3B07F8u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x3B07F8u, 0x3B0E68u, 0x3B0E70u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0E70u;
label_3b0e70:
    // 0x3b0e70: 0x24430008  addiu       $v1, $v0, 0x8
    ctx->pc = 0x3b0e70u;
    SET_GPR_S32(ctx, 3, (int32_t)ADD32(GPR_U32(ctx, 2), 8));
label_3b0e74:
    // 0x3b0e74: 0x8e440020  lw          $a0, 0x20($s2)
    ctx->pc = 0x3b0e74u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 32)));
label_3b0e78:
    // 0x3b0e78: 0x2180a  movz        $v1, $zero, $v0
    ctx->pc = 0x3b0e78u;
    if (GPR_U64(ctx, 2) == 0) SET_GPR_VEC(ctx, 3, GPR_VEC(ctx, 0));
label_3b0e7c:
    // 0x3b0e7c: 0xae430020  sw          $v1, 0x20($s2)
    ctx->pc = 0x3b0e7cu;
    WRITE32(ADD32(GPR_U32(ctx, 18), 32), GPR_U32(ctx, 3));
label_3b0e80:
    // 0x3b0e80: 0xac830004  sw          $v1, 0x4($a0)
    ctx->pc = 0x3b0e80u;
    WRITE32(ADD32(GPR_U32(ctx, 4), 4), GPR_U32(ctx, 3));
label_3b0e84:
    // 0x3b0e84: 0xac640000  sw          $a0, 0x0($v1)
    ctx->pc = 0x3b0e84u;
    WRITE32(ADD32(GPR_U32(ctx, 3), 0), GPR_U32(ctx, 4));
label_3b0e88:
    // 0x3b0e88: 0x1660ffeb  bnez        $s3, . + 4 + (-0x15 << 2)
label_3b0e8c:
    if (ctx->pc == 0x3B0E8Cu) {
        ctx->pc = 0x3B0E8Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0E88u;
        // 0x3b0e8c: 0xac750004  sw          $s5, 0x4($v1) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 3), 4), GPR_U32(ctx, 21));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0E90u;
        goto label_3b0e90;
    }
    ctx->pc = 0x3B0E88u;
    {
        const bool branch_taken_0x3b0e88 = (GPR_U64(ctx, 19) != GPR_U64(ctx, 0));
        ctx->pc = 0x3B0E8Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0E88u;
        // 0x3b0e8c: 0xac750004  sw          $s5, 0x4($v1) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 3), 4), GPR_U32(ctx, 21));
        ctx->in_delay_slot = false;
        if (branch_taken_0x3b0e88) {
            ctx->pc = 0x3B0E38u;
            if (runtime->eeCheckpointDue()) {
                return;
            }
            goto label_3b0e38;
        }
    }
    ctx->pc = 0x3B0E90u;
label_3b0e90:
    // 0x3b0e90: 0x8e42000c  lw          $v0, 0xC($s2)
    ctx->pc = 0x3b0e90u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 12)));
label_3b0e94:
    // 0x3b0e94: 0x27d09430  addiu       $s0, $fp, -0x6BD0
    ctx->pc = 0x3b0e94u;
    SET_GPR_S32(ctx, 16, (int32_t)ADD32(GPR_U32(ctx, 30), 4294939696));
label_3b0e98:
    // 0x3b0e98: 0x8e490008  lw          $t1, 0x8($s2)
    ctx->pc = 0x3b0e98u;
    SET_GPR_S32(ctx, 9, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 8)));
label_3b0e9c:
    // 0x3b0e9c: 0x3c040049  lui         $a0, 0x49
    ctx->pc = 0x3b0e9cu;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)73 << 16));
label_3b0ea0:
    // 0x3b0ea0: 0x8e080008  lw          $t0, 0x8($s0)
    ctx->pc = 0x3b0ea0u;
    SET_GPR_S32(ctx, 8, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 8)));
label_3b0ea4:
    // 0x3b0ea4: 0x248453f0  addiu       $a0, $a0, 0x53F0
    ctx->pc = 0x3b0ea4u;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 21488));
label_3b0ea8:
    // 0x3b0ea8: 0x1224818  mult        $t1, $t1, $v0
    ctx->pc = 0x3b0ea8u;
    { int64_t result = (int64_t)GPR_S32(ctx, 9) * (int64_t)GPR_S32(ctx, 2); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 9, (int32_t)result); }
label_3b0eac:
    // 0x3b0eac: 0x302d  daddu       $a2, $zero, $zero
    ctx->pc = 0x3b0eacu;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_3b0eb0:
    // 0x3b0eb0: 0x8fc29430  lw          $v0, -0x6BD0($fp)
    ctx->pc = 0x3b0eb0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 30), 4294939696)));
label_3b0eb4:
    // 0x3b0eb4: 0x35080400  ori         $t0, $t0, 0x400
    ctx->pc = 0x3b0eb4u;
    SET_GPR_U64(ctx, 8, GPR_U64(ctx, 8) | (uint64_t)(uint16_t)1024);
label_3b0eb8:
    // 0x3b0eb8: 0x382d  daddu       $a3, $zero, $zero
    ctx->pc = 0x3b0eb8u;
    SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_3b0ebc:
    // 0x3b0ebc: 0x928c0  sll         $a1, $t1, 3
    ctx->pc = 0x3b0ebcu;
    SET_GPR_S32(ctx, 5, (int32_t)SLL32(GPR_U32(ctx, 9), 3));
label_3b0ec0:
    // 0x3b0ec0: 0xa92821  addu        $a1, $a1, $t1
    ctx->pc = 0x3b0ec0u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 9)));
label_3b0ec4:
    // 0x3b0ec4: 0x51fc2  srl         $v1, $a1, 31
    ctx->pc = 0x3b0ec4u;
    SET_GPR_S32(ctx, 3, (int32_t)SRL32(GPR_U32(ctx, 5), 31));
label_3b0ec8:
    // 0x3b0ec8: 0xa32821  addu        $a1, $a1, $v1
    ctx->pc = 0x3b0ec8u;
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), GPR_U32(ctx, 3)));
label_3b0ecc:
    // 0x3b0ecc: 0x52843  sra         $a1, $a1, 1
    ctx->pc = 0x3b0eccu;
    SET_GPR_S32(ctx, 5, SRA32(GPR_S32(ctx, 5), 1));
label_3b0ed0:
    // 0x3b0ed0: 0x40f809  jalr        $v0
label_3b0ed4:
    if (ctx->pc == 0x3B0ED4u) {
        ctx->pc = 0x3B0ED4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0ED0u;
        // 0x3b0ed4: 0x24a5176c  addiu       $a1, $a1, 0x176C (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 5996));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0ED8u;
        goto label_3b0ed8;
    }
    ctx->pc = 0x3B0ED0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x3B0ED8u);
        ctx->pc = 0x3B0ED4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0ED0u;
        // 0x3b0ed4: 0x24a5176c  addiu       $a1, $a1, 0x176C (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 5), 5996));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0ED0u, 0x3B0ED8u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x3B0ED8u;
label_3b0ed8:
    // 0x3b0ed8: 0xae42002c  sw          $v0, 0x2C($s2)
    ctx->pc = 0x3b0ed8u;
    WRITE32(ADD32(GPR_U32(ctx, 18), 44), GPR_U32(ctx, 2));
label_3b0edc:
    // 0x3b0edc: 0x3c050003  lui         $a1, 0x3
    ctx->pc = 0x3b0edcu;
    SET_GPR_S32(ctx, 5, (int32_t)((uint32_t)3 << 16));
label_3b0ee0:
    // 0x3b0ee0: 0x3c040049  lui         $a0, 0x49
    ctx->pc = 0x3b0ee0u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)73 << 16));
label_3b0ee4:
    // 0x3b0ee4: 0x382d  daddu       $a3, $zero, $zero
    ctx->pc = 0x3b0ee4u;
    SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_3b0ee8:
    // 0x3b0ee8: 0x8e080008  lw          $t0, 0x8($s0)
    ctx->pc = 0x3b0ee8u;
    SET_GPR_S32(ctx, 8, (int32_t)READ32(ADD32(GPR_U32(ctx, 16), 8)));
label_3b0eec:
    // 0x3b0eec: 0x24845400  addiu       $a0, $a0, 0x5400
    ctx->pc = 0x3b0eecu;
    SET_GPR_S32(ctx, 4, (int32_t)ADD32(GPR_U32(ctx, 4), 21504));
label_3b0ef0:
    // 0x3b0ef0: 0x8fc29430  lw          $v0, -0x6BD0($fp)
    ctx->pc = 0x3b0ef0u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 30), 4294939696)));
label_3b0ef4:
    // 0x3b0ef4: 0x302d  daddu       $a2, $zero, $zero
    ctx->pc = 0x3b0ef4u;
    SET_GPR_U64(ctx, 6, (uint64_t)GPR_U64(ctx, 0) + (uint64_t)GPR_U64(ctx, 0));
label_3b0ef8:
    // 0x3b0ef8: 0x35080400  ori         $t0, $t0, 0x400
    ctx->pc = 0x3b0ef8u;
    SET_GPR_U64(ctx, 8, GPR_U64(ctx, 8) | (uint64_t)(uint16_t)1024);
label_3b0efc:
    // 0x3b0efc: 0x40f809  jalr        $v0
label_3b0f00:
    if (ctx->pc == 0x3B0F00u) {
        ctx->pc = 0x3B0F00u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0EFCu;
        // 0x3b0f00: 0x34a52000  ori         $a1, $a1, 0x2000 (Delay Slot)
        SET_GPR_U64(ctx, 5, GPR_U64(ctx, 5) | (uint64_t)(uint16_t)8192);
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0F04u;
        goto label_3b0f04;
    }
    ctx->pc = 0x3B0EFCu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 2);
        SET_GPR_U32(ctx, 31, 0x3B0F04u);
        ctx->pc = 0x3B0F00u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0EFCu;
        // 0x3b0f00: 0x34a52000  ori         $a1, $a1, 0x2000 (Delay Slot)
        SET_GPR_U64(ctx, 5, GPR_U64(ctx, 5) | (uint64_t)(uint16_t)8192);
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        if (!runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0EFCu, 0x3B0F04u, PS2Runtime::GuestBranchKind::IndirectCall, "JALR")) {
            return;
        }
    }
    ctx->pc = 0x3B0F04u;
label_3b0f04:
    // 0x3b0f04: 0x3c030fff  lui         $v1, 0xFFF
    ctx->pc = 0x3b0f04u;
    SET_GPR_S32(ctx, 3, (int32_t)((uint32_t)4095 << 16));
label_3b0f08:
    // 0x3b0f08: 0x3c043000  lui         $a0, 0x3000
    ctx->pc = 0x3b0f08u;
    SET_GPR_S32(ctx, 4, (int32_t)((uint32_t)12288 << 16));
label_3b0f0c:
    // 0x3b0f0c: 0x3463ffff  ori         $v1, $v1, 0xFFFF
    ctx->pc = 0x3b0f0cu;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 3) | (uint64_t)(uint16_t)65535);
label_3b0f10:
    // 0x3b0f10: 0xae420078  sw          $v0, 0x78($s2)
    ctx->pc = 0x3b0f10u;
    WRITE32(ADD32(GPR_U32(ctx, 18), 120), GPR_U32(ctx, 2));
label_3b0f14:
    // 0x3b0f14: 0x431824  and         $v1, $v0, $v1
    ctx->pc = 0x3b0f14u;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 2) & GPR_U64(ctx, 3));
label_3b0f18:
    // 0x3b0f18: 0x641825  or          $v1, $v1, $a0
    ctx->pc = 0x3b0f18u;
    SET_GPR_U64(ctx, 3, GPR_U64(ctx, 3) | GPR_U64(ctx, 4));
label_3b0f1c:
    // 0x3b0f1c: 0xc1009c2  jal         func_402708
label_3b0f20:
    if (ctx->pc == 0x3B0F20u) {
        ctx->pc = 0x3B0F20u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0F1Cu;
        // 0x3b0f20: 0xae43007c  sw          $v1, 0x7C($s2) (Delay Slot)
        WRITE32(ADD32(GPR_U32(ctx, 18), 124), GPR_U32(ctx, 3));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0F24u;
        goto label_3b0f24;
    }
    ctx->pc = 0x3B0F1Cu;
    SET_GPR_U32(ctx, 31, 0x3B0F24u);
    ctx->pc = 0x3B0F20u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0F1Cu;
    // 0x3b0f20: 0xae43007c  sw          $v1, 0x7C($s2) (Delay Slot)
    WRITE32(ADD32(GPR_U32(ctx, 18), 124), GPR_U32(ctx, 3));
    ctx->in_delay_slot = false;
    ctx->pc = 0x402708u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x402708u, 0x3B0F1Cu, 0x3B0F24u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0F24u;
label_3b0f24:
    // 0x3b0f24: 0x8e42000c  lw          $v0, 0xC($s2)
    ctx->pc = 0x3b0f24u;
    SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 12)));
label_3b0f28:
    // 0x3b0f28: 0x8e430008  lw          $v1, 0x8($s2)
    ctx->pc = 0x3b0f28u;
    SET_GPR_S32(ctx, 3, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 8)));
label_3b0f2c:
    // 0x3b0f2c: 0x8fa40000  lw          $a0, 0x0($sp)
    ctx->pc = 0x3b0f2cu;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 29), 0)));
label_3b0f30:
    // 0x3b0f30: 0x621818  mult        $v1, $v1, $v0
    ctx->pc = 0x3b0f30u;
    { int64_t result = (int64_t)GPR_S32(ctx, 3) * (int64_t)GPR_S32(ctx, 2); ctx->lo = (uint64_t)(int64_t)(int32_t)result; ctx->hi = (uint64_t)(int64_t)(int32_t)(result >> 32); SET_GPR_S32(ctx, 3, (int32_t)result); }
label_3b0f34:
    // 0x3b0f34: 0x8e45002c  lw          $a1, 0x2C($s2)
    ctx->pc = 0x3b0f34u;
    SET_GPR_S32(ctx, 5, (int32_t)READ32(ADD32(GPR_U32(ctx, 18), 44)));
label_3b0f38:
    // 0x3b0f38: 0x330c0  sll         $a2, $v1, 3
    ctx->pc = 0x3b0f38u;
    SET_GPR_S32(ctx, 6, (int32_t)SLL32(GPR_U32(ctx, 3), 3));
label_3b0f3c:
    // 0x3b0f3c: 0xc33021  addu        $a2, $a2, $v1
    ctx->pc = 0x3b0f3cu;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 3)));
label_3b0f40:
    // 0x3b0f40: 0x617c2  srl         $v0, $a2, 31
    ctx->pc = 0x3b0f40u;
    SET_GPR_S32(ctx, 2, (int32_t)SRL32(GPR_U32(ctx, 6), 31));
label_3b0f44:
    // 0x3b0f44: 0xc23021  addu        $a2, $a2, $v0
    ctx->pc = 0x3b0f44u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), GPR_U32(ctx, 2)));
label_3b0f48:
    // 0x3b0f48: 0x63043  sra         $a2, $a2, 1
    ctx->pc = 0x3b0f48u;
    SET_GPR_S32(ctx, 6, SRA32(GPR_S32(ctx, 6), 1));
label_3b0f4c:
    // 0x3b0f4c: 0xc1009ee  jal         func_4027B8
label_3b0f50:
    if (ctx->pc == 0x3B0F50u) {
        ctx->pc = 0x3B0F50u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0F4Cu;
        // 0x3b0f50: 0x24c6176c  addiu       $a2, $a2, 0x176C (Delay Slot)
        SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), 5996));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0F54u;
        goto label_3b0f54;
    }
    ctx->pc = 0x3B0F4Cu;
    SET_GPR_U32(ctx, 31, 0x3B0F54u);
    ctx->pc = 0x3B0F50u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0F4Cu;
    // 0x3b0f50: 0x24c6176c  addiu       $a2, $a2, 0x176C (Delay Slot)
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), 5996));
    ctx->in_delay_slot = false;
    ctx->pc = 0x4027B8u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x4027B8u, 0x3B0F4Cu, 0x3B0F54u, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0F54u;
label_3b0f54:
    // 0x3b0f54: 0x8fa40000  lw          $a0, 0x0($sp)
    ctx->pc = 0x3b0f54u;
    SET_GPR_S32(ctx, 4, (int32_t)READ32(ADD32(GPR_U32(ctx, 29), 0)));
label_3b0f58:
    // 0x3b0f58: 0x3c06003b  lui         $a2, 0x3B
    ctx->pc = 0x3b0f58u;
    SET_GPR_S32(ctx, 6, (int32_t)((uint32_t)59 << 16));
label_3b0f5c:
    // 0x3b0f5c: 0x240382d  daddu       $a3, $s2, $zero
    ctx->pc = 0x3b0f5cu;
    SET_GPR_U64(ctx, 7, (uint64_t)GPR_U64(ctx, 18) + (uint64_t)GPR_U64(ctx, 0));
label_3b0f60:
    // 0x3b0f60: 0x24c60b10  addiu       $a2, $a2, 0xB10
    ctx->pc = 0x3b0f60u;
    SET_GPR_S32(ctx, 6, (int32_t)ADD32(GPR_U32(ctx, 6), 2832));
label_3b0f64:
    // 0x3b0f64: 0xc100b02  jal         func_402C08
label_3b0f68:
    if (ctx->pc == 0x3B0F68u) {
        ctx->pc = 0x3B0F68u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0F64u;
        // 0x3b0f68: 0x24050001  addiu       $a1, $zero, 0x1 (Delay Slot)
        SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0F6Cu;
        goto label_3b0f6c;
    }
    ctx->pc = 0x3B0F64u;
    SET_GPR_U32(ctx, 31, 0x3B0F6Cu);
    ctx->pc = 0x3B0F68u;
    ctx->in_delay_slot = true;
    ctx->branch_pc = 0x3B0F64u;
    // 0x3b0f68: 0x24050001  addiu       $a1, $zero, 0x1 (Delay Slot)
    SET_GPR_S32(ctx, 5, (int32_t)ADD32(GPR_U32(ctx, 0), 1));
    ctx->in_delay_slot = false;
    ctx->pc = 0x402C08u;
    if (!runtime->dispatchGuestBranch(rdram, ctx, 0x402C08u, 0x3B0F64u, 0x3B0F6Cu, PS2Runtime::GuestBranchKind::DirectCall, "JAL")) {
        return;
    }
    ctx->pc = 0x3B0F6Cu;
label_3b0f6c:
    // 0x3b0f6c: 0x7bb000a0  lq          $s0, 0xA0($sp)
    ctx->pc = 0x3b0f6cu;
    SET_GPR_VEC(ctx, 16, READ128(ADD32(GPR_U32(ctx, 29), 160)));
label_3b0f70:
    // 0x3b0f70: 0x24020002  addiu       $v0, $zero, 0x2
    ctx->pc = 0x3b0f70u;
    SET_GPR_S32(ctx, 2, (int32_t)ADD32(GPR_U32(ctx, 0), 2));
label_3b0f74:
    // 0x3b0f74: 0x7bb10090  lq          $s1, 0x90($sp)
    ctx->pc = 0x3b0f74u;
    SET_GPR_VEC(ctx, 17, READ128(ADD32(GPR_U32(ctx, 29), 144)));
label_3b0f78:
    // 0x3b0f78: 0x7bb20080  lq          $s2, 0x80($sp)
    ctx->pc = 0x3b0f78u;
    SET_GPR_VEC(ctx, 18, READ128(ADD32(GPR_U32(ctx, 29), 128)));
label_3b0f7c:
    // 0x3b0f7c: 0x7bb30070  lq          $s3, 0x70($sp)
    ctx->pc = 0x3b0f7cu;
    SET_GPR_VEC(ctx, 19, READ128(ADD32(GPR_U32(ctx, 29), 112)));
label_3b0f80:
    // 0x3b0f80: 0x7bb40060  lq          $s4, 0x60($sp)
    ctx->pc = 0x3b0f80u;
    SET_GPR_VEC(ctx, 20, READ128(ADD32(GPR_U32(ctx, 29), 96)));
label_3b0f84:
    // 0x3b0f84: 0x7bb50050  lq          $s5, 0x50($sp)
    ctx->pc = 0x3b0f84u;
    SET_GPR_VEC(ctx, 21, READ128(ADD32(GPR_U32(ctx, 29), 80)));
label_3b0f88:
    // 0x3b0f88: 0x7bb60040  lq          $s6, 0x40($sp)
    ctx->pc = 0x3b0f88u;
    SET_GPR_VEC(ctx, 22, READ128(ADD32(GPR_U32(ctx, 29), 64)));
label_3b0f8c:
    // 0x3b0f8c: 0x7bb70030  lq          $s7, 0x30($sp)
    ctx->pc = 0x3b0f8cu;
    SET_GPR_VEC(ctx, 23, READ128(ADD32(GPR_U32(ctx, 29), 48)));
label_3b0f90:
    // 0x3b0f90: 0x7bbe0020  lq          $fp, 0x20($sp)
    ctx->pc = 0x3b0f90u;
    SET_GPR_VEC(ctx, 30, READ128(ADD32(GPR_U32(ctx, 29), 32)));
label_3b0f94:
    // 0x3b0f94: 0xdfbf0010  ld          $ra, 0x10($sp)
    ctx->pc = 0x3b0f94u;
    SET_GPR_U64(ctx, 31, READ64(ADD32(GPR_U32(ctx, 29), 16)));
label_3b0f98:
    // 0x3b0f98: 0x3e00008  jr          $ra
label_3b0f9c:
    if (ctx->pc == 0x3B0F9Cu) {
        ctx->pc = 0x3B0F9Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0F98u;
        // 0x3b0f9c: 0x27bd00b0  addiu       $sp, $sp, 0xB0 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 176));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0FA0u;
        goto label_3b0fa0;
    }
    ctx->pc = 0x3B0F98u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3B0F9Cu;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0F98u;
        // 0x3b0f9c: 0x27bd00b0  addiu       $sp, $sp, 0xB0 (Delay Slot)
        SET_GPR_S32(ctx, 29, (int32_t)ADD32(GPR_U32(ctx, 29), 176));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0F98u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3B0FA0u;
label_3b0fa0:
    // 0x3b0fa0: 0x3e00008  jr          $ra
label_3b0fa4:
    if (ctx->pc == 0x3B0FA4u) {
        ctx->pc = 0x3B0FA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0FA0u;
        // 0x3b0fa4: 0x8c820010  lw          $v0, 0x10($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 16)));
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0FA8u;
        goto label_3b0fa8;
    }
    ctx->pc = 0x3B0FA0u;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3B0FA4u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0FA0u;
        // 0x3b0fa4: 0x8c820010  lw          $v0, 0x10($a0) (Delay Slot)
        SET_GPR_S32(ctx, 2, (int32_t)READ32(ADD32(GPR_U32(ctx, 4), 16)));
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0FA0u, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3B0FA8u;
label_3b0fa8:
    // 0x3b0fa8: 0x3c020051  lui         $v0, 0x51
    ctx->pc = 0x3b0fa8u;
    SET_GPR_S32(ctx, 2, (int32_t)((uint32_t)81 << 16));
label_3b0fac:
    // 0x3b0fac: 0x3e00008  jr          $ra
label_3b0fb0:
    if (ctx->pc == 0x3B0FB0u) {
        ctx->pc = 0x3B0FB0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0FACu;
        // 0x3b0fb0: 0xc4409508  lwc1        $f0, -0x6AF8($v0) (Delay Slot)
        { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 2), 4294939912)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
        ctx->in_delay_slot = false;
        ctx->pc = 0x3B0FB4u;
        goto label_3b0fb4;
    }
    ctx->pc = 0x3B0FACu;
    {
        const uint32_t jumpTarget = GPR_U32(ctx, 31);
        ctx->pc = 0x3B0FB0u;
        ctx->in_delay_slot = true;
        ctx->branch_pc = 0x3B0FACu;
        // 0x3b0fb0: 0xc4409508  lwc1        $f0, -0x6AF8($v0) (Delay Slot)
        { uint32_t bits = READ32(ADD32(GPR_U32(ctx, 2), 4294939912)); float f; std::memcpy(&f, &bits, sizeof(f)); ctx->f[0] = f; }
        ctx->in_delay_slot = false;
        ctx->pc = jumpTarget;
        #if defined(PS2X_STRICT_RETURN_DIAGNOSTICS) && PS2X_STRICT_RETURN_DIAGNOSTICS
        (void)runtime->dispatchGuestBranch(rdram, ctx, jumpTarget, 0x3B0FACu, 0u, PS2Runtime::GuestBranchKind::Return, "JR $ra");
        return;
        #else
        ctx->pc = jumpTarget;
        return;
        #endif
    }
    ctx->pc = 0x3B0FB4u;
label_3b0fb4:
    // 0x3b0fb4: 0x0  nop
    ctx->pc = 0x3b0fb4u;
    // NOP
    ctx->pc = 0x3b0fb8u;
}
